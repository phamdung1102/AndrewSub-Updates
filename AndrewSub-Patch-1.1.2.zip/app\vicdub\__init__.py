"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.1.2"
APP_NAME = "AndrewSub"

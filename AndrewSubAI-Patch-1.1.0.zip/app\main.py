"""VICDub AI - Điểm khởi động ứng dụng.

Phần mềm desktop lồng tiếng video bằng AI:
Tách phụ đề -> Dịch -> Phân vai -> Sinh voice -> Đồng bộ video -> Ghép video.
"""

import os
import sys
from pathlib import Path

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QFont, QIcon

from vicdub.config import APP_ROOT, AppConfig
from vicdub.logging_setup import setup_logging


def _first_run_setup(config, logger) -> None:
    """Ghi log thành phần thiếu; người dùng chủ động cài trong tab Cập nhật.

    Bản đóng gói có Python riêng nên tuyệt đối không yêu cầu install_models.bat.
    App luôn mở ngay; tab Cập nhật sẽ cài tuần tự đúng các phần còn thiếu.
    """
    from vicdub.core import bootstrap

    need_setup = bootstrap.needs_setup(config)
    if need_setup:
        names = ", ".join(c.label for c in need_setup)
        logger.info("Thiếu thành phần tùy chọn: %s — cài trong tab Cập nhật.", names)

    # Không tải model ~3GB lúc mở app. Tab Cập nhật cài tuần tự khi người dùng cần.
    if bootstrap.needs_download(config):
        logger.info("Model giọng chưa có — sẽ tự tải khi sinh giọng lần đầu (lazy).")


def main() -> int:
    """Khởi tạo logging, cấu hình và cửa sổ chính."""
    config = AppConfig.load()

    # Model AI (OmniVoice) tải về ổ D cùng app thay vì cache mặc định trên C -
    # tránh đầy ổ C. Phải set TRƯỚC khi import model.
    hf_cache = Path(config.data_dir) / "hf_cache"
    hf_cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(hf_cache))

    logger = setup_logging(config.log_dir)
    logger.info("Khởi động VICDub AI (HF_HOME=%s)", os.environ.get("HF_HOME"))

    app = QApplication(sys.argv)
    app.setApplicationName("VICDub AI")
    app.setOrganizationName("VICDub")
    app.setFont(QFont("Segoe UI", 10))
    icon_path = APP_ROOT / "assets" / "icon.ico"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # 'App nhẹ, tải sau': lần đầu kiểm tra môi trường + tự tải model giọng.
    # Bọc try để lỗi bootstrap không bao giờ chặn app mở.
    try:
        _first_run_setup(config, logger)
    except Exception:  # noqa: BLE001
        logger.exception("Bootstrap lần đầu lỗi - bỏ qua, mở app bình thường")

    # Import muộn để QApplication tồn tại trước khi tạo widget.
    from vicdub.ui.main_window import MainWindow

    window = MainWindow(config)
    # Mở cố định ở trạng thái phóng to để toàn bộ bảng/panel luôn vừa khung,
    # người dùng không phải kéo và căn lại cửa sổ mỗi lần chạy.
    window.showMaximized()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())

"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.7.14"
APP_NAME = "AndrewSub"

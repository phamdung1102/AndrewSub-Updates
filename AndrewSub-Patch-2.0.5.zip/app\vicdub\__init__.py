﻿"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "2.0.5"
APP_NAME = "AndrewSub"


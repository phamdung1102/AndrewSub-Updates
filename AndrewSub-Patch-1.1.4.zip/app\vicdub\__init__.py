"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.1.4"
APP_NAME = "AndrewSub"

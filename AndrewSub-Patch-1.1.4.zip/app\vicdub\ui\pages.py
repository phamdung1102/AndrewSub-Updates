"""8 trang chức năng của panel giữa.

Mỗi trang chỉ gọi services qua MainWindow (app) - không gọi module trực tiếp.
"""

from __future__ import annotations

import os
import json
import re
import shutil
import tempfile
import time
import threading
from pathlib import Path
from typing import TYPE_CHECKING

import wave

from PyQt6.QtCore import QObject, QRect, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QProgressBar, QPushButton, QRadioButton, QScrollArea, QSlider, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
    QDialog, QDialogButtonBox, QFrame,
)

from vicdub.ui.timeline import (
    TimelineWidget, project_clip_path, project_voice_path, wav_seconds,
)

from vicdub.api.api_manager import DEFAULT_GEMINI_MODEL, ApiKey
from vicdub.modules.import_module import SUPPORTED_VIDEO_EXTS, ImportModule
from vicdub.modules.video_module import VideoModule
from vicdub.modules.voice_module import VoiceModule, create_engine
from vicdub.ui.widgets import (
    CollapsibleBox, SubtitleTable, muted_label, title_label,
)
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.series_merge import sort_paths_natural, split_by_episodes, sub_overrun
from vicdub.utils.subtitles import (
    Segment, clean_subtitle_text, load_subtitle_file, match_translations, write_srt,
)

if TYPE_CHECKING:
    from vicdub.ui.main_window import MainWindow

VIDEO_FILTER = "Video (" + " ".join(f"*{e}" for e in SUPPORTED_VIDEO_EXTS) + ")"
SUBTITLE_FILTER = "Phụ đề (*.srt *.ass *.vtt)"
AUDIO_FILTER = "Audio/Video (*.wav *.mp3 *.mp4 *.m4a *.aac *.flac *.ogg *.wma *.mkv *.mov)"
AUDIO_EXTS = {
    ".wav", ".mp3", ".mp4", ".m4a", ".aac", ".flac", ".ogg", ".wma", ".mkv", ".mov",
}


def preview_wav_path(data_dir: str, prefix: str, voice: str = "") -> str:
    """Tạo file preview riêng để QSoundEffect không phát lại cache file cũ."""
    safe_voice = re.sub(r"[^A-Za-z0-9_.-]+", "_", voice or "voice").strip("_")
    folder = Path(data_dir) / "previews"
    folder.mkdir(parents=True, exist_ok=True)
    return str(folder / f"{prefix}_{safe_voice}_{int(time.time() * 1000)}.wav")


class _DriveSelfTestBridge(QObject):
    """Cầu nối thread-safe: worker phát tín hiệu, slot chạy ở main thread.

    QTimer.singleShot gọi TỪ thread nền không kích hoạt (thread không có event
    loop) nên phải dùng signal của QObject tạo ở main thread để marshal về.
    """
    progress = pyqtSignal(str)
    done = pyqtSignal(str)


def run_drive_ocr_selftest(page, config, on_done=None) -> None:
    """Chạy Test Drive OCR trong thread nền, hiện tiến trình + kết quả an toàn.

    Dùng chung cho nút Test Drive OCR ở nhiều trang (Cài đặt, Subtitle Studio).
    """
    def finish() -> None:
        if on_done:
            on_done()

    creds = config.resolve_drive_credentials()
    accounts = config.enabled_drive_accounts()
    if not creds and not any(a.get("credentials_path") for a in accounts):
        page.warn("Chưa có file kết nối. Vào tab Cài đặt và kết nối tài khoản xử lý trước.")
        finish()
        return
    if not accounts:
        page.warn("Chưa đăng nhập tài khoản xử lý. Vào tab Cài đặt để kết nối trước.")
        finish()
        return

    # Bridge tạo Ở MAIN THREAD; giữ ref trên page để không bị GC trước khi phát.
    bridge = _DriveSelfTestBridge()
    page._drive_selftest_bridge = bridge

    def on_done_msg(msg: str) -> None:
        page.app.show_status(msg.split(chr(10))[0])
        (page.info if msg.startswith("✅") else page.warn)(msg)
        page.refresh()
        finish()

    bridge.progress.connect(page.app.show_status)
    bridge.done.connect(on_done_msg)
    page.app.show_status("Kiểm tra nhận diện: chuẩn bị ảnh mẫu...")

    def worker() -> None:
        try:
            from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
                DriveOcrClient, self_test,
            )
            from concurrent.futures import ThreadPoolExecutor, as_completed  # noqa: PLC0415

            def test_one(index_account):
                index, account = index_account
                try:
                    identity = DriveOcrClient(
                        account.get("credentials_path") or creds,
                        account["token_path"], account.get("folder_id", ""),
                    )
                    try:
                        email = identity.account_email()
                    finally:
                        identity.close()
                    good, total, _res = self_test(
                        account.get("credentials_path") or creds,
                        account["token_path"], account.get("folder_id", ""),
                        report=lambda m, n=index: bridge.progress.emit(
                            f"Kiểm tra tài khoản {n + 1}: {BasePage._public_message(m)}"
                        ),
                    )
                    return index, good == total, email, f"đọc đúng {good}/{total} mẫu"
                except Exception as exc:  # noqa: BLE001
                    return index, False, str(account.get("email", "")), BasePage._public_message(str(exc))

            statuses = []
            with ThreadPoolExecutor(max_workers=len(accounts)) as executor:
                futures = [executor.submit(test_one, pair) for pair in enumerate(accounts)]
                for future in as_completed(futures):
                    statuses.append(future.result())
            statuses.sort()
            ok_count = sum(1 for _index, ok, _email, _detail in statuses if ok)
            lines = [
                f"Tài khoản {index + 1} ({email or 'chưa rõ email'}): "
                f"{'OK' if ok else 'LỖI'} — {detail}"
                for index, ok, email, detail in statuses
            ]
            # Test thành công cũng là dịp cập nhật email cũ/chưa có trong cấu hình.
            by_token = {
                str(account.get("token_path", "")): account
                for account in (config.drive_ocr_accounts or [])
            }
            for index, _ok, email, _detail in statuses:
                token = accounts[index]["token_path"]
                if token in by_token and email:
                    by_token[token]["email"] = email
            config.save()
            icon = "✅" if ok_count == len(statuses) else "⚠"
            msg = (
                f"{icon} Nhận diện phụ đề: {ok_count}/{len(statuses)} tài khoản hoạt động.\n"
                + "\n".join(lines)
            )
        except Exception as exc:  # noqa: BLE001
            msg = f"❌ Kiểm tra nhận diện lỗi: {BasePage._public_message(str(exc))}"
        bridge.done.emit(msg)

    threading.Thread(target=worker, daemon=True).start()


class BasePage(QWidget):
    """Trang cơ sở: giữ tham chiếu app và layout dọc."""

    def __init__(self, app: "MainWindow", heading: str, hint: str) -> None:
        super().__init__()
        self.app = app
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(16, 16, 16, 16)
        self.body.setSpacing(10)
        self.body.addWidget(title_label(heading))
        self.body.addWidget(muted_label(hint))

    def refresh(self) -> None:
        """Gọi khi mở trang hoặc dữ liệu project thay đổi."""

    # ---------- Tiện ích ----------

    @staticmethod
    def _public_message(message: str) -> str:
        """Ẩn tên nhà cung cấp và thuật ngữ triển khai khỏi thông báo UI."""
        text = re.sub(r"Gemini(?:\s+Web)?", "dịch vụ trực tuyến", str(message),
                      flags=re.IGNORECASE)
        replacements = (
            (r"Google\s+Drive|Drive\s+OCR|Google", "tài khoản trực tuyến"),
            (r"Cloud\s+Vision|Vision\s+OCR|Vision\s+API|Vision", "bộ tăng tốc"),
            (r"VideoSubFinder|VSF", "bộ nhận diện"),
            (r"Gemini", "dịch vụ trực tuyến"),
            (r"credentials\.json|credential[s]?", "file kết nối"),
            (r"token\.json|token", "phiên đăng nhập"),
            (r"API\s*key|API", "khóa truy cập"),
            (r"montage|panel", "ảnh mẫu"),
            (r"Chrome|Playwright|browser|profile", "trình duyệt"),
            (r"FFmpeg|ffprobe", "thành phần xử lý video"),
        )
        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    def warn(self, message: str) -> None:
        QMessageBox.warning(self, "AndrewSub", self._public_message(message))

    def info(self, message: str) -> None:
        QMessageBox.information(self, "AndrewSub", self._public_message(message))

    def confirm(self, message: str) -> bool:
        """Hỏi Yes/No, trả True nếu người dùng chọn Yes."""
        return QMessageBox.question(
            self, "AndrewSub", self._public_message(message)
        ) == QMessageBox.StandardButton.Yes

    def need_project(self) -> bool:
        """True nếu CHƯA có project (kèm cảnh báo)."""
        if self.app.projects.current is None:
            self.warn("Vui lòng tạo hoặc mở một dự án.")
            return True
        return False


def choose_project_ocr_region(page: BasePage, project, config) -> bool:
    """Choose and persist an OCR rectangle for one project/video."""
    if not project or not project.video_path or not Path(project.video_path).exists():
        page.warn("Dự án chưa có video hợp lệ để chọn vùng phụ đề.")
        return False
    frame_png = str(Path(project.root) / "ocr_region_preview.png")
    try:
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        duration = max(1.0, ffmpeg.duration(project.video_path))
        ffmpeg.extract_frame(project.video_path, min(60.0, duration / 2), frame_png)
    except FFmpegError as exc:
        page.warn(f"Không trích được khung hình: {exc}")
        return False

    fracs = [0.25, 0.7, 0.4, 0.85, 0.1, 0.6, 0.5]
    state = {"i": 0}

    def next_frame() -> str | None:
        frac = fracs[state["i"] % len(fracs)]
        state["i"] += 1
        at = min(max(1.0, duration * frac), max(1.0, duration - 0.5))
        try:
            ffmpeg.extract_frame(project.video_path, at, frame_png)
        except FFmpegError:
            return None
        return frame_png

    from vicdub.ui.region_dialog import OcrRegionDialog  # noqa: PLC0415
    from vicdub.utils.video_frames import DEFAULT_REGION  # noqa: PLC0415

    region = tuple(project.get_ocr_region(
        getattr(config, "ocr_region", None) or DEFAULT_REGION
    ))
    dialog = OcrRegionDialog(frame_png, region, page, frame_provider=next_frame)
    if not dialog.exec():
        return False
    selected = list(dialog.selected_region())
    project.set_ocr_region(selected)
    # Giữ làm mặc định hợp lý cho project tạo sau, nhưng project hiện tại luôn
    # đọc metadata riêng và không bị project khác ghi đè.
    config.ocr_region = selected
    config.save()
    return True


# ====================================================================
class ProjectPage(BasePage):
    """Dự án & Video gộp một tab: project bên trái, video nguồn bên phải."""

    thumbnail_ready = pyqtSignal(str, str)  # video_path, png_path

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Dự án", "Quản lý dự án và video nguồn.")
        self._thumb_video_path = ""
        self._thumb_busy = False
        self._thumb_pending = ""
        self.thumbnail_ready.connect(self._on_thumbnail_ready)

        columns = QHBoxLayout()
        self.body.addLayout(columns, 1)

        # ================= Cột trái: project =================
        left_card = QFrame()
        left_card.setObjectName("projectWorkspaceCard")
        left = QVBoxLayout(left_card)
        left.setContentsMargins(14, 14, 14, 14)
        left.setSpacing(9)
        columns.addWidget(left_card, 4)

        row = QHBoxLayout()
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Tên dự án")
        btn_create = QPushButton("Tạo dự án")
        btn_create.setProperty("variant", "primary")
        btn_create.clicked.connect(self._create)
        row.addWidget(self.name_input)
        row.addWidget(btn_create)
        left.addLayout(row)

        # Thư mục lưu project (đổi được).
        dir_row = QHBoxLayout()
        self.projects_dir_label = muted_label("")
        btn_change_dir = QPushButton("Đổi thư mục lưu...")
        btn_change_dir.setToolTip("Chọn thư mục chứa toàn bộ project")
        btn_change_dir.clicked.connect(self._change_projects_dir)
        dir_row.addWidget(self.projects_dir_label, 1)
        dir_row.addWidget(btn_change_dir)
        left.addLayout(dir_row)

        left.addWidget(title_label("Danh sách dự án"))
        self.project_list = QListWidget()
        self.project_list.itemDoubleClicked.connect(lambda _: self._open())
        left.addWidget(self.project_list, 1)

        select_row = QHBoxLayout()
        btn_select_all = QPushButton("Chọn tất cả")
        btn_select_all.clicked.connect(lambda: self._set_all_projects_checked(True))
        btn_select_none = QPushButton("Bỏ chọn")
        btn_select_none.clicked.connect(lambda: self._set_all_projects_checked(False))
        select_row.addWidget(btn_select_all)
        select_row.addWidget(btn_select_none)
        left.addLayout(select_row)

        self.btn_run_batch = QPushButton("Chạy trọn quy trình các dự án đã chọn")
        self.btn_run_batch.setProperty("variant", "primary")
        self.btn_run_batch.setMinimumHeight(42)
        self.btn_run_batch.setToolTip(
            "Chạy tuần tự: tách phụ đề → dịch → tạo giọng → ghép video."
        )
        self.btn_run_batch.clicked.connect(self._run_selected_projects)
        left.addWidget(self.btn_run_batch)
        self.btn_export_batch = QPushButton("Xuất video các dự án đã chọn")
        self.btn_export_batch.setMinimumHeight(38)
        self.btn_export_batch.setToolTip(
            "Dùng phụ đề và voice đã có trong từng dự án, rồi xuất video hàng loạt."
        )
        self.btn_export_batch.clicked.connect(self._export_selected_projects)
        left.addWidget(self.btn_export_batch)
        self.batch_status_label = muted_label("Chưa có hàng đợi dự án.")
        left.addWidget(self.batch_status_label)

        open_row = QHBoxLayout()
        btn_open = QPushButton("Mở dự án")
        btn_open.clicked.connect(self._open)
        btn_delete_proj = QPushButton("Xóa dự án")
        btn_delete_proj.setProperty("variant", "danger")
        btn_delete_proj.setToolTip("Xóa hẳn project đã chọn khỏi ổ đĩa")
        btn_delete_proj.clicked.connect(self._delete_project)
        open_row.addWidget(btn_open)
        open_row.addWidget(btn_delete_proj)
        left.addLayout(open_row)

        left.addWidget(title_label("Lịch sử"))
        self.history_list = QListWidget()
        self.history_list.setMaximumHeight(150)
        left.addWidget(self.history_list)

        # ================= Cột phải: video nguồn =================
        right_card = QFrame()
        right_card.setObjectName("projectWorkspaceCard")
        right = QVBoxLayout(right_card)
        right.setContentsMargins(14, 14, 14, 14)
        right.setSpacing(8)
        columns.addWidget(right_card, 6)

        vrow = QHBoxLayout()
        btn_pick = QPushButton("Chọn video...")
        btn_pick.setProperty("variant", "primary")
        btn_pick.clicked.connect(self._pick_video)
        btn_batch = QPushButton("Chọn thư mục...")
        btn_batch.clicked.connect(self._pick_folder)
        btn_region = QPushButton("Khoanh vùng phụ đề")
        btn_region.setToolTip("Lưu vùng phụ đề riêng cho video của project hiện tại")
        btn_region.clicked.connect(self._choose_ocr_region)
        btn_clear_video = QPushButton("Xóa video")
        btn_clear_video.setProperty("variant", "danger")
        btn_clear_video.setToolTip("Bỏ video nguồn khỏi project (không xóa file gốc)")
        btn_clear_video.clicked.connect(self._clear_video)
        vrow.addWidget(btn_pick)
        vrow.addWidget(btn_batch)
        vrow.addWidget(btn_region)
        vrow.addWidget(btn_clear_video)
        vrow.addStretch()
        right.addLayout(vrow)

        self.video_label = muted_label("Chưa chọn video.")
        right.addWidget(self.video_label)
        self.input_quality_label = muted_label("Nguồn: —")
        self.output_quality_label = muted_label("Kết quả: —")
        self.region_label = muted_label("Vùng phụ đề: chưa chọn riêng")
        right.addWidget(self.input_quality_label)
        right.addWidget(self.output_quality_label)
        right.addWidget(self.region_label)

        self.preview = QLabel("(preview khung hình)")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(240)
        self.preview.setStyleSheet(
            "background-color: #0f1724; border: 1px solid #223044; border-radius: 6px;"
        )
        right.addWidget(self.preview, 1)

        right.addWidget(muted_label("Video trong thư mục"))
        self.batch_list = QListWidget()
        self.batch_list.setMaximumHeight(130)
        self.batch_list.itemDoubleClicked.connect(
            lambda item: self._set_video(item.text())
        )
        right.addWidget(self.batch_list, 1)

    def refresh(self) -> None:
        self.projects_dir_label.setText(f"Lưu tại: {self.app.config.projects_dir}")
        checked = {
            self._project_name(self.project_list.item(index))
            for index in range(self.project_list.count())
            if self.project_list.item(index).checkState() == Qt.CheckState.Checked
        }
        self.project_list.clear()
        current_name = self.app.projects.current.name if self.app.projects.current else ""
        for name in self.app.projects.list_projects():
            label = f"{name}   • đang mở" if name == current_name else name
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, name)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Checked if name in checked else Qt.CheckState.Unchecked
            )
            self.project_list.addItem(item)
            if name == current_name:
                self.project_list.setCurrentItem(item)
        self.history_list.clear()
        project = self.app.projects.current
        if project:
            for h in project.load_history(50):
                self.history_list.addItem(
                    f'{h["ts"]}  [{h["status"]}]  {h["step"]}  {h["detail"]}'
                )
        if project and project.video_path:
            self.video_label.setText(f"Video: {project.video_path}")
            self._update_quality_labels(project)
            self._show_thumbnail(project.video_path)
            self.region_label.setText(
                "Vùng phụ đề: đã lưu riêng cho dự án"
                if project.has_ocr_region else
                "Vùng phụ đề: đang dùng mặc định — nên khoanh trước khi chạy"
            )
        elif project:
            self.video_label.setText("Chưa chọn video.")
            self.input_quality_label.setText("Nguồn: —")
            self.output_quality_label.setText("Kết quả: —")
            self.region_label.setText("Vùng phụ đề: chưa có video")
        else:
            self.video_label.setText("Chưa mở dự án.")
            self.input_quality_label.setText("Nguồn: —")
            self.output_quality_label.setText("Kết quả: —")
            self.region_label.setText("Vùng phụ đề: chưa mở dự án")
        self.btn_run_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )
        self.btn_export_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )

    # ---------- Project ----------

    @staticmethod
    def _project_name(item: QListWidgetItem | None) -> str:
        if item is None:
            return ""
        return str(item.data(Qt.ItemDataRole.UserRole) or item.text()).strip()

    def _set_all_projects_checked(self, checked: bool) -> None:
        state = Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked
        for index in range(self.project_list.count()):
            self.project_list.item(index).setCheckState(state)

    def _selected_project_names(self) -> list[str]:
        return [
            self._project_name(self.project_list.item(index))
            for index in range(self.project_list.count())
            if self.project_list.item(index).checkState() == Qt.CheckState.Checked
        ]

    def _run_selected_projects(self) -> None:
        names = self._selected_project_names()
        if not names:
            self.warn("Hãy đánh dấu ít nhất một dự án trong danh sách.")
            return
        if not self.confirm(
            f"Chạy trọn quy trình cho {len(names)} dự án theo thứ tự danh sách?"
        ):
            return
        self.app.start_project_batch(names)

    def _export_selected_projects(self) -> None:
        names = self._selected_project_names()
        if not names:
            self.warn("Hãy đánh dấu ít nhất một dự án trong danh sách.")
            return
        if not self.confirm(
            f"Xuất video cho {len(names)} dự án đã chọn? "
            "Tool sẽ dùng phụ đề và voice đã có trong từng dự án."
        ):
            return
        self.app.start_export_batch(names)

    def set_batch_status(self, message: str) -> None:
        self.batch_status_label.setText(message)
        self.btn_run_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )
        self.btn_export_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )

    def _create(self) -> None:
        name = self.name_input.text().strip()
        if not name:
            self.warn("Vui lòng nhập tên dự án.")
            return
        try:
            self.app.projects.create(name)
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.name_input.clear()
        self.app.on_project_changed()

    def _open(self) -> None:
        item = self.project_list.currentItem()
        if item is None:
            self.warn("Vui lòng chọn một dự án.")
            return
        try:
            self.app.projects.open(self._project_name(item))
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.app.on_project_changed()

    def _delete_project(self) -> None:
        item = self.project_list.currentItem()
        if item is None:
            self.warn("Vui lòng chọn dự án cần xóa.")
            return
        name = self._project_name(item)
        if not self.confirm(
            f"Xóa dự án '{name}'? Thao tác này không thể hoàn tác."
        ):
            return
        try:
            self.app.projects.delete(name)
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.app.on_project_changed()
        self.app.show_status(f"Đã xóa project '{name}'.")

    def _change_projects_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu project", self.app.config.projects_dir
        )
        if not folder:
            return
        self.app.config.projects_dir = folder
        self.app.config.save()
        self.app.projects.set_projects_dir(folder)
        self.app.on_project_changed()
        self.app.show_status(f"Đã đổi thư mục lưu project: {folder}")

    # ---------- Video nguồn ----------

    def _choose_ocr_region(self) -> None:
        project = self.app.projects.current
        if choose_project_ocr_region(self, project, self.app.config):
            self.region_label.setText("Vùng phụ đề: đã lưu riêng cho dự án")
            self.app.show_status(f"Đã lưu vùng phụ đề cho dự án {project.name}.")

    def _pick_video(self) -> None:
        if self.need_project():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Chọn video", "", VIDEO_FILTER)
        if path:
            self._set_video(path)

    def _pick_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục video")
        if not folder:
            return
        try:
            videos = ImportModule.scan_folder(folder)
        except Exception as exc:  # noqa: BLE001
            self.warn(str(exc))
            return
        self.batch_list.clear()
        self.batch_list.addItems(videos)
        if not videos:
            self.info("Thư mục không có video nào được hỗ trợ.")

    def _set_video(self, path: str) -> None:
        if self.need_project():
            return
        project = self.app.projects.current
        if project.video_path != path:
            # Vùng của video cũ không được tái dùng âm thầm cho video mới.
            project.set_meta("ocr_region", "")
        project.set_meta("video_path", path)
        self.video_label.setText(f"Video: {path}")
        self._update_quality_labels(project)
        self._show_thumbnail(path)
        self.region_label.setText("Vùng phụ đề: chưa chọn cho video này")
        self.app.update_right_panel()

    def _clear_video(self) -> None:
        if self.need_project():
            return
        project = self.app.projects.current
        if not project.video_path:
            return
        if not self.confirm("Bỏ video nguồn khỏi project này? (không xóa file gốc)"):
            return
        project.set_meta("video_path", "")
        project.set_meta("ocr_region", "")
        self._thumb_video_path = ""
        self.video_label.setText("Chưa chọn video.")
        self.input_quality_label.setText("Input: —")
        self.output_quality_label.setText("Output: —")
        self.preview.clear()
        self.preview.setText("(preview khung hình)")
        self.region_label.setText("Vùng phụ đề: chưa có video")
        self.app.update_right_panel()
        self.app.show_status("Đã bỏ video nguồn khỏi project.")

    def _update_quality_labels(self, project) -> None:
        """Hiển thị nhanh chất lượng video đầu vào và output nếu đã có."""
        config = self.app.config
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        if project.video_path and Path(project.video_path).exists():
            try:
                self.input_quality_label.setText(
                    "Nguồn: " + ffmpeg.video_summary(project.video_path)
                )
            except FFmpegError as exc:
                self.input_quality_label.setText(f"Nguồn: không đọc được ({exc})")
        else:
            self.input_quality_label.setText("Nguồn: —")

        final = Path(project.root) / "output" / "Final.mp4"
        export_dir = getattr(config, "export_dir", "")
        exported = Path(export_dir) / f"{project.name}.mp4" if export_dir else None
        output = exported if exported and exported.exists() else final
        if output.exists():
            try:
                self.output_quality_label.setText(
                    "Kết quả: " + ffmpeg.video_summary(str(output))
                )
            except FFmpegError as exc:
                self.output_quality_label.setText(f"Kết quả: không đọc được ({exc})")
        else:
            self.output_quality_label.setText("Kết quả: chưa có")

    def _show_thumbnail(self, video_path: str) -> None:
        project = self.app.projects.current
        if not project or not Path(video_path).exists():
            return
        thumb = Path(project.root) / "preview.png"
        if self._thumb_video_path == video_path and thumb.exists():
            pixmap = QPixmap(str(thumb))
            if not pixmap.isNull():
                self.preview.setPixmap(pixmap.scaledToHeight(
                    240, Qt.TransformationMode.SmoothTransformation
                ))
            return
        if self._thumb_busy:
            self._thumb_pending = video_path
            return
        self._thumb_busy = True
        self.preview.setText("Đang tạo preview...")
        config = self.app.config

        def work() -> None:
            try:
                ffmpeg = FFmpeg(
                    config.ffmpeg_path, config.ffprobe_path,
                    timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
                )
                ffmpeg.extract_frame(video_path, 1.0, str(thumb))
                self.thumbnail_ready.emit(video_path, str(thumb))
            except FFmpegError as exc:
                self.thumbnail_ready.emit(video_path, f"ERROR:{exc}")

        threading.Thread(target=work, daemon=True).start()

    def _on_thumbnail_ready(self, video_path: str, result: str) -> None:
        self._thumb_busy = False
        pending = self._thumb_pending
        self._thumb_pending = ""
        project = self.app.projects.current
        if not project or project.video_path != video_path:
            if pending:
                self._show_thumbnail(pending)
            return
        if result.startswith("ERROR:"):
            self.preview.setText(f"Không tạo được preview: {result[6:]}")
            return
        self._thumb_video_path = video_path
        try:
            pixmap = QPixmap(result)
            if pixmap.isNull():
                self.preview.setText("Không tạo được preview.")
            else:
                self.preview.setPixmap(pixmap.scaledToHeight(
                    240, Qt.TransformationMode.SmoothTransformation
                ))
        except OSError as exc:
            self.preview.setText(f"Không tạo được preview: {exc}")
        if pending and pending != video_path:
            self._show_thumbnail(pending)


# ====================================================================
class SubtitlePage(BasePage):
    """Subtitle Studio: chỉnh mọi thứ trên bảng, thao tác dòng, upload bản
    dịch, so sánh clip/voice từng dòng, đồng bộ và xem thử kèm sub chữ."""

    #: Phát từ worker thread khi một tác vụ studio xong (thread-safe).
    studio_done = pyqtSignal(str)
    studio_progress = pyqtSignal(str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Phụ đề", "Biên tập nội dung, bản dịch và giọng đọc.")
        self.studio_done.connect(self._on_studio_done)
        self.studio_progress.connect(self.app.show_status)
        self._studio_cancel = threading.Event()
        self._studio_threads: set[threading.Thread] = set()
        self._studio_threads_lock = threading.Lock()
        self._cached_segments: list = []
        self._voices: list[str] = ["auto"]

        # ----- Toolbar Studio: nguồn sub / dịch / xuất / sửa dòng -----
        toolbar = QFrame()
        toolbar.setObjectName("studioToolbar")
        toolbar_layout = QVBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(10, 8, 10, 8)
        toolbar_layout.setSpacing(8)

        row_source = QHBoxLayout()
        row_source.setSpacing(8)
        row_source.addWidget(muted_label("Phụ đề"))
        btn_web_ocr = QPushButton("Nhận diện từ video")
        btn_web_ocr.setToolTip("Nhận diện phụ đề hiển thị trong video.")
        btn_web_ocr.setProperty("variant", "primary")
        btn_web_ocr.clicked.connect(self._run_gemini_web)
        btn_import = QPushButton("Nhập SRT gốc")
        btn_import.setToolTip("Nhập file phụ đề gốc: SRT, ASS hoặc VTT.")
        btn_import.clicked.connect(self._import_subtitle)
        btn_import_voice_top = QPushButton("Nhập voice")
        btn_import_voice_top.setToolTip("Nhập thư mục file voice/audio, khớp theo số thứ tự dòng phụ đề.")
        btn_import_voice_top.clicked.connect(self._import_voice_folder)
        for b in (btn_web_ocr, btn_import, btn_import_voice_top):
            row_source.addWidget(b)
        row_source.addSpacing(14)
        btn_translate = QPushButton("Dịch tự động")
        btn_translate.setProperty("variant", "primary")
        btn_translate.clicked.connect(self._translate_ai)
        btn_upload_trans = QPushButton("Nhập bản dịch")
        btn_upload_trans.clicked.connect(self._upload_translation)
        row_source.addWidget(btn_translate)
        row_source.addWidget(btn_upload_trans)
        btn_repair_ocr = QPushButton("Sửa dòng nhận diện lỗi")
        btn_repair_ocr.setToolTip(
            "Chỉ trích lại frame tại timestamp của các dòng lỗi; không quét lại video."
        )
        btn_repair_ocr.clicked.connect(self._repair_all_ocr_errors)
        row_source.addWidget(btn_repair_ocr)
        row_source.addSpacing(14)
        row_source.addWidget(muted_label("Tệp phụ đề"))
        btn_export_org = QPushButton("Lưu SRT gốc")
        btn_export_org.clicked.connect(lambda: self._export_srt(False))
        btn_export_trans = QPushButton("Lưu SRT bản dịch")
        btn_export_trans.clicked.connect(lambda: self._export_srt(True))
        for b in (btn_export_org, btn_export_trans):
            row_source.addWidget(b)
        row_source.addStretch()
        toolbar_layout.addLayout(row_source)

        row_edit = QHBoxLayout()
        row_edit.setSpacing(8)
        row_edit.addWidget(muted_label("Sửa dòng"))
        btn_add = QPushButton("+ Dòng")
        btn_add.clicked.connect(self._add_row)
        btn_delete = QPushButton("Xóa dòng")
        btn_delete.setProperty("variant", "danger")
        btn_delete.clicked.connect(self._delete_row)
        btn_merge = QPushButton("Gộp xuống")
        btn_merge.clicked.connect(self._merge_down)
        btn_split = QPushButton("Tách dòng")
        btn_split.clicked.connect(self._split_row)
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Tìm trong sub...")
        self.filter_input.textChanged.connect(self._apply_filter)
        for b in (btn_add, btn_delete, btn_merge, btn_split):
            row_edit.addWidget(b)
        row_edit.addWidget(self.filter_input, 1)
        toolbar_layout.addLayout(row_edit)
        self.body.addWidget(toolbar)

        # ----- Khung làm việc: bảng trái + panel voice phải -----
        work = QHBoxLayout()
        work.setSpacing(10)
        left = QVBoxLayout()
        left.setSpacing(8)
        work.addLayout(left, 1)

        self.table = SubtitleTable()
        self.table.setColumnHidden(3, True)
        self.table.segment_edited.connect(self._save_segment)
        self.table.play_requested.connect(self._play_line)
        self.table.currentCellChanged.connect(
            lambda *_: self._sync_voice_combo()
        )
        left.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.count_label = muted_label("")
        bottom.addWidget(self.count_label, 1)
        btn_preview = QPushButton("Xem thử dòng")
        btn_preview.clicked.connect(self._preview_line)
        btn_sync_line = QPushButton("Đồng bộ dòng")
        btn_sync_line.clicked.connect(self._sync_line)
        btn_sync_all = QPushButton("Đồng bộ tất cả")
        btn_sync_all.clicked.connect(self._sync_all)
        btn_play_all = QPushButton("Nghe tất cả")
        btn_play_all.clicked.connect(self._play_all_voices)
        for b in (btn_preview, btn_sync_line, btn_sync_all, btn_play_all):
            bottom.addWidget(b)
        left.addLayout(bottom)

        side = QFrame()
        side.setObjectName("voicePanel")
        side.setFixedWidth(260)
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(12, 12, 12, 12)
        side_layout.setSpacing(8)
        side_layout.addWidget(title_label("Giọng đọc"))
        self._line_voice_guard = False
        btn_render_line = QPushButton("Tạo giọng cho dòng")
        btn_render_line.setProperty("variant", "primary")
        btn_render_line.clicked.connect(self._generate_voice_line)
        btn_render_all = QPushButton("Tạo toàn bộ giọng đọc")
        btn_render_all.setProperty("variant", "primary")
        btn_render_all.clicked.connect(self._generate_voice_all)
        btn_import_voice = QPushButton("Nhập voice từ thư mục")
        btn_import_voice.clicked.connect(self._import_voice_folder)
        btn_line_voice = QPushButton("Áp dụng cho dòng này")
        btn_line_voice.clicked.connect(self._save_line_voice)
        btn_pick_voice_file = QPushButton("Chọn file voice cho dòng...")
        btn_pick_voice_file.setToolTip(
            "Dùng file audio của mày cho đúng dòng này (thay TTS). File được "
            "convert về WAV và KHOÁ lại — Sinh giọng sẽ không đè lên."
        )
        btn_pick_voice_file.clicked.connect(self._pick_line_voice_file)
        btn_lock_voice = QPushButton("Khoá voice dòng này")
        btn_lock_voice.setToolTip(
            "Khoá voice HIỆN TẠI của dòng (kể cả voice TTS vừa sinh mà mày ưng) — "
            "'Sinh giọng' chạy lại sẽ giữ nguyên, không sinh đè."
        )
        btn_lock_voice.clicked.connect(self._lock_line_voice)
        btn_unpick_voice_file = QPushButton("Mở khoá voice dòng")
        btn_unpick_voice_file.setToolTip(
            "Bỏ khoá voice của dòng đang chọn để TTS được sinh lại."
        )
        btn_unpick_voice_file.clicked.connect(self._remove_line_custom_voice)
        side_layout.addWidget(muted_label("Giọng dùng cho toàn bộ phụ đề"))
        self.all_voice_combo = QComboBox()
        self._setup_voice_combo(self.all_voice_combo)
        self.all_voice_combo.setToolTip(
            "Giọng này được dùng nguyên preset khi tạo một dòng hoặc toàn bộ; "
            "ứng dụng không tự đổi tone theo nhân vật."
        )
        side_layout.addWidget(self.all_voice_combo)
        btn_hear_voice = QPushButton("Nghe giọng này")
        btn_hear_voice.clicked.connect(self._hear_selected_voice)
        side_layout.addWidget(btn_hear_voice)
        btn_apply_all = QPushButton("Áp dụng cho tất cả")
        btn_apply_all.clicked.connect(self._apply_voice_all_lines)
        for b in (btn_render_line, btn_render_all, btn_import_voice, btn_line_voice,
                  btn_apply_all, btn_pick_voice_file, btn_lock_voice,
                  btn_unpick_voice_file):
            side_layout.addWidget(b)

        side_layout.addSpacing(6)
        side_layout.addWidget(muted_label("Sửa nhận diện theo thời gian"))
        btn_auto_repair_line = QPushButton("Quét lại dòng lỗi")
        btn_auto_repair_line.clicked.connect(self._repair_selected_ocr_error)
        btn_manual_capture = QPushButton("Kéo thời gian và chụp lại")
        btn_manual_capture.clicked.connect(self._manual_ocr_capture)
        side_layout.addWidget(btn_auto_repair_line)
        side_layout.addWidget(btn_manual_capture)

        side_layout.addWidget(muted_label("Dòng đang chọn"))
        self.preview_time_label = muted_label("—")
        self.preview_source_label = muted_label("Gốc: —")
        self.preview_translation_label = muted_label("Dịch: —")
        self.preview_voice_label = muted_label("Giọng: —")
        for label in (
            self.preview_time_label, self.preview_source_label,
            self.preview_translation_label, self.preview_voice_label,
        ):
            side_layout.addWidget(label)
        side_layout.addStretch()
        work.addWidget(side)
        self.body.addLayout(work, 1)

    # ---------- Nạp / lưu ----------

    @staticmethod
    def _setup_voice_combo(combo: QComboBox) -> None:
        """Combo chọn giọng: click là xổ danh sách, không nhập tay."""
        combo.setEditable(False)
        combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        combo.setMaxVisibleItems(12)
        combo.setMinimumHeight(34)
        combo.setToolTip("Bấm để xổ danh sách giọng và chọn.")

    def refresh(self) -> None:
        project = self.app.projects.current
        if not project:
            return
        segments = project.load_segments()
        self._cached_segments = segments
        # Nạp danh sách giọng TRƯỚC để đổ vào combo từng hàng của bảng.
        self._line_voice_guard = True
        try:
            voices = create_engine(self.app.config).list_voices()
        except Exception:  # noqa: BLE001
            voices = ["auto"]
        self._voices = voices
        all_voice = self.all_voice_combo.currentText().strip()
        self.all_voice_combo.clear()
        self.all_voice_combo.addItems(voices)
        if all_voice and self.all_voice_combo.findText(all_voice) >= 0:
            self.all_voice_combo.setCurrentText(all_voice)
        self._line_voice_guard = False

        self.table.load(segments, self._sync_info(segments), voices)
        self._apply_filter(self.filter_input.text())
        over = sum(1 for s in segments
                   if len(s.text) > self.app.config.sub_max_chars)
        self.count_label.setText(
            f"{len(segments)} phụ đề | {over} dòng vượt "
            f"{self.app.config.sub_max_chars} ký tự"
        )
        self._sync_voice_combo()

    # ---------- Giọng tại chỗ ----------

    def _current_segment(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self._cached_segments):
            return None
        return self._cached_segments[row]

    def _sync_voice_combo(self) -> None:
        """Dòng chọn đổi -> chỉ cập nhật thông tin; không tự đổi giọng đã chọn."""
        seg = self._current_segment()
        if seg is None:
            self._update_selected_preview(None)
            return
        self._update_selected_preview(seg)

    def _update_selected_preview(self, seg) -> None:
        """Cập nhật panel preview bên phải theo dòng đang chọn."""
        if seg is None:
            self.preview_time_label.setText("—")
            self.preview_source_label.setText("Gốc: —")
            self.preview_translation_label.setText("Dịch: —")
            self.preview_voice_label.setText("Giọng: —")
            return
        self.preview_time_label.setText(f"{seg.start:.2f}s → {seg.end:.2f}s")
        self.preview_source_label.setText(f"Gốc: {seg.text or '—'}")
        self.preview_translation_label.setText(f"Dịch: {seg.translation or '—'}")
        voice = seg.voice or self.all_voice_combo.currentText() or "—"
        locked = ""
        project = self.app.projects.current
        if project is not None:
            from vicdub.utils.custom_voices import load_custom_lines  # noqa: PLC0415
            if seg.line in load_custom_lines(project.root):
                locked = "  🔒 đã khoá (Sinh giọng sẽ giữ nguyên)"
        self.preview_voice_label.setText(f"Giọng: {voice}{locked}")

    def _apply_voice_all_lines(self) -> None:
        """Áp giọng đang chọn cho toàn bộ dòng sub trong project."""
        if self.need_project():
            return
        voice = self.all_voice_combo.currentText().strip()
        if not voice:
            return
        for seg in self._cached_segments:
            seg.voice = voice
        self.app.projects.current.save_segments(self._cached_segments)
        self.app.engine.context["segments"] = self._cached_segments
        current_row = self.table.currentRow()
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        if 0 <= current_row < self.table.rowCount():
            self.table.setCurrentCell(current_row, 0)
        self._sync_voice_combo()
        self.app.show_status(
            f"Đã áp giọng '{voice}' cho toàn bộ {len(self._cached_segments)} dòng sub."
        )

    def _save_line_voice(self) -> None:
        """Lưu voice riêng cho đúng dòng đang chọn."""
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        voice = self.all_voice_combo.currentText().strip()
        if not voice:
            return
        seg.voice = voice
        self.app.projects.current.update_segment(seg)
        self.app.engine.context["segments"] = self._cached_segments
        self.app.show_status(f"Dòng {seg.line}: dùng voice riêng '{voice}'.")
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        self.table.setCurrentCell(seg.line - 1, 0)
        self._sync_voice_combo()

    def _hear_selected_voice(self) -> None:
        """Nghe thử giọng đang chọn với chính câu thoại của dòng chọn."""
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        text = (seg.translation or seg.text).strip() or "Xin chào."
        voice = self.all_voice_combo.currentText().strip() or self._voice_for(seg)
        config = self.app.config

        def work() -> str:
            engine = create_engine(config)
            out = preview_wav_path(config.data_dir, "speaker", voice)
            engine.synthesize(text, voice, 1.0, out)
            self.app.play_audio(out)
            return f"Đang phát '{voice}' đọc dòng {seg.line}."

        self._run_bg(work)

    def _save_segment(self, segment) -> None:
        project = self.app.projects.current
        if project:
            project.update_segment(segment)
            self.app.engine.context["segments"] = self._cached_segments

    def _segments(self) -> list:
        if self._cached_segments:
            return self._cached_segments
        return self.app.projects.current.load_segments()

    def _save_and_reload(self, segments: list) -> None:
        """Đánh lại số thứ tự, lưu DB rồi nạp lại bảng."""
        for i, seg in enumerate(segments, start=1):
            seg.line = i
        self.app.projects.current.save_segments(segments)
        self.refresh()
        self.app.update_right_panel()

    def _current_index(self) -> int:
        row = self.table.currentRow()
        if row < 0:
            self.warn("Chọn một dòng trong bảng trước.")
        return row

    # ---------- Nguồn sub ----------

    def _sub_steps(self) -> list[str]:
        """Chỉ lưu timeline sub; clip xem thử được cắt riêng khi người dùng yêu cầu."""
        return ["subtitle"]

    def _run_gemini_web(self) -> None:
        """Tách sub gắn cứng theo nguồn đã chọn trong Cài đặt."""
        if self.need_project():
            return
        project = self.app.projects.current
        if not project or not project.video_path or not Path(project.video_path).exists():
            self.warn("Vui lòng chọn video trước khi nhận diện phụ đề.")
            return
        # Tôn trọng nguồn người dùng chọn ở tab Cài đặt; không ép Gemini Web nữa.
        source = "drive"
        self.app.config.subtitle_source = "drive"
        accounts = self.app.config.enabled_drive_accounts()
        has_credentials = bool(self.app.config.resolve_drive_credentials()) or any(
            Path(account.get("credentials_path", "")).is_file()
            for account in accounts
        )
        if not accounts or not has_credentials:
            self.warn(
                "Chưa có tài khoản OCR hoạt động. Vào tab Cài đặt, chọn JSON và "
                "kết nối ít nhất một tài khoản OCR trước khi nhận diện video."
            )
            return
        # Nếu đã khoanh ở tab Dự án thì dùng luôn; chỉ hỏi khi project chưa có
        # vùng riêng. Nhờ vậy batch và chạy thủ công dùng cùng một cấu hình.
        if not project.has_ocr_region and not self._pick_ocr_region():
            return
        self.app.show_status(
            f"Đang nhận diện phụ đề bằng {'nguồn chính' if source == 'drive' else 'nguồn dự phòng'}..."
        )
        self.app.start_pipeline(self._sub_steps())

    def _pick_ocr_region(self) -> bool:
        """Chọn vùng chữ và lưu riêng cho project hiện tại."""
        project = self.app.projects.current
        return choose_project_ocr_region(self, project, self.app.config)

    def _import_subtitle(self) -> None:
        if self.need_project():
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Chọn file phụ đề gốc", "", SUBTITLE_FILTER
        )
        if path:
            self.app.start_pipeline(self._sub_steps(), {"subtitle_path": path})

    def _translate_ai(self) -> None:
        """Mở lựa chọn dịch ngay tại Studio rồi mới chạy pipeline."""
        if self.need_project():
            return
        if not self._segments():
            self.warn("Chưa có phụ đề. Hãy nhận diện từ video hoặc nhập một tệp phụ đề.")
            return
        config = self.app.config
        dialog = QDialog(self)
        dialog.setWindowTitle("Tùy chọn dịch phụ đề")
        dialog.setMinimumWidth(480)
        layout = QVBoxLayout(dialog)
        form = QFormLayout()

        target = QComboBox()
        target.setEditable(True)
        target.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        target.setPlaceholderText("Chọn hoặc nhập ngôn ngữ đích")
        target_languages = (
            ("Tiếng Việt", "Tiếng Việt"),
            ("Tiếng Anh", "English"),
            ("Tiếng Trung giản thể", "简体中文"),
            ("Tiếng Trung phồn thể", "繁體中文"),
            ("Tiếng Nhật", "日本語"),
            ("Tiếng Hàn", "한국어"),
            ("Tiếng Thái", "ภาษาไทย"),
            ("Tiếng Indonesia", "Bahasa Indonesia"),
            ("Tiếng Tây Ban Nha", "Español"),
            ("Tiếng Pháp", "Français"),
            ("Tiếng Đức", "Deutsch"),
            ("Tiếng Bồ Đào Nha", "Português"),
            ("Tiếng Nga", "Русский"),
        )
        for label, prompt_name in target_languages:
            target.addItem(label, prompt_name)
        saved_target = str(getattr(config, "target_language", "") or "").strip()
        saved_index = target.findData(saved_target)
        if saved_index < 0:
            saved_index = target.findText(saved_target)
        if saved_index >= 0:
            target.setCurrentIndex(saved_index)
        else:
            target.setCurrentIndex(-1)
            target.setEditText(saved_target)
        style = QComboBox()
        from vicdub.utils.translation_styles import STYLES
        for key, (label, _instruction) in STYLES.items():
            style.addItem(label, key)
        index = style.findData(getattr(config, "translation_style", "conversational"))
        style.setCurrentIndex(max(0, index))
        custom = QLineEdit(getattr(config, "translation_style_custom", ""))
        custom.setPlaceholderText(
            "Ví dụ: xưng hô anh/em, câu thật ngắn, giọng hài hước..."
        )
        custom.setEnabled(style.currentData() == "custom")
        style.currentIndexChanged.connect(
            lambda _index: custom.setEnabled(style.currentData() == "custom")
        )
        form.addRow("Ngôn ngữ đích:", target)
        form.addRow("Phong cách:", style)
        form.addRow("Yêu cầu riêng:", custom)
        layout.addLayout(form)

        hint = muted_label(
            "Bản dịch sẽ ưu tiên câu thoại tự nhiên, ngắn gọn và vừa thời lượng."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.Ok
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Bắt đầu dịch")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Hủy")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        target_language = target.currentText().strip()
        target_index = target.currentIndex()
        if (target_index >= 0
                and target.currentText() == target.itemText(target_index)):
            target_language = str(target.itemData(target_index) or "").strip()
        if not target_language:
            self.warn("Hãy chọn hoặc nhập ngôn ngữ đích trước khi dịch.")
            return
        config.target_language = target_language
        config.translation_style = style.currentData() or "conversational"
        config.translation_style_custom = custom.text().strip()
        config.save()
        self.app.start_pipeline(["translate"])

    def _upload_translation(self) -> None:
        """Tải file translated.srt lên, khớp theo thời gian vào sub hiện có."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có phụ đề gốc. Hãy nhận diện từ video hoặc nhập một tệp phụ đề.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Chọn file bản dịch", "", SUBTITLE_FILTER
        )
        if not path:
            return
        try:
            translated = load_subtitle_file(path)
        except (ValueError, OSError) as exc:
            self.warn(f"Không đọc được file: {exc}")
            return
        match_translations(segments, translated)
        self._save_and_reload(segments)
        self.app.engine.context["segments"] = segments
        # Đếm số dòng THỰC SỰ có bản dịch (không rỗng) - phản ánh đúng hơn
        # cả khi lệch số dòng lẫn khi file dịch có dòng để trống.
        n_base, n_tr = len(segments), len(translated)
        filled = sum(1 for s in segments if s.translation.strip())
        if filled >= n_base:
            self.info(f"Đã ghép đủ bản dịch cho {n_base} dòng.")
        else:
            detail = (f"Sub gốc {n_base} dòng, file dịch {n_tr} dòng"
                      + (" — LỆCH số dòng." if n_base != n_tr else "."))
            self.warn(
                f"Còn {n_base - filled}/{n_base} dòng chưa có bản dịch. {detail}\n"
                f"Muốn ghép đủ thì GIỮ NGUYÊN số dòng và timestamp của 'SRT "
                f"gốc' — chỉ dịch phần chữ, đừng để công cụ dịch gộp/tách/bỏ "
                f"dòng rỗng hay đổi thời gian. Tải lại 'SRT gốc về...' rồi dịch "
                f"lại giữ nguyên số thứ tự."
            )

    def _export_srt(self, translated: bool) -> None:
        """Tải file SRT thô (gốc hoặc bản dịch) về vị trí tùy chọn."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có sub để tải.")
            return
        if translated and not any(s.translation for s in segments):
            self.warn("Chưa có bản dịch để tải.")
            return
        default = "translated.srt" if translated else "original.srt"
        path, _ = QFileDialog.getSaveFileName(
            self, "Lưu SRT", default, "SubRip (*.srt)"
        )
        if path:
            write_srt(segments, path, translated=translated)
            self.info(f"Đã lưu: {path}")

    # ---------- Thao tác dòng ----------

    def _add_row(self) -> None:
        """Chèn dòng mới sau dòng đang chọn (hoặc cuối bảng)."""
        if self.need_project():
            return
        segments = self._segments()
        index = self.table.currentRow()
        if index < 0:
            index = len(segments) - 1
        prev_end = segments[index].end if segments else 0.0
        new_seg = Segment(
            line=0, start=round(prev_end, 3), end=round(prev_end + 2.0, 3),
            text="(sub mới)", speaker="Narrator",
        )
        segments.insert(index + 1, new_seg)
        self._save_and_reload(segments)

    def _delete_row(self) -> None:
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        if index >= len(segments):
            return
        segments.pop(index)
        self._save_and_reload(segments)

    def _merge_down(self) -> None:
        """Gộp dòng đang chọn với dòng ngay dưới (nối text, giữ khung giờ)."""
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        if index >= len(segments) - 1:
            self.warn("Không có dòng dưới để gộp.")
            return
        cur, nxt = segments[index], segments[index + 1]
        cur.text = f"{cur.text} {nxt.text}".strip()
        cur.translation = f"{cur.translation} {nxt.translation}".strip()
        cur.end = nxt.end
        segments.pop(index + 1)
        self._save_and_reload(segments)

    def _split_row(self) -> None:
        """Tách đôi dòng đang chọn tại khoảng trắng giữa, chia giờ tỷ lệ."""
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        seg = segments[index]
        words = seg.text.split()
        if len(words) < 2:
            self.warn("Dòng quá ngắn để tách.")
            return
        half = len(words) // 2
        left_text, right_text = " ".join(words[:half]), " ".join(words[half:])
        ratio = len(left_text) / max(1, len(seg.text))
        mid_time = round(seg.start + seg.duration * ratio, 3)

        t_words = seg.translation.split()
        t_half = len(t_words) // 2
        left_trans = " ".join(t_words[:t_half])
        right_trans = " ".join(t_words[t_half:])

        right_seg = Segment(
            line=0, start=mid_time, end=seg.end, text=right_text,
            translation=right_trans, speaker=seg.speaker, gender=seg.gender,
        )
        seg.text, seg.translation, seg.end = left_text, left_trans, mid_time
        segments.insert(index + 1, right_seg)
        self._save_and_reload(segments)

    # ---------- Studio: so sánh clip / voice ----------

    def _voice_path(self, line: int) -> Path:
        return Path(self.app.projects.current.root) / "voices" / f"{line:04d}.wav"

    @staticmethod
    def _wav_seconds(path: Path) -> float:
        """Đọc thời lượng wav bằng thư viện chuẩn - tức thời, không cần ffprobe."""
        try:
            with wave.open(str(path), "rb") as f:
                rate = f.getframerate()
                return f.getnframes() / rate if rate else 0.0
        except (wave.Error, OSError):
            return 0.0

    def _sync_info(self, segments: list) -> dict[int, tuple[str, str]]:
        """Tính cột Voice(s) và Sync cho bảng: tốc độ cần kéo video."""
        info: dict[int, tuple[str, str]] = {}
        cfg = self.app.config
        for seg in segments:
            wav = self._voice_path(seg.line)
            if not wav.exists():
                continue
            voice_dur = self._wav_seconds(wav)
            if voice_dur <= 0 or seg.duration <= 0:
                continue
            if voice_dur <= seg.duration:
                pad = seg.duration - voice_dur
                sync = "OK khớp" if pad <= 0.05 else f"OK (đệm {pad:.1f}s lặng)"
            else:
                v_speed, voice_speed, _ = VideoModule._plan_sync(
                    seg.duration, voice_dur, cfg.speed_min, cfg.speed_max, 0, [],
                )
                if voice_speed > 1.005:
                    mark = " ⚠" if v_speed < cfg.speed_min - 0.005 else ""
                    sync = f"video {v_speed:.2f}x + voice {voice_speed:.2f}x{mark}"
                else:
                    sync = f"video {v_speed:.2f}x"
            info[seg.line] = (f"{voice_dur:.2f}", sync)
        return info

    def _selected_segment(self):
        index = self._current_index()
        if index < 0:
            return None
        segments = self._segments()
        return segments[index] if index < len(segments) else None

    def _voice_for(self, seg) -> str:
        """Voice của dòng: ưu tiên voice riêng, sau đó default config."""
        engine = create_engine(self.app.config)
        return (seg.voice
                or (getattr(self.app.config, "default_voice", "") or "").strip()
                or engine.default_voice(getattr(seg, "gender", "neutral")))

    @staticmethod
    def _sync_speed(clip_dur: float, voice_dur: float) -> float:
        """Voice ngắn hơn clip -> giữ 1.0 (đệm lặng khi ghép);
        voice dài hơn -> kéo video chậm đúng bằng voice."""
        if voice_dur <= 0 or clip_dur <= 0 or voice_dur <= clip_dur:
            return 1.0
        return clip_dur / voice_dur

    def _run_bg(self, fn) -> None:
        """Chạy tác vụ studio ở thread nền, báo kết quả qua signal."""
        with self._studio_threads_lock:
            if any(thread.is_alive() for thread in self._studio_threads):
                self.warn("Một tác vụ Studio đang chạy. Hãy chờ hoặc đóng app để hủy.")
                return
        self._studio_cancel.clear()

        def wrap() -> None:
            try:
                message = fn() or "Xong."
            except Exception as exc:  # noqa: BLE001 - báo mọi lỗi lên UI
                message = f"Lỗi: {exc}"
            finally:
                with self._studio_threads_lock:
                    self._studio_threads.discard(threading.current_thread())
            if not self._studio_cancel.is_set():
                self.studio_done.emit(str(message))

        thread = threading.Thread(target=wrap, daemon=True, name="vicdub-studio")
        with self._studio_threads_lock:
            self._studio_threads.add(thread)
        thread.start()
        self.app.show_status("Đang xử lý ở nền...")

    def has_background_task(self) -> bool:
        with self._studio_threads_lock:
            return any(thread.is_alive() for thread in self._studio_threads)

    def cancel_background_tasks(self) -> None:
        self._studio_cancel.set()

    def _on_studio_done(self, message: str) -> None:
        self.app.show_status(message)
        self.refresh()

    # ---------- Studio: tác vụ từng dòng ----------

    @staticmethod
    def _is_ocr_error(seg) -> bool:
        return (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được")

    def _repair_ocr_segments(self, targets: list, manual_times: dict[int, float] | None = None) -> None:
        """OCR lại đúng các timestamp đã biết, không chạy lại detector/video scan."""
        if not targets:
            self.warn("Không có dòng nhận diện lỗi cần xử lý.")
            return
        project = self.app.projects.current
        config = self.app.config
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Không tìm thấy video nguồn.")
            return
        accounts = config.enabled_drive_accounts()
        creds = config.resolve_drive_credentials()
        if not accounts:
            self.warn("Chưa kết nối tài khoản xử lý phụ đề.")
            return

        manual_times = manual_times or {}

        def work() -> str:
            from PIL import Image  # noqa: PLC0415
            from vicdub.api.drive_ocr_client import DriveOcrClient  # noqa: PLC0415
            from vicdub.utils.detect_ocr import (  # noqa: PLC0415
                _enhance_failed_image, _ocr_each_image, _ocr_montage_pool,
            )
            from vicdub.utils.sub_detector import frame_quality, text_signature  # noqa: PLC0415
            from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415

            ffmpeg = FFmpeg(
                config.ffmpeg_path, config.ffprobe_path,
                cancel_event=self._studio_cancel,
                timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
            )
            width, height = ffmpeg.video_size(video)
            region = tuple(project.get_ocr_region(
                getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
            ))
            crop = region_to_crop(region, width, height)
            cw, ch, cx, cy = crop
            clients = [
                DriveOcrClient(
                    account.get("credentials_path") or creds,
                    account["token_path"], account.get("folder_id", ""),
                    report=None,
                )
                for account in accounts
            ]
            # Kết quả sửa phải được lưu ngay từng dòng. Trước đây code chỉ ghi
            # database sau khi quét xong toàn bộ, nên đóng app/lỗi giữa chừng
            # làm mất cả những dòng Drive OCR đã đọc thành công.
            result_dir = Path(project.root) / ".ocr_repair_results"
            result_dir.mkdir(parents=True, exist_ok=True)
            persist_lock = threading.Lock()
            repaired_lines: set[int] = set()

            def persist(seg, text: str) -> bool:
                value = str(text or "").strip()
                if not value or value.casefold().startswith("[ocr chưa đọc được"):
                    return False
                with persist_lock:
                    if seg.line in repaired_lines:
                        return True
                    seg.text = value
                    seg.translation = ""  # nguyên văn đổi -> dịch lại dòng này
                    project.update_segment(seg)
                    payload = {
                        "line": seg.line, "start": seg.start, "end": seg.end,
                        "text": value,
                    }
                    path = result_dir / f"line_{seg.line:06d}.json"
                    temp_path = path.with_suffix(".tmp")
                    temp_path.write_text(
                        json.dumps(payload, ensure_ascii=False), encoding="utf-8"
                    )
                    os.replace(temp_path, path)
                    repaired_lines.add(seg.line)
                self.studio_progress.emit(
                    f"Sửa nhận diện — đã lưu ngay {len(repaired_lines)}/{len(targets)} dòng"
                )
                return True

            def restore_saved(seg) -> bool:
                # Kéo frame thủ công luôn OCR lại đúng frame người dùng chọn.
                if seg.line in manual_times:
                    return False
                path = result_dir / f"line_{seg.line:06d}.json"
                try:
                    saved = json.loads(path.read_text(encoding="utf-8"))
                    same_timing = (
                        int(saved.get("line", -1)) == seg.line
                        and abs(float(saved.get("start", -1)) - seg.start) < 0.01
                        and abs(float(saved.get("end", -1)) - seg.end) < 0.01
                    )
                    return same_timing and persist(seg, saved.get("text", ""))
                except (OSError, ValueError, TypeError):
                    return False

            # Khôi phục checkpoint của bản Repair cũ. Dữ liệu cũ đánh số theo
            # vị trí trong danh sách 173 dòng nên chỉ dùng khi count khớp tuyệt đối.
            legacy = Path(project.root) / ".ocr_repair"
            try:
                legacy_state = json.loads((legacy / "state.json").read_text(encoding="utf-8"))
                if int(legacy_state.get("count", -1)) == len(targets):
                    legacy_failed_targets = []
                    for index, seg in enumerate(targets):
                        path = legacy / f"image_{index:06d}.json"
                        saved = {}
                        if path.exists():
                            saved = json.loads(path.read_text(encoding="utf-8"))
                        if saved.get("status") != "done":
                            legacy_failed_targets.append(seg)
                            continue
                        if seg.line not in manual_times:
                            persist(seg, saved.get("text", ""))

                    # Lượt cứu hộ cũ đánh lại index theo đúng danh sách những
                    # ảnh còn lỗi của lượt trên, nên có thể khôi phục an toàn
                    # khi số lượng trong state cũng khớp.
                    enhanced_legacy = Path(project.root) / ".ocr_repair_enhanced"
                    enhanced_state = json.loads(
                        (enhanced_legacy / "state.json").read_text(encoding="utf-8")
                    )
                    if int(enhanced_state.get("count", -1)) == len(legacy_failed_targets):
                        for index, seg in enumerate(legacy_failed_targets):
                            if seg.line in manual_times:
                                continue
                            path = enhanced_legacy / f"image_{index:06d}.json"
                            if not path.exists():
                                continue
                            saved = json.loads(path.read_text(encoding="utf-8"))
                            if saved.get("status") == "done":
                                persist(seg, saved.get("text", ""))
            except (OSError, ValueError, TypeError):
                pass

            for seg in targets:
                if self._is_ocr_error(seg):
                    restore_saved(seg)
            pending = [seg for seg in targets if self._is_ocr_error(seg)]
            images = []
            try:
                if not pending:
                    self.app.engine.context["segments"] = self._cached_segments
                    return f"Đã khôi phục và lưu {len(repaired_lines)}/{len(targets)} dòng nhận diện."
                with tempfile.TemporaryDirectory(prefix="vicdub_ocr_repair_") as folder:
                    temp = Path(folder)
                    total = len(pending)
                    for index, seg in enumerate(pending):
                        if self._studio_cancel.is_set():
                            return f"Đã hủy; {len(repaired_lines)} dòng đọc được đã được lưu."
                        self.studio_progress.emit(
                            f"Chuẩn bị lại khung hình {index + 1}/{total} — dòng {seg.line}..."
                        )
                        if seg.line in manual_times:
                            times = [manual_times[seg.line]]
                        else:
                            duration = max(0.001, seg.end - seg.start)
                            saved = (
                                Path(project.root) / ".drive_ocr_checkpoint" /
                                "failed_images" / f"image_{seg.line - 1:06d}.png"
                            )
                            if saved.exists():
                                with Image.open(saved) as cached_image:
                                    images.append(cached_image.convert("RGB").copy())
                                continue
                            # Project cũ chưa lưu ảnh lỗi: lấy frame giữa để sửa
                            # nhanh. Nếu vẫn khó, người dùng kéo frame thủ công.
                            times = [seg.start + duration * 0.5]
                        best_image = None
                        best_score = -1.0
                        for sample, at in enumerate(times):
                            frame_path = temp / f"{seg.line:05d}_{sample}.png"
                            ffmpeg.extract_frame(video, max(0.0, at), str(frame_path))
                            with Image.open(frame_path) as full:
                                roi = full.convert("RGB").crop((cx, cy, cx + cw, cy + ch))
                            score = frame_quality(text_signature(roi))
                            if score > best_score:
                                best_score = score
                                best_image = roi.copy()
                        if best_image is None:
                            raise RuntimeError(f"Dòng {seg.line}: không trích được frame.")
                        images.append(best_image)

                def report(_pct: int, message: str) -> None:
                    self.studio_progress.emit("Sửa nhận diện — " + message)

                # Repair dùng montage nhỏ: 173 dòng chỉ còn khoảng 22 tài liệu
                # Drive. Panel montage bị thiếu mới rơi về OCR đơn ở dưới.
                texts, failed = _ocr_montage_pool(
                    clients, images, getattr(config, "llm_ocr_lang_hint", ""),
                    report, batch_size=8,
                    is_cancelled=self._studio_cancel.is_set,
                    on_result=lambda index, value: persist(pending[index], value),
                )
                if failed and not self._studio_cancel.is_set():
                    enhanced = [_enhance_failed_image(images[i]) for i in failed]
                    rescued, _ = _ocr_each_image(
                        clients, enhanced, getattr(config, "llm_ocr_lang_hint", ""),
                        report, self._studio_cancel.is_set,
                        checkpoint_dir=str(Path(project.root) / ".ocr_repair_enhanced"),
                        max_attempts=2,
                        on_result=lambda index, value: persist(
                            pending[failed[index]], value
                        ),
                    )
                    for source_index, value in zip(failed, rescued):
                        if value.strip():
                            texts[source_index] = value.strip()

                # Callback đã commit từng kết quả. Vòng này chỉ là hàng rào an
                # toàn nếu backend nào đó không gọi callback.
                for seg, text in zip(pending, texts):
                    persist(seg, text)
                self.app.engine.context["segments"] = self._cached_segments
                remaining = sum(1 for seg in targets if self._is_ocr_error(seg))
                repaired = len(targets) - remaining
                return (
                    f"Đã lưu thật {repaired}/{len(targets)} dòng nhận diện vào project"
                    + (f"; còn {remaining} dòng cần kéo frame/nhập tay/xóa." if remaining else ".")
                )
            finally:
                for client in clients:
                    client.close()

        self._run_bg(work)

    def _repair_all_ocr_errors(self) -> None:
        if self.need_project():
            return
        errors = [seg for seg in self._segments() if self._is_ocr_error(seg)]
        self._repair_ocr_segments(errors)

    def _repair_selected_ocr_error(self) -> None:
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        if not self._is_ocr_error(seg):
            self.warn("Dòng đang chọn không phải dòng nhận diện lỗi.")
            return
        self._repair_ocr_segments([seg])

    def _manual_ocr_capture(self) -> None:
        """Preview crop tại timestamp, cho kéo playhead rồi OCR đúng frame chọn."""
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Không tìm thấy video nguồn.")
            return

        from PIL import Image  # noqa: PLC0415
        from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415

        config = self.app.config
        ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
        try:
            width, height = ffmpeg.video_size(video)
        except FFmpegError as exc:
            self.warn(str(exc))
            return
        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
        ))
        cw, ch, cx, cy = region_to_crop(region, width, height)

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Chụp lại phụ đề — dòng {seg.line}")
        dialog.resize(780, 360)
        layout = QVBoxLayout(dialog)
        preview = QLabel("Đang lấy frame...")
        preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        preview.setMinimumHeight(210)
        layout.addWidget(preview, 1)
        time_label = QLabel()
        slider = QSlider(Qt.Orientation.Horizontal)
        start_ms = max(0, int(round(seg.start * 1000)))
        end_ms = max(start_ms + 1, int(round(seg.end * 1000)))
        slider.setRange(start_ms, end_ms)
        slider.setValue((start_ms + end_ms) // 2)
        layout.addWidget(time_label)
        layout.addWidget(slider)
        hint = muted_label("Kéo tới khung hình chữ rõ nhất rồi bấm “Chụp và đọc”.")
        layout.addWidget(hint)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Chụp và đọc")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Hủy")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        with tempfile.TemporaryDirectory(prefix="vicdub_manual_ocr_") as folder:
            temp = Path(folder)

            def render_frame() -> None:
                at = slider.value() / 1000.0
                time_label.setText(
                    f"Thời gian: {at:.3f}s   |   đoạn {seg.start:.3f}s → {seg.end:.3f}s"
                )
                full_path = temp / "full.png"
                crop_path = temp / "crop.png"
                try:
                    ffmpeg.extract_frame(video, at, str(full_path))
                    with Image.open(full_path) as full:
                        full.convert("RGB").crop((cx, cy, cx + cw, cy + ch)).save(crop_path)
                    pixmap = QPixmap(str(crop_path))
                    preview.setPixmap(pixmap.scaled(
                        preview.size(), Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    ))
                except Exception as exc:  # noqa: BLE001
                    preview.setText(f"Không lấy được frame: {exc}")

            slider.valueChanged.connect(
                lambda value: time_label.setText(
                    f"Thời gian: {value / 1000.0:.3f}s   |   thả chuột để cập nhật ảnh"
                )
            )
            slider.sliderReleased.connect(render_frame)
            render_frame()
            accepted = dialog.exec() == QDialog.DialogCode.Accepted
            selected_time = slider.value() / 1000.0
        if accepted:
            self._repair_ocr_segments([seg], {seg.line: selected_time})

    def _generate_voice_line(self) -> None:
        """Sinh voice riêng cho dòng đang chọn."""
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        text = seg.translation or seg.text
        if (not text.strip()
                or text.strip().casefold().startswith("[ocr chưa đọc được")):
            self.warn("Dòng này chưa có nội dung để đọc.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, unmark_custom_lines,
        )
        if seg.line in load_custom_lines(self.app.projects.current.root):
            if not self.confirm(
                f"Dòng {seg.line} đang KHOÁ voice (nhập tay hoặc đã chốt).\n"
                "Sinh TTS đè lên và mở khoá?"
            ):
                return
            unmark_custom_lines(self.app.projects.current.root, [seg.line])
        selected_voice = self.all_voice_combo.currentText().strip()
        if selected_voice:
            seg.voice = selected_voice
            self.app.projects.current.update_segment(seg)
            self.app.engine.context["segments"] = self._cached_segments
        voice = selected_voice or self._voice_for(seg)
        config = self.app.config
        out = self._voice_path(seg.line)
        project = self.app.projects.current

        def work() -> str:
            VoiceModule().run({
                "project": project, "segments": [seg], "config": config,
            })
            dur = self._wav_seconds(out)
            return f"Dòng {seg.line}: voice {dur:.2f}s (clip {seg.duration:.2f}s)"

        self._run_bg(work)

    def _generate_voice_all(self) -> None:
        """Dùng chung VoiceModule: batch, cache, retry và checkpoint."""
        if self.need_project():
            return
        from vicdub.core import bootstrap  # noqa: PLC0415
        voice_missing = [
            c.label for c in bootstrap.missing(self.app.config)
            if c.key in ("torch", "omnivoice", "omnivoice_model")
        ]
        if voice_missing:
            self.warn(
                "Chưa đủ thành phần để sinh giọng:\n- "
                + "\n- ".join(voice_missing)
                + "\n\nMở tab 'Cập nhật' để tải và cài tự động."
            )
            return
        segments = [
            seg for seg in self._segments()
            if (seg.translation or seg.text).strip()
        ]
        if not segments:
            self.warn("Chưa có dòng nào có nội dung để render voice.")
            return
        selected_voice = self.all_voice_combo.currentText().strip()
        if selected_voice:
            # Nút tạo toàn bộ luôn dùng đúng lựa chọn đang hiển thị, không rơi về
            # giọng mặc định/giới tính/nhân vật khiến tone thay đổi giữa các câu.
            for seg in segments:
                seg.voice = selected_voice
            self.app.projects.current.save_segments(self._cached_segments)
        self.app.engine.context["segments"] = segments
        self.app.start_pipeline(["voice"], {"segments": segments})

    @staticmethod
    def _voice_file_index(path: Path) -> int | None:
        """Nhận số dòng từ tên voice.

        Hỗ trợ các dạng phổ biến:
        - 1-xxxxx.wav / 001_xxxxx.wav / 001.xxxxx.wav
        - line_001_xxxxx.wav / voice-001-xxxxx.wav / audio 001 xxxxx.wav
        - 0001.wav
        """
        stem = path.stem.strip()
        patterns = (
            r"^\s*0*(\d{1,6})(?=$|[-_.\s])",
            r"(?:^|[-_.\s])(line|voice|audio|sub|seg|segment)[-_.\s]*0*(\d{1,6})(?=$|[-_.\s])",
            r"(?:^|[-_.\s])0*(\d{1,6})(?=$|[-_.\s])",
        )
        for pattern in patterns:
            match = re.search(pattern, stem, flags=re.IGNORECASE)
            if not match:
                continue
            value = match.group(match.lastindex or 1)
            if value and value.isdigit():
                index = int(value)
                return index if index > 0 else None
        return None

    def _scan_voice_folder(self, folder: Path) -> tuple[dict[int, Path], list[Path], list[tuple[int, Path, Path]]]:
        """Quét thư mục voice, trả matched + duplicate + conflict."""
        matched: dict[int, Path] = {}
        ignored: list[Path] = []
        conflicts: list[tuple[int, Path, Path]] = []
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in AUDIO_EXTS:
                continue
            index = self._voice_file_index(path)
            if index is None:
                ignored.append(path)
                continue
            if index in matched:
                conflicts.append((index, matched[index], path))
                continue
            matched[index] = path
        return matched, ignored, conflicts

    def _pick_line_voice_file(self) -> None:
        """Chọn MỘT file audio làm voice cho đúng dòng đang chọn (thay TTS).

        File được convert về voices/NNNN.wav và KHOÁ (custom_lines.json) để
        'Sinh giọng' không sinh đè — đây là lựa chọn chủ động của người dùng.
        """
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, f"Chọn file voice cho dòng {seg.line}", "",
            "Audio (*.wav *.mp3 *.m4a *.aac *.flac *.ogg *.opus);;Tất cả (*.*)",
        )
        if not path:
            return
        from vicdub.utils.custom_voices import mark_custom_lines  # noqa: PLC0415

        project = self.app.projects.current
        voices_dir = Path(project.root) / "voices"
        voices_dir.mkdir(parents=True, exist_ok=True)
        dest = voices_dir / f"{seg.line:04d}.wav"
        src = Path(path)
        try:
            if src.suffix.lower() == ".wav":
                if src.resolve() != dest.resolve():
                    shutil.copy2(src, dest)
            else:
                config = self.app.config
                FFmpeg(config.ffmpeg_path, config.ffprobe_path).to_wav(
                    str(src), str(dest))
        except (OSError, FFmpegError) as exc:
            self.warn(f"Không dùng được file audio này: {exc}")
            return
        mark_custom_lines(project.root, [seg.line])
        voice_files = dict(self.app.engine.context.get("voice_files") or {})
        voice_files[seg.line] = str(dest)
        self.app.engine.context["voice_files"] = voice_files
        self.app.show_status(
            f"Dòng {seg.line}: dùng voice nhập tay '{src.name}' (đã khoá, TTS không đè)."
        )
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        self.table.setCurrentCell(seg.line - 1, 0)

    def _lock_line_voice(self) -> None:
        """Khoá TAY voice hiện tại của dòng — kể cả voice TTS vừa sinh mà ưng ý.

        Bổ trợ cho auto-khoá (chỉ chạy khi nhập file ngoài): sau khi khoá, đổi
        text/giọng rồi 'Sinh giọng' lại hàng loạt cũng không đè lên dòng này.
        """
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, mark_custom_lines,
        )

        project = self.app.projects.current
        wav = Path(project.root) / "voices" / f"{seg.line:04d}.wav"
        if not wav.exists():
            self.warn(
                f"Dòng {seg.line} chưa có voice để khoá. Sinh voice hoặc chọn "
                "file voice trước."
            )
            return
        if seg.line in load_custom_lines(project.root):
            self.app.show_status(f"Dòng {seg.line} đã khoá sẵn.")
            return
        mark_custom_lines(project.root, [seg.line])
        self.app.show_status(
            f"Dòng {seg.line}: đã khoá voice hiện tại — Sinh giọng sẽ giữ nguyên."
        )
        self._update_selected_preview(seg)

    def _remove_line_custom_voice(self) -> None:
        """Mở khoá voice của dòng đang chọn (TTS được sinh lại)."""
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, unmark_custom_lines,
        )

        project = self.app.projects.current
        if seg.line not in load_custom_lines(project.root):
            self.warn(f"Dòng {seg.line} không bị khoá voice.")
            return
        if not self.confirm(
            f"Mở khoá voice của dòng {seg.line}?\n"
            "File wav hiện tại được giữ nguyên nhưng lần 'Sinh giọng' tới "
            "TTS sẽ sinh đè lên."
        ):
            return
        unmark_custom_lines(project.root, [seg.line])
        self.app.show_status(f"Dòng {seg.line}: đã mở khoá voice.")
        self._update_selected_preview(seg)

    def _import_voice_folder(self) -> None:
        """Nhập voice đã render sẵn, match theo số thứ tự trong tên file."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có phụ đề để khớp voice.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục chứa voice")
        if not folder:
            return
        source_dir = Path(folder)
        matched, ignored, conflicts = self._scan_voice_folder(source_dir)
        valid_lines = {seg.line for seg in segments}
        usable = {line: path for line, path in matched.items() if line in valid_lines}
        overflow = sorted(line for line in matched if line not in valid_lines)
        missing = sorted(line for line in valid_lines if line not in usable)
        if not usable:
            self.warn(
                "Không khớp được file voice nào.\n"
                "Tên file cần có số dòng, ví dụ: 1-xxx.wav, 001_xxx.wav, "
                "line_001_xxx.wav."
            )
            return
        preview_missing = ", ".join(map(str, missing[:12]))
        preview_overflow = ", ".join(map(str, overflow[:12]))
        preview_conflicts = ", ".join(str(line) for line, _old, _new in conflicts[:12])
        message = (
            f"Tìm thấy {len(matched)} file voice có số thứ tự.\n"
            f"Khớp {len(usable)}/{len(segments)} dòng phụ đề.\n"
            f"Bỏ qua {len(ignored)} file không đọc được số thứ tự.\n"
            f"Trùng số: {len(conflicts)}"
        )
        if missing:
            message += f"\nThiếu dòng: {preview_missing}{'...' if len(missing) > 12 else ''}"
        if overflow:
            message += f"\nDư ngoài số dòng sub: {preview_overflow}{'...' if len(overflow) > 12 else ''}"
        if conflicts:
            message += f"\nFile trùng số dòng: {preview_conflicts}{'...' if len(conflicts) > 12 else ''}"
        message += "\n\nÁp dụng voice đã khớp vào project?"
        if not self.confirm(message):
            return

        project = self.app.projects.current
        voices_dir = Path(project.root) / "voices"
        voices_dir.mkdir(parents=True, exist_ok=True)
        config = self.app.config

        def work() -> str:
            ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
            imported: dict[int, str] = {}
            converted = 0
            copied = 0
            for line, src in sorted(usable.items()):
                self._studio_cancel.wait(0)
                if self._studio_cancel.is_set():
                    return "Đã hủy nhập voice."
                dest = voices_dir / f"{line:04d}.wav"
                if src.suffix.lower() == ".wav":
                    if src.resolve() != dest.resolve():
                        shutil.copy2(src, dest)
                    copied += 1
                else:
                    ffmpeg.to_wav(str(src), str(dest))
                    converted += 1
                imported[line] = str(dest)
            # Khoá các dòng vừa nhập: 'Sinh giọng' sẽ giữ nguyên, không TTS đè.
            from vicdub.utils.custom_voices import mark_custom_lines  # noqa: PLC0415
            mark_custom_lines(project.root, imported.keys())
            existing = dict(self.app.engine.context.get("voice_files") or {})
            existing.update(imported)
            self.app.engine.context["voice_files"] = existing
            return (
                f"Đã nhập {len(imported)} voice "
                f"({copied} copy, {converted} convert) — đã khoá chống TTS đè. "
                "Có thể bấm Đồng bộ tất cả hoặc xuất video."
            )

        self._run_bg(work)

    def _preview_line(self) -> None:
        """Xem thử dòng chọn: cắt clip, kéo giãn theo voice, ghép voice,
        đóng sub chữ rồi mở bằng trình phát mặc định."""
        if self.need_project():
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Chưa chọn video nguồn (tab Video).")
            return
        seg = self._selected_segment()
        if seg is None:
            return
        config = self.app.config
        wav = self._voice_path(seg.line)
        out_dir = Path(project.root) / "output"
        text = seg.translation or seg.text

        def work() -> str:
            ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
            raw = out_dir / "_preview_raw.mp4"
            has_voice = wav.exists() and self._wav_seconds(wav) > 0
            ffmpeg.cut_clip(video, seg.start, seg.end, str(raw),
                            keep_audio=not has_voice)

            current = raw
            note = "audio gốc (chưa có voice)"
            if has_voice:
                voice_dur = self._wav_seconds(wav)
                video_speed, voice_speed, _ = VideoModule._plan_sync(
                    seg.duration, voice_dur,
                    config.speed_min, config.speed_max, 0, [],
                )
                if abs(video_speed - 1.0) > 0.005:
                    retimed = out_dir / "_preview_retimed.mp4"
                    ffmpeg.retime_clip(str(current), video_speed, str(retimed))
                    current = retimed
                voice_src = str(wav)
                if voice_speed > 1.005:
                    sped = out_dir / "_preview_voice.wav"
                    ffmpeg.speed_audio(str(wav), voice_speed, str(sped))
                    voice_src = str(sped)
                voiced = out_dir / "_preview_voiced.mp4"
                ffmpeg.mux_voice(str(current), voice_src, str(voiced))
                current = voiced
                note = (f"video {video_speed:.2f}x + voice tăng tốc {voice_speed:.2f}x"
                        if voice_speed > 1.005
                        else f"kéo video {video_speed:.2f}x theo voice {voice_dur:.2f}s")

            final = out_dir / f"preview_line_{seg.line:04d}.mp4"
            if text.strip():
                dur = ffmpeg.duration(str(current))
                srt = out_dir / "_preview.srt"
                write_srt([Segment(1, 0.0, dur, text=text)], srt)
                ffmpeg.burn_subtitle(str(current), str(srt), str(final))
            else:
                Path(current).replace(final)
            if os.name == "nt":
                os.startfile(str(final))  # noqa: S606
            return f"Xem thử dòng {seg.line}: {note}, sub đã đóng vào hình"

        self._run_bg(work)

    def _sync_line(self) -> None:
        """Đồng bộ dòng chọn: cắt + kéo giãn clip đúng thời lượng voice,
        lưu vào clips/ để bước Ghép video dùng luôn."""
        if self.need_project():
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Chưa chọn video nguồn (tab Video).")
            return
        seg = self._selected_segment()
        if seg is None:
            return
        wav = self._voice_path(seg.line)
        if not wav.exists():
            self.warn("Dòng này chưa có voice. Bấm 'Sinh voice dòng chọn' trước.")
            return
        config = self.app.config
        clips_dir = Path(project.root) / "clips"

        def work() -> str:
            ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
            voice_dur = self._wav_seconds(wav)
            speed = self._sync_speed(seg.duration, voice_dur)
            raw = clips_dir / f"{seg.line:03d}_raw.mp4"
            final = clips_dir / f"{seg.line:03d}.mp4"
            ffmpeg.cut_clip(video, seg.start, seg.end, str(raw))
            if abs(speed - 1.0) > 0.005:
                ffmpeg.retime_clip(str(raw), speed, str(final))
                raw.unlink(missing_ok=True)
            else:
                raw.replace(final)
            if voice_dur <= seg.duration:
                pad = seg.duration - voice_dur
                note = (f"giữ tốc độ gốc, đệm {pad:.1f}s lặng" if pad > 0.05
                        else "khớp hoàn hảo")
            else:
                warn = (" ⚠ quá ngưỡng, cân nhắc rút gọn bản dịch"
                        if speed < config.speed_min else "")
                note = f"kéo video {speed:.2f}x theo voice{warn}"
            return (f"Dòng {seg.line}: clip {seg.duration:.2f}s / voice "
                    f"{voice_dur:.2f}s - {note}")

        self._run_bg(work)

    def _sync_all(self) -> None:
        """Đồng bộ toàn bộ: chạy bước 'Đồng bộ video' của pipeline."""
        if self.need_project():
            return
        self.app.start_pipeline(["video"])

    def _play_line(self, line: int) -> None:
        """Nút ▶ trên bảng: phát voice của dòng đó ngay trong app."""
        wav = self._voice_path(line)
        if not wav.exists():
            self.app.show_status(
                f"Dòng {line} chưa có voice - chọn dòng rồi bấm "
                "'Sinh voice dòng chọn'."
            )
            return
        self.app.play_audio(str(wav))
        self.app.show_status(
            f"Đang phát voice dòng {line} ({self._wav_seconds(wav):.1f}s)."
        )

    def _play_all_voices(self) -> None:
        """Nối toàn bộ voice đã render theo thứ tự và phát trong app."""
        if self.need_project():
            return
        segments = self._segments()
        wavs = [str(self._voice_path(seg.line)) for seg in segments
                if self._voice_path(seg.line).exists()]
        if not wavs:
            self.warn("Chưa có voice nào được render. Sinh voice trước.")
            return
        config = self.app.config
        out = str(Path(config.data_dir) / "preview_all.wav")

        def work() -> str:
            FFmpeg(config.ffmpeg_path, config.ffprobe_path).concat_audio(wavs, out)
            self.app.play_audio(out)
            total = sum(self._wav_seconds(Path(w)) for w in wavs)
            return (f"Đang phát {len(wavs)} voice liên tục "
                    f"(tổng {total:.0f} giây).")

        self._run_bg(work)

    # ---------- Tìm kiếm ----------

    def _apply_filter(self, needle: str) -> None:
        needle = needle.strip().lower()
        for row in range(self.table.rowCount()):
            if not needle:
                self.table.setRowHidden(row, False)
                continue
            text_item = self.table.item(row, 4)
            trans_item = self.table.item(row, 5)
            haystack = f"{text_item.text() if text_item else ''} " \
                       f"{trans_item.text() if trans_item else ''}".lower()
            self.table.setRowHidden(row, needle not in haystack)


# ====================================================================
class DraggableSubtitlePreview(QLabel):
    """Video still preview that emits normalized subtitle drop coordinates."""

    position_changed = pyqtSignal(float, float)

    def __init__(self, text: str = "") -> None:
        super().__init__(text)
        self._dragging = False
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    def _emit_position(self, event) -> None:
        pixmap = self.pixmap()
        if pixmap is None or pixmap.isNull():
            return
        left = (self.width() - pixmap.width()) / 2.0
        top = (self.height() - pixmap.height()) / 2.0
        x = (event.position().x() - left) / max(1, pixmap.width())
        y = (event.position().y() - top) / max(1, pixmap.height())
        self.position_changed.emit(
            max(0.03, min(0.97, x)), max(0.03, min(0.97, y))
        )

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging = True
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            self._emit_position(event)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._dragging and event.buttons() & Qt.MouseButton.LeftButton:
            self._emit_position(event)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            self._emit_position(event)
            event.accept()
            return
        super().mouseReleaseEvent(event)


class SeriesPage(BasePage):
    """Ghép nhiều video + nhiều sub thành một video/SRT tổng."""

    progress = pyqtSignal(str)
    done = pyqtSignal(bool, str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(
            app,
            "Ghép series",
            "Ghép nhiều video nhỏ và cộng dồn timecode phụ đề thành một bản tổng.",
        )
        self.items: list[dict] = []
        self._known_subs: dict[str, str] = {}
        self._batch_series_dirs: list[str] = []
        self._busy = False

        name_row = QHBoxLayout()
        name_row.addWidget(muted_label("Tên series/dự án:"))
        self.series_name = QLineEdit("series_full")
        self.series_name.setPlaceholderText("Ví dụ: tap_01 hoặc ten_du_an")
        name_row.addWidget(self.series_name, 1)
        self.btn_batch_dirs = QPushButton("Chọn nhiều thư mục series...")
        name_row.addWidget(self.btn_batch_dirs)
        self.body.addLayout(name_row)

        row = QHBoxLayout()
        self.btn_add_videos = QPushButton("Chọn video...")
        self.btn_add_video_dir = QPushButton("Chọn thư mục video...")
        self.btn_add_subs = QPushButton("Chọn SRT...")
        self.btn_add_sub_dir = QPushButton("Chọn thư mục SRT...")
        self.btn_match = QPushButton("Tự khớp theo tên")
        self.btn_clear = QPushButton("Xóa danh sách")
        for btn in (
            self.btn_add_videos, self.btn_add_video_dir, self.btn_add_subs,
            self.btn_add_sub_dir, self.btn_match, self.btn_clear,
        ):
            row.addWidget(btn)
        row.addStretch(1)
        self.body.addLayout(row)

        out_row = QHBoxLayout()
        out_row.addWidget(muted_label("Thư mục xuất:"))
        self.output_dir = QLineEdit(str(Path(self.app.config.projects_dir).parent / "series_output"))
        self.btn_output = QPushButton("Chọn...")
        out_row.addWidget(self.output_dir, 1)
        out_row.addWidget(self.btn_output)
        self.body.addLayout(out_row)

        opt_row = QHBoxLayout()
        self.merge_video_cb = QCheckBox("Xuất video tổng")
        self.merge_video_cb.setChecked(True)
        self.merge_srt_cb = QCheckBox("Xuất SRT gốc tổng")
        self.merge_srt_cb.setChecked(True)
        self.translate_later_cb = QCheckBox("Dịch SRT tổng sau khi ghép")
        self.translate_later_cb.setChecked(False)
        self.split_back_cb = QCheckBox("Tách SRT dịch về từng tập")
        self.split_back_cb.setChecked(False)
        self.split_back_cb.setToolTip(
            "Sau khi dịch bản tổng, tách ngược thành SRT dịch riêng cho từng tập "
            "(theo đúng bảng offset đã ghép) — dùng khi cần đăng lẻ."
        )
        for cb in (self.merge_video_cb, self.merge_srt_cb, self.translate_later_cb,
                   self.split_back_cb):
            cb.setObjectName("seriesOption")
            cb.setMinimumHeight(34)
            cb.setStyleSheet("""
                QCheckBox#seriesOption {
                    background-color: #111827;
                    border: 1px solid #334155;
                    border-radius: 8px;
                    padding: 7px 12px;
                    color: #e5eef8;
                    font-weight: 600;
                    spacing: 10px;
                }
                QCheckBox#seriesOption:hover {
                    border-color: #38bdf8;
                    background-color: #162033;
                }
                QCheckBox#seriesOption:checked {
                    border-color: #1f6feb;
                    background-color: #13213a;
                }
                QCheckBox#seriesOption::indicator {
                    width: 16px;
                    height: 16px;
                    border-radius: 4px;
                    border: 1px solid #64748b;
                    background-color: #0b1220;
                }
                QCheckBox#seriesOption::indicator:checked {
                    border-color: #38bdf8;
                    background-color: #1f6feb;
                }
            """)
        opt_row.addWidget(self.merge_video_cb)
        opt_row.addWidget(self.merge_srt_cb)
        opt_row.addWidget(self.translate_later_cb)
        opt_row.addWidget(self.split_back_cb)
        opt_row.addStretch(1)
        self.body.addLayout(opt_row)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["#", "Video", "SRT", "Duration", "Trạng thái"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.body.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.status = QLabel("Chưa có dữ liệu.")
        self.btn_export = QPushButton("Xuất video + SRT full")
        self.btn_batch_export = QPushButton("Render hàng loạt")
        self.btn_open_output = QPushButton("Mở thư mục xuất")
        bottom.addWidget(self.status, 1)
        bottom.addWidget(self.btn_open_output)
        bottom.addWidget(self.btn_batch_export)
        bottom.addWidget(self.btn_export)
        self.body.addLayout(bottom)

        self.btn_add_videos.clicked.connect(self._add_videos)
        self.btn_add_video_dir.clicked.connect(self._add_video_dir)
        self.btn_add_subs.clicked.connect(self._add_subs)
        self.btn_add_sub_dir.clicked.connect(self._add_sub_dir)
        self.btn_match.clicked.connect(self._auto_match)
        self.btn_clear.clicked.connect(self._clear)
        self.btn_output.clicked.connect(self._choose_output)
        self.btn_open_output.clicked.connect(self._open_output)
        self.btn_export.clicked.connect(self._export)
        self.btn_batch_dirs.clicked.connect(self._choose_batch_series_dirs)
        self.btn_batch_export.clicked.connect(self._export_batch)
        self.progress.connect(self._set_status)
        self.done.connect(self._on_done)

    def refresh(self) -> None:
        self._render()

    def _set_status(self, text: str) -> None:
        self.status.setText(text)
        self.app.show_status(text)

    def _video_exts(self) -> tuple[str, ...]:
        return tuple(e.lower() for e in SUPPORTED_VIDEO_EXTS)

    def _add_videos(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Chọn video", "", VIDEO_FILTER)
        self._append_videos(paths)

    def _add_video_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục video")
        if not folder:
            return
        paths = sort_paths_natural(
            str(p) for p in Path(folder).iterdir()
            if p.is_file() and p.suffix.lower() in self._video_exts()
        )
        self._append_videos(paths)

    def _add_subs(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Chọn SRT", "", SUBTITLE_FILTER)
        self._remember_subs(paths)
        self._auto_match()

    def _add_sub_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục SRT")
        if not folder:
            return
        paths = sort_paths_natural(
            str(p) for p in Path(folder).rglob("*")
            if p.is_file() and p.suffix.lower() in {".srt", ".ass", ".vtt"}
        )
        self._remember_subs(paths)
        self._auto_match()

    def _append_videos(self, paths: list[str]) -> None:
        existing = {str(Path(item["video"]).resolve()).casefold() for item in self.items}
        for raw in paths:
            if not raw:
                continue
            path = str(Path(raw))
            key = str(Path(path).resolve()).casefold()
            if key in existing:
                continue
            self.items.append({"video": path, "sub": "", "duration": 0.0, "status": "Chưa kiểm tra"})
            existing.add(key)
        self._auto_match()

    def _remember_subs(self, paths: list[str]) -> None:
        for raw in paths:
            path = Path(raw)
            if path.suffix.lower() not in {".srt", ".ass", ".vtt"}:
                continue
            for key in self._match_keys(path.stem):
                self._known_subs.setdefault(key, str(path))

    @staticmethod
    def _match_keys(stem: str) -> list[str]:
        """Tạo khóa khớp mềm cho video/sub: exact, tên đã lọc, số đầu file."""
        raw = stem.casefold().strip()
        # Bỏ một số hậu tố hay gặp ở video/sub tải về: không làm mất số tập.
        cleaned = re.sub(
            r"(无字幕版|有字幕版|字幕版|无字幕|有字幕|vietsub|sub|subtitle|translated|bản dịch)",
            "",
            raw,
            flags=re.IGNORECASE,
        )
        cleaned = re.sub(r"[\s._\\-]+", "", cleaned).strip()
        keys = [raw, cleaned]
        # Match theo số đầu file: 01xxx.mp4 ↔ 01.srt / 1.srt.
        m = re.match(r"^\D*0*(\d{1,4})", raw)
        if m:
            keys.append(f"num:{int(m.group(1))}")
        return [k for i, k in enumerate(keys) if k and k not in keys[:i]]

    def _auto_match(self) -> None:
        for item in self.items:
            video = Path(item["video"])
            candidates = [
                video.with_suffix(".srt"),
                video.with_suffix(".ass"),
                video.with_suffix(".vtt"),
            ]
            matched = next((str(p) for p in candidates if p.exists()), "")
            if not matched:
                matched = next(
                    (self._known_subs.get(key, "") for key in self._match_keys(video.stem)
                     if self._known_subs.get(key, "")),
                    "",
                )
            if matched:
                item["sub"] = matched
                item["status"] = "OK"
            elif not item.get("sub"):
                item["status"] = "Thiếu SRT"
        self._render()

    def _clear(self) -> None:
        if self._busy:
            return
        self.items.clear()
        self._known_subs.clear()
        self._render()

    def _choose_output(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất")
        if folder:
            self.output_dir.setText(folder)

    def _open_output(self) -> None:
        folder = Path(self.output_dir.text().strip())
        folder.mkdir(parents=True, exist_ok=True)
        os.startfile(str(folder))

    def _choose_batch_series_dirs(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self,
            "Chọn thư mục cha chứa nhiều series",
        )
        if not folder:
            return
        root = Path(folder)
        dirs = sort_paths_natural(
            str(p) for p in root.iterdir()
            if p.is_dir() and self._collect_series_items(p)
        )
        if not dirs and self._collect_series_items(root):
            dirs = [str(root)]
        self._batch_series_dirs = dirs
        self.status.setText(f"Đã chọn {len(dirs)} series để render hàng loạt.")

    def _render(self) -> None:
        self.table.setRowCount(len(self.items))
        for row, item in enumerate(self.items):
            duration = float(item.get("duration") or 0.0)
            values = [
                str(row + 1),
                Path(item["video"]).name,
                Path(item["sub"]).name if item.get("sub") else "Chưa có",
                self._fmt_duration(duration) if duration else "-",
                item.get("status") or "",
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(value)
                if col == 1:
                    cell.setToolTip(item["video"])
                elif col == 2:
                    cell.setToolTip(item.get("sub", ""))
                self.table.setItem(row, col, cell)
        matched = sum(1 for item in self.items if item.get("sub"))
        self.status.setText(f"{len(self.items)} video | {matched} SRT đã khớp")

    @staticmethod
    def _fmt_duration(seconds: float) -> str:
        total = max(0, int(round(seconds)))
        return f"{total // 3600:02d}:{(total % 3600) // 60:02d}:{total % 60:02d}"

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        for btn in (
            self.btn_add_videos, self.btn_add_video_dir, self.btn_add_subs,
            self.btn_add_sub_dir, self.btn_match, self.btn_clear,
            self.btn_output, self.btn_export, self.btn_batch_dirs, self.btn_batch_export,
        ):
            btn.setEnabled(not busy)

    @staticmethod
    def _safe_name(value: str, fallback: str = "series_full") -> str:
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", value.strip())
        name = re.sub(r"\s+", " ", name).strip(" ._")
        return name or fallback

    def _series_output_name(self) -> str:
        return self._safe_name(self.series_name.text(), "series_full")

    def _collect_series_items(self, folder: Path) -> list[dict]:
        videos = sort_paths_natural(
            p for p in folder.iterdir()
            if p.is_file() and p.suffix.lower() in self._video_exts()
        )
        subs: dict[str, str] = {}
        for p in sort_paths_natural(folder.rglob("*")):
            if not p.is_file() or p.suffix.lower() not in {".srt", ".ass", ".vtt"}:
                continue
            for key in self._match_keys(p.stem):
                subs.setdefault(key, str(p))
        items: list[dict] = []
        for video in videos:
            sub = next(
                (subs.get(key, "") for key in self._match_keys(video.stem)
                 if subs.get(key, "")),
                "",
            )
            items.append({
                "video": str(video),
                "sub": sub,
                "duration": 0.0,
                "status": "OK" if sub else "Thiếu SRT",
            })
        return items

    def _export(self) -> None:
        if self._busy:
            return
        if not self.items:
            self.warn("Chưa có video để ghép.")
            return
        if (
            not self.merge_video_cb.isChecked()
            and not self.merge_srt_cb.isChecked()
            and not self.translate_later_cb.isChecked()
        ):
            self.warn("Chọn ít nhất một đầu ra: video tổng, SRT tổng hoặc SRT dịch.")
            return
        output_dir = Path(self.output_dir.text().strip())
        if not str(output_dir):
            self.warn("Chưa chọn thư mục xuất.")
            return
        items = [dict(item) for item in self.items]
        options = {
            "merge_video": self.merge_video_cb.isChecked(),
            "merge_srt": self.merge_srt_cb.isChecked(),
            "translate": self.translate_later_cb.isChecked(),
            "split_back": self.split_back_cb.isChecked(),
            "name": self._series_output_name(),
        }
        self._set_busy(True)
        self._set_status("Đang chuẩn bị ghép series...")

        def worker() -> None:
            try:
                result = self._export_worker(items, output_dir, options)
                self.done.emit(True, result)
            except Exception as exc:  # noqa: BLE001
                self.done.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _export_batch(self) -> None:
        if self._busy:
            return
        if not self._batch_series_dirs:
            self._choose_batch_series_dirs()
        if not self._batch_series_dirs:
            self.warn("Chưa chọn thư mục series để render hàng loạt.")
            return
        output_dir = Path(self.output_dir.text().strip())
        options = {
            "merge_video": self.merge_video_cb.isChecked(),
            "merge_srt": self.merge_srt_cb.isChecked(),
            "translate": self.translate_later_cb.isChecked(),
            "split_back": self.split_back_cb.isChecked(),
        }
        if (
            not options["merge_video"]
            and not options["merge_srt"]
            and not options["translate"]
        ):
            self.warn("Chọn ít nhất một đầu ra: video tổng, SRT tổng hoặc SRT dịch.")
            return
        dirs = [Path(p) for p in self._batch_series_dirs]
        self._set_busy(True)
        self._set_status(f"Chuẩn bị render hàng loạt {len(dirs)} series...")

        def worker() -> None:
            try:
                outputs: list[str] = []
                for index, folder in enumerate(dirs, start=1):
                    items = self._collect_series_items(folder)
                    if not items:
                        outputs.append(f"{folder.name}: bỏ qua vì không có video")
                        continue
                    name = self._safe_name(folder.name, f"series_{index:03d}")
                    series_out = output_dir / name
                    opts = dict(options)
                    opts["name"] = name
                    self.progress.emit(f"Series {index}/{len(dirs)}: {name}")
                    outputs.append(self._export_worker(items, series_out, opts, quiet=True))
                self.done.emit(True, "Render hàng loạt xong:\n" + "\n\n".join(outputs))
            except Exception as exc:  # noqa: BLE001
                self.done.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _export_worker(
        self, items: list[dict], output_dir: Path, options: dict, quiet: bool = False,
    ) -> str:
        output_dir.mkdir(parents=True, exist_ok=True)
        out_name = self._safe_name(str(options.get("name") or "series_full"), "series_full")
        ffmpeg = FFmpeg(
            self.app.config.ffmpeg_path,
            self.app.config.ffprobe_path,
            timeout_seconds=getattr(self.app.config, "ffmpeg_timeout_seconds", 21600),
        )
        offset = 0.0
        merged_segments: list[Segment] = []
        video_paths: list[str] = []
        episodes: list[tuple[str, float, float]] = []   # (tên tập, offset, duration)
        overrun_notes: list[str] = []
        total = len(items)

        for index, item in enumerate(items, start=1):
            video = str(item["video"])
            if not Path(video).exists():
                raise FileNotFoundError(f"Không thấy video: {video}")
            self.progress.emit(f"Đọc {index}/{total}: {Path(video).name}")
            duration = ffmpeg.duration(video)
            if duration <= 0:
                # Duration hỏng mà cứ đi tiếp thì offset các tập sau sập hết ->
                # toàn bộ sub từ đây lẫn sang nhau. Dừng ngay còn hơn ra file sai.
                raise ValueError(
                    f"Không đọc được thời lượng video (file hỏng?): {Path(video).name}"
                )
            item["duration"] = duration
            video_paths.append(video)
            episodes.append((Path(video).stem, offset, duration))

            sub = str(item.get("sub") or "")
            if sub and Path(sub).exists():
                segments = load_subtitle_file(sub)
                # Sub có dòng BẮT ĐẦU sau khi video hết = gần như chắc ghép nhầm
                # cặp (sub của tập khác). Không chặn, nhưng phải nói to.
                overrun = sub_overrun(segments, duration)
                for seg in segments:
                    text = clean_subtitle_text(seg.text or seg.translation or "")
                    merged_segments.append(Segment(
                        line=len(merged_segments) + 1,
                        start=seg.start + offset,
                        end=seg.end + offset,
                        text=text,
                        translation=seg.translation,
                        speaker=seg.speaker,
                        gender=seg.gender,
                        voice=seg.voice,
                    ))
                nonempty = sum(1 for seg in segments if (seg.text or seg.translation or "").strip())
                if overrun:
                    item["status"] = f"⚠ {overrun} dòng sau khi video hết — sub có đúng tập này?"
                    overrun_notes.append(
                        f"{Path(video).name} ↔ {Path(sub).name}: {overrun} dòng vượt thời lượng"
                    )
                else:
                    item["status"] = f"OK ({nonempty}/{len(segments)} dòng)"
            else:
                item["status"] = "Không có SRT"
            offset += duration

        if (
            (options.get("merge_srt") or options.get("translate"))
            and not any((seg.text or "").strip() for seg in merged_segments)
        ):
            raise ValueError(
                "SRT tổng không có nội dung chữ. Kiểm tra file sub đầu vào hoặc định dạng sub."
            )

        outputs: list[str] = []
        srt_path = output_dir / f"{out_name}.srt"
        if options.get("merge_srt") or options.get("translate"):
            write_srt(merged_segments, srt_path, translated=False)
            outputs.append(str(srt_path))
            # Manifest offset: bằng chứng ghép + đầu vào cho tách ngược sau này.
            manifest_path = output_dir / f"{out_name}.episodes.json"
            manifest_path.write_text(json.dumps({
                "episodes": [
                    {"name": name, "offset": round(off, 3), "duration": round(dur, 3),
                     "video": video_paths[i], "sub": str(items[i].get("sub") or "")}
                    for i, (name, off, dur) in enumerate(episodes)
                ],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            outputs.append(str(manifest_path))

        if options.get("translate"):
            self.progress.emit("Đang dịch SRT tổng...")
            translated_path, translated_rows = self._translate_merged_srt(
                merged_segments, output_dir, out_name)
            outputs.append(str(translated_path))
            if options.get("split_back"):
                self.progress.emit("Đang tách SRT dịch về từng tập...")
                per_dir = output_dir / f"{out_name}_tung_tap"
                per_dir.mkdir(parents=True, exist_ok=True)
                for order, (name, rows) in enumerate(
                        split_by_episodes(translated_rows, episodes), start=1):
                    if not rows:
                        continue
                    write_srt(rows, per_dir / f"{order:03d}_{name}.srt", translated=True)
                outputs.append(str(per_dir))

        if overrun_notes:
            outputs.append("⚠ Kiểm lại các cặp nghi ghép nhầm:\n  " + "\n  ".join(overrun_notes))

        if options.get("merge_video"):
            video_path = output_dir / f"{out_name}.mp4"
            self.progress.emit("Đang ghép video tổng bằng FFmpeg...")
            mode = ffmpeg.concat_auto(video_paths, str(video_path))
            if mode == "copy":
                self.progress.emit("Đã nối nhanh video, không encode lại.")
            else:
                self.progress.emit("Video khác chuẩn hoặc nối nhanh lỗi, đã render lại.")
            outputs.append(str(video_path))

        if not quiet:
            self.items = items
        return f"{out_name}:\n" + "\n".join(outputs)

    def _translate_merged_srt(
        self, segments: list[Segment], output_dir: Path, out_name: str,
    ) -> tuple[Path, list[Segment]]:
        if not segments:
            raise ValueError("Không có dòng phụ đề để dịch.")
        if not str(getattr(self.app.config, "target_language", "") or "").strip():
            raise ValueError("Chưa chọn ngôn ngữ đích ở phần Dịch tự động.")

        from vicdub.api.gemini_client import GeminiClient  # noqa: PLC0415
        from vicdub.modules.translate_module import TranslateModule  # noqa: PLC0415

        work_root = output_dir / ".series_translate"
        (work_root / "subtitles").mkdir(parents=True, exist_ok=True)

        class SeriesProject:
            def __init__(self, root: Path, rows: list[Segment]) -> None:
                self.root = str(root)
                self._segments = rows

            def load_segments(self) -> list[Segment]:
                return self._segments

            def save_segments(self, rows: list[Segment]) -> None:
                self._segments = rows

            def update_segment(self, segment: Segment) -> None:
                if 1 <= segment.line <= len(self._segments):
                    self._segments[segment.line - 1] = segment

            def add_history(self, *_args, **_kwargs) -> None:
                return None

        project = SeriesProject(work_root, segments)
        module = TranslateModule()
        module.attach(
            lambda pct, msg: self.progress.emit(f"Dịch SRT tổng {pct}% - {msg}"),
            threading.Event(),
        )
        result = module.run({
            "project": project,
            "segments": segments,
            "config": self.app.config,
            "tm": self.app.tm,
            "gemini": GeminiClient(self.app.api) if self.app.api.keys else None,
        })
        translated_path = output_dir / f"{out_name}.translated.srt"
        shutil.copyfile(result["translated_srt"], translated_path)
        # Trả cả segments đã dịch (module cập nhật vào project) để tách từng tập.
        return translated_path, project.load_segments()

    def _on_done(self, ok: bool, message: str) -> None:
        self._set_busy(False)
        self._render()
        if ok:
            self.info(message)
            self._set_status("Ghép series xong.")
        else:
            self.warn(f"Ghép series lỗi: {message}")
            self._set_status("Ghép series lỗi.")





# ====================================================================
class ExportPage(BasePage):
    """Studio xuất video: demo + timeline 3 track, điều khiển gọn bên phải."""

    #: Báo từ worker thread (thông điệp) - cập nhật status + timeline.
    bg_done = pyqtSignal(str)
    #: Khung hình preview đã trích xong (đường dẫn ảnh).
    frame_ready = pyqtSignal(str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Xuất video", "Xem trước, thiết lập và tạo video cuối.")
        self.bg_done.connect(self._on_bg_done)
        self.frame_ready.connect(self._on_frame_ready)
        self._selected_line: int | None = None
        self._timeline_segments: list[Segment] = []
        self._timeline_by_line: dict[int, Segment] = {}
        self._scrub_busy = False
        self._scrub_pending: float | None = None
        self._frame_request_seconds: float | None = None
        self._frame_timer = QTimer(self)
        self._frame_timer.setSingleShot(True)
        self._frame_timer.setInterval(160)
        self._frame_timer.timeout.connect(self._flush_frame_request)
        self._volume_guard = False

        columns = QHBoxLayout()
        self.body.addLayout(columns, 1)

        # ================= Cột trái: demo + timeline =================
        left = QVBoxLayout()
        columns.addLayout(left, 1)

        # Nút bật/tắt bảng tùy chọn xuất - mặc định ẩn cho khung làm việc rộng.
        top_row = QHBoxLayout()
        top_row.addStretch()
        self.btn_toggle_panel = QPushButton("Thiết lập xuất ▸")
        self.btn_toggle_panel.setToolTip(
            "Hiện/ẩn thiết lập âm lượng, phụ đề, thư mục xuất và lệnh xuất video"
        )
        self.btn_toggle_panel.clicked.connect(self._toggle_panel)
        top_row.addWidget(self.btn_toggle_panel)
        left.addLayout(top_row)

        # ----- Khung xem trước video (chữ sub tiếng Việt vẽ luôn lên hình) -----
        self.preview_frame = DraggableSubtitlePreview(
            "(kéo playhead trên thước thời gian\nhoặc click block để xem khung hình)"
        )
        self.preview_frame.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_frame.setMinimumSize(640, 400)
        self.preview_frame.setStyleSheet(
            "background-color: #0f1724; border: 1px solid #223044; "
            "border-radius: 6px; color: #9fb0c2;"
        )
        self.preview_frame.setToolTip(
            "Giữ chuột trái và kéo trên khung hình để đặt vị trí phụ đề."
        )
        self.preview_frame.position_changed.connect(self._on_subtitle_dragged)
        left.addWidget(self.preview_frame, 3)
        self.preview_meta = muted_label("")
        left.addWidget(self.preview_meta)
        # Khung hình gốc gần nhất + chữ sub hiện tại, để vẽ lại overlay khi
        # đổi vị trí chữ hoặc đổi dòng mà chưa có khung mới.
        self._preview_pixmap: QPixmap | None = None
        self._preview_sub = ""
        self._preview_original = ""

        # ----- Timeline -----
        timeline_head = QHBoxLayout()
        timeline_head.addWidget(title_label("Dòng thời gian"))
        timeline_head.addStretch()
        timeline_head.addWidget(QLabel("Zoom:"))
        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setRange(5, 200)
        self.zoom_slider.setValue(40)
        self.zoom_slider.setFixedWidth(160)
        self.zoom_slider.valueChanged.connect(self._on_zoom)
        timeline_head.addWidget(self.zoom_slider)
        left.addLayout(timeline_head)

        self.timeline = TimelineWidget()
        self.timeline.line_clicked.connect(self._on_timeline_click)
        self.timeline.line_played.connect(self._on_timeline_play)
        self.timeline.time_scrubbed.connect(self._on_scrub)
        scroll = QScrollArea()
        scroll.setWidgetResizable(False)
        scroll.setWidget(self.timeline)
        scroll.setMinimumHeight(170)
        left.addWidget(scroll, 1)

        left.addWidget(muted_label(
            "TÍM = đoạn video | XANH DƯƠNG = phụ đề | "
            "XANH LÁ = giọng khớp | CAM = giọng dài | "
            "XÁM = chưa có."
        ))

        # ================= Cột phải: điều khiển thu gọn =================
        panel = QFrame()
        panel.setObjectName("exportPanelShell")
        panel.setFixedWidth(360)
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)
        panel_scroll = QScrollArea()
        panel_scroll.setObjectName("exportPanelScroll")
        panel_scroll.setWidgetResizable(True)
        panel_scroll.setFrameShape(QFrame.Shape.NoFrame)
        panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        panel_content = QWidget()
        panel_content.setObjectName("exportPanel")
        panel_content.setMinimumWidth(330)
        right = QVBoxLayout(panel_content)
        right.setContentsMargins(12, 12, 12, 16)
        right.setSpacing(12)
        panel_scroll.setWidget(panel_content)
        panel_layout.addWidget(panel_scroll)
        columns.addWidget(panel)
        self.panel = panel
        self._panel_shown = False
        panel.setVisible(False)  # ẩn mặc định, bấm "Thiết lập xuất" mới hiện

        def add_card(title: str) -> QVBoxLayout:
            card = QFrame()
            card.setObjectName("exportSection")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 10, 12, 12)
            card_layout.setSpacing(8)
            card_layout.addWidget(title_label(title))
            right.addWidget(card)
            return card_layout

        output_actions = add_card("Tạo video cuối")
        btn_merge = QPushButton("Xuất video")
        btn_merge.setToolTip(
            "Dùng voice đã render để ghép vào video gốc và chèn phụ đề theo lựa chọn bên dưới."
        )
        btn_merge.setProperty("variant", "primary")
        btn_merge.clicked.connect(lambda: self._run(["merge"]))
        btn_open = QPushButton("Mở thư mục xuất")
        btn_open.clicked.connect(self._open_output)
        for b in (btn_merge, btn_open):
            b.setMinimumHeight(38)
            output_actions.addWidget(b)

        render_card = add_card("Chế độ render")
        self.render_profile_combo = QComboBox()
        self.render_profile_combo.addItem(
            "Tự động — ưu tiên GPU (khuyên dùng)", "auto"
        )
        self.render_profile_combo.addItem("Nhanh — ưu tiên tốc độ", "fast")
        self.render_profile_combo.addItem("Cân bằng — chất lượng / tốc độ", "balanced")
        self.render_profile_combo.addItem("Chất lượng cao — CPU", "quality")
        self.render_profile_combo.setToolTip(
            "Tự động sẽ thử NVIDIA GPU trước; nếu GPU lỗi, ứng dụng tự chuyển "
            "sang CPU và tiếp tục xuất."
        )
        self.render_profile_combo.currentIndexChanged.connect(
            self._on_render_profile
        )
        render_card.addWidget(self.render_profile_combo)
        render_hint = muted_label(
            "Hard-sub cần xử lý lại hình. Không hard-sub và không kéo hình sẽ "
            "giữ nguyên luồng video để xuất nhanh."
        )
        render_hint.setWordWrap(True)
        render_card.addWidget(render_hint)

        audio_card = add_card("Âm lượng")
        self.bg_vol_label = muted_label("")
        self.bg_slider = QSlider(Qt.Orientation.Horizontal)
        self.bg_slider.setRange(0, 100)
        self.bg_slider.valueChanged.connect(self._on_volumes)
        self.voice_vol_label = muted_label("")
        self.voice_slider = QSlider(Qt.Orientation.Horizontal)
        self.voice_slider.setRange(10, 200)
        self.voice_slider.valueChanged.connect(self._on_volumes)
        audio_card.addWidget(self.bg_vol_label)
        audio_card.addWidget(self.bg_slider)
        audio_card.addWidget(self.voice_vol_label)
        audio_card.addWidget(self.voice_slider)
        audio_hint = muted_label("Điều chỉnh âm nền và giọng đọc trong video xuất.")
        audio_hint.setWordWrap(True)
        audio_card.addWidget(audio_hint)

        subtitle_card = add_card("Phụ đề trong video")
        self.radio_none = QRadioButton("Không có phụ đề")
        self.radio_hard = QRadioButton("Cố định trên video")
        self.radio_soft = QRadioButton("Track bật / tắt")
        for radio, mode_name in (
            (self.radio_none, "none"),
            (self.radio_hard, "hard"),
            (self.radio_soft, "soft"),
        ):
            radio.setObjectName("subtitleMode")
            radio.setProperty("mode", mode_name)
            radio.setMinimumHeight(42)
            radio.toggled.connect(self._on_sub_mode_changed)
            subtitle_card.addWidget(radio)
        subtitle_hint = muted_label("Chọn cách hiển thị phụ đề trong video xuất.")
        subtitle_hint.setWordWrap(True)
        subtitle_card.addWidget(subtitle_hint)

        self.sub_position_label = QLabel("Vị trí chữ:")
        subtitle_card.addWidget(self.sub_position_label)
        self.sub_position = QComboBox()
        self.sub_position.addItem("Dưới", "bottom")
        self.sub_position.addItem("Giữa", "center")
        self.sub_position.addItem("Trên", "top")
        self.sub_position.addItem("Tùy chỉnh — kéo trên ảnh", "custom")
        self.sub_position.setToolTip(
            "Vị trí dòng phụ đề - áp cho cả khung xem trước lẫn video xuất ra."
        )
        self.sub_position.currentIndexChanged.connect(self._on_sub_position)
        self.sub_position.setMinimumHeight(36)
        subtitle_card.addWidget(self.sub_position)

        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Cỡ chữ:"))
        self.sub_font_size = QSpinBox()
        self.sub_font_size.setRange(10, 72)
        self.sub_font_size.setMinimumWidth(110)
        self.sub_font_size.valueChanged.connect(self._on_sub_style)
        size_row.addWidget(self.sub_font_size)
        subtitle_card.addLayout(size_row)
        self.sub_bg = QCheckBox("Nền hộp mờ sau chữ")
        self.sub_bg.setToolTip("Vẽ nền tối sau chữ cho dễ đọc trên cảnh sáng")
        self.sub_bg.toggled.connect(self._on_sub_style)
        subtitle_card.addWidget(self.sub_bg)
        self.blur_original_sub = QCheckBox("Làm mờ phụ đề gốc")
        self.blur_original_sub.setToolTip(
            "Chỉ làm mờ vùng phụ đề gốc trong đúng thời gian từng câu xuất hiện."
        )
        self.blur_original_sub.toggled.connect(self._on_sub_style)
        subtitle_card.addWidget(self.blur_original_sub)
        blur_size_row = QHBoxLayout()
        self.blur_size_label = QLabel("Độ phủ vùng mờ:")
        self.blur_size = QSpinBox()
        self.blur_size.setRange(80, 250)
        self.blur_size.setMinimumWidth(110)
        self.blur_size.setSingleStep(10)
        self.blur_size.setSuffix("%")
        self.blur_size.setToolTip(
            "100% bám sát chữ; tăng tỷ lệ để vùng mờ phủ rộng hơn quanh câu gốc."
        )
        self.blur_size.valueChanged.connect(self._on_sub_style)
        blur_size_row.addWidget(self.blur_size_label)
        blur_size_row.addWidget(self.blur_size)
        subtitle_card.addLayout(blur_size_row)
        drag_hint = muted_label(
            "Kéo chữ trực tiếp trên ảnh xem trước để đặt vị trí tự do."
        )
        drag_hint.setWordWrap(True)
        subtitle_card.addWidget(drag_hint)

        folder_card = add_card("Thư mục xuất")
        self.export_label = muted_label("")
        self.export_label.setWordWrap(True)
        folder_card.addWidget(self.export_label)
        btn_pick_export = QPushButton("Chọn thư mục xuất...")
        btn_pick_export.clicked.connect(self._pick_export_dir)
        btn_reset_export = QPushButton("Dùng thư mục dự án")
        btn_reset_export.clicked.connect(self._reset_export_dir)
        btn_pick_export.setMinimumHeight(36)
        btn_reset_export.setMinimumHeight(36)
        folder_card.addWidget(btn_pick_export)
        folder_card.addWidget(btn_reset_export)

        self.result_label = muted_label("")
        self.result_label.setWordWrap(True)
        right.addWidget(self.result_label)
        right.addStretch()

    def refresh(self) -> None:
        mode = self.app.config.subtitle_mode
        self.radio_none.setChecked(mode == "none")
        self.radio_hard.setChecked(mode == "hard")
        self.radio_soft.setChecked(mode == "soft")
        profile = str(getattr(self.app.config, "render_profile", "auto") or "auto")
        profile_index = self.render_profile_combo.findData(profile)
        self.render_profile_combo.blockSignals(True)
        self.render_profile_combo.setCurrentIndex(
            profile_index if profile_index >= 0 else 0
        )
        self.render_profile_combo.blockSignals(False)
        export_dir = self.app.config.export_dir
        self.export_label.setText(
            f"Xuất về: {export_dir}" if export_dir
            else "Xuất về: projects\\<tên project>\\output (mặc định)"
        )
        pos = getattr(self.app.config, "subtitle_position", "bottom")
        idx = self.sub_position.findData(pos)
        self.sub_position.blockSignals(True)
        self.sub_position.setCurrentIndex(idx if idx >= 0 else 0)
        self.sub_position.blockSignals(False)
        self.sub_font_size.blockSignals(True)
        self.sub_font_size.setValue(int(getattr(self.app.config, "subtitle_font_size", 24)))
        self.sub_font_size.blockSignals(False)
        self.sub_bg.blockSignals(True)
        self.sub_bg.setChecked(bool(getattr(self.app.config, "subtitle_bg", False)))
        self.sub_bg.blockSignals(False)
        self.blur_original_sub.blockSignals(True)
        self.blur_original_sub.setChecked(bool(
            getattr(self.app.config, "subtitle_blur_original", False)
        ))
        self.blur_original_sub.blockSignals(False)
        self.blur_size.blockSignals(True)
        self.blur_size.setValue(int(
            getattr(self.app.config, "subtitle_blur_scale", 140)
        ))
        self.blur_size.blockSignals(False)
        self._update_subtitle_controls()
        self._volume_guard = True
        self.bg_slider.setValue(self.app.config.bg_volume)
        self.voice_slider.setValue(self.app.config.voice_volume)
        self._volume_guard = False
        self._on_volumes()
        final = self.app.engine.context.get("final_video", "")
        if final:
            self.result_label.setText(f"Video hoàn chỉnh: {final}")
        self._refresh_timeline()

    def _refresh_timeline(self) -> None:
        project = self.app.projects.current
        if not project:
            self._timeline_segments = []
            self._timeline_by_line = {}
            self.timeline.set_data([], {}, {})
            return
        segments = project.load_segments()
        self._timeline_segments = segments
        self._timeline_by_line = {s.line: s for s in segments}
        voices: dict[int, tuple[float, bool]] = {}
        clips: dict[int, bool] = {}
        for seg in segments:
            wav = project_voice_path(project.root, seg.line)
            if wav.exists():
                dur = wav_seconds(wav)
                if dur > 0:
                    voices[seg.line] = (dur, dur <= seg.duration + 0.05)
            clips[seg.line] = project_clip_path(project.root, seg.line).exists()
        self.timeline.set_data(segments, voices, clips)

    def _toggle_panel(self) -> None:
        """Hiện/ẩn bảng tùy chọn xuất bên phải để khung làm việc rộng hơn."""
        self._panel_shown = not self._panel_shown
        self.panel.setVisible(self._panel_shown)
        self.btn_toggle_panel.setText(
            "Ẩn thiết lập ◂" if self._panel_shown else "Thiết lập xuất ▸"
        )

    def _on_zoom(self, value: int) -> None:
        self.timeline.set_zoom(float(value))

    def _on_timeline_click(self, line: int) -> None:
        """Click block: hiện chữ sub + khung hình video của dòng đó."""
        project = self.app.projects.current
        if not project:
            return
        seg = self._timeline_by_line.get(line)
        if seg is None:
            return
        self._selected_line = line

        # Chữ sub tiếng Việt vẽ luôn lên khung xem trước.
        self._preview_sub = seg.translation or seg.text
        self._preview_original = seg.text
        self._render_preview()
        wav = project_voice_path(project.root, line)
        voice_note = (f"voice {wav_seconds(wav):.1f}s" if wav.exists()
                      else "chưa có voice")
        self.preview_meta.setText(
            f"Dòng {line} | {seg.speaker} | "
            f"{seg.start:.2f}s - {seg.end:.2f}s ({seg.duration:.1f}s) | "
            f"{voice_note}"
        )
        self.app.show_status(f"Đã chọn dòng {line}.")
        self._request_frame(seg.start + 0.1)

    def _on_scrub(self, seconds: float) -> None:
        """Kéo playhead: preview khung hình + thông tin dòng tại vị trí đó."""
        project = self.app.projects.current
        if not project:
            return
        seg = next((s for s in self._timeline_segments
                    if s.start <= seconds <= s.end), None)
        if seg is not None:
            self._selected_line = seg.line
            self.timeline.select_line(seg.line)
            self._preview_sub = seg.translation or seg.text
            self._preview_original = seg.text
            wav = project_voice_path(project.root, seg.line)
            voice_note = (f"voice {wav_seconds(wav):.1f}s" if wav.exists()
                          else "chưa có voice")
            self.preview_meta.setText(
                f"⏱ {seconds:.2f}s | dòng {seg.line} | {seg.speaker} | "
                f"{voice_note}"
            )
        else:
            self._preview_sub = ""
            self._preview_original = ""
            self.preview_meta.setText(f"⏱ {seconds:.2f}s (khoảng lặng)")
        self._render_preview()
        self._request_frame(seconds)

    def _request_frame(self, seconds: float) -> None:
        self._frame_request_seconds = seconds
        self._frame_timer.start()

    def _flush_frame_request(self) -> None:
        """Trích khung hình ở thread nền, có chống dội khi kéo nhanh."""
        if self._frame_request_seconds is None:
            return
        seconds = self._frame_request_seconds
        self._frame_request_seconds = None
        project = self.app.projects.current
        if not project:
            return
        video = project.video_path
        if not video or not Path(video).exists():
            return
        if self._scrub_busy:
            self._scrub_pending = seconds  # đang bận thì nhớ vị trí mới nhất
            return
        self._scrub_busy = True
        config = self.app.config
        out = str(Path(project.root) / "output" / "_frame.png")

        def work() -> None:
            try:
                FFmpeg(config.ffmpeg_path, config.ffprobe_path).extract_frame(
                    video, max(0.0, seconds), out
                )
                self.frame_ready.emit(out)
            except Exception:  # noqa: BLE001 - preview lỗi thì thôi
                self.frame_ready.emit("")

        threading.Thread(target=work, daemon=True).start()

    def _on_frame_ready(self, image_path: str) -> None:
        self._scrub_busy = False
        if image_path:
            pixmap = QPixmap(image_path)
            if not pixmap.isNull():
                self._preview_pixmap = pixmap
                self._render_preview()
        if self._scrub_pending is not None:
            pending, self._scrub_pending = self._scrub_pending, None
            self._request_frame(pending)

    def _on_sub_position(self, _idx: int = 0) -> None:
        """Đổi vị trí chữ: lưu config + vẽ lại khung xem trước."""
        pos = self.sub_position.currentData() or "bottom"
        self.app.config.subtitle_position = pos
        presets = {
            "bottom": (0.5, 0.90), "center": (0.5, 0.50), "top": (0.5, 0.10),
        }
        if pos in presets:
            self.app.config.subtitle_x, self.app.config.subtitle_y = presets[pos]
        self.app.config.save()
        self._render_preview()

    def _on_sub_mode_changed(self, checked: bool) -> None:
        if not checked:
            return
        self._apply_mode()
        self._update_subtitle_controls()

    def _update_subtitle_controls(self) -> None:
        """Only hard subtitles own appearance/position; soft tracks use player style."""
        hard = self.radio_hard.isChecked()
        for widget in (
            self.sub_position_label, self.sub_position, self.sub_font_size, self.sub_bg,
        ):
            widget.setEnabled(hard)
        blur_enabled = self.blur_original_sub.isChecked()
        self.blur_size_label.setEnabled(blur_enabled)
        self.blur_size.setEnabled(blur_enabled)
        self.preview_frame.setToolTip(
            "Giữ chuột trái và kéo để đặt vị trí phụ đề cố định."
            if hard else
            "Chọn 'Cố định trên video' để kéo thả vị trí phụ đề."
        )

    def _on_subtitle_dragged(self, x: float, y: float) -> None:
        """Save free subtitle coordinates selected directly on the preview."""
        if not self.radio_hard.isChecked():
            return
        self.app.config.subtitle_position = "custom"
        self.app.config.subtitle_x = round(float(x), 4)
        self.app.config.subtitle_y = round(float(y), 4)
        custom_index = self.sub_position.findData("custom")
        self.sub_position.blockSignals(True)
        self.sub_position.setCurrentIndex(custom_index)
        self.sub_position.blockSignals(False)
        self.app.config.save()
        self._render_preview()

    def _on_sub_style(self, _v: object = None) -> None:
        """Đổi cỡ chữ / nền: lưu config + vẽ lại khung xem trước."""
        self.app.config.subtitle_font_size = self.sub_font_size.value()
        self.app.config.subtitle_bg = self.sub_bg.isChecked()
        self.app.config.subtitle_blur_original = self.blur_original_sub.isChecked()
        self.app.config.subtitle_blur_scale = self.blur_size.value()
        self.blur_size_label.setEnabled(self.blur_original_sub.isChecked())
        self.blur_size.setEnabled(self.blur_original_sub.isChecked())
        self.app.config.save()
        self._render_preview()

    def _render_preview(self) -> None:
        """Vẽ khung hình gốc gần nhất, chồng chữ sub tiếng Việt lên theo vị trí."""
        if self._preview_pixmap is None or self._preview_pixmap.isNull():
            return
        scaled = self._preview_pixmap.scaled(
            self.preview_frame.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        cfg = self.app.config
        project = self.app.projects.current
        preview_region = tuple(
            project.get_ocr_region(
                getattr(cfg, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
            ) if project else
            (getattr(cfg, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0))
        )
        if (bool(getattr(cfg, "subtitle_blur_original", False))
                and (self._preview_sub or "").strip()):
            self._draw_preview_blur(
                scaled,
                preview_region,
                self._preview_original,
                int(getattr(cfg, "subtitle_blur_scale", 140)),
            )
        text = (self._preview_sub or "").strip()
        if text:
            scaled = QPixmap(scaled)  # bản sao để vẽ đè
            self._draw_subtitle(
                scaled, text,
                getattr(cfg, "subtitle_position", "bottom"),
                int(getattr(cfg, "subtitle_font_size", 24)),
                bool(getattr(cfg, "subtitle_bg", False)),
                float(getattr(cfg, "subtitle_x", 0.5)),
                float(getattr(cfg, "subtitle_y", 0.90)),
            )
        self.preview_frame.setPixmap(scaled)

    @staticmethod
    def _draw_preview_blur(pixmap: QPixmap, region, text: str,
                           scale_percent: int = 140) -> None:
        """Preview the per-subtitle blur box, not the whole OCR strip."""
        x0, y0, x1, y1 = (max(0.0, min(1.0, float(v))) for v in region)
        x0, x1 = sorted((x0, x1)); y0, y1 = sorted((y0, y1))
        region_w = max(1, round(pixmap.width() * (x1 - x0)))
        region_h = max(1, round(pixmap.height() * (y1 - y0)))
        font_px = max(9, min(34, round(region_h * 0.32)))
        metrics = QFontMetrics(QFont("Arial", font_px, QFont.Weight.Bold))
        lines = (text or " ").splitlines() or [" "]
        content_w = max(metrics.horizontalAdvance(line) for line in lines)
        content_h = metrics.height() * max(1, len(lines))
        pad = max(5, font_px // 4)
        scale = max(0.8, min(2.5, float(scale_percent) / 100.0))
        box_w = min(region_w, round((content_w + 2 * pad) * scale))
        box_h = min(region_h, round((content_h + 2 * pad) * scale))
        center_x = round(pixmap.width() * (x0 + x1) / 2.0)
        center_y = round(pixmap.height() * (y0 + y1) / 2.0)
        rect = QRect(
            max(0, center_x - box_w // 2), max(0, center_y - box_h // 2),
            box_w, box_h,
        )
        crop = pixmap.copy(rect)
        tiny = crop.scaled(
            max(1, crop.width() // 24), max(1, crop.height() // 12),
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        blurred = tiny.scaled(
            crop.size(), Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        painter = QPainter(pixmap)
        painter.drawPixmap(rect.topLeft(), blurred)
        painter.end()

    @staticmethod
    def _draw_subtitle(pixmap: QPixmap, text: str, position: str,
                       font_size: int = 24, background: bool = False,
                       x: float = 0.5, y: float = 0.90) -> None:
        """Vẽ chữ phụ đề lên pixmap tại vị trí chọn (mô phỏng cỡ chữ + nền).

        font_size hiểu theo hệ ASS (~cao khung 360) nên quy về pixel theo chiều
        cao khung xem trước cho gần đúng với video xuất ra.
        """
        painter = QPainter(pixmap)
        w, h = pixmap.width(), pixmap.height()
        px = max(9, round(h * font_size / 360.0))
        font = QFont("Arial", px)
        font.setBold(True)
        painter.setFont(font)
        margin = max(8, h // 28)
        flags = int(Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap)
        rect_w = max(1, w - 2 * margin)
        bound = painter.boundingRect(QRect(margin, 0, rect_w, h), flags, text)
        if position == "top":
            x, y = 0.5, 0.10
        elif position == "center":
            x, y = 0.5, 0.50
        elif position == "bottom":
            x, y = 0.5, 0.90
        center_x = round(max(0.03, min(0.97, x)) * w)
        center_y = round(max(0.03, min(0.97, y)) * h)
        left = max(margin, min(w - rect_w - margin, center_x - rect_w // 2))
        top = max(0, min(h - bound.height(), center_y - bound.height() // 2))
        rect = QRect(left, top, rect_w, bound.height())
        if background:
            box = rect.adjusted(-margin // 2, -margin // 4, margin // 2, margin // 4)
            painter.fillRect(box, QColor(0, 0, 0, 140))
            painter.setPen(QColor(255, 255, 255))
            painter.drawText(rect, flags, text)
        else:
            painter.setPen(QColor(0, 0, 0))
            for dx, dy in ((-2, -2), (-2, 2), (2, -2), (2, 2),
                           (-2, 0), (2, 0), (0, -2), (0, 2)):
                painter.drawText(rect.translated(dx, dy), flags, text)
            painter.setPen(QColor(255, 255, 255))
            painter.drawText(rect, flags, text)
        painter.end()

    def _on_volumes(self, _value: int = 0) -> None:
        """Slider âm lượng đổi: cập nhật nhãn + lưu cấu hình."""
        self.bg_vol_label.setText(f"Âm nền video: {self.bg_slider.value()}%")
        self.voice_vol_label.setText(f"Giọng đọc: {self.voice_slider.value()}%")
        if self._volume_guard:
            return
        self.app.config.bg_volume = self.bg_slider.value()
        self.app.config.voice_volume = self.voice_slider.value()
        self.app.config.save()

    def _on_render_profile(self, _index: int = 0) -> None:
        profile = self.render_profile_combo.currentData() or "auto"
        self.app.config.render_profile = str(profile)
        self.app.config.save()

    def _on_bg_done(self, message: str) -> None:
        self.app.show_status(message)
        self._refresh_timeline()

    def _on_timeline_play(self, line: int) -> None:
        project = self.app.projects.current
        if not project:
            return
        wav = project_voice_path(project.root, line)
        if wav.exists():
            self.app.play_audio(str(wav))
            self.app.show_status(f"Đang phát voice dòng {line}.")
        else:
            self.app.show_status(f"Dòng {line} chưa render voice.")

    def _pick_export_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất video")
        if folder:
            self.app.config.export_dir = folder
            self.app.config.save()
            self.refresh()

    def _reset_export_dir(self) -> None:
        self.app.config.export_dir = ""
        self.app.config.save()
        self.refresh()

    def _apply_mode(self) -> None:
        if self.radio_hard.isChecked():
            self.app.config.subtitle_mode = "hard"
        elif self.radio_soft.isChecked():
            self.app.config.subtitle_mode = "soft"
        else:
            self.app.config.subtitle_mode = "none"
        self.app.config.save()

    def _run(self, steps: list[str]) -> None:
        if self.need_project():
            return
        # Xuất khi đang để không có phụ đề -> nhắc bật chế độ cố định,
        # tránh xuất ra video không có chữ dù preview vẫn hiện chữ.
        if "merge" in steps and self.radio_none.isChecked():
            if self.confirm(
                "Đang để 'Không có phụ đề' nên video xuất ra sẽ không có chữ.\n"
                "Bật 'Cố định trên video' để ghép chữ vào hình?"
            ):
                self.radio_hard.setChecked(True)
        self._apply_mode()
        self.app.start_pipeline(steps)

    def _open_output(self) -> None:
        if self.app.config.export_dir:
            out = Path(self.app.config.export_dir)
        else:
            if self.need_project():
                return
            out = Path(self.app.projects.current.root) / "output"
        out.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(out))  # noqa: S606


# ====================================================================
class ComponentsPage(BasePage):
    """Tab Cập nhật: kiểm tra & tải các thành phần còn thiếu (voice, FFmpeg...).

    App-first: bản cài nhẹ mở được ngay; phần NẶNG (PyTorch, model giọng ~3GB,
    FFmpeg) tải ở đây khi cần — có tiến trình, huỷ được, chọn CPU/GPU.
    """

    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    update_checked = pyqtSignal(object, str, bool)
    update_progress = pyqtSignal(int, str)
    update_downloaded = pyqtSignal(bool, str, object)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(
            app, "Cập nhật",
            "Chuẩn bị môi trường và giọng nói khi cần. App tự kiểm tra rồi cài "
            "tuần tự từng phần còn thiếu; không cần chạy install_models.bat.",
        )
        self._busy = False
        self._update_busy = False
        self._update_info = None
        self._cancel = threading.Event()
        self._components: list = []

        update_box = QFrame()
        update_box.setFrameShape(QFrame.Shape.StyledPanel)
        update_layout = QVBoxLayout(update_box)
        update_title = title_label("Cập nhật ứng dụng")
        self.app_version_label = QLabel(f"Phiên bản đang dùng: {__import__('vicdub').__version__}")
        self.app_update_status = muted_label("Sẵn sàng kiểm tra phiên bản mới.")
        update_actions = QHBoxLayout()
        self.btn_check_app_update = QPushButton("Kiểm tra cập nhật")
        self.btn_check_app_update.clicked.connect(lambda: self.check_app_update(False))
        self.btn_apply_app_update = QPushButton("Cập nhật ngay")
        self.btn_apply_app_update.setProperty("variant", "primary")
        self.btn_apply_app_update.setEnabled(False)
        self.btn_apply_app_update.clicked.connect(self._download_app_update)
        update_actions.addWidget(self.btn_check_app_update)
        update_actions.addWidget(self.btn_apply_app_update)
        update_actions.addStretch(1)
        self.app_update_bar = QProgressBar()
        self.app_update_bar.setRange(0, 100)
        self.app_update_bar.setValue(0)
        update_layout.addWidget(update_title)
        update_layout.addWidget(self.app_version_label)
        update_layout.addWidget(self.app_update_status)
        update_layout.addLayout(update_actions)
        update_layout.addWidget(self.app_update_bar)
        self.body.addWidget(update_box)

        top = QHBoxLayout()
        self.gpu_checkbox = QCheckBox("Dùng bản GPU (NVIDIA) cho giọng nói")
        self.gpu_checkbox.setToolTip(
            "Máy có card NVIDIA thì sinh giọng nhanh hơn nhiều nhưng phải tải "
            "~9GB; bản CPU chỉ ~0.5GB nhưng chậm."
        )
        top.addWidget(self.gpu_checkbox)
        top.addStretch(1)
        self.btn_refresh = QPushButton("Kiểm tra lại")
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_install_all = QPushButton("Chuẩn bị môi trường && giọng nói")
        self.btn_install_all.setProperty("variant", "primary")
        self.btn_install_all.clicked.connect(lambda: self._install(None))
        self.btn_cancel = QPushButton("Huỷ")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel.set)
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_install_all)
        top.addWidget(self.btn_cancel)
        self.body.addLayout(top)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(
            ["Thành phần", "Trạng thái", "Tải về", ""])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in (1, 2, 3):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.body.addWidget(self.table, 1)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.status_label = muted_label("Chưa kiểm tra.")
        self.body.addWidget(self.progress_bar)
        self.body.addWidget(self.status_label)

        self.progress.connect(self._on_progress)
        self.finished.connect(self._on_finished)
        self.update_checked.connect(self._on_update_checked)
        self.update_progress.connect(self._on_update_progress)
        self.update_downloaded.connect(self._on_update_downloaded)

    def check_app_update(self, silent: bool = False) -> None:
        if self._update_busy:
            return
        source = str(getattr(self.app.config, "update_manifest_url", "") or "").strip()
        source = source or os.environ.get("ANDREWSUB_UPDATE_URL", "").strip()
        if not source:
            if not silent:
                self.warn("Chưa cấu hình kênh cập nhật cho bản phát hành này.")
            return
        self._update_busy = True
        self.btn_check_app_update.setEnabled(False)
        self.app_update_status.setText("Đang kiểm tra phiên bản mới...")

        def worker() -> None:
            try:
                from vicdub import __version__  # noqa: PLC0415
                from vicdub.core.app_update import is_newer, load_manifest  # noqa: PLC0415
                info = load_manifest(source)
                if is_newer(info.version, __version__):
                    self.update_checked.emit(info, "", silent)
                else:
                    self.update_checked.emit(None, "Bạn đang dùng phiên bản mới nhất.", silent)
            except Exception as exc:  # noqa: BLE001
                self.update_checked.emit(None, str(exc), silent)

        threading.Thread(target=worker, daemon=True, name="app-update-check").start()

    def _on_update_checked(self, info, message: str, silent: bool) -> None:
        self._update_busy = False
        self.btn_check_app_update.setEnabled(True)
        self._update_info = info
        if info is None:
            self.btn_apply_app_update.setEnabled(False)
            if message:
                self.app_update_status.setText(message)
            if message and not silent and "mới nhất" not in message:
                self.warn(f"Không kiểm tra được cập nhật: {message}")
            return
        notes = "\n".join(f"• {item}" for item in info.notes)
        self.app_update_status.setText(f"Có phiên bản {info.version}." + (f"\n{notes}" if notes else ""))
        self.btn_apply_app_update.setEnabled(True)
        if silent:
            answer = QMessageBox.question(
                self, "Cập nhật ứng dụng",
                f"Có phiên bản {info.version}.\n\n{notes}\n\nCập nhật ngay?",
            )
            if answer == QMessageBox.StandardButton.Yes:
                self._download_app_update()

    def _download_app_update(self) -> None:
        if self._update_busy or self._update_info is None:
            return
        if self.app.engine.is_running() or getattr(self.app, "_batch_active", False):
            self.warn("Hãy hoàn tất hoặc hủy tác vụ đang chạy trước khi cập nhật.")
            return
        self._update_busy = True
        self._cancel.clear()
        self.btn_apply_app_update.setEnabled(False)
        info = self._update_info
        destination = Path(self.app.config.data_dir) / "updates"

        def worker() -> None:
            try:
                from vicdub.core.app_update import download_update  # noqa: PLC0415
                package = download_update(
                    info, destination,
                    progress=self.update_progress.emit,
                    cancelled=self._cancel.is_set,
                )
                self.update_downloaded.emit(True, str(package), info)
            except Exception as exc:  # noqa: BLE001
                self.update_downloaded.emit(False, str(exc), info)

        threading.Thread(target=worker, daemon=True, name="app-update-download").start()

    def _on_update_progress(self, pct: int, message: str) -> None:
        if pct >= 0:
            self.app_update_bar.setValue(pct)
        self.app_update_status.setText(message)

    def _on_update_downloaded(self, ok: bool, message: str, info) -> None:
        self._update_busy = False
        if not ok:
            self.btn_apply_app_update.setEnabled(True)
            self.warn(f"Tải cập nhật lỗi: {message}")
            return
        try:
            from vicdub.core.app_update import launch_updater  # noqa: PLC0415
            launch_updater(Path(message), info)
        except Exception as exc:  # noqa: BLE001
            self.btn_apply_app_update.setEnabled(True)
            self.warn(str(exc))
            return
        self.app_update_status.setText("Đang đóng ứng dụng để cài cập nhật...")
        QApplication.instance().quit()

    def has_background_task(self) -> bool:
        return self._busy or self._update_busy

    def cancel_background_tasks(self) -> None:
        self._cancel.set()

    def refresh(self) -> None:
        from vicdub.core import bootstrap  # noqa: PLC0415
        from vicdub.core.component_setup import (  # noqa: PLC0415
            estimate_size_gb, has_nvidia_gpu, installable,
        )

        if not self._busy:
            has_gpu = has_nvidia_gpu()
            self.gpu_checkbox.setChecked(has_gpu)
            self.gpu_checkbox.setEnabled(has_gpu)
            if not has_gpu:
                self.gpu_checkbox.setText("Không thấy card NVIDIA — dùng bản CPU")
        self._components = bootstrap.component_status(self.app.config)
        self.table.setRowCount(len(self._components))
        missing_installable = []
        for row, comp in enumerate(self._components):
            self.table.setItem(row, 0, QTableWidgetItem(comp.label))
            state = QTableWidgetItem("✅ Sẵn sàng" if comp.ready else "❌ Thiếu")
            self.table.setItem(row, 1, state)
            size = ""
            if not comp.ready and installable(comp.key):
                size = f"~{estimate_size_gb([comp.key], self.gpu_checkbox.isChecked()):g} GB"
                missing_installable.append(comp.key)
            self.table.setItem(row, 2, QTableWidgetItem(size))
            self.table.setCellWidget(row, 3, None)
            if not comp.ready and installable(comp.key):
                button = QPushButton("Tải && cài")
                button.setEnabled(not self._busy)
                button.clicked.connect(
                    lambda _checked=False, key=comp.key: self._install([key]))
                self.table.setCellWidget(row, 3, button)
            elif not comp.ready:
                hint = QTableWidgetItem(comp.detail or "Cài thủ công")
                self.table.setItem(row, 3, hint)
        self.btn_install_all.setEnabled(bool(missing_installable) and not self._busy)
        if missing_installable:
            total = estimate_size_gb(missing_installable, self.gpu_checkbox.isChecked())
            self.status_label.setText(
                f"Thiếu {len(missing_installable)} thành phần — tổng cần tải ~{total:g} GB."
            )
        else:
            self.status_label.setText("Mọi thành phần đã sẵn sàng. 🎉")

    def _install(self, keys: list | None) -> None:
        if self._busy:
            return
        from vicdub.core import bootstrap  # noqa: PLC0415
        from vicdub.core.component_setup import (  # noqa: PLC0415
            estimate_size_gb, sort_for_install,
        )

        missing_keys = [c.key for c in bootstrap.missing(self.app.config)]
        todo = sort_for_install(missing_keys if keys is None else keys)
        if not todo:
            self.info("Không có gì cần cài.")
            return
        cuda = self.gpu_checkbox.isChecked()
        total_gb = estimate_size_gb(todo, cuda)
        if not self.confirm(
            f"Tải và cài {len(todo)} thành phần (~{total_gb:g} GB)?\n"
            "Có thể huỷ giữa chừng; đã tải xong phần nào giữ phần đó."
        ):
            return

        self._busy = True
        self._cancel.clear()
        self.btn_cancel.setEnabled(True)
        self.btn_install_all.setEnabled(False)
        self.btn_refresh.setEnabled(False)
        config = self.app.config

        def worker() -> None:
            try:
                from vicdub.core.component_setup import install_missing  # noqa: PLC0415
                done = install_missing(
                    config,
                    report=self.progress.emit,
                    is_cancelled=self._cancel.is_set,
                    keys=todo, cuda=cuda,
                )
                self.finished.emit(True, f"Đã cài xong: {', '.join(done) or '—'}")
            except Exception as exc:  # noqa: BLE001 - mọi lỗi phải lên UI
                self.finished.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _on_progress(self, pct: int, msg: str) -> None:
        if pct >= 0:
            self.progress_bar.setValue(pct)
        self.status_label.setText(msg)

    def _on_finished(self, ok: bool, message: str) -> None:
        self._busy = False
        self.btn_cancel.setEnabled(False)
        self.btn_refresh.setEnabled(True)
        if ok:
            self.progress_bar.setValue(100)
            self.info(message)
        else:
            self.warn(f"Cài thành phần lỗi: {message}")
        self.refresh()


class SettingsPage(BasePage):
    """Cấu hình xử lý video, giọng đọc và dịch vụ trực tuyến."""

    API_COLUMNS = ("Tên", "Khóa truy cập", "Chế độ", "Giới hạn", "Ưu tiên", "Bật")
    # Nhãn cho lựa chọn "không đặt giọng mặc định".
    DEFAULT_VOICE_BY_GENDER = "(giọng mặc định hệ thống)"

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Cài đặt", "Quản lý các thành phần và tùy chọn ứng dụng.")

        # ----- Tạo widget cấu hình -----
        self.ffmpeg_input = QLineEdit()
        self.ffprobe_input = QLineEdit()
        self.tts_device = QComboBox()
        self.tts_device.addItems(("auto", "cuda", "cpu"))
        self.tts_num_step = QSpinBox()
        self.tts_num_step.setRange(4, 64)
        self.tts_batch_size = QSpinBox()
        self.tts_batch_size.setRange(1, 32)
        self.tts_provider = QComboBox()
        self.tts_provider.addItem("Giọng cục bộ", "local")
        self.tts_provider.addItem("API giọng nói", "api")
        self.voice_api_type = QComboBox()
        self.voice_api_type.addItem("OpenAI / API tương thích", "openai")
        self.voice_api_type.addItem("ElevenLabs", "elevenlabs")
        self.voice_api_type.addItem("REST tùy chỉnh", "custom")
        self.voice_api_key = QLineEdit()
        self.voice_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.voice_api_key.setPlaceholderText("Để trống nếu giữ khóa đã lưu")
        self.voice_api_base_url = QLineEdit()
        self.voice_api_model = QLineEdit()
        self.voice_api_voices_url = QLineEdit()
        self.voice_api_voices_url.setPlaceholderText("REST: URL trả danh sách voices")
        self.voice_api_synthesis_url = QLineEdit()
        self.voice_api_synthesis_url.setPlaceholderText("REST: URL POST; dùng {voice_id} nếu cần")
        self.voice_api_type.currentIndexChanged.connect(self._voice_api_type_changed)
        # Giọng mặc định chung cho mọi dòng chưa gán riêng.
        self.default_voice = QComboBox()
        self.default_voice.setEditable(True)
        self.default_voice.setToolTip(
            "Giọng dùng cho mọi dòng chưa gán giọng riêng.\n"
            "Chọn '" + self.DEFAULT_VOICE_BY_GENDER + "' để dùng default của engine."
        )
        self.default_voice.addItem(self.DEFAULT_VOICE_BY_GENDER)
        try:
            self.default_voice.addItems(create_engine(self.app.config).list_voices())
        except Exception:  # noqa: BLE001 - thiếu OmniVoice vẫn mở được tab
            pass
        self.settings_voice_combo = QComboBox()
        self.settings_sample_input = QLineEdit()
        self.settings_sample_input.setText(
            "Xin chào, tôi là giọng đọc lồng tiếng cho video của bạn."
        )
        self.ocr_lang = QComboBox()
        self.ocr_lang.setEditable(True)
        self.ocr_lang.addItems(("ch", "en", "japan", "korean", "vi"))
        self.ocr_fps = QDoubleSpinBox()
        self.ocr_fps.setRange(0.5, 24.0)
        self.ocr_fps.setSingleStep(0.5)
        self.ocr_min_conf = QDoubleSpinBox()
        self.ocr_min_conf.setRange(0.0, 1.0)
        self.ocr_min_conf.setSingleStep(0.05)
        self.llm_ocr_fps = QDoubleSpinBox()
        self.llm_ocr_fps.setRange(16.0, 20.0)
        self.llm_ocr_fps.setSingleStep(1.0)
        self.llm_ocr_batch = QSpinBox()
        self.llm_ocr_batch.setRange(1, 50)
        self.llm_ocr_lang_hint = QLineEdit()
        self.llm_ocr_lang_hint.setPlaceholderText("Ví dụ: Trung, Nhật, Anh; để trống = tự đoán")
        # --- Drive OCR ---
        self.drive_account_buttons = []
        self.drive_account_paths = []
        self.drive_account_choose_buttons = []
        for slot in range(1, 5):
            button = QPushButton(f"Kết nối tài khoản {slot}")
            button.setProperty("variant", "primary")
            button.clicked.connect(
                lambda _checked=False, value=slot, btn=button: self._login_drive_ocr(value, btn)
            )
            self.drive_account_buttons.append(button)
            path_display = QLineEdit()
            path_display.setReadOnly(True)
            account_path = self.app.config.drive_account_credentials_path(slot)
            Path(account_path).parent.mkdir(parents=True, exist_ok=True)
            path_display.setText(account_path)
            path_display.setToolTip("Mỗi tài khoản dùng một thư mục kết nối riêng.")
            self.drive_account_paths.append(path_display)
            choose_button = QPushButton("Chọn file...")
            choose_button.clicked.connect(
                lambda _checked=False, value=slot: self._browse_drive_creds(value)
            )
            self.drive_account_choose_buttons.append(choose_button)
        self.btn_drive_test = QPushButton("Kiểm tra nguồn chính")
        self.btn_drive_test.setToolTip("Kiểm tra tài khoản nhận diện phụ đề.")
        self.btn_drive_test.clicked.connect(self._test_drive_ocr)
        self.vision_api_key = QLineEdit()
        self.vision_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.vision_api_key.setPlaceholderText("Khóa tăng tốc nhận diện (tùy chọn)")
        self.btn_vision_test = QPushButton("Kiểm tra tăng tốc")
        self.btn_vision_test.setToolTip("Kiểm tra khóa tăng tốc nhận diện.")
        self.btn_vision_test.clicked.connect(self._test_vision_ocr)
        self.translation_source = QComboBox()
        self.translation_source.addItem("Nguồn chính", "web")
        self.translation_source.addItem("Nguồn dự phòng", "api")
        self.translation_profile_count = QComboBox()
        self.translation_profile_count.addItem("1 phiên — ổn định", 1)
        self.translation_profile_count.addItem("2 phiên — nhanh hơn", 2)
        self.translation_api_fallback = QCheckBox("Tự động dùng nguồn dự phòng khi nguồn chính lỗi")
        self.translation_login_buttons = []
        for slot in range(1, 3):
            button = QPushButton(f"Kết nối phiên dịch {slot}")
            button.clicked.connect(
                lambda _checked=False, value=slot, btn=button:
                self._login_gemini_web_profile(f"translation_{value}", btn)
            )
            self.translation_login_buttons.append(button)
        self.batch_size = QSpinBox()
        self.batch_size.setRange(1, 200)
        self.speed_min = QDoubleSpinBox()
        self.speed_min.setRange(0.5, 1.0)
        self.speed_min.setSingleStep(0.01)
        self.speed_max = QDoubleSpinBox()
        self.speed_max.setRange(1.0, 2.0)
        self.speed_max.setSingleStep(0.01)
        self.sub_max_chars = QSpinBox()
        self.sub_max_chars.setRange(20, 300)
        self.sub_max_duration = QDoubleSpinBox()
        self.sub_max_duration.setRange(1.0, 30.0)
        self.sub_max_duration.setSingleStep(0.5)
        self.sub_split_gap = QDoubleSpinBox()
        self.sub_split_gap.setRange(0.1, 3.0)
        self.sub_split_gap.setSingleStep(0.1)
        self.strategy = QComboBox()
        self.strategy.addItems(("priority", "round_robin", "random", "fastest"))
        self.api_table = QTableWidget(0, len(self.API_COLUMNS))
        self.api_table.setHorizontalHeaderLabels(self.API_COLUMNS)
        self.api_table.setColumnHidden(2, True)
        self.api_table.verticalHeader().setVisible(False)
        self.api_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.api_table.setMinimumHeight(120)

        def _form(rows: list[tuple[str, QWidget]]) -> QFormLayout:
            f = QFormLayout()
            f.setContentsMargins(0, 0, 0, 0)
            for label, widget in rows:
                f.addRow(label, widget)
            return f

        # ----- Các mục thu gọn trong vùng cuộn (đỡ tràn màn hình) -----
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll_host = QWidget()
        scroll_host_layout = QHBoxLayout(scroll_host)
        scroll_host_layout.setContentsMargins(12, 0, 12, 0)
        scroll_host_layout.addStretch(1)
        inner = QWidget()
        inner.setObjectName("settingsContent")
        inner.setMinimumWidth(760)
        inner.setMaximumWidth(1080)
        col = QVBoxLayout(inner)
        col.setContentsMargins(20, 16, 20, 20)
        col.setSpacing(8)
        scroll_host_layout.addWidget(inner, 8)
        scroll_host_layout.addStretch(1)
        scroll.setWidget(scroll_host)

        sec_ff = CollapsibleBox("Xử lý video", collapsed=True)
        sec_ff.add_layout(_form([
            ("Bộ xử lý video:", self.ffmpeg_input), ("Bộ đọc thông tin video:", self.ffprobe_input),
        ]))
        btn_check = QPushButton("Kiểm tra thành phần")
        btn_check.clicked.connect(self._check_ffmpeg)
        sec_ff.add_widget(btn_check)
        col.addWidget(sec_ff)

        sec_voice = CollapsibleBox("Giọng đọc")
        sec_voice.add_layout(_form([
            ("Nguồn giọng:", self.tts_provider),
            ("Thiết bị:", self.tts_device),
            ("Chất lượng:", self.tts_num_step),
            ("Số câu xử lý đồng thời:", self.tts_batch_size),
            ("Giọng mặc định:", self.default_voice),
        ]))
        sec_voice.add_layout(_form([
            ("Nền tảng API:", self.voice_api_type),
            ("API key:", self.voice_api_key),
            ("Địa chỉ API:", self.voice_api_base_url),
            ("Model:", self.voice_api_model),
            ("URL danh sách giọng:", self.voice_api_voices_url),
            ("URL sinh giọng:", self.voice_api_synthesis_url),
        ]))
        vrow = QHBoxLayout()
        btn_check_omni = QPushButton("Kiểm tra giọng đọc")
        btn_check_omni.clicked.connect(self._check_omnivoice)
        vrow.addWidget(btn_check_omni)
        btn_sync_voices = QPushButton("Đồng bộ danh sách giọng")
        btn_sync_voices.clicked.connect(self._sync_voice_catalog)
        vrow.addWidget(btn_sync_voices)
        vrow.addStretch()
        sec_voice.add_layout(vrow)
        voice_preview_row = QHBoxLayout()
        btn_preview_voice = QPushButton("Nghe thử giọng")
        btn_preview_voice.setProperty("variant", "primary")
        btn_preview_voice.clicked.connect(self._preview_settings_voice)
        voice_preview_row.addWidget(self.settings_voice_combo, 1)
        voice_preview_row.addWidget(self.settings_sample_input, 2)
        voice_preview_row.addWidget(btn_preview_voice)
        sec_voice.add_layout(voice_preview_row)
        col.addWidget(sec_voice)

        sec_ocr = CollapsibleBox("Nhận diện phụ đề")
        sec_ocr.add_layout(_form([
            ("Mức quét:", self.llm_ocr_fps),
            ("Kích thước lô:", self.llm_ocr_batch),
            ("Ngôn ngữ nguồn:", self.llm_ocr_lang_hint),
        ]))
        for slot, (path_display, choose_button, button) in enumerate(
            zip(
                self.drive_account_paths,
                self.drive_account_choose_buttons,
                self.drive_account_buttons,
            ), 1
        ):
            account_row = QHBoxLayout()
            account_row.addWidget(QLabel(f"Tài khoản xử lý {slot}:"))
            account_row.addWidget(path_display, 1)
            account_row.addWidget(choose_button)
            account_row.addWidget(button)
            sec_ocr.add_layout(account_row)
        vision_row = QHBoxLayout()
        vision_row.addWidget(QLabel("Khóa tăng tốc:"))
        vision_row.addWidget(self.vision_api_key, 1)
        sec_ocr.add_layout(vision_row)
        sec_ocr.add_widget(QLabel(
            "Tùy chọn. Có khóa tăng tốc thì nhận diện nhanh hơn; để trống vẫn dùng chế độ ổn định."
        ))
        test_row = QHBoxLayout()
        test_row.addWidget(self.btn_drive_test)
        test_row.addWidget(self.btn_vision_test)
        test_row.addStretch()
        sec_ocr.add_layout(test_row)
        col.addWidget(sec_ocr)

        sec_trans = CollapsibleBox("Dịch & Đồng bộ", collapsed=True)
        sec_trans.add_layout(_form([
            ("Chế độ dịch:", self.translation_source),
            ("Số phiên dịch:", self.translation_profile_count),
            ("Số dòng mỗi lô dịch:", self.batch_size),
            ("Video chậm tối thiểu (0.95 = 95%):", self.speed_min),
            ("Voice tăng tốc tối đa (vd 1.5):", self.speed_max),
        ]))
        sec_trans.add_widget(self.translation_api_fallback)
        translation_login_row = QHBoxLayout()
        for button in self.translation_login_buttons:
            translation_login_row.addWidget(button)
        translation_login_row.addStretch()
        sec_trans.add_layout(translation_login_row)
        col.addWidget(sec_trans)

        sec_sub = CollapsibleBox("Tách câu phụ đề", collapsed=True)
        sec_sub.add_layout(_form([
            ("Ký tự tối đa/câu:", self.sub_max_chars),
            ("Giây tối đa/câu:", self.sub_max_duration),
            ("Khoảng lặng tách câu (s):", self.sub_split_gap),
        ]))
        col.addWidget(sec_sub)

        sec_api = CollapsibleBox("Kết nối dịch vụ")
        sec_api.add_widget(self.api_table)
        api_row = QHBoxLayout()
        btn_add_key = QPushButton("Thêm kết nối")
        btn_add_key.clicked.connect(self._add_key_row)
        btn_del_key = QPushButton("Xóa kết nối")
        btn_del_key.setProperty("variant", "danger")
        btn_del_key.clicked.connect(self._delete_key_row)
        api_row.addWidget(btn_add_key)
        api_row.addWidget(btn_del_key)
        api_row.addWidget(QLabel("Chế độ sử dụng:"))
        api_row.addWidget(self.strategy)
        api_row.addStretch()
        sec_api.add_layout(api_row)
        col.addWidget(sec_api)

        col.addStretch()
        self.body.addWidget(scroll, 1)

        # Nút Lưu luôn hiển thị dưới cùng (ngoài vùng cuộn).
        btn_save = QPushButton("Lưu cài đặt")
        btn_save.setProperty("variant", "primary")
        btn_save.setFixedWidth(240)
        btn_save.setMinimumHeight(40)
        btn_save.clicked.connect(self._save)
        save_row = QHBoxLayout()
        save_row.addStretch()
        save_row.addWidget(btn_save)
        save_row.addStretch()
        self.body.addLayout(save_row)
        QTimer.singleShot(700, self._auto_sync_voice_catalog)

    def refresh(self) -> None:
        c = self.app.config
        self.ffmpeg_input.setText(c.ffmpeg_path)
        self.ffprobe_input.setText(c.ffprobe_path)
        self.tts_device.setCurrentText(c.tts_device)
        self.tts_num_step.setValue(c.tts_num_step)
        self.tts_batch_size.setValue(c.tts_batch_size)
        self.tts_provider.setCurrentIndex(max(0, self.tts_provider.findData(
            getattr(c, "tts_provider", "local")
        )))
        self.voice_api_type.setCurrentIndex(max(0, self.voice_api_type.findData(
            getattr(c, "voice_api_type", "openai")
        )))
        self.voice_api_key.clear()
        self.voice_api_key.setPlaceholderText(
            "Khóa đã lưu an toàn — nhập mới để thay" if getattr(c, "voice_api_key", "")
            else "Nhập khóa API giọng nói"
        )
        self.voice_api_base_url.setText(getattr(c, "voice_api_base_url", ""))
        self.voice_api_model.setText(getattr(c, "voice_api_model", ""))
        self.voice_api_voices_url.setText(getattr(c, "voice_api_voices_url", ""))
        self.voice_api_synthesis_url.setText(getattr(c, "voice_api_synthesis_url", ""))
        try:
            voices = create_engine(self.app.config).list_voices()
        except Exception:  # noqa: BLE001
            voices = ["auto"]
        current_default = getattr(c, "default_voice", "") or self.DEFAULT_VOICE_BY_GENDER
        self.default_voice.clear()
        self.default_voice.addItem(self.DEFAULT_VOICE_BY_GENDER)
        self.default_voice.addItems(voices)
        self.default_voice.setCurrentText(current_default)
        current_voice = self.settings_voice_combo.currentText()
        self.settings_voice_combo.clear()
        self.settings_voice_combo.addItems(voices)
        if current_voice in voices:
            self.settings_voice_combo.setCurrentText(current_voice)
        self.ocr_lang.setCurrentText(getattr(c, "ocr_lang", "ch"))
        self.ocr_fps.setValue(float(getattr(c, "ocr_fps", 3.0)))
        self.ocr_min_conf.setValue(float(getattr(c, "ocr_min_confidence", 0.6)))
        self.llm_ocr_fps.setValue(float(getattr(c, "llm_ocr_fps", 2.0)))
        self.llm_ocr_batch.setValue(int(getattr(c, "llm_ocr_batch", 18)))
        self.llm_ocr_lang_hint.setText(getattr(c, "llm_ocr_lang_hint", ""))
        self.vision_api_key.setText(getattr(c, "vision_api_key", ""))
        index = self.translation_source.findData(getattr(c, "translation_source", "web"))
        self.translation_source.setCurrentIndex(max(0, index))
        count = max(1, min(2, int(getattr(c, "translation_web_profiles", 2))))
        self.translation_profile_count.setCurrentIndex(
            max(0, self.translation_profile_count.findData(count))
        )
        self.translation_api_fallback.setChecked(
            bool(getattr(c, "translation_api_fallback", True))
        )
        connected = {Path(a["token_path"]).resolve() for a in c.enabled_drive_accounts()}
        account_by_token = {
            Path(a["token_path"]).resolve(): a for a in c.enabled_drive_accounts()
        }
        for slot, button in enumerate(self.drive_account_buttons, 1):
            token = Path(c.drive_account_token_path(slot)).resolve()
            account = account_by_token.get(token, {})
            email = str(account.get("email", "")).strip()
            button.setText(
                (f"TK {slot}: {email}" if email else f"Tài khoản {slot}: đã kết nối")
                if token in connected and token.exists()
                else f"Kết nối tài khoản {slot}"
            )
            button.setToolTip(
                f"Tài khoản xử lý {slot}: {email}" if email
                else f"Tài khoản xử lý {slot}; bấm kiểm tra để cập nhật email."
            )
        self.batch_size.setValue(c.translate_batch_size)
        self.speed_min.setValue(c.speed_min)
        self.speed_max.setValue(c.speed_max)
        self.sub_max_chars.setValue(c.sub_max_chars)
        self.sub_max_duration.setValue(c.sub_max_duration)
        self.sub_split_gap.setValue(c.sub_split_gap)
        self.strategy.setCurrentText(c.api_pool_strategy)

        keys = self.app.api.to_config()
        self.api_table.setRowCount(len(keys))
        for r, k in enumerate(keys):
            display_name = k["name"]
            if "gemini" in display_name.lower():
                display_name = f"Dịch vụ {r + 1}"
            values = (display_name, "", k["model"], str(k["rpm"]),
                      str(k["priority"]), "1" if k["enabled"] else "0")
            for col, value in enumerate(values):
                self.api_table.setItem(r, col, QTableWidgetItem(value))
            self._set_key_editor(r, k["key"])

    def _check_ffmpeg(self) -> None:
        try:
            FFmpeg(self.ffmpeg_input.text(), self.ffprobe_input.text()).version()
            self.info("Thành phần xử lý video hoạt động bình thường.")
        except FFmpegError as exc:
            self.warn(str(exc))

    def _check_omnivoice(self) -> None:
        """Kiểm tra thư viện OmniVoice, thiết bị và bộ giọng Việt."""
        try:
            self._apply_voice_settings()
            self.info(create_engine(self.app.config).check())
        except Exception as exc:  # noqa: BLE001
            self.warn(str(exc))

    def _voice_api_type_changed(self) -> None:
        kind = self.voice_api_type.currentData()
        known = self.voice_api_base_url.text().strip()
        if kind == "elevenlabs" and (not known or "openai.com" in known):
            self.voice_api_base_url.setText("https://api.elevenlabs.io")
            self.voice_api_model.setText("eleven_multilingual_v2")
        elif kind == "openai" and (not known or "elevenlabs.io" in known):
            self.voice_api_base_url.setText("https://api.openai.com/v1")
            self.voice_api_model.setText("gpt-4o-mini-tts")

    def _apply_voice_settings(self) -> None:
        """Chép riêng phần voice từ form vào config, chưa ghi đĩa."""
        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
        c = self.app.config
        c.tts_provider = self.tts_provider.currentData() or "local"
        c.voice_api_type = self.voice_api_type.currentData() or "openai"
        entered_key = self.voice_api_key.text().strip()
        if entered_key:
            c.voice_api_key = protect_secret(entered_key)
            self.voice_api_key.clear()
            self.voice_api_key.setPlaceholderText("Khóa đã lưu an toàn — nhập mới để thay")
        elif getattr(c, "voice_api_key", "") and not str(c.voice_api_key).startswith(("dpapi:", "base64:")):
            c.voice_api_key = protect_secret(c.voice_api_key)
        c.voice_api_base_url = self.voice_api_base_url.text().strip()
        c.voice_api_model = self.voice_api_model.text().strip()
        c.voice_api_voices_url = self.voice_api_voices_url.text().strip()
        c.voice_api_synthesis_url = self.voice_api_synthesis_url.text().strip()

    def _sync_voice_catalog(self) -> None:
        self._apply_voice_settings()
        if self.app.config.tts_provider != "api":
            self.warn("Hãy chọn 'API giọng nói' trước khi đồng bộ.")
            return
        self.app.show_status("Đang đồng bộ danh sách giọng từ nền tảng...")

        def worker() -> None:
            try:
                engine = create_engine(self.app.config)
                voices = engine.list_voices(force=True)
                self.app.show_status(f"Đã đồng bộ {len(voices)} giọng.")
                QTimer.singleShot(0, self.refresh)
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Đồng bộ giọng lỗi: {self._public_message(str(exc))}")

        threading.Thread(target=worker, daemon=True).start()

    def _auto_sync_voice_catalog(self) -> None:
        """Đồng bộ nền mỗi 24 giờ, không bật hộp thoại khi mất mạng."""
        if getattr(self.app.config, "tts_provider", "local") != "api":
            return
        try:
            engine = create_engine(self.app.config)
            if not getattr(engine, "catalog_stale", lambda: False)():
                return
        except Exception:
            return

        def worker() -> None:
            try:
                engine.sync_voices()
                self.app.show_status("Danh sách giọng API đã được cập nhật.")
            except Exception as exc:  # noqa: BLE001
                logger = __import__("logging").getLogger(__name__)
                logger.info("Bỏ qua đồng bộ giọng nền: %s", exc)

        threading.Thread(target=worker, daemon=True).start()

    def _login_gemini_web_profile(self, profile_name: str, button: QPushButton) -> None:
        """Mở phiên tài khoản riêng để đăng nhập/kiểm tra."""
        config = self.app.config
        button.setEnabled(False)
        self.app.show_status(f"Đang kết nối tài khoản {profile_name}...")

        def report(_pct: int, msg: str) -> None:
            self.app.show_status(msg)

        def worker() -> None:
            try:
                from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415

                with GeminiWebClient(
                    config.data_dir,
                    report=report,
                    login_timeout=getattr(config, "gemini_web_login_timeout", 300),
                    response_timeout=getattr(config, "gemini_web_response_timeout", 240),
                    profile_name=profile_name,
                ):
                    pass
                self.app.show_status(f"Tài khoản {profile_name} đã kết nối.")
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Không thể kết nối tài khoản {profile_name}: {self._public_message(str(exc))}")
            finally:
                QTimer.singleShot(0, lambda: button.setEnabled(True))

        threading.Thread(target=worker, daemon=True).start()

    def _browse_drive_creds(self, slot: int) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, f"Chọn file kết nối cho tài khoản {slot}", "", "Tệp kết nối (*.json)"
        )
        if path:
            destination = self.app.config.drive_account_credentials_path(slot)
            try:
                Path(destination).parent.mkdir(parents=True, exist_ok=True)
                if Path(path).resolve() != Path(destination).resolve():
                    shutil.copyfile(path, destination)
                self.drive_account_paths[slot - 1].setText(destination)
                self.app.show_status(f"Đã chọn file kết nối cho tài khoản {slot}.")
            except OSError as exc:
                self.warn(f"Không lưu được file kết nối cho tài khoản {slot}: {exc}")

    def _login_drive_ocr(self, slot: int = 1, button: QPushButton | None = None) -> None:
        """Kết nối một tài khoản xử lý phụ đề."""
        config = self.app.config
        creds = config.drive_account_credentials_path(slot)
        if not Path(creds).exists():
            self._browse_drive_creds(slot)
        if not Path(creds).exists():
            self.warn(f"Chưa chọn file kết nối cho tài khoản {slot}.")
            return
        token_path = config.drive_account_token_path(slot)
        active_button = button or self.drive_account_buttons[slot - 1]
        active_button.setEnabled(False)
        self.app.show_status("Đang mở trình duyệt để cấp quyền tài khoản...")

        def worker() -> None:
            try:
                from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
                    DriveOcrClient, authorize,
                )
                authorize(creds, token_path)
                identity = DriveOcrClient(creds, token_path)
                try:
                    email = identity.account_email()
                finally:
                    identity.close()
                accounts = [
                    account for account in (config.drive_ocr_accounts or [])
                    if str(account.get("token_path", "")) != token_path
                ]
                accounts.append({
                    "name": f"Tài khoản {slot}",
                    "email": email,
                    "credentials_path": creds,
                    "token_path": token_path,
                    "folder_id": "",
                    "enabled": True,
                })
                config.drive_ocr_accounts = accounts
                config.save()
                self.app.show_status(
                    f"Đã kết nối tài khoản nhận diện {slot}: {email or 'không đọc được email'}."
                )
                QTimer.singleShot(0, self.refresh)
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Kết nối tài khoản thất bại: {self._public_message(str(exc))}")
            finally:
                QTimer.singleShot(0, lambda: active_button.setEnabled(True))

        threading.Thread(target=worker, daemon=True).start()

    def _test_drive_ocr(self) -> None:
        """Kiểm tra tài khoản nhận diện phụ đề."""
        config = self.app.config
        creds = config.resolve_drive_credentials()
        accounts = config.enabled_drive_accounts()
        if not creds and not any(a.get("credentials_path") for a in accounts):
            self.warn("Chưa có file kết nối. Kết nối tài khoản xử lý trước.")
            return
        if not accounts:
            self.warn("Chưa đăng nhập tài khoản xử lý. Bấm kết nối tài khoản trước.")
            return
        self.btn_drive_test.setEnabled(False)
        run_drive_ocr_selftest(
            self, config, on_done=lambda: self.btn_drive_test.setEnabled(True)
        )

    def _preview_settings_voice(self) -> None:
        voice = self.settings_voice_combo.currentText()
        if not voice:
            return
        text = self.settings_sample_input.text().strip() or "Xin chào."
        config = self.app.config

        def worker() -> None:
            try:
                engine = create_engine(config)
                out = preview_wav_path(config.data_dir, "settings", voice)
                engine.synthesize(text, voice, 1.0, out)
                self.app.play_audio(out)
                self.app.show_status(f"Đang phát giọng '{voice}'.")
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Nghe thử lỗi: {exc}")

        threading.Thread(target=worker, daemon=True).start()
        self.app.show_status(f"Đang sinh giọng thử '{voice}'...")
    def _add_key_row(self) -> None:
        row = self.api_table.rowCount()
        self.api_table.insertRow(row)
        defaults = (f"Dịch vụ {row + 1}", "", DEFAULT_GEMINI_MODEL, "15", "1", "1")
        for col, value in enumerate(defaults):
            self.api_table.setItem(row, col, QTableWidgetItem(value))
        self._set_key_editor(row, "")

    def _delete_key_row(self) -> None:
        row = self.api_table.currentRow()
        if row >= 0:
            self.api_table.removeRow(row)

    def _set_key_editor(self, row: int, key: str) -> None:
        editor = QLineEdit()
        editor.setText(key)
        editor.setEchoMode(QLineEdit.EchoMode.Password)
        editor.setPlaceholderText("Nhập khóa truy cập...")
        editor.setClearButtonEnabled(True)
        self.api_table.setCellWidget(row, 1, editor)

    def _test_vision_ocr(self) -> None:
        import threading  # noqa: PLC0415

        key = self.vision_api_key.text().strip()
        if not key:
            self.warn("Chưa nhập khóa tăng tốc.")
            return

        bridge = _DriveSelfTestBridge()          # cùng cầu nối thread-safe
        self._vision_selftest_bridge = bridge

        def on_done_msg(msg: str) -> None:
            self.app.show_status(msg.split(chr(10))[0])
            (self.info if msg.startswith("✅") else self.warn)(msg)
            self.btn_vision_test.setEnabled(True)

        bridge.progress.connect(self.app.show_status)
        bridge.done.connect(on_done_msg)
        self.btn_vision_test.setEnabled(False)
        self.app.show_status("Kiểm tra tăng tốc: chuẩn bị ảnh mẫu...")

        def worker() -> None:
            try:
                from vicdub.api.vision_ocr_client import self_test  # noqa: PLC0415
                good, total, texts = self_test(key, report=bridge.progress.emit)
            except Exception as exc:  # noqa: BLE001 - mọi lỗi phải hiện lên UI
                bridge.done.emit(f"❌ Kiểm tra tăng tốc lỗi: {self._public_message(str(exc))}")
                return
            icon = "✅" if good == total else "⚠️"
            bridge.done.emit(
                f"{icon} Bộ tăng tốc đọc đúng {good}/{total} câu mẫu.\n"
                + "\n".join(f"  {index + 1}. {text or '(rỗng)'}"
                            for index, text in enumerate(texts))
            )

        threading.Thread(target=worker, daemon=True).start()

    def _save(self) -> None:
        c = self.app.config
        c.ffmpeg_path = self.ffmpeg_input.text().strip() or "ffmpeg"
        c.ffprobe_path = self.ffprobe_input.text().strip() or "ffprobe"
        c.tts_device = self.tts_device.currentText()
        c.tts_num_step = self.tts_num_step.value()
        c.tts_batch_size = self.tts_batch_size.value()
        self._apply_voice_settings()
        dv = self.default_voice.currentText().strip()
        c.default_voice = "" if dv == self.DEFAULT_VOICE_BY_GENDER else dv
        c.subtitle_source = "drive"
        c.ocr_lang = self.ocr_lang.currentText().strip() or "ch"
        c.ocr_fps = self.ocr_fps.value()
        c.ocr_min_confidence = self.ocr_min_conf.value()
        c.llm_ocr_fps = self.llm_ocr_fps.value()
        c.llm_ocr_batch = self.llm_ocr_batch.value()
        c.llm_ocr_lang_hint = self.llm_ocr_lang_hint.text().strip()
        c.vision_api_key = self.vision_api_key.text().strip()
        c.translation_source = self.translation_source.currentData() or "web"
        c.translation_web_profiles = int(self.translation_profile_count.currentData() or 1)
        c.translation_api_fallback = self.translation_api_fallback.isChecked()
        c.translate_batch_size = self.batch_size.value()
        c.speed_min = self.speed_min.value()
        c.speed_max = self.speed_max.value()
        c.sub_max_chars = self.sub_max_chars.value()
        c.sub_max_duration = self.sub_max_duration.value()
        c.sub_split_gap = self.sub_split_gap.value()
        c.api_pool_strategy = self.strategy.currentText()

        keys = []
        for row in range(self.api_table.rowCount()):
            def cell(col: int) -> str:
                widget = self.api_table.cellWidget(row, col)
                if isinstance(widget, QLineEdit):
                    return widget.text().strip()
                item = self.api_table.item(row, col)
                return item.text().strip() if item else ""
            if not cell(1):
                continue  # bỏ dòng không có key
            try:
                keys.append(ApiKey(
                    name=cell(0) or f"Dịch vụ {row + 1}",
                    key=cell(1),
                    model=cell(2) or DEFAULT_GEMINI_MODEL,
                    rpm=int(cell(3) or 15),
                    priority=int(cell(4) or 1),
                    enabled=cell(5) != "0",
                ).to_dict())
            except ValueError:
                self.warn(f"Dòng {row + 1}: RPM/Priority phải là số.")
                return
        c.api_keys = keys
        c.save()
        self.app.reload_api_manager()
        self.info("Đã lưu cài đặt.")
        self.app.update_right_panel()


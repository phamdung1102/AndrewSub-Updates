"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.6.18"
APP_NAME = "AndrewSub"

"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.7.21"
APP_NAME = "AndrewSub"

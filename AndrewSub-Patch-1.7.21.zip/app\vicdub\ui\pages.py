"""8 trang chức năng của panel giữa.

Mỗi trang chỉ gọi services qua MainWindow (app) - không gọi module trực tiếp.
"""

from __future__ import annotations

import os
import importlib.util
import json
import re
import shutil
import tempfile
import time
import threading
from pathlib import Path
from typing import TYPE_CHECKING

import wave

from PyQt6.QtCore import QObject, QRect, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont, QFontMetrics, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox, QFileDialog, QFontComboBox, QFormLayout, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QProgressBar, QPushButton, QRadioButton, QScrollArea, QSlider, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, QAbstractItemView,
    QDialog, QDialogButtonBox, QFrame, QTabWidget, QStackedWidget,
)

from vicdub.ui.timeline import (
    TimelineWidget, project_clip_path, project_voice_path, wav_seconds,
)

from vicdub.api.api_manager import DEFAULT_GEMINI_MODEL, ApiKey
from vicdub.modules.import_module import SUPPORTED_VIDEO_EXTS, ImportModule
from vicdub.modules.video_module import VideoModule
from vicdub.modules.voice_module import VoiceModule, create_engine
from vicdub.core.bootstrap import hf_home, omnivoice_model_ready, vi_voices_ready
from vicdub.core.project_manager import Project
from vicdub.ui.widgets import (
    CollapsibleBox, SubtitleTable, muted_label, title_label,
)
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.series_merge import sort_paths_natural, split_by_episodes, sub_overrun
from vicdub.utils.subtitles import (
    Segment, clean_subtitle_text, load_subtitle_file, match_translations,
    normalize_gender, wrap_for_box, write_srt,
)

if TYPE_CHECKING:
    from vicdub.ui.main_window import MainWindow

VIDEO_FILTER = "Video (" + " ".join(f"*{e}" for e in SUPPORTED_VIDEO_EXTS) + ")"
SUBTITLE_FILTER = "Phụ đề (*.srt *.ass *.vtt)"
AUDIO_FILTER = "Audio/Video (*.wav *.mp3 *.mp4 *.m4a *.aac *.flac *.ogg *.wma *.mkv *.mov)"
AUDIO_EXTS = {
    ".wav", ".mp3", ".mp4", ".m4a", ".aac", ".flac", ".ogg", ".wma", ".mkv", ".mov",
}


def preview_wav_path(data_dir: str, prefix: str, voice: str = "") -> str:
    """Tạo file preview riêng để QSoundEffect không phát lại cache file cũ."""
    safe_voice = re.sub(r"[^A-Za-z0-9_.-]+", "_", voice or "voice").strip("_")
    folder = Path(data_dir) / "previews"
    folder.mkdir(parents=True, exist_ok=True)
    return str(folder / f"{prefix}_{safe_voice}_{int(time.time() * 1000)}.wav")


def _voice_catalog_key(config) -> tuple:
    """Khóa cache UI cho danh sách giọng theo đúng nguồn đang chọn."""
    provider = getattr(config, "tts_provider", "local")
    if provider == "api":
        api_type = getattr(config, "voice_api_type", "")
        if api_type == "omnivoice_server":
            return (
                "api", api_type,
                getattr(config, "voice_api_omnivoice_base_url", ""),
                getattr(config, "voice_api_omnivoice_voices_url", ""),
                bool(getattr(config, "voice_api_omnivoice_key", "")),
            )
        return (
            "api",
            api_type,
            getattr(config, "voice_api_base_url", ""),
            getattr(config, "voice_api_model", ""),
            getattr(config, "voice_api_voices_url", ""),
            bool(getattr(config, "voice_api_key", "")),
        )
    data_dir = Path(getattr(config, "data_dir", "data"))
    return (
        "local",
        importlib.util.find_spec("omnivoice") is not None,
        omnivoice_model_ready(hf_home(config)),
        vi_voices_ready(data_dir),
    )


def _voice_choices_for_config(config, force: bool = False) -> list[str]:
    """Danh sách giọng hiển thị trong UI.

    Local OmniVoice chỉ hiện khi setup đủ gói + model + preset. API chỉ hiện
    catalog của API đang chọn; không trộn preset local vào danh sách API.
    """
    if getattr(config, "tts_provider", "local") == "api":
        if not getattr(config, "voice_api_key", ""):
            return []
        engine = create_engine(config)
        if force:
            try:
                return engine.list_voices(force=True)  # type: ignore[call-arg]
            except TypeError:
                return engine.list_voices()
        return engine.list_voices()

    data_dir = Path(getattr(config, "data_dir", "data"))
    if importlib.util.find_spec("omnivoice") is None:
        return []
    if not omnivoice_model_ready(hf_home(config)):
        return []
    if not vi_voices_ready(data_dir):
        return []
    return create_engine(config).list_voices()


class _DriveSelfTestBridge(QObject):
    """Cầu nối thread-safe: worker phát tín hiệu, slot chạy ở main thread.

    QTimer.singleShot gọi TỪ thread nền không kích hoạt (thread không có event
    loop) nên phải dùng signal của QObject tạo ở main thread để marshal về.
    """
    progress = pyqtSignal(str)
    done = pyqtSignal(str)


class _AsrKeyCheckBridge(QObject):
    """Marshal kết quả kiểm tra ASR key từ worker thread về main thread."""

    done = pyqtSignal(object)


def run_drive_ocr_selftest(page, config, on_done=None) -> None:
    """Chạy Test Drive OCR trong thread nền, hiện tiến trình + kết quả an toàn.

    Dùng chung cho nút Test Drive OCR ở nhiều trang (Cài đặt, Subtitle Studio).
    """
    def finish() -> None:
        if on_done:
            on_done()

    creds = config.resolve_drive_credentials()
    accounts = config.enabled_drive_accounts()
    if not creds and not any(a.get("credentials_path") for a in accounts):
        page.warn("Chưa có file kết nối. Vào tab Cài đặt và kết nối tài khoản xử lý trước.")
        finish()
        return
    if not accounts:
        page.warn("Chưa đăng nhập tài khoản xử lý. Vào tab Cài đặt để kết nối trước.")
        finish()
        return

    # Bridge tạo Ở MAIN THREAD; giữ ref trên page để không bị GC trước khi phát.
    bridge = _DriveSelfTestBridge()
    page._drive_selftest_bridge = bridge

    def on_done_msg(msg: str) -> None:
        page.app.show_status(msg.split(chr(10))[0])
        (page.info if msg.startswith("✅") else page.warn)(msg)
        page.refresh()
        finish()

    bridge.progress.connect(page.app.show_status)
    bridge.done.connect(on_done_msg)
    page.app.show_status("Kiểm tra nhận diện: chuẩn bị ảnh mẫu...")

    def worker() -> None:
        try:
            from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
                DriveOcrClient, self_test,
            )

            def test_one(index_account):
                index, account = index_account
                try:
                    identity = DriveOcrClient(
                        account.get("credentials_path") or creds,
                        account["token_path"], account.get("folder_id", ""),
                    )
                    try:
                        email = identity.account_email()
                    finally:
                        identity.close()
                    good, total, _res = self_test(
                        account.get("credentials_path") or creds,
                        account["token_path"], account.get("folder_id", ""),
                        report=lambda m, n=index: bridge.progress.emit(
                            f"Kiểm tra tài khoản {n + 1}: {BasePage._public_message(m)}"
                        ),
                    )
                    return index, good == total, email, f"đọc đúng {good}/{total} mẫu"
                except Exception as exc:  # noqa: BLE001
                    return index, False, str(account.get("email", "")), BasePage._public_message(str(exc))

            statuses = []
            # Mạng yếu dễ làm bốn lần refresh/upload cùng lúc bị giới hạn.
            # Kiểm tra tuần tự; luồng OCR thật vẫn phân tải song song khi làm việc.
            for pair in enumerate(accounts):
                statuses.append(test_one(pair))
                if len(statuses) < len(accounts):
                    time.sleep(0.35)
            statuses.sort()
            ok_count = sum(1 for _index, ok, _email, _detail in statuses if ok)
            lines = [
                f"Tài khoản {index + 1} ({email or 'chưa rõ email'}): "
                f"{'OK' if ok else 'LỖI'} — {detail}"
                for index, ok, email, detail in statuses
            ]
            # Test thành công cũng là dịp cập nhật email cũ/chưa có trong cấu hình.
            by_token = {
                str(account.get("token_path", "")): account
                for account in (config.drive_ocr_accounts or [])
            }
            for index, _ok, email, _detail in statuses:
                token = accounts[index]["token_path"]
                if token in by_token and email:
                    by_token[token]["email"] = email
            config.save()
            icon = "✅" if ok_count == len(statuses) else "⚠"
            msg = (
                f"{icon} Nhận diện phụ đề: {ok_count}/{len(statuses)} tài khoản hoạt động.\n"
                + "\n".join(lines)
            )
        except Exception as exc:  # noqa: BLE001
            msg = f"❌ Kiểm tra nhận diện lỗi: {BasePage._public_message(str(exc))}"
        bridge.done.emit(msg)

    threading.Thread(target=worker, daemon=True).start()


class BasePage(QWidget):
    """Trang cơ sở: giữ tham chiếu app và layout dọc."""

    def __init__(self, app: "MainWindow", heading: str, hint: str) -> None:
        super().__init__()
        self.app = app
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(16, 16, 16, 16)
        self.body.setSpacing(10)
        self.body.addWidget(title_label(heading))
        self.body.addWidget(muted_label(hint))

    def refresh(self) -> None:
        """Gọi khi mở trang hoặc dữ liệu project thay đổi."""

    # ---------- Tiện ích ----------

    @staticmethod
    def _public_message(message: str) -> str:
        """Ẩn tên nhà cung cấp và thuật ngữ triển khai khỏi thông báo UI."""
        text = re.sub(r"Gemini(?:\s+Web)?", "dịch vụ trực tuyến", str(message),
                      flags=re.IGNORECASE)
        replacements = (
            (r"Google\s+Drive|Drive\s+OCR|Google", "tài khoản trực tuyến"),
            (r"Cloud\s+Vision|Vision\s+OCR|Vision\s+API|Vision", "bộ tăng tốc"),
            (r"VideoSubFinder|VSF", "bộ nhận diện"),
            (r"Gemini", "dịch vụ trực tuyến"),
            (r"credentials\.json|credential[s]?", "file kết nối"),
            (r"token\.json|token", "phiên đăng nhập"),
            (r"API\s*key|API", "khóa truy cập"),
            (r"montage|panel", "ảnh mẫu"),
            (r"Chrome|Playwright|browser|profile", "trình duyệt"),
            (r"FFmpeg|ffprobe", "thành phần xử lý video"),
        )
        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    def warn(self, message: str) -> None:
        QMessageBox.warning(self, "AndrewSub", self._public_message(message))

    def info(self, message: str) -> None:
        QMessageBox.information(self, "AndrewSub", self._public_message(message))

    def confirm(self, message: str) -> bool:
        """Hỏi Yes/No, trả True nếu người dùng chọn Yes."""
        return QMessageBox.question(
            self, "AndrewSub", self._public_message(message)
        ) == QMessageBox.StandardButton.Yes

    def need_project(self) -> bool:
        """True nếu CHƯA có project (kèm cảnh báo)."""
        if self.app.projects.current is None:
            self.warn("Vui lòng tạo hoặc mở một dự án.")
            return True
        return False


def choose_project_ocr_region(page: BasePage, project, config) -> bool:
    """Choose and persist an OCR rectangle for one project/video."""
    if not project or not project.video_path or not Path(project.video_path).exists():
        page.warn("Dự án chưa có video hợp lệ để chọn vùng phụ đề.")
        return False
    frame_png = str(Path(project.root) / "ocr_region_preview.png")
    try:
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        duration = max(1.0, ffmpeg.duration(project.video_path))
        ffmpeg.extract_frame_exact(
            project.video_path,
            min(60.0, duration / 2),
            frame_png,
            str(Path(project.root) / ".frame_index"),
        )
    except FFmpegError as exc:
        page.warn(f"Không trích được khung hình: {exc}")
        return False

    fracs = [0.25, 0.7, 0.4, 0.85, 0.1, 0.6, 0.5]
    state = {"i": 0}

    def next_frame() -> str | None:
        frac = fracs[state["i"] % len(fracs)]
        state["i"] += 1
        at = min(max(1.0, duration * frac), max(1.0, duration - 0.5))
        try:
            ffmpeg.extract_frame_exact(
                project.video_path, at, frame_png,
                str(Path(project.root) / ".frame_index"),
            )
        except FFmpegError:
            return None
        return frame_png

    from vicdub.ui.region_dialog import OcrRegionDialog  # noqa: PLC0415
    from vicdub.utils.video_frames import DEFAULT_REGION  # noqa: PLC0415

    region = tuple(project.get_ocr_region(
        getattr(config, "ocr_region", None) or DEFAULT_REGION
    ))
    try:
        picked_colors = json.loads(project.get_meta(
            "ocr_picked_colors", json.dumps(getattr(config, "ocr_picked_colors", []))
        ))
    except (TypeError, ValueError, json.JSONDecodeError):
        picked_colors = []
    filter_enabled = project.get_meta(
        "ocr_color_filter_enabled",
        "1" if getattr(config, "ocr_color_filter_enabled", False) else "0",
    ) == "1"
    tolerance = int(project.get_meta(
        "ocr_color_tolerance", str(getattr(config, "ocr_color_tolerance", 45))
    ))
    dialog = OcrRegionDialog(
        frame_png, region, page, frame_provider=next_frame,
        picked_colors=picked_colors,
        color_filter_enabled=filter_enabled,
        color_tolerance=tolerance,
    )
    if not dialog.exec():
        return False
    selected = list(dialog.selected_region())
    project.set_ocr_region(selected)
    colors = dialog.selected_colors()
    project.set_meta("ocr_picked_colors", json.dumps(colors))
    project.set_meta(
        "ocr_color_filter_enabled", "1" if dialog.color_filter_enabled() else "0"
    )
    project.set_meta("ocr_color_tolerance", str(dialog.color_tolerance()))
    # Giữ làm mặc định hợp lý cho project tạo sau, nhưng project hiện tại luôn
    # đọc metadata riêng và không bị project khác ghi đè.
    config.ocr_region = selected
    config.ocr_picked_colors = colors
    config.ocr_color_filter_enabled = dialog.color_filter_enabled()
    config.ocr_color_tolerance = dialog.color_tolerance()
    config.save()
    return True


def batch_workflow_defaults(config) -> dict:
    """Bộ mặc định an toàn cho một lần chạy nhiều dự án."""
    translation = str(getattr(config, "translation_source", "web") or "web")
    voice_provider = str(getattr(config, "tts_provider", "api") or "api")
    return {
        "steps": ["subtitle", "translate", "voice", "merge"],
        "subtitle_primary": "project",
        "subtitle_fallback": "none",
        "translation_primary": translation,
        "translation_fallback": "qwen" if translation == "web" else "web",
        "voice_primary": voice_provider,
        "voice_fallback": "local" if voice_provider == "api" else "none",
        "voice_name": str(getattr(config, "default_voice", "") or ""),
        "render_profile": str(getattr(config, "render_profile", "auto") or "auto"),
        "skip_completed": True,
        "error_policy": "continue",
    }


class BatchWorkflowDialog(QDialog):
    """Chụp cấu hình cho toàn bộ hàng đợi; không đổi settings khi mới mở hộp."""

    def __init__(self, config, parent=None) -> None:
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("Thiết lập quy trình hàng loạt")
        self.setMinimumWidth(620)
        saved = batch_workflow_defaults(config)
        saved.update(dict(getattr(config, "batch_workflow_plan", {}) or {}))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)
        layout.addWidget(title_label("Quy trình cho các dự án đã chọn"))
        layout.addWidget(muted_label(
            "Mỗi bước có nguồn chính và dự phòng. Kết quả đã hoàn thành được giữ lại."
        ))

        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Mẫu nhanh:"))
        self.preset = QComboBox()
        self.preset.addItem("Tùy chỉnh", "custom")
        self.preset.addItem("Toàn bộ quy trình", "full")
        self.preset.addItem("Chỉ tách và dịch", "sub_translate")
        self.preset.addItem("Chỉ voice và xuất", "voice_export")
        self.preset.currentIndexChanged.connect(self._apply_preset)
        preset_row.addWidget(self.preset, 1)
        layout.addLayout(preset_row)

        steps_frame = QFrame()
        steps_frame.setObjectName("projectWorkspaceCard")
        steps = QHBoxLayout(steps_frame)
        steps.setContentsMargins(10, 8, 10, 8)
        self.step_checks: dict[str, QCheckBox] = {}
        for key, label in (
            ("subtitle", "Tách phụ đề"),
            ("translate", "Dịch phụ đề"),
            ("voice", "Tạo voice"),
            ("merge", "Xuất video"),
        ):
            check = QCheckBox(label)
            check.setChecked(key in saved.get("steps", []))
            self.step_checks[key] = check
            steps.addWidget(check)
        layout.addWidget(steps_frame)

        form = QFormLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(8)
        self.subtitle_primary = QComboBox()
        self._fill(self.subtitle_primary, (
            ("Theo lựa chọn riêng từng dự án", "project"),
            ("OCR phụ đề trong hình", "drive"),
            ("Nhận diện lời thoại", "voice"),
        ), saved.get("subtitle_primary"))
        self.subtitle_fallback = QComboBox()
        self._fill(self.subtitle_fallback, (
            ("Không tự đổi nguồn", "none"),
            ("Dự phòng bằng nhận diện lời thoại", "voice"),
            ("Dự phòng bằng OCR trong hình", "drive"),
        ), saved.get("subtitle_fallback"))
        self.translation_primary = QComboBox()
        translation_options = (
            ("Dịch nhanh", "qwen"), ("Dịch Gemini", "web"),
            ("API dự phòng cũ", "api"),
        )
        self._fill(self.translation_primary, translation_options, saved.get("translation_primary"))
        self.translation_fallback = QComboBox()
        self._fill(self.translation_fallback, (("Không", "none"),) + translation_options,
                   saved.get("translation_fallback"))
        self.voice_primary = QComboBox()
        self._fill(self.voice_primary, (
            ("API giọng nói", "api"), ("Giọng cục bộ", "local"),
        ), saved.get("voice_primary"))
        self.voice_fallback = QComboBox()
        self._fill(self.voice_fallback, (
            ("Không", "none"), ("API giọng nói", "api"),
            ("Giọng cục bộ", "local"),
        ), saved.get("voice_fallback"))
        self.voice_name = QComboBox()
        self.voice_name.setEditable(True)
        current_voice = str(saved.get("voice_name", "") or "")
        try:
            voices = _voice_choices_for_config(config)
        except Exception:  # noqa: BLE001
            voices = []
        self.voice_name.addItem("Theo giọng mặc định hiện tại", "")
        for voice in voices:
            self.voice_name.addItem(voice, voice)
        if current_voice:
            index = self.voice_name.findData(current_voice)
            if index < 0:
                self.voice_name.addItem(current_voice, current_voice)
                index = self.voice_name.count() - 1
            self.voice_name.setCurrentIndex(index)
        self.render_profile = QComboBox()
        self._fill(self.render_profile, (
            ("Tự chọn GPU/CPU", "auto"), ("Nhanh", "fast"),
            ("Cân bằng", "balanced"), ("CPU chất lượng cao", "quality"),
        ), saved.get("render_profile"))
        form.addRow("Tách sub chính:", self.subtitle_primary)
        form.addRow("Tách sub dự phòng:", self.subtitle_fallback)
        form.addRow("Dịch chính:", self.translation_primary)
        form.addRow("Dịch dự phòng:", self.translation_fallback)
        form.addRow("Voice chính:", self.voice_primary)
        form.addRow("Voice dự phòng:", self.voice_fallback)
        form.addRow("Giọng áp cho cả hàng đợi:", self.voice_name)
        form.addRow("Chế độ xuất video:", self.render_profile)
        layout.addLayout(form)

        self.skip_completed = QCheckBox("Bỏ qua bước đã có kết quả hợp lệ")
        self.skip_completed.setChecked(bool(saved.get("skip_completed", True)))
        layout.addWidget(self.skip_completed)
        self.error_policy = QComboBox()
        self._fill(self.error_policy, (
            ("Hết nguồn dự phòng thì đánh dấu lỗi và chạy dự án kế tiếp", "continue"),
            ("Hết nguồn dự phòng thì dừng toàn bộ hàng đợi", "stop"),
        ), saved.get("error_policy"))
        layout.addWidget(self.error_policy)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Chạy quy trình")
        buttons.accepted.connect(self._accept_plan)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    @staticmethod
    def _fill(combo: QComboBox, options, selected) -> None:
        for label, value in options:
            combo.addItem(label, value)
        index = combo.findData(selected)
        combo.setCurrentIndex(max(0, index))

    def _apply_preset(self) -> None:
        preset = self.preset.currentData()
        selected = {
            "full": {"subtitle", "translate", "voice", "merge"},
            "sub_translate": {"subtitle", "translate"},
            "voice_export": {"voice", "merge"},
        }.get(preset)
        if selected is None:
            return
        for key, check in self.step_checks.items():
            check.setChecked(key in selected)

    def plan(self) -> dict:
        voice_data = self.voice_name.currentData()
        voice = str(voice_data if voice_data is not None else self.voice_name.currentText()).strip()
        return {
            "steps": [key for key, check in self.step_checks.items() if check.isChecked()],
            "subtitle_primary": self.subtitle_primary.currentData(),
            "subtitle_fallback": self.subtitle_fallback.currentData(),
            "translation_primary": self.translation_primary.currentData(),
            "translation_fallback": self.translation_fallback.currentData(),
            "voice_primary": self.voice_primary.currentData(),
            "voice_fallback": self.voice_fallback.currentData(),
            "voice_name": voice,
            "render_profile": self.render_profile.currentData(),
            "skip_completed": self.skip_completed.isChecked(),
            "error_policy": self.error_policy.currentData(),
        }

    def _accept_plan(self) -> None:
        if not any(check.isChecked() for check in self.step_checks.values()):
            QMessageBox.warning(self, "AndrewSub", "Hãy chọn ít nhất một bước cần chạy.")
            return
        self.accept()


# ====================================================================
class ProjectPage(BasePage):
    """Dự án & Video gộp một tab: project bên trái, video nguồn bên phải."""

    thumbnail_ready = pyqtSignal(str, str)  # video_path, png_path

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Dự án", "Quản lý dự án và video nguồn.")
        self._thumb_video_path = ""
        self._thumb_busy = False
        self._thumb_pending = ""
        self._project_runtime: dict[str, dict] = {}
        self._refreshing_source_mode = False
        self._refreshing_ocr_scan_mode = False
        self.thumbnail_ready.connect(self._on_thumbnail_ready)

        columns = QHBoxLayout()
        self.body.addLayout(columns, 1)

        # ================= Cột trái: project =================
        left_card = QFrame()
        left_card.setObjectName("projectWorkspaceCard")
        left = QVBoxLayout(left_card)
        left.setContentsMargins(14, 14, 14, 14)
        left.setSpacing(9)
        columns.addWidget(left_card, 4)

        row = QHBoxLayout()
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Tên dự án")
        btn_create = QPushButton("Tạo dự án")
        btn_create.setProperty("variant", "primary")
        btn_create.clicked.connect(self._create)
        row.addWidget(self.name_input)
        row.addWidget(btn_create)
        left.addLayout(row)

        # Thư mục lưu project (đổi được).
        dir_row = QHBoxLayout()
        self.projects_dir_label = muted_label("")
        btn_change_dir = QPushButton("Đổi thư mục lưu...")
        btn_change_dir.setToolTip("Chọn thư mục chứa toàn bộ project")
        btn_change_dir.clicked.connect(self._change_projects_dir)
        dir_row.addWidget(self.projects_dir_label, 1)
        dir_row.addWidget(btn_change_dir)
        left.addLayout(dir_row)

        left.addWidget(title_label("Danh sách dự án"))
        self.project_list = QTableWidget(0, 7)
        self.project_list.setHorizontalHeaderLabels(
            ["", "Tên dự án", "Video", "Số dòng", "Bước hiện tại", "Tiến độ", "Trạng thái"]
        )
        self.project_list.verticalHeader().setVisible(False)
        self.project_list.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.project_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.project_list.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.project_list.setAlternatingRowColors(True)
        header = self.project_list.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self.project_list.cellDoubleClicked.connect(lambda *_: self._open())
        left.addWidget(self.project_list, 1)

        select_row = QHBoxLayout()
        btn_select_all = QPushButton("Chọn tất cả")
        btn_select_all.clicked.connect(lambda: self._set_all_projects_checked(True))
        btn_select_none = QPushButton("Bỏ chọn")
        btn_select_none.clicked.connect(lambda: self._set_all_projects_checked(False))
        select_row.addWidget(btn_select_all)
        select_row.addWidget(btn_select_none)
        left.addLayout(select_row)

        self.btn_run_batch = QPushButton("Chạy trọn quy trình các dự án đã chọn")
        self.btn_run_batch.setProperty("variant", "primary")
        self.btn_run_batch.setMinimumHeight(42)
        self.btn_run_batch.setToolTip(
            "Chạy tuần tự: tách phụ đề → dịch → tạo giọng → ghép video."
        )
        self.btn_run_batch.clicked.connect(self._run_selected_projects)
        left.addWidget(self.btn_run_batch)
        self.btn_export_batch = QPushButton("Xuất video các dự án đã chọn")
        self.btn_export_batch.setMinimumHeight(38)
        self.btn_export_batch.setToolTip(
            "Dùng phụ đề và voice đã có trong từng dự án, rồi xuất video hàng loạt."
        )
        self.btn_export_batch.clicked.connect(self._export_selected_projects)
        left.addWidget(self.btn_export_batch)
        self.batch_status_label = muted_label("Chưa có hàng đợi dự án.")
        left.addWidget(self.batch_status_label)

        open_row = QHBoxLayout()
        btn_open = QPushButton("Mở dự án")
        btn_open.clicked.connect(self._open)
        btn_delete_proj = QPushButton("Xóa dự án")
        btn_delete_proj.setProperty("variant", "danger")
        btn_delete_proj.setToolTip("Xóa hẳn project đã chọn khỏi ổ đĩa")
        btn_delete_proj.clicked.connect(self._delete_project)
        open_row.addWidget(btn_open)
        open_row.addWidget(btn_delete_proj)
        left.addLayout(open_row)

        left.addWidget(title_label("Lịch sử"))
        self.history_list = QListWidget()
        self.history_list.setMaximumHeight(150)
        left.addWidget(self.history_list)

        # ================= Cột phải: video nguồn =================
        right_card = QFrame()
        right_card.setObjectName("projectWorkspaceCard")
        right = QVBoxLayout(right_card)
        right.setContentsMargins(14, 14, 14, 14)
        right.setSpacing(8)
        columns.addWidget(right_card, 6)

        vrow = QHBoxLayout()
        btn_pick = QPushButton("Chọn video...")
        btn_pick.setProperty("variant", "primary")
        btn_pick.clicked.connect(self._pick_video)
        btn_batch = QPushButton("Chọn thư mục...")
        btn_batch.clicked.connect(self._pick_folder)
        self.btn_region = QPushButton("Khoanh vùng phụ đề")
        self.btn_region.setToolTip("Lưu vùng phụ đề riêng cho video của project hiện tại")
        self.btn_region.clicked.connect(self._choose_ocr_region)
        btn_clear_video = QPushButton("Xóa video")
        btn_clear_video.setProperty("variant", "danger")
        btn_clear_video.setToolTip("Bỏ video nguồn khỏi project (không xóa file gốc)")
        btn_clear_video.clicked.connect(self._clear_video)
        vrow.addWidget(btn_pick)
        vrow.addWidget(btn_batch)
        vrow.addWidget(self.btn_region)
        vrow.addWidget(btn_clear_video)
        vrow.addStretch()
        right.addLayout(vrow)

        self.video_label = muted_label("Chưa chọn video.")
        right.addWidget(self.video_label)
        self.input_quality_label = muted_label("Nguồn: —")
        self.output_quality_label = muted_label("Kết quả: —")
        self.region_label = muted_label("Vùng phụ đề: chưa chọn riêng")
        right.addWidget(self.input_quality_label)
        right.addWidget(self.output_quality_label)
        right.addWidget(self.region_label)

        source_card = QFrame()
        source_card.setObjectName("subtitleSourceCard")
        source_layout = QVBoxLayout(source_card)
        source_layout.setContentsMargins(12, 10, 12, 12)
        source_layout.setSpacing(8)
        source_choices = QHBoxLayout()
        source_choices.setSpacing(10)
        self.source_group = QButtonGroup(self)
        # Hai lựa chọn kỹ thuật được gom thành tên nghiệp vụ đơn giản. Các nút
        # legacy vẫn tồn tại để đọc project cũ nhưng không còn hiển thị.
        self.source_ocr = QRadioButton("OCR cục bộ")
        self.source_ocr.setObjectName("subtitleSourceChoice")
        self.source_ocr.setProperty("sourceMode", "ocr")
        self.source_ocr.setToolTip("Đọc phụ đề cứng hiển thị trong khung hình.")
        self.source_remote_ocr = QRadioButton("OCR phụ đề trong hình")
        self.source_remote_ocr.setObjectName("subtitleSourceChoice")
        self.source_remote_ocr.setProperty("sourceMode", "remote_ocr")
        self.source_remote_ocr.setToolTip("Gửi ảnh phụ đề tới máy chủ nhận diện dùng chung.")
        self.source_audio = QRadioButton("Tách bằng âm thanh")
        self.source_audio.setObjectName("subtitleSourceChoice")
        self.source_audio.setProperty("sourceMode", "audio")
        self.source_audio.setToolTip(
            "Nhận diện lời thoại bằng dịch vụ âm thanh đã cấu hình."
        )
        self.source_whisper = QRadioButton("Tách bằng máy chủ riêng")
        self.source_whisper.setObjectName("subtitleSourceChoice")
        self.source_whisper.setProperty("sourceMode", "audio")
        self.source_whisper.setToolTip("Dùng Whisper Large V3 trên máy chủ riêng.")
        self.source_group.addButton(self.source_ocr)
        self.source_group.addButton(self.source_remote_ocr)
        self.source_group.addButton(self.source_audio)
        self.source_group.addButton(self.source_whisper)
        source_choices.addWidget(self.source_remote_ocr, 1)
        source_choices.addWidget(self.source_audio, 1)
        source_layout.addLayout(source_choices)

        ocr_mode_row = QHBoxLayout()
        self.ocr_scan_mode_label = QLabel("Chế độ OCR:")
        self.ocr_scan_mode = QComboBox()
        self.ocr_scan_mode.addItem("Nhanh (18 fps)", "fast")
        self.ocr_scan_mode.addItem("Chuẩn (25 fps)", "standard")
        self.ocr_scan_mode.setToolTip(
            "Nhanh: quét 18 fps để giảm thời gian. Chuẩn: quét tối đa 25 fps để bắt sub nhanh tốt hơn."
        )
        self.ocr_scan_mode.currentIndexChanged.connect(self._ocr_scan_mode_changed)
        ocr_mode_row.addWidget(self.ocr_scan_mode_label)
        ocr_mode_row.addWidget(self.ocr_scan_mode, 1)
        source_layout.addLayout(ocr_mode_row)

        self.source_hint = muted_label("")
        self.source_hint.setWordWrap(True)
        source_layout.addWidget(self.source_hint)
        self.btn_start_subtitle = QPushButton("Bắt đầu tách phụ đề")
        self.btn_start_subtitle.setProperty("variant", "primary")
        self.btn_start_subtitle.setMinimumHeight(40)
        self.btn_start_subtitle.clicked.connect(self._start_subtitle_extraction)
        source_layout.addWidget(self.btn_start_subtitle)
        right.addWidget(source_card)

        self.source_ocr.toggled.connect(self._source_mode_changed)
        self.source_remote_ocr.toggled.connect(self._source_mode_changed)
        self.source_audio.toggled.connect(self._source_mode_changed)
        self.source_whisper.toggled.connect(self._source_mode_changed)
        self.source_remote_ocr.setChecked(True)
        self._update_source_mode_ui()

        self.preview = QLabel("(preview khung hình)")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(240)
        self.preview.setStyleSheet(
            "background-color: #0f1724; border: 1px solid #223044; border-radius: 6px;"
        )
        right.addWidget(self.preview, 1)

        right.addWidget(muted_label("Video trong thư mục"))
        self.batch_list = QListWidget()
        self.batch_list.setMaximumHeight(130)
        self.batch_list.itemDoubleClicked.connect(
            lambda item: self._set_video(item.text())
        )
        right.addWidget(self.batch_list, 1)

    def refresh(self) -> None:
        self.projects_dir_label.setText(f"Lưu tại: {self.app.config.projects_dir}")
        checked = {
            self._project_name(self.project_list.item(row, 1))
            for row in range(self.project_list.rowCount())
            if self.project_list.item(row, 0)
            and self.project_list.item(row, 0).checkState() == Qt.CheckState.Checked
        }
        self.project_list.setRowCount(0)
        current_name = self.app.projects.current.name if self.app.projects.current else ""
        for row, name in enumerate(self.app.projects.list_projects()):
            self.project_list.insertRow(row)
            check_item = QTableWidgetItem()
            check_item.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsUserCheckable
            )
            check_item.setCheckState(
                Qt.CheckState.Checked if name in checked else Qt.CheckState.Unchecked
            )
            self.project_list.setItem(row, 0, check_item)
            name_item = QTableWidgetItem(name)
            name_item.setData(Qt.ItemDataRole.UserRole, name)
            if name == current_name:
                name_item.setText(f"{name}  • đang mở")
            self.project_list.setItem(row, 1, name_item)
            video, count, step, progress, status, tone = self._project_row_info(name)
            values = (video, count, step, progress, status)
            for column, value in enumerate(values, start=2):
                item = QTableWidgetItem(str(value))
                if column in {3, 5}:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.project_list.setItem(row, column, item)
            self._paint_project_status(row, tone)
            if name == current_name:
                self.project_list.selectRow(row)
        self.history_list.clear()
        project = self.app.projects.current
        mode = (
            project.get_meta("subtitle_extraction_mode", "ocr")
            if project else "ocr"
        )
        if mode not in {"ocr", "audio", "remote_ocr"}:
            mode = "remote_ocr"
        # Project cũ từng lưu OCR cục bộ được đưa về lựa chọn OCR thống nhất.
        if mode == "ocr":
            mode = "remote_ocr"
        self._refreshing_source_mode = True
        provider = (
            project.get_meta("subtitle_audio_provider", self.app.config.asr_provider)
            if project else self.app.config.asr_provider
        )
        self.source_audio.setChecked(mode == "audio")
        self.source_whisper.setChecked(False)
        self.source_remote_ocr.setChecked(mode == "remote_ocr")
        self.source_ocr.setChecked(mode == "ocr")
        self._refreshing_source_mode = False
        scan_mode = (
            project.get_meta("ocr_scan_mode", getattr(self.app.config, "ocr_scan_mode", "fast"))
            if project else getattr(self.app.config, "ocr_scan_mode", "fast")
        )
        if scan_mode not in {"fast", "standard"}:
            scan_mode = "fast"
        self._refreshing_ocr_scan_mode = True
        idx = self.ocr_scan_mode.findData(scan_mode)
        self.ocr_scan_mode.setCurrentIndex(idx if idx >= 0 else 0)
        self._refreshing_ocr_scan_mode = False
        self._update_source_mode_ui()
        if project:
            for h in project.load_history(50):
                self.history_list.addItem(
                    f'{h["ts"]}  [{h["status"]}]  {h["step"]}  {h["detail"]}'
                )
        if project and project.video_path:
            self.video_label.setText(f"Video: {project.video_path}")
            self._update_quality_labels(project)
            self._show_thumbnail(project.video_path)
            self.region_label.setText(
                "Vùng phụ đề: đã lưu riêng cho dự án"
                if project.has_ocr_region else
                "Vùng phụ đề: đang dùng mặc định — nên khoanh trước khi chạy"
            )
        elif project:
            self.video_label.setText("Chưa chọn video.")
            self.input_quality_label.setText("Nguồn: —")
            self.output_quality_label.setText("Kết quả: —")
            self.region_label.setText("Vùng phụ đề: chưa có video")
        else:
            self.video_label.setText("Chưa mở dự án.")
            self.input_quality_label.setText("Nguồn: —")
            self.output_quality_label.setText("Kết quả: —")
            self.region_label.setText("Vùng phụ đề: chưa mở dự án")
        self.btn_run_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )
        self.btn_export_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )
        self.btn_start_subtitle.setEnabled(
            bool(project and project.video_path)
            and not self.app.engine.is_running()
            and not self.app.is_batch_running()
        )

    # ---------- Project ----------

    @staticmethod
    def _project_name(item: QTableWidgetItem | None) -> str:
        if item is None:
            return ""
        return str(item.data(Qt.ItemDataRole.UserRole) or item.text()).strip()

    def _set_all_projects_checked(self, checked: bool) -> None:
        state = Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked
        for row in range(self.project_list.rowCount()):
            item = self.project_list.item(row, 0)
            if item:
                item.setCheckState(state)

    def _selected_project_names(self) -> list[str]:
        return [
            self._project_name(self.project_list.item(row, 1))
            for row in range(self.project_list.rowCount())
            if self.project_list.item(row, 0)
            and self.project_list.item(row, 0).checkState() == Qt.CheckState.Checked
        ]

    def _project_row(self, name: str) -> int:
        for row in range(self.project_list.rowCount()):
            if self._project_name(self.project_list.item(row, 1)) == name:
                return row
        return -1

    def _project_row_info(self, name: str) -> tuple[str, str, str, str, str, str]:
        runtime = self._project_runtime.get(name)
        root = self.app.projects.projects_dir / name
        try:
            project = Project(root)
        except Exception:  # noqa: BLE001
            return "—", "—", "—", "—", "Không đọc được dự án", "error"
        try:
            video = Path(project.video_path).name if project.video_path else "—"
            segments = project.load_segments()
            count = str(len(segments)) if segments else "—"
            if runtime:
                return (
                    video, count, str(runtime.get("step", "—")),
                    f"{int(runtime.get('progress', 0))}%",
                    str(runtime.get("status", "Đang chờ")),
                    str(runtime.get("tone", "queued")),
                )
            if not project.video_path or not Path(project.video_path).is_file():
                return video, count, "Chuẩn bị", "—", "Mới tạo", "idle"
            if not segments:
                return video, count, "Tách phụ đề", "0%", "Chờ tách sub", "idle"
            unreadable = sum(
                1 for seg in segments
                if (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được")
            )
            if unreadable:
                return video, count, "Kiểm tra phụ đề", "—", f"Lỗi OCR {unreadable} dòng", "error"
            missing_translation = sum(
                1 for seg in segments
                if (seg.text or "").strip() and not (seg.translation or "").strip()
            )
            if missing_translation:
                return video, count, "Dịch phụ đề", "—", f"Chờ dịch {missing_translation} dòng", "warning"
            voices = {
                int(path.stem) for path in (Path(project.root) / "voices").glob("*.wav")
                if path.stem.isdigit()
            }
            missing_voice = sum(1 for seg in segments if seg.line not in voices)
            if missing_voice:
                return video, count, "Tạo voice", "—", f"Chờ voice {missing_voice} dòng", "warning"
            export_dir = str(getattr(self.app.config, "export_dir", "") or "").strip()
            final_video = (
                Path(export_dir) / f"{project.name}.mp4"
                if export_dir else Path(project.root) / "output" / "Final.mp4"
            )
            if final_video.is_file() and final_video.stat().st_size > 0:
                return video, count, "Hoàn tất", "100%", "Hoàn tất", "complete"
            return video, count, "Xuất video", "—", "Chờ xuất", "warning"
        finally:
            project.close()

    def _paint_project_status(self, row: int, tone: str) -> None:
        colors = {
            "running": ("#dbeafe", "#1d4ed8"),
            "queued": ("#ede9fe", "#6d28d9"),
            "complete": ("#d1fae5", "#047857"),
            "warning": ("#fef3c7", "#b45309"),
            "error": ("#fee2e2", "#b91c1c"),
            "idle": ("#cbd5e1", "#475569"),
        }
        foreground, background = colors.get(tone, colors["idle"])
        for column in (4, 5, 6):
            item = self.project_list.item(row, column)
            if item:
                item.setForeground(QBrush(QColor(foreground)))
                item.setBackground(QBrush(QColor(background)))

    def set_project_runtime(
        self, name: str, step: str, progress: int, status: str, tone: str = "running"
    ) -> None:
        self._project_runtime[name] = {
            "step": step, "progress": max(0, min(100, int(progress))),
            "status": status, "tone": tone,
        }
        row = self._project_row(name)
        if row < 0:
            return
        for column, value in (
            (4, step), (5, f"{max(0, min(100, int(progress)))}%"), (6, status),
        ):
            item = self.project_list.item(row, column)
            if item:
                item.setText(value)
        self._paint_project_status(row, tone)

    def prepare_batch_rows(self, names: list[str]) -> None:
        for index, name in enumerate(names, start=1):
            self.set_project_runtime(
                name, "Đang chờ", 0, f"Trong hàng đợi {index}/{len(names)}", "queued"
            )

    def clear_project_runtime(self, name: str) -> None:
        self._project_runtime.pop(name, None)
        row = self._project_row(name)
        if row < 0:
            return
        video, count, step, progress, status, tone = self._project_row_info(name)
        for column, value in enumerate((video, count, step, progress, status), start=2):
            item = self.project_list.item(row, column)
            if item:
                item.setText(str(value))
        self._paint_project_status(row, tone)

    def _run_selected_projects(self) -> None:
        names = self._selected_project_names()
        if not names:
            self.warn("Hãy đánh dấu ít nhất một dự án trong danh sách.")
            return
        dialog = BatchWorkflowDialog(self.app.config, self)
        if not dialog.exec():
            return
        plan = dialog.plan()
        self.app.config.batch_workflow_plan = dict(plan)
        self.app.config.save()
        self.app.start_project_batch(names, plan)

    def _export_selected_projects(self) -> None:
        names = self._selected_project_names()
        if not names:
            self.warn("Hãy đánh dấu ít nhất một dự án trong danh sách.")
            return
        if not self.confirm(
            f"Xuất video cho {len(names)} dự án đã chọn? "
            "Tool sẽ dùng phụ đề và voice đã có trong từng dự án."
        ):
            return
        self.app.start_export_batch(names)

    def set_batch_status(self, message: str) -> None:
        self.batch_status_label.setText(message)
        self.btn_run_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )
        self.btn_export_batch.setEnabled(
            not self.app.engine.is_running() and not self.app.is_batch_running()
        )

    def _create(self) -> None:
        name = self.name_input.text().strip()
        if not name:
            self.warn("Vui lòng nhập tên dự án.")
            return
        try:
            self.app.projects.create(name)
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.name_input.clear()
        self.app.on_project_changed()

    def _open(self) -> None:
        row = self.project_list.currentRow()
        item = self.project_list.item(row, 1) if row >= 0 else None
        if item is None:
            self.warn("Vui lòng chọn một dự án.")
            return
        try:
            self.app.projects.open(self._project_name(item))
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.app.on_project_changed()

    def _delete_project(self) -> None:
        row = self.project_list.currentRow()
        item = self.project_list.item(row, 1) if row >= 0 else None
        if item is None:
            self.warn("Vui lòng chọn dự án cần xóa.")
            return
        name = self._project_name(item)
        if not self.confirm(
            f"Xóa dự án '{name}'? Thao tác này không thể hoàn tác."
        ):
            return
        try:
            self.app.projects.delete(name)
        except ValueError as exc:
            self.warn(str(exc))
            return
        self.app.on_project_changed()
        self.app.show_status(f"Đã xóa project '{name}'.")

    def _change_projects_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu project", self.app.config.projects_dir
        )
        if not folder:
            return
        self.app.config.projects_dir = folder
        self.app.config.save()
        self.app.projects.set_projects_dir(folder)
        self.app.on_project_changed()
        self.app.show_status(f"Đã đổi thư mục lưu project: {folder}")

    # ---------- Video nguồn ----------

    def _selected_source_mode(self) -> str:
        if self.source_audio.isChecked() or self.source_whisper.isChecked():
            return "audio"
        if self.source_remote_ocr.isChecked():
            return "remote_ocr"
        return "ocr"

    def _selected_ocr_scan_mode(self) -> str:
        mode = self.ocr_scan_mode.currentData()
        return mode if mode in {"fast", "standard"} else "fast"

    def _ocr_scan_mode_changed(self, *_args) -> None:
        if getattr(self, "_refreshing_ocr_scan_mode", False):
            return
        mode = self._selected_ocr_scan_mode()
        self.app.config.ocr_scan_mode = mode
        self.app.config.llm_ocr_fps = 25.0 if mode == "standard" else 18.0
        self.app.config.save()
        project = self.app.projects.current
        if project:
            project.set_meta("ocr_scan_mode", mode)
        self._update_source_mode_ui()

    def _selected_audio_provider(self) -> str:
        # Lựa chọn đơn giản trên UI luôn đi qua API âm thanh đã cấu hình.
        return "whisper_server"

    def _source_mode_changed(self, checked: bool) -> None:
        if not checked:
            return
        mode = self._selected_source_mode()
        project = self.app.projects.current
        if project and not self._refreshing_source_mode:
            project.set_meta("subtitle_extraction_mode", mode)
            if mode == "audio":
                project.set_meta("subtitle_audio_provider", self._selected_audio_provider())
        self._update_source_mode_ui()

    def _update_source_mode_ui(self) -> None:
        audio = self._selected_source_mode() == "audio"
        self.btn_region.setEnabled(not audio)
        self.ocr_scan_mode_label.setEnabled(not audio)
        self.ocr_scan_mode.setEnabled(not audio)
        if audio:
            self.source_hint.setText("Tách lời thoại trực tiếp từ âm thanh của video.")
        else:
            mode_label = "25 fps, ưu tiên bắt sub rất nhanh" if self._selected_ocr_scan_mode() == "standard" else "18 fps, nhanh hơn"
            self.source_hint.setText(
                f"Dùng cho video có phụ đề cứng. Chế độ hiện tại: {mode_label}. Hãy khoanh đúng vùng chữ trước khi chạy."
            )

    def _start_subtitle_extraction(self) -> None:
        if self.need_project():
            return
        project = self.app.projects.current
        if not project or not project.video_path or not Path(project.video_path).exists():
            self.warn("Vui lòng chọn video trước khi tách phụ đề.")
            return

        mode = self._selected_source_mode()
        project.set_meta("subtitle_extraction_mode", mode)
        scan_mode = self._selected_ocr_scan_mode()
        project.set_meta("ocr_scan_mode", scan_mode)
        self.app.config.ocr_scan_mode = scan_mode
        self.app.config.llm_ocr_fps = 25.0 if scan_mode == "standard" else 18.0
        self.app.config.save()
        if mode == "audio":
            # Nhận diện lời thoại: dịch vụ cloud Qwen3-ASR (nhẹ, không cài model).
            self.app.config.subtitle_source = "voice"
            provider = self._selected_audio_provider()
            project.set_meta("subtitle_audio_provider", provider)
            self.app.config.asr_provider = provider
            if not self.app.config.asr_configured():
                self.warn(
                    "Chưa cấu hình dịch vụ nhận diện lời thoại.\n\n"
                    "Vào tab Cài đặt → mục 'Nhận diện phụ đề', nhập khóa "
                    "dịch vụ âm thanh rồi lưu."
                )
                return
            if self.app.start_pipeline(["subtitle"]):
                self.app.nav.setCurrentRow(1)
            return

        if mode == "remote_ocr":
            self.app.config.subtitle_source = "remote_ocr"
            if not str(getattr(self.app.config, "remote_ocr_url", "") or "").strip():
                self.warn("Chưa cấu hình máy chủ nhận diện. Vào Cài đặt → Nhận diện để kết nối.")
                return
            if not project.has_ocr_region and not self._choose_ocr_region_for_start():
                return
            if self.app.start_pipeline(["subtitle"]):
                self.app.nav.setCurrentRow(1)
            return

        self.app.config.subtitle_source = "drive"
        accounts = self.app.config.enabled_drive_accounts()
        has_credentials = bool(self.app.config.resolve_drive_credentials()) or any(
            Path(account.get("credentials_path", "")).is_file()
            for account in accounts
        )
        if not accounts or not has_credentials:
            self.warn(
                "Chưa có tài khoản OCR hoạt động. Vào tab Cài đặt, chọn JSON và "
                "kết nối ít nhất một tài khoản trước khi tách phụ đề."
            )
            return
        if not project.has_ocr_region and not self._choose_ocr_region_for_start():
            return
        if self.app.start_pipeline(["subtitle"]):
            self.app.nav.setCurrentRow(1)

    def _choose_ocr_region_for_start(self) -> bool:
        project = self.app.projects.current
        if not choose_project_ocr_region(self, project, self.app.config):
            return False
        self.region_label.setText("Vùng phụ đề: đã lưu riêng cho dự án")
        return True

    def _choose_ocr_region(self) -> None:
        project = self.app.projects.current
        if choose_project_ocr_region(self, project, self.app.config):
            self.region_label.setText("Vùng phụ đề: đã lưu riêng cho dự án")
            self.app.show_status(f"Đã lưu vùng phụ đề cho dự án {project.name}.")

    def _pick_video(self) -> None:
        if self.need_project():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Chọn video", "", VIDEO_FILTER)
        if path:
            self._set_video(path)

    def _pick_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục video")
        if not folder:
            return
        try:
            videos = ImportModule.scan_folder(folder)
        except Exception as exc:  # noqa: BLE001
            self.warn(str(exc))
            return
        self.batch_list.clear()
        self.batch_list.addItems(videos)
        if not videos:
            self.info("Thư mục không có video nào được hỗ trợ.")

    def _set_video(self, path: str) -> None:
        if self.need_project():
            return
        project = self.app.projects.current
        if project.video_path != path:
            # Vùng của video cũ không được tái dùng âm thầm cho video mới.
            project.set_meta("ocr_region", "")
        project.set_meta("video_path", path)
        self.video_label.setText(f"Video: {path}")
        self._update_quality_labels(project)
        self._show_thumbnail(path)
        self.region_label.setText("Vùng phụ đề: chưa chọn cho video này")
        self.app.update_right_panel()

    def _clear_video(self) -> None:
        if self.need_project():
            return
        project = self.app.projects.current
        if not project.video_path:
            return
        if not self.confirm("Bỏ video nguồn khỏi project này? (không xóa file gốc)"):
            return
        project.set_meta("video_path", "")
        project.set_meta("ocr_region", "")
        self._thumb_video_path = ""
        self.video_label.setText("Chưa chọn video.")
        self.input_quality_label.setText("Input: —")
        self.output_quality_label.setText("Output: —")
        self.preview.clear()
        self.preview.setText("(preview khung hình)")
        self.region_label.setText("Vùng phụ đề: chưa có video")
        self.app.update_right_panel()
        self.app.show_status("Đã bỏ video nguồn khỏi project.")

    def _update_quality_labels(self, project) -> None:
        """Hiển thị nhanh chất lượng video đầu vào và output nếu đã có."""
        config = self.app.config
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        if project.video_path and Path(project.video_path).exists():
            try:
                self.input_quality_label.setText(
                    "Nguồn: " + ffmpeg.video_summary(project.video_path)
                )
            except FFmpegError as exc:
                self.input_quality_label.setText(f"Nguồn: không đọc được ({exc})")
        else:
            self.input_quality_label.setText("Nguồn: —")

        final = Path(project.root) / "output" / "Final.mp4"
        export_dir = getattr(config, "export_dir", "")
        exported = Path(export_dir) / f"{project.name}.mp4" if export_dir else None
        output = exported if exported and exported.exists() else final
        if output.exists():
            try:
                self.output_quality_label.setText(
                    "Kết quả: " + ffmpeg.video_summary(str(output))
                )
            except FFmpegError as exc:
                self.output_quality_label.setText(f"Kết quả: không đọc được ({exc})")
        else:
            self.output_quality_label.setText("Kết quả: chưa có")

    def _show_thumbnail(self, video_path: str) -> None:
        project = self.app.projects.current
        if not project or not Path(video_path).exists():
            return
        thumb = Path(project.root) / "preview.png"
        if self._thumb_video_path == video_path and thumb.exists():
            pixmap = QPixmap(str(thumb))
            if not pixmap.isNull():
                self.preview.setPixmap(pixmap.scaledToHeight(
                    240, Qt.TransformationMode.SmoothTransformation
                ))
            return
        if self._thumb_busy:
            self._thumb_pending = video_path
            return
        self._thumb_busy = True
        self.preview.setText("Đang tạo preview...")
        config = self.app.config

        def work() -> None:
            try:
                ffmpeg = FFmpeg(
                    config.ffmpeg_path, config.ffprobe_path,
                    timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
                )
                ffmpeg.extract_frame(video_path, 1.0, str(thumb))
                self.thumbnail_ready.emit(video_path, str(thumb))
            except FFmpegError as exc:
                self.thumbnail_ready.emit(video_path, f"ERROR:{exc}")

        threading.Thread(target=work, daemon=True).start()

    def _on_thumbnail_ready(self, video_path: str, result: str) -> None:
        self._thumb_busy = False
        pending = self._thumb_pending
        self._thumb_pending = ""
        project = self.app.projects.current
        if not project or project.video_path != video_path:
            if pending:
                self._show_thumbnail(pending)
            return
        if result.startswith("ERROR:"):
            self.preview.setText(f"Không tạo được preview: {result[6:]}")
            return
        self._thumb_video_path = video_path
        try:
            pixmap = QPixmap(result)
            if pixmap.isNull():
                self.preview.setText("Không tạo được preview.")
            else:
                self.preview.setPixmap(pixmap.scaledToHeight(
                    240, Qt.TransformationMode.SmoothTransformation
                ))
        except OSError as exc:
            self.preview.setText(f"Không tạo được preview: {exc}")
        if pending and pending != video_path:
            self._show_thumbnail(pending)


# ====================================================================
class SubtitlePage(BasePage):
    """Subtitle Studio: chỉnh mọi thứ trên bảng, thao tác dòng, upload bản
    dịch, so sánh clip/voice từng dòng, đồng bộ và xem thử kèm sub chữ."""

    #: Phát từ worker thread khi một tác vụ studio xong (thread-safe).
    studio_done = pyqtSignal(str)
    studio_progress = pyqtSignal(str)
    voice_scan_done = pyqtSignal(object)
    voice_import_done = pyqtSignal(object)
    sync_info_ready = pyqtSignal(object, str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Phụ đề", "Biên tập nội dung, bản dịch và giọng đọc.")
        self.studio_done.connect(self._on_studio_done)
        self.studio_progress.connect(self.app.show_status)
        self.voice_scan_done.connect(self._on_voice_scan_done)
        self.voice_import_done.connect(self._on_voice_import_done)
        self.sync_info_ready.connect(self._on_sync_info_ready)
        self._studio_cancel = threading.Event()
        self._studio_threads: set[threading.Thread] = set()
        self._studio_threads_lock = threading.Lock()
        self._cached_segments: list = []
        self._voices: list[str] = ["auto"]
        self._voices_cache_key: tuple = ()
        self._wav_duration_cache: dict[str, tuple[int, int, float]] = {}
        self._loaded_project_root = ""
        self._refresh_dirty = True

        # ----- Toolbar Studio: nguồn sub / dịch / xuất / sửa dòng -----
        toolbar = QFrame()
        toolbar.setObjectName("studioToolbar")
        toolbar_layout = QVBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(10, 8, 10, 8)
        toolbar_layout.setSpacing(8)

        row_source = QHBoxLayout()
        row_source.setSpacing(8)
        row_source.addWidget(muted_label("Phụ đề"))
        btn_import = QPushButton("Nhập SRT gốc")
        btn_import.setToolTip("Nhập file phụ đề gốc: SRT, ASS hoặc VTT.")
        btn_import.clicked.connect(self._import_subtitle)
        btn_import_voice_top = QPushButton("Nhập voice")
        btn_import_voice_top.setToolTip("Nhập thư mục file voice/audio, khớp theo số thứ tự dòng phụ đề.")
        btn_import_voice_top.clicked.connect(self._import_voice_folder)
        for b in (btn_import, btn_import_voice_top):
            row_source.addWidget(b)
        row_source.addSpacing(14)
        btn_translate = QPushButton("Dịch tự động")
        btn_translate.setProperty("variant", "primary")
        btn_translate.clicked.connect(self._translate_ai)
        btn_upload_trans = QPushButton("Nhập bản dịch")
        btn_upload_trans.clicked.connect(self._upload_translation)
        row_source.addWidget(btn_translate)
        row_source.addWidget(btn_upload_trans)
        btn_repair_ocr = QPushButton("Sửa dòng nhận diện lỗi")
        btn_repair_ocr.setToolTip(
            "Chỉ trích lại frame tại timestamp của các dòng lỗi; không quét lại video."
        )
        btn_repair_ocr.clicked.connect(self._repair_all_ocr_errors)
        row_source.addWidget(btn_repair_ocr)
        row_source.addStretch()
        toolbar_layout.addLayout(row_source)

        row_export = QHBoxLayout()
        row_export.setSpacing(8)
        row_export.addWidget(muted_label("Xuất phụ đề"))
        btn_export_org = QPushButton("Lưu SRT gốc")
        btn_export_org.clicked.connect(lambda: self._export_srt(False))
        btn_export_trans = QPushButton("Lưu SRT bản dịch")
        btn_export_trans.clicked.connect(lambda: self._export_srt(True))
        btn_export_male = QPushButton("Lưu SRT nam")
        btn_export_male.setToolTip("Xuất riêng các dòng đã đánh dấu giới tính Nam.")
        btn_export_male.clicked.connect(lambda: self._export_gender_srt("male"))
        btn_export_female = QPushButton("Lưu SRT nữ")
        btn_export_female.setToolTip("Xuất riêng các dòng đã đánh dấu giới tính Nữ.")
        btn_export_female.clicked.connect(lambda: self._export_gender_srt("female"))
        for b in (btn_export_org, btn_export_trans, btn_export_male, btn_export_female):
            row_export.addWidget(b)
        row_export.addStretch()
        toolbar_layout.addLayout(row_export)

        row_edit = QHBoxLayout()
        row_edit.setSpacing(8)
        row_edit.addWidget(muted_label("Sửa dòng"))
        btn_add = QPushButton("+ Dòng")
        btn_add.clicked.connect(self._add_row)
        btn_delete = QPushButton("Xóa dòng")
        btn_delete.setProperty("variant", "danger")
        btn_delete.clicked.connect(self._delete_row)
        btn_merge = QPushButton("Gộp xuống")
        btn_merge.clicked.connect(self._merge_down)
        btn_split = QPushButton("Tách dòng")
        btn_split.clicked.connect(self._split_row)
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Tìm trong sub...")
        self.filter_input.textChanged.connect(self._apply_filter)
        for b in (btn_add, btn_delete, btn_merge, btn_split):
            row_edit.addWidget(b)
        row_edit.addWidget(self.filter_input, 1)
        toolbar_layout.addLayout(row_edit)
        self.body.addWidget(toolbar)

        # ----- Khung làm việc: bảng trái + panel voice phải -----
        work = QHBoxLayout()
        work.setSpacing(10)
        left = QVBoxLayout()
        left.setSpacing(8)
        work.addLayout(left, 1)

        self.table = SubtitleTable()
        self.table.setColumnHidden(3, True)
        self.table.segment_edited.connect(self._save_segment)
        self.table.play_requested.connect(self._play_line)
        self.table.currentCellChanged.connect(
            lambda *_: self._sync_voice_combo()
        )
        left.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.count_label = muted_label("")
        bottom.addWidget(self.count_label, 1)
        btn_preview = QPushButton("Xem thử dòng")
        btn_preview.clicked.connect(self._preview_line)
        btn_sync_line = QPushButton("Đồng bộ dòng")
        btn_sync_line.clicked.connect(self._sync_line)
        btn_sync_all = QPushButton("Đồng bộ tất cả")
        btn_sync_all.clicked.connect(self._sync_all)
        btn_play_all = QPushButton("Nghe tất cả")
        btn_play_all.clicked.connect(self._play_all_voices)
        for b in (btn_preview, btn_sync_line, btn_sync_all, btn_play_all):
            bottom.addWidget(b)
        left.addLayout(bottom)

        side = QFrame()
        side.setObjectName("voicePanel")
        side.setFixedWidth(360)
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(14, 14, 14, 14)
        side_layout.setSpacing(10)
        side_layout.addWidget(title_label("GIỌNG ĐỌC"))
        side_layout.addWidget(muted_label("Nguồn tạo giọng"))
        self.voice_provider_combo = QComboBox()
        self.voice_provider_combo.addItem("API giọng đối tác", "partner")
        self.voice_provider_combo.addItem("API máy chủ riêng", "omnivoice_server")
        self.voice_provider_combo.addItem("Giọng cục bộ", "local")
        self.voice_provider_combo.setToolTip(
            "Chọn trực tiếp nguồn tạo giọng. Các khóa và địa chỉ của từng nguồn được giữ riêng."
        )
        self.voice_provider_combo.currentIndexChanged.connect(self._voice_provider_changed)
        side_layout.addWidget(self.voice_provider_combo)
        self.voice_service_status = QLabel("● Đang kiểm tra dịch vụ giọng đọc…")
        self.voice_service_status.setObjectName("voiceServiceStatus")
        side_layout.addWidget(self.voice_service_status)
        self._line_voice_guard = False
        btn_render_line = QPushButton("Tạo giọng cho dòng")
        btn_render_line.clicked.connect(self._generate_voice_line)
        btn_render_all = QPushButton("Tạo toàn bộ giọng đọc")
        btn_render_all.setProperty("variant", "primary")
        btn_render_all.setMinimumHeight(46)
        render_all_font = btn_render_all.font()
        render_all_font.setBold(True)
        btn_render_all.setFont(render_all_font)
        btn_render_all.clicked.connect(self._generate_voice_all)
        side_layout.addWidget(muted_label("Giọng mặc định"))
        self.all_voice_combo = QComboBox()
        self._setup_voice_combo(self.all_voice_combo)
        self.all_voice_combo.setToolTip(
            "Giọng này được dùng nguyên preset khi tạo một dòng hoặc toàn bộ; "
            "ứng dụng không tự đổi tone theo nhân vật."
        )
        side_layout.addWidget(self.all_voice_combo)
        btn_apply_voice_all = QPushButton("Áp dụng toàn bộ")
        btn_apply_voice_all.setProperty("variant", "primary")
        btn_apply_voice_all.setMinimumHeight(42)
        apply_all_font = btn_apply_voice_all.font()
        apply_all_font.setBold(True)
        btn_apply_voice_all.setFont(apply_all_font)
        btn_apply_voice_all.setToolTip(
            "Gán giọng đang chọn cho toàn bộ dòng phụ đề; chưa tạo lại file voice."
        )
        btn_apply_voice_all.clicked.connect(self._apply_voice_all_lines)
        self.use_gender_voices = QCheckBox("Dùng giọng theo giới tính nhân vật")
        self.use_gender_voices.setToolTip(
            "Dòng có giới tính Nam/Nữ sẽ dùng giọng tương ứng bên dưới; "
            "dòng đã gán voice riêng vẫn được giữ nguyên."
        )
        self.use_gender_voices.toggled.connect(self._save_gender_voice_defaults)
        side_layout.addWidget(self.use_gender_voices)

        male_box = QVBoxLayout()
        male_box.setSpacing(3)
        male_box.addWidget(muted_label("Giọng nam"))
        self.male_voice_combo = QComboBox()
        self.male_voice_combo.setMinimumContentsLength(24)
        self._setup_voice_combo(self.male_voice_combo)
        self.male_voice_combo.currentTextChanged.connect(
            self._save_gender_voice_defaults
        )
        male_box.addWidget(self.male_voice_combo)
        female_box = QVBoxLayout()
        female_box.setSpacing(3)
        female_box.addWidget(muted_label("Giọng nữ"))
        self.female_voice_combo = QComboBox()
        self.female_voice_combo.setMinimumContentsLength(24)
        self._setup_voice_combo(self.female_voice_combo)
        self.female_voice_combo.currentTextChanged.connect(
            self._save_gender_voice_defaults
        )
        female_box.addWidget(self.female_voice_combo)
        # Xếp dọc để tên giọng dài không đè lên ô bên cạnh.
        side_layout.addLayout(male_box)
        side_layout.addLayout(female_box)
        btn_hear_voice = QPushButton("Nghe thử")
        btn_hear_voice.clicked.connect(self._hear_selected_voice)
        side_layout.addWidget(btn_hear_voice)
        side_layout.addWidget(btn_apply_voice_all)
        side_layout.addWidget(btn_render_line)
        side_layout.addWidget(btn_render_all)

        btn_voice_settings = QPushButton("Thiết lập kết nối…")
        btn_voice_settings.setProperty("variant", "quiet")
        btn_voice_settings.setToolTip(
            "Mở phần kết nối dịch vụ giọng đọc trong Cài đặt."
        )
        btn_voice_settings.clicked.connect(self._open_voice_connection_settings)
        side_layout.addWidget(btn_voice_settings)

        side_layout.addSpacing(6)
        side_layout.addWidget(muted_label("Sửa nhận diện theo thời gian"))
        btn_auto_repair_line = QPushButton("Quét lại dòng lỗi")
        btn_auto_repair_line.clicked.connect(self._repair_selected_ocr_error)
        btn_manual_capture = QPushButton("Kéo thời gian và chụp lại")
        btn_manual_capture.clicked.connect(self._manual_ocr_capture)
        side_layout.addWidget(btn_auto_repair_line)
        side_layout.addWidget(btn_manual_capture)

        # Các nhãn vẫn tồn tại để đồng bộ trạng thái nội bộ, nhưng không cần
        # chiếm diện tích trên giao diện vì thông tin đã có ngay trong bảng.
        self.preview_time_label = muted_label("—")
        self.preview_source_label = muted_label("Gốc: —")
        self.preview_translation_label = muted_label("Dịch: —")
        self.preview_voice_label = muted_label("Giọng: —")
        side_layout.addStretch()
        work.addWidget(side)
        self.body.addLayout(work, 1)

    def _open_voice_connection_settings(self) -> None:
        """Mở đúng nơi cấu hình kết nối, không đưa khóa kỹ thuật ra Studio."""
        self.app.nav.setCurrentRow(3)
        settings = getattr(self.app, "settings_page", None)
        if settings is not None:
            settings.settings_tabs.setCurrentIndex(0)

    def _update_voice_service_status(self, voices: list[str] | None = None) -> None:
        """Trạng thái công khai, không lộ tên nền tảng hay model phía dưới."""
        available = len(voices if voices is not None else self._voices)
        if available:
            self.voice_service_status.setText(
                f"● Dịch vụ sẵn sàng · {available} giọng"
            )
            self.voice_service_status.setProperty("state", "ready")
        else:
            self.voice_service_status.setText("● Chưa thiết lập dịch vụ giọng đọc")
            self.voice_service_status.setProperty("state", "offline")
        self.voice_service_status.style().unpolish(self.voice_service_status)
        self.voice_service_status.style().polish(self.voice_service_status)

    # ---------- Nạp / lưu ----------

    @staticmethod
    def _setup_voice_combo(combo: QComboBox) -> None:
        """Combo chọn giọng: click là xổ danh sách, không nhập tay."""
        combo.setEditable(False)
        combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        combo.setMaxVisibleItems(12)
        combo.setMinimumHeight(34)
        combo.setToolTip("Bấm để xổ danh sách giọng và chọn.")

    def invalidate(self) -> None:
        """Đánh dấu dữ liệu đổi; lần mở tab kế tiếp mới dựng lại bảng."""
        self._refresh_dirty = True

    @staticmethod
    def _partner_voice_api_kind(config) -> str:
        """Suy ra API đối tác từ nhóm cấu hình chung, không đụng máy chủ riêng."""
        current = str(getattr(config, "voice_api_type", "") or "").lower()
        if current and current != "omnivoice_server":
            return current
        url = str(getattr(config, "voice_api_base_url", "") or "").lower()
        if "vietauto" in url:
            return "vietauto"
        if "elevenlabs" in url:
            return "elevenlabs"
        if "openai" in url:
            return "openai"
        return "custom"

    def _sync_voice_provider_selector(self) -> None:
        config = self.app.config
        self.table.set_cps_target(getattr(config, "tts_chars_per_second", 15.0))
        partner_kind = self._partner_voice_api_kind(config)
        partner_names = {
            "vietauto": "API giọng đối tác",
            "elevenlabs": "API giọng cao cấp",
            "openai": "API giọng tiêu chuẩn",
            "custom": "API giọng tùy chỉnh",
        }
        self.voice_provider_combo.setItemText(
            self.voice_provider_combo.findData("partner"),
            partner_names.get(partner_kind, "API giọng đối tác"),
        )
        if getattr(config, "tts_provider", "local") == "local":
            selected = "local"
        elif getattr(config, "voice_api_type", "") == "omnivoice_server":
            selected = "omnivoice_server"
        else:
            selected = "partner"
        blocked = self.voice_provider_combo.blockSignals(True)
        self.voice_provider_combo.setCurrentIndex(
            max(0, self.voice_provider_combo.findData(selected))
        )
        self.voice_provider_combo.blockSignals(blocked)

    def _voice_provider_changed(self) -> None:
        config = self.app.config
        selected = self.voice_provider_combo.currentData() or "partner"
        if selected == "local":
            config.tts_provider = "local"
        else:
            config.tts_provider = "api"
            config.voice_api_type = (
                "omnivoice_server" if selected == "omnivoice_server"
                else self._partner_voice_api_kind(config)
            )
        config.save()
        self._voices_cache_key = None
        self._refresh_dirty = True
        self.refresh(force=True)

    def refresh(self, force: bool = False) -> None:
        self._sync_voice_provider_selector()
        project = self.app.projects.current
        if not project:
            self._cached_segments = []
            self._loaded_project_root = ""
            self._refresh_dirty = True
            self._update_voice_service_status()
            return
        project_root = str(project.root)
        config = self.app.config
        voices_key = _voice_catalog_key(config)
        if (
            not force
            and not self._refresh_dirty
            and self._loaded_project_root == project_root
            and voices_key == self._voices_cache_key
        ):
            self._sync_voice_combo()
            self._update_voice_service_status()
            return
        segments = project.load_segments()
        if (
            not force
            and self._refresh_dirty
            and self._loaded_project_root == project_root
            and voices_key == self._voices_cache_key
            and self.table.rowCount() == len(segments)
        ):
            self._refresh_table_text_columns(segments)
            self._cached_segments = segments
            self._apply_filter(self.filter_input.text())
            over = sum(
                1 for s in segments
                if len(s.text) > self.app.config.sub_max_chars
            )
            self.count_label.setText(
                f"{len(segments)} phụ đề | {over} dòng vượt "
                f"{self.app.config.sub_max_chars} ký tự"
            )
            self._sync_voice_combo()
            self._update_voice_service_status()
            self._refresh_dirty = False
            return
        self._cached_segments = segments
        # Danh sách giọng không đổi khi chuyển tab; chỉ đọc lại nếu cấu hình đổi.
        if voices_key != self._voices_cache_key:
            self._line_voice_guard = True
            try:
                voices = _voice_choices_for_config(config)
            except Exception:  # noqa: BLE001
                voices = []
            try:
                self._voices = voices
                self._voices_cache_key = voices_key
                all_voice = self.all_voice_combo.currentText().strip()
                self.all_voice_combo.clear()
                self.all_voice_combo.addItems(voices)
                self.all_voice_combo.setEnabled(bool(voices))
                configured_all = (
                    all_voice or getattr(config, "default_voice", "") or ""
                ).strip()
                if configured_all and self.all_voice_combo.findText(configured_all) >= 0:
                    self.all_voice_combo.setCurrentText(configured_all)
                for combo, configured in (
                    (self.male_voice_combo, getattr(config, "default_male_voice", "")),
                    (self.female_voice_combo, getattr(config, "default_female_voice", "")),
                ):
                    combo.clear()
                    combo.addItems(voices)
                    combo.setEnabled(bool(voices))
                    if configured and combo.findText(configured) >= 0:
                        combo.setCurrentText(configured)
                self.use_gender_voices.setChecked(
                    bool(getattr(config, "use_gender_voices", False))
                )
            finally:
                self._line_voice_guard = False

        self._update_voice_service_status()

        if len(segments) >= 500:
            # Dự án dài: dựng ô theo từng lô và đọc metadata WAV ở thread nền.
            # Qt vẫn repaint/click được nên Windows không gắn nhãn Not Responding.
            self.table.load_deferred(segments, {}, self._voices)

            def collect_sync() -> None:
                result = self._sync_info(segments, project_root, config)
                self.sync_info_ready.emit(result, project_root)

            threading.Thread(
                target=collect_sync, daemon=True, name="vicdub-sync-info",
            ).start()
        else:
            self.table.load(segments, self._sync_info(segments), self._voices)
        self._apply_filter(self.filter_input.text())
        over = sum(1 for s in segments
                   if len(s.text) > self.app.config.sub_max_chars)
        self.count_label.setText(
            f"{len(segments)} phụ đề | {over} dòng vượt "
            f"{self.app.config.sub_max_chars} ký tự"
        )
        self._sync_voice_combo()
        self._loaded_project_root = project_root
        self._refresh_dirty = False

    def _on_sync_info_ready(self, info: object, project_root: str) -> None:
        """Nhận thời lượng voice từ worker; chỉ áp vào đúng dự án đang mở."""
        project = self.app.projects.current
        if not project or str(project.root) != project_root:
            return
        if self.table._loading:
            from PyQt6.QtCore import QTimer  # noqa: PLC0415
            QTimer.singleShot(40, lambda: self._on_sync_info_ready(info, project_root))
            return
        if isinstance(info, dict):
            if len(self._cached_segments) >= 500:
                self.table.update_sync_info_deferred(info)
            else:
                self.table.update_sync_info(info)

    def _refresh_table_text_columns(self, segments: list) -> None:
        """Cập nhật nhẹ sau dịch: không dựng lại toàn bộ QTableWidget."""
        from vicdub.utils.subtitles import gender_label  # noqa: PLC0415

        old_block = self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        try:
            self.table._segments = segments
            for row, seg in enumerate(segments):
                values = (
                    (4, gender_label(getattr(seg, "gender", ""))),
                    (5, getattr(seg, "text", "")),
                    (6, getattr(seg, "translation", "")),
                    (7, seg.voice if getattr(seg, "voice", "") else self.table.FOLLOW_SPEAKER),
                )
                for column, value in values:
                    item = self.table.item(row, column)
                    if item is not None and item.text() != str(value):
                        item.setText(str(value))
                self.table.refresh_fit_cell(row, seg)
        finally:
            self.table.setUpdatesEnabled(True)
            self.table.blockSignals(old_block)
            self.table.viewport().update()

    # ---------- Giọng tại chỗ ----------

    def _current_segment(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self._cached_segments):
            return None
        return self._cached_segments[row]

    def _sync_voice_combo(self) -> None:
        """Dòng chọn đổi -> chỉ cập nhật thông tin; không tự đổi giọng đã chọn."""
        seg = self._current_segment()
        if seg is None:
            self._update_selected_preview(None)
            return
        self._update_selected_preview(seg)

    def _update_selected_preview(self, seg) -> None:
        """Cập nhật panel preview bên phải theo dòng đang chọn."""
        if seg is None:
            self.preview_time_label.setText("—")
            self.preview_source_label.setText("Gốc: —")
            self.preview_translation_label.setText("Dịch: —")
            self.preview_voice_label.setText("Giọng: —")
            return
        self.preview_time_label.setText(f"{seg.start:.2f}s → {seg.end:.2f}s")
        self.preview_source_label.setText(f"Gốc: {seg.text or '—'}")
        self.preview_translation_label.setText(f"Dịch: {seg.translation or '—'}")
        voice = self._voice_for(seg) or "—"
        locked = ""
        project = self.app.projects.current
        if project is not None:
            from vicdub.utils.custom_voices import load_custom_lines  # noqa: PLC0415
            if seg.line in load_custom_lines(project.root):
                locked = "  🔒 đã khoá (Sinh giọng sẽ giữ nguyên)"
        self.preview_voice_label.setText(f"Giọng: {voice}{locked}")

    def _apply_voice_all_lines(self) -> None:
        """Áp giọng đang chọn cho toàn bộ dòng sub trong project."""
        if self.need_project():
            return
        voice = self.all_voice_combo.currentText().strip()
        if not voice:
            return
        for seg in self._cached_segments:
            seg.voice = voice
        self.app.projects.current.save_segments(self._cached_segments)
        self.app.engine.context["segments"] = self._cached_segments
        current_row = self.table.currentRow()
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        if 0 <= current_row < self.table.rowCount():
            self.table.setCurrentCell(current_row, 0)
        self._sync_voice_combo()
        self.app.show_status(
            f"Đã áp giọng '{voice}' cho toàn bộ {len(self._cached_segments)} dòng sub."
        )

    def _save_line_voice(self) -> None:
        """Lưu voice riêng cho đúng dòng đang chọn."""
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        voice = self.all_voice_combo.currentText().strip()
        if not voice:
            return
        seg.voice = voice
        self.app.projects.current.update_segment(seg)
        self.app.engine.context["segments"] = self._cached_segments
        self.app.show_status(f"Dòng {seg.line}: dùng voice riêng '{voice}'.")
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        self.table.setCurrentCell(seg.line - 1, 0)
        self._sync_voice_combo()

    def _hear_selected_voice(self) -> None:
        """Nghe thử giọng đang chọn với chính câu thoại của dòng chọn."""
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        text = (seg.translation or seg.text).strip() or "Xin chào."
        voice = self.all_voice_combo.currentText().strip() or self._voice_for(seg)
        config = self.app.config

        def work() -> str:
            engine = create_engine(config)
            out = preview_wav_path(config.data_dir, "speaker", voice)
            engine.synthesize(text, voice, 1.0, out)
            self.app.play_audio(out)
            return f"Đang phát '{voice}' đọc dòng {seg.line}."

        self._run_bg(work)

    def _save_segment(self, segment) -> None:
        project = self.app.projects.current
        if project:
            project.update_segment(segment)
            self.app.engine.context["segments"] = self._cached_segments

    def _segments(self) -> list:
        if self._cached_segments:
            return self._cached_segments
        return self.app.projects.current.load_segments()

    def _save_and_reload(self, segments: list) -> None:
        """Đánh lại số thứ tự, lưu DB rồi nạp lại bảng."""
        for i, seg in enumerate(segments, start=1):
            seg.line = i
        self.app.projects.current.save_segments(segments)
        self.invalidate()
        self.refresh(force=True)
        self.app.update_right_panel()

    def _current_index(self) -> int:
        row = self.table.currentRow()
        if row < 0:
            self.warn("Chọn một dòng trong bảng trước.")
        return row

    # ---------- Nguồn sub ----------

    def _sub_steps(self) -> list[str]:
        """Chỉ lưu timeline sub; clip xem thử được cắt riêng khi người dùng yêu cầu."""
        return ["subtitle"]

    def _import_subtitle(self) -> None:
        if self.need_project():
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Chọn file phụ đề gốc", "", SUBTITLE_FILTER
        )
        if path:
            self.app.start_pipeline(self._sub_steps(), {"subtitle_path": path})

    def _translate_ai(self) -> None:
        """Mở lựa chọn dịch ngay tại Studio rồi mới chạy pipeline."""
        if self.need_project():
            return
        if not self._segments():
            self.warn("Chưa có phụ đề. Hãy nhận diện từ video hoặc nhập một tệp phụ đề.")
            return
        config = self.app.config
        dialog = QDialog(self)
        dialog.setWindowTitle("Tùy chọn dịch phụ đề")
        dialog.setMinimumWidth(480)
        layout = QVBoxLayout(dialog)
        form = QFormLayout()

        source_combo = QComboBox()
        source_combo.addItem("Dịch nhanh", "qwen")
        source_combo.addItem("Dịch Gemini", "web")
        source_combo.addItem("API dự phòng cũ", "api")
        source_index = source_combo.findData(
            getattr(config, "translation_source", "web")
        )
        source_combo.setCurrentIndex(max(0, source_index))
        target = QComboBox()
        target.setEditable(True)
        target.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        target.setPlaceholderText("Chọn hoặc nhập ngôn ngữ đích")
        target_languages = (
            ("Tiếng Việt", "Tiếng Việt"),
            ("Tiếng Anh", "English"),
            ("Tiếng Trung giản thể", "简体中文"),
            ("Tiếng Trung phồn thể", "繁體中文"),
            ("Tiếng Nhật", "日本語"),
            ("Tiếng Hàn", "한국어"),
            ("Tiếng Thái", "ภาษาไทย"),
            ("Tiếng Indonesia", "Bahasa Indonesia"),
            ("Tiếng Tây Ban Nha", "Español"),
            ("Tiếng Pháp", "Français"),
            ("Tiếng Đức", "Deutsch"),
            ("Tiếng Bồ Đào Nha", "Português"),
            ("Tiếng Nga", "Русский"),
        )
        for label, prompt_name in target_languages:
            target.addItem(label, prompt_name)
        saved_target = str(getattr(config, "target_language", "") or "").strip()
        saved_index = target.findData(saved_target)
        if saved_index < 0:
            saved_index = target.findText(saved_target)
        if saved_index >= 0:
            target.setCurrentIndex(saved_index)
        else:
            target.setCurrentIndex(-1)
            target.setEditText(saved_target)
        style = QComboBox()
        from vicdub.utils.translation_styles import GENRES, STYLES, TRANSLATION_MODES
        for key, (label, _instruction) in STYLES.items():
            style.addItem(label, key)
        index = style.findData(getattr(config, "translation_style", "conversational"))
        style.setCurrentIndex(max(0, index))
        custom = QLineEdit(getattr(config, "translation_style_custom", ""))
        custom.setPlaceholderText(
            "Ví dụ: xưng hô anh/em, câu thật ngắn, giọng hài hước..."
        )
        custom.setEnabled(style.currentData() == "custom")
        style.currentIndexChanged.connect(
            lambda _index: custom.setEnabled(style.currentData() == "custom")
        )
        genre = QComboBox()
        for key, (label, _instruction) in GENRES.items():
            genre.addItem(label, key)
        genre.setCurrentIndex(max(0, genre.findData(
            getattr(config, "translation_genre", "neutral")
        )))
        mode = QComboBox()
        for key, (label, description) in TRANSLATION_MODES.items():
            mode.addItem(label, key)
            mode.setItemData(mode.count() - 1, description, Qt.ItemDataRole.ToolTipRole)
        mode.setCurrentIndex(max(0, mode.findData(
            getattr(config, "translation_mode", "balanced")
        )))
        form.addRow("Nguồn dịch:", source_combo)
        form.addRow("Ngôn ngữ đích:", target)
        form.addRow("Phong cách:", style)
        form.addRow("Thể loại:", genre)
        form.addRow("Mức xử lý:", mode)
        form.addRow("Yêu cầu riêng:", custom)
        layout.addLayout(form)

        hint = muted_label(
            "Bản dịch sẽ ưu tiên câu thoại tự nhiên, ngắn gọn và vừa thời lượng."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        if getattr(config, "translation_source", "web") == "web":
            account_by_slot = {
                int(item.get("slot", 0)): item
                for item in (getattr(config, "translation_accounts", []) or [])
                if str(item.get("slot", "")).isdigit()
            }
            active_accounts = []
            requested = max(
                1, min(4, int(getattr(config, "translation_web_profiles", 2)))
            )
            for slot in range(1, requested + 1):
                account = account_by_slot.get(slot, {})
                marker = (
                    Path(config.data_dir)
                    / f"gemini_web_login_translation_{slot}.ok"
                )
                if (
                    marker.exists()
                    and str(account.get("status", "")) not in {"error", "duplicate"}
                ):
                    email = str(account.get("email", "")).strip()
                    active_accounts.append(
                        f"Phiên {slot}" + (f" · {email}" if email else "")
                    )
            account_hint = muted_label(
                "Tài khoản sẽ làm việc: "
                + (
                    ", ".join(active_accounts)
                    if active_accounts else
                    "chưa có phiên nào sẵn sàng — hãy kiểm tra trong Cài đặt"
                )
            )
            account_hint.setWordWrap(True)
            layout.addWidget(account_hint)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.Ok
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Bắt đầu dịch")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Hủy")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        target_language = target.currentText().strip()
        target_index = target.currentIndex()
        if (target_index >= 0
                and target.currentText() == target.itemText(target_index)):
            target_language = str(target.itemData(target_index) or "").strip()
        if not target_language:
            self.warn("Hãy chọn hoặc nhập ngôn ngữ đích trước khi dịch.")
            return
        config.target_language = target_language
        config.translation_source = source_combo.currentData() or "web"
        if config.translation_source == "qwen":
            try:
                from vicdub.api.qwen_translation_client import (  # noqa: PLC0415
                    qwen_translation_configured,
                )
                if not qwen_translation_configured(config):
                    self.warn("Chưa có khóa dịch nhanh. Vào Cài đặt → Dịch & Đồng bộ để nhập khóa.")
                    return
            except Exception as exc:  # noqa: BLE001
                self.warn(f"Không kiểm tra được dịch nhanh: {exc}")
                return
        config.translation_style = style.currentData() or "conversational"
        config.translation_style_custom = custom.text().strip()
        config.translation_genre = genre.currentData() or "neutral"
        config.translation_mode = mode.currentData() or "balanced"
        config.save()
        self.app.start_pipeline(["translate"])

    def _upload_translation(self) -> None:
        """Tải file translated.srt lên, khớp theo thời gian vào sub hiện có."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có phụ đề gốc. Hãy nhận diện từ video hoặc nhập một tệp phụ đề.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Chọn file bản dịch", "", SUBTITLE_FILTER
        )
        if not path:
            return
        try:
            translated = load_subtitle_file(path)
        except (ValueError, OSError) as exc:
            self.warn(f"Không đọc được file: {exc}")
            return
        match_translations(segments, translated)
        self._save_and_reload(segments)
        self.app.engine.context["segments"] = segments
        # Đếm số dòng THỰC SỰ có bản dịch (không rỗng) - phản ánh đúng hơn
        # cả khi lệch số dòng lẫn khi file dịch có dòng để trống.
        n_base, n_tr = len(segments), len(translated)
        filled = sum(1 for s in segments if s.translation.strip())
        if filled >= n_base:
            self.info(f"Đã ghép đủ bản dịch cho {n_base} dòng.")
        else:
            detail = (f"Sub gốc {n_base} dòng, file dịch {n_tr} dòng"
                      + (" — LỆCH số dòng." if n_base != n_tr else "."))
            self.warn(
                f"Còn {n_base - filled}/{n_base} dòng chưa có bản dịch. {detail}\n"
                f"Muốn ghép đủ thì GIỮ NGUYÊN số dòng và timestamp của 'SRT "
                f"gốc' — chỉ dịch phần chữ, đừng để công cụ dịch gộp/tách/bỏ "
                f"dòng rỗng hay đổi thời gian. Tải lại 'SRT gốc về...' rồi dịch "
                f"lại giữ nguyên số thứ tự."
            )

    def _export_srt(self, translated: bool) -> None:
        """Tải file SRT thô (gốc hoặc bản dịch) về vị trí tùy chọn."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có sub để tải.")
            return
        if translated and not any(s.translation for s in segments):
            self.warn("Chưa có bản dịch để tải.")
            return
        default = "translated.srt" if translated else "original.srt"
        path, _ = QFileDialog.getSaveFileName(
            self, "Lưu SRT", default, "SubRip (*.srt)"
        )
        if path:
            write_srt(segments, path, translated=translated)
            self.info(f"Đã lưu: {path}")

    def _export_gender_srt(self, gender: str) -> None:
        """Xuất riêng SRT cho thoại nam hoặc nữ, giữ nguyên timing từng cut."""
        if self.need_project():
            return
        wanted = normalize_gender(gender)
        segments = [
            seg for seg in self._segments()
            if normalize_gender(getattr(seg, "gender", "")) == wanted
        ]
        label = "nam" if wanted == "male" else "nữ"
        if not segments:
            self.warn(
                f"Chưa có dòng nào được đánh dấu giới tính {label}. "
                "Sau khi dịch, kiểm tra cột 'Giới tính' hoặc sửa tay Nam/Nữ rồi xuất lại."
            )
            return
        translated = any(seg.translation for seg in segments)
        default = (
            f"{'male' if wanted == 'male' else 'female'}_"
            f"{'translated' if translated else 'original'}.srt"
        )
        path, _ = QFileDialog.getSaveFileName(
            self, "Lưu SRT theo giới tính", default, "SubRip (*.srt)"
        )
        if path:
            write_srt(segments, path, translated=translated)
            self.info(f"Đã lưu {len(segments)} dòng SRT {label}: {path}")

    # ---------- Thao tác dòng ----------

    def _add_row(self) -> None:
        """Chèn dòng mới sau dòng đang chọn (hoặc cuối bảng)."""
        if self.need_project():
            return
        segments = self._segments()
        index = self.table.currentRow()
        if index < 0:
            index = len(segments) - 1
        prev_end = segments[index].end if segments else 0.0
        new_seg = Segment(
            line=0, start=round(prev_end, 3), end=round(prev_end + 2.0, 3),
            text="(sub mới)", speaker="Narrator",
        )
        segments.insert(index + 1, new_seg)
        self._save_and_reload(segments)

    def _delete_row(self) -> None:
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        if index >= len(segments):
            return
        segments.pop(index)
        self._save_and_reload(segments)

    def _merge_down(self) -> None:
        """Gộp dòng đang chọn với dòng ngay dưới (nối text, giữ khung giờ)."""
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        if index >= len(segments) - 1:
            self.warn("Không có dòng dưới để gộp.")
            return
        cur, nxt = segments[index], segments[index + 1]
        cur.text = f"{cur.text} {nxt.text}".strip()
        cur.translation = f"{cur.translation} {nxt.translation}".strip()
        cur.end = nxt.end
        segments.pop(index + 1)
        self._save_and_reload(segments)

    def _split_row(self) -> None:
        """Tách đôi dòng đang chọn tại khoảng trắng giữa, chia giờ tỷ lệ."""
        if self.need_project():
            return
        index = self._current_index()
        if index < 0:
            return
        segments = self._segments()
        seg = segments[index]
        words = seg.text.split()
        if len(words) < 2:
            self.warn("Dòng quá ngắn để tách.")
            return
        half = len(words) // 2
        left_text, right_text = " ".join(words[:half]), " ".join(words[half:])
        ratio = len(left_text) / max(1, len(seg.text))
        mid_time = round(seg.start + seg.duration * ratio, 3)

        t_words = seg.translation.split()
        t_half = len(t_words) // 2
        left_trans = " ".join(t_words[:t_half])
        right_trans = " ".join(t_words[t_half:])

        right_seg = Segment(
            line=0, start=mid_time, end=seg.end, text=right_text,
            translation=right_trans, speaker=seg.speaker, gender=seg.gender,
        )
        seg.text, seg.translation, seg.end = left_text, left_trans, mid_time
        segments.insert(index + 1, right_seg)
        self._save_and_reload(segments)

    # ---------- Studio: so sánh clip / voice ----------

    def _voice_path(self, line: int) -> Path:
        return Path(self.app.projects.current.root) / "voices" / f"{line:04d}.wav"

    def _wav_seconds(self, path: Path) -> float:
        """Đọc thời lượng wav bằng thư viện chuẩn - tức thời, không cần ffprobe."""
        try:
            stat = path.stat()
            cache_key = str(path)
            cached = self._wav_duration_cache.get(cache_key)
            signature = (stat.st_mtime_ns, stat.st_size)
            if cached and cached[:2] == signature:
                return cached[2]
            with wave.open(str(path), "rb") as f:
                rate = f.getframerate()
                duration = f.getnframes() / rate if rate else 0.0
            self._wav_duration_cache[cache_key] = (*signature, duration)
            return duration
        except (wave.Error, OSError):
            return 0.0

    def _sync_info(
        self, segments: list, project_root: str | None = None, cfg=None,
    ) -> dict[int, tuple[str, str]]:
        """Tính cột Voice(s) và mức co voice; hình luôn giữ 1.0x."""
        info: dict[int, tuple[str, str]] = {}
        cfg = cfg or self.app.config
        root = Path(project_root) if project_root else Path(self.app.projects.current.root)
        for seg in segments:
            wav = root / "voices" / f"{seg.line:04d}.wav"
            if not wav.exists():
                continue
            voice_dur = self._wav_seconds(wav)
            if voice_dur <= 0 or seg.duration <= 0:
                continue
            if voice_dur <= seg.duration:
                pad = seg.duration - voice_dur
                sync = "OK khớp" if pad <= 0.05 else f"OK (đệm {pad:.1f}s lặng)"
            else:
                _video_speed, voice_speed, _ = VideoModule._plan_sync(
                    seg.duration, voice_dur, 1.0, cfg.speed_max, 0, [],
                )
                needed = voice_dur / seg.duration
                mark = " ⚠ mix" if needed > cfg.speed_max + 0.005 else ""
                sync = f"voice {voice_speed:.2f}x{mark}"
            info[seg.line] = (f"{voice_dur:.2f}", sync)
        return info

    def _selected_segment(self):
        index = self._current_index()
        if index < 0:
            return None
        segments = self._segments()
        return segments[index] if index < len(segments) else None

    def _voice_for(self, seg) -> str:
        """Voice của dòng: ưu tiên voice riêng, sau đó default config."""
        engine = create_engine(self.app.config)
        gender = normalize_gender(getattr(seg, "gender", "neutral"))
        gender_voice = ""
        if getattr(self.app.config, "use_gender_voices", False):
            if gender == "male":
                gender_voice = getattr(self.app.config, "default_male_voice", "")
            elif gender == "female":
                gender_voice = getattr(self.app.config, "default_female_voice", "")
        return (seg.voice
                or (gender_voice or "").strip()
                or (getattr(self.app.config, "default_voice", "") or "").strip()
                or engine.default_voice(getattr(seg, "gender", "neutral")))

    def _save_gender_voice_defaults(self, *_args) -> None:
        """Lưu ngay lựa chọn giọng Nam/Nữ, nhưng không sửa voice từng dòng."""
        if self._line_voice_guard:
            return
        config = self.app.config
        config.default_male_voice = self.male_voice_combo.currentText().strip()
        config.default_female_voice = self.female_voice_combo.currentText().strip()
        config.use_gender_voices = self.use_gender_voices.isChecked()
        config.save()

    def _run_bg(self, fn, result_signal=None, status: str = "Đang xử lý ở nền...") -> None:
        """Chạy tác vụ studio ở thread nền, báo kết quả qua signal."""
        with self._studio_threads_lock:
            if any(thread.is_alive() for thread in self._studio_threads):
                self.warn("Một tác vụ Studio đang chạy. Hãy chờ hoặc đóng app để hủy.")
                return
        self._studio_cancel.clear()

        def wrap() -> None:
            try:
                message = fn() or "Xong."
            except Exception as exc:  # noqa: BLE001 - báo mọi lỗi lên UI
                message = f"Lỗi: {exc}"
            finally:
                with self._studio_threads_lock:
                    self._studio_threads.discard(threading.current_thread())
            if not self._studio_cancel.is_set():
                if result_signal is not None:
                    result_signal.emit(message)
                else:
                    self.studio_done.emit(str(message))

        thread = threading.Thread(target=wrap, daemon=True, name="vicdub-studio")
        with self._studio_threads_lock:
            self._studio_threads.add(thread)
        thread.start()
        self.app.show_status(status)

    def has_background_task(self) -> bool:
        with self._studio_threads_lock:
            return any(thread.is_alive() for thread in self._studio_threads)

    def cancel_background_tasks(self) -> None:
        self._studio_cancel.set()

    def _on_studio_done(self, message: str) -> None:
        self.app.show_status(message)
        self.invalidate()
        self.refresh(force=True)

    # ---------- Studio: tác vụ từng dòng ----------

    @staticmethod
    def _is_ocr_error(seg) -> bool:
        return (
            bool(getattr(seg, "ocr_warning", ""))
            or (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được")
        )

    def _repair_ocr_segments(self, targets: list, manual_times: dict[int, float] | None = None) -> None:
        """OCR lại đúng các timestamp đã biết, không chạy lại detector/video scan."""
        if not targets:
            self.warn("Không có dòng nhận diện lỗi cần xử lý.")
            return
        project = self.app.projects.current
        config = self.app.config
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Không tìm thấy video nguồn.")
            return
        accounts = config.enabled_drive_accounts()
        creds = config.resolve_drive_credentials()
        if not accounts:
            self.warn("Chưa kết nối tài khoản xử lý phụ đề.")
            return

        manual_times = manual_times or {}

        def work() -> str:
            from PIL import Image  # noqa: PLC0415
            from vicdub.api.drive_ocr_client import DriveOcrClient  # noqa: PLC0415
            from vicdub.utils.detect_ocr import (  # noqa: PLC0415
                _enhance_failed_image, _ocr_each_image, _ocr_montage_pool,
            )
            from vicdub.utils.sub_detector import frame_quality, text_signature  # noqa: PLC0415
            from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415

            ffmpeg = FFmpeg(
                config.ffmpeg_path, config.ffprobe_path,
                cancel_event=self._studio_cancel,
                timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
            )
            width, height = ffmpeg.video_size(video)
            region = tuple(project.get_ocr_region(
                getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
            ))
            crop = region_to_crop(region, width, height)
            cw, ch, cx, cy = crop
            clients = [
                DriveOcrClient(
                    account.get("credentials_path") or creds,
                    account["token_path"], account.get("folder_id", ""),
                    report=None,
                )
                for account in accounts
            ]
            # Kết quả sửa phải được lưu ngay từng dòng. Trước đây code chỉ ghi
            # database sau khi quét xong toàn bộ, nên đóng app/lỗi giữa chừng
            # làm mất cả những dòng Drive OCR đã đọc thành công.
            result_dir = Path(project.root) / ".ocr_repair_results"
            result_dir.mkdir(parents=True, exist_ok=True)
            persist_lock = threading.Lock()
            repaired_lines: set[int] = set()

            def persist(seg, text: str) -> bool:
                value = str(text or "").strip()
                if not value or value.casefold().startswith("[ocr chưa đọc được"):
                    return False
                with persist_lock:
                    if seg.line in repaired_lines:
                        return True
                    seg.text = value
                    seg.translation = ""  # nguyên văn đổi -> dịch lại dòng này
                    seg.ocr_warning = ""
                    project.update_segment(seg)
                    payload = {
                        "line": seg.line, "start": seg.start, "end": seg.end,
                        "text": value,
                    }
                    path = result_dir / f"line_{seg.line:06d}.json"
                    temp_path = path.with_suffix(".tmp")
                    temp_path.write_text(
                        json.dumps(payload, ensure_ascii=False), encoding="utf-8"
                    )
                    os.replace(temp_path, path)
                    repaired_lines.add(seg.line)
                self.studio_progress.emit(
                    f"Sửa nhận diện — đã lưu ngay {len(repaired_lines)}/{len(targets)} dòng"
                )
                return True

            def restore_saved(seg) -> bool:
                # Kéo frame thủ công luôn OCR lại đúng frame người dùng chọn.
                if seg.line in manual_times:
                    return False
                path = result_dir / f"line_{seg.line:06d}.json"
                try:
                    saved = json.loads(path.read_text(encoding="utf-8"))
                    same_timing = (
                        int(saved.get("line", -1)) == seg.line
                        and abs(float(saved.get("start", -1)) - seg.start) < 0.01
                        and abs(float(saved.get("end", -1)) - seg.end) < 0.01
                    )
                    return same_timing and persist(seg, saved.get("text", ""))
                except (OSError, ValueError, TypeError):
                    return False

            # Khôi phục checkpoint của bản Repair cũ. Dữ liệu cũ đánh số theo
            # vị trí trong danh sách 173 dòng nên chỉ dùng khi count khớp tuyệt đối.
            legacy = Path(project.root) / ".ocr_repair"
            try:
                legacy_state = json.loads((legacy / "state.json").read_text(encoding="utf-8"))
                if int(legacy_state.get("count", -1)) == len(targets):
                    legacy_failed_targets = []
                    for index, seg in enumerate(targets):
                        path = legacy / f"image_{index:06d}.json"
                        saved = {}
                        if path.exists():
                            saved = json.loads(path.read_text(encoding="utf-8"))
                        if saved.get("status") != "done":
                            legacy_failed_targets.append(seg)
                            continue
                        if seg.line not in manual_times:
                            persist(seg, saved.get("text", ""))

                    # Lượt cứu hộ cũ đánh lại index theo đúng danh sách những
                    # ảnh còn lỗi của lượt trên, nên có thể khôi phục an toàn
                    # khi số lượng trong state cũng khớp.
                    enhanced_legacy = Path(project.root) / ".ocr_repair_enhanced"
                    enhanced_state = json.loads(
                        (enhanced_legacy / "state.json").read_text(encoding="utf-8")
                    )
                    if int(enhanced_state.get("count", -1)) == len(legacy_failed_targets):
                        for index, seg in enumerate(legacy_failed_targets):
                            if seg.line in manual_times:
                                continue
                            path = enhanced_legacy / f"image_{index:06d}.json"
                            if not path.exists():
                                continue
                            saved = json.loads(path.read_text(encoding="utf-8"))
                            if saved.get("status") == "done":
                                persist(seg, saved.get("text", ""))
            except (OSError, ValueError, TypeError):
                pass

            for seg in targets:
                if self._is_ocr_error(seg):
                    restore_saved(seg)
            pending = [seg for seg in targets if self._is_ocr_error(seg)]
            images = []
            try:
                if not pending:
                    self.app.engine.context["segments"] = self._cached_segments
                    return f"Đã khôi phục và lưu {len(repaired_lines)}/{len(targets)} dòng nhận diện."
                with tempfile.TemporaryDirectory(prefix="vicdub_ocr_repair_") as folder:
                    temp = Path(folder)
                    total = len(pending)
                    for index, seg in enumerate(pending):
                        if self._studio_cancel.is_set():
                            return f"Đã hủy; {len(repaired_lines)} dòng đọc được đã được lưu."
                        self.studio_progress.emit(
                            f"Chuẩn bị lại khung hình {index + 1}/{total} — dòng {seg.line}..."
                        )
                        if seg.line in manual_times:
                            times = [manual_times[seg.line]]
                        else:
                            duration = max(0.001, seg.end - seg.start)
                            saved = (
                                Path(project.root) / ".drive_ocr_checkpoint" /
                                "failed_images" / f"image_{seg.line - 1:06d}.png"
                            )
                            if saved.exists():
                                with Image.open(saved) as cached_image:
                                    images.append(cached_image.convert("RGB").copy())
                                continue
                            # Project cũ chưa lưu ảnh lỗi: lấy frame giữa để sửa
                            # nhanh. Nếu vẫn khó, người dùng kéo frame thủ công.
                            times = [seg.start + duration * 0.5]
                        best_image = None
                        best_score = -1.0
                        for sample, at in enumerate(times):
                            frame_path = temp / f"{seg.line:05d}_{sample}.png"
                            ffmpeg.extract_frame_exact(
                                video, max(0.0, at), str(frame_path),
                                str(Path(project.root) / ".frame_index"),
                            )
                            with Image.open(frame_path) as full:
                                roi = full.convert("RGB").crop((cx, cy, cx + cw, cy + ch))
                            score = frame_quality(text_signature(roi))
                            if score > best_score:
                                best_score = score
                                best_image = roi.copy()
                        if best_image is None:
                            raise RuntimeError(f"Dòng {seg.line}: không trích được frame.")
                        images.append(best_image)

                def report(_pct: int, message: str) -> None:
                    self.studio_progress.emit("Sửa nhận diện — " + message)

                # Repair dùng montage nhỏ: 173 dòng chỉ còn khoảng 22 tài liệu
                # Drive. Panel montage bị thiếu mới rơi về OCR đơn ở dưới.
                texts, failed = _ocr_montage_pool(
                    clients, images, getattr(config, "llm_ocr_lang_hint", ""),
                    report, batch_size=8,
                    is_cancelled=self._studio_cancel.is_set,
                    on_result=lambda index, value: persist(pending[index], value),
                )
                if failed and not self._studio_cancel.is_set():
                    enhanced = [_enhance_failed_image(images[i]) for i in failed]
                    rescued, _ = _ocr_each_image(
                        clients, enhanced, getattr(config, "llm_ocr_lang_hint", ""),
                        report, self._studio_cancel.is_set,
                        checkpoint_dir=str(Path(project.root) / ".ocr_repair_enhanced"),
                        max_attempts=2,
                        on_result=lambda index, value: persist(
                            pending[failed[index]], value
                        ),
                    )
                    for source_index, value in zip(failed, rescued):
                        if value.strip():
                            texts[source_index] = value.strip()

                # Callback đã commit từng kết quả. Vòng này chỉ là hàng rào an
                # toàn nếu backend nào đó không gọi callback.
                for seg, text in zip(pending, texts):
                    persist(seg, text)
                self.app.engine.context["segments"] = self._cached_segments
                remaining = sum(1 for seg in targets if self._is_ocr_error(seg))
                repaired = len(targets) - remaining
                return (
                    f"Đã lưu thật {repaired}/{len(targets)} dòng nhận diện vào project"
                    + (f"; còn {remaining} dòng cần kéo frame/nhập tay/xóa." if remaining else ".")
                )
            finally:
                for client in clients:
                    client.close()

        self._run_bg(work)

    def _repair_all_ocr_errors(self) -> None:
        if self.need_project():
            return
        errors = [seg for seg in self._segments() if self._is_ocr_error(seg)]
        self._repair_ocr_segments(errors)

    def _repair_selected_ocr_error(self) -> None:
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        if not self._is_ocr_error(seg):
            self.warn("Dòng đang chọn không phải dòng nhận diện lỗi.")
            return
        self._repair_ocr_segments([seg])

    def _manual_ocr_capture(self) -> None:
        """Preview crop tại timestamp, cho kéo playhead rồi OCR đúng frame chọn."""
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Không tìm thấy video nguồn.")
            return

        from PIL import Image  # noqa: PLC0415
        from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415

        config = self.app.config
        ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
        try:
            width, height = ffmpeg.video_size(video)
        except FFmpegError as exc:
            self.warn(str(exc))
            return
        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
        ))
        cw, ch, cx, cy = region_to_crop(region, width, height)

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Chụp lại phụ đề — dòng {seg.line}")
        dialog.resize(780, 360)
        layout = QVBoxLayout(dialog)
        preview = QLabel("Đang lấy frame...")
        preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        preview.setMinimumHeight(210)
        layout.addWidget(preview, 1)
        time_label = QLabel()
        slider = QSlider(Qt.Orientation.Horizontal)
        start_ms = max(0, int(round(seg.start * 1000)))
        end_ms = max(start_ms + 1, int(round(seg.end * 1000)))
        slider.setRange(start_ms, end_ms)
        slider.setValue((start_ms + end_ms) // 2)
        layout.addWidget(time_label)
        layout.addWidget(slider)
        hint = muted_label("Kéo tới khung hình chữ rõ nhất rồi bấm “Chụp và đọc”.")
        layout.addWidget(hint)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Chụp và đọc")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Hủy")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        with tempfile.TemporaryDirectory(prefix="vicdub_manual_ocr_") as folder:
            temp = Path(folder)

            def render_frame() -> None:
                at = slider.value() / 1000.0
                time_label.setText(
                    f"Thời gian: {at:.3f}s   |   đoạn {seg.start:.3f}s → {seg.end:.3f}s"
                )
                full_path = temp / "full.png"
                crop_path = temp / "crop.png"
                try:
                    ffmpeg.extract_frame_exact(
                        video, at, str(full_path),
                        str(Path(project.root) / ".frame_index"),
                    )
                    with Image.open(full_path) as full:
                        full.convert("RGB").crop((cx, cy, cx + cw, cy + ch)).save(crop_path)
                    pixmap = QPixmap(str(crop_path))
                    preview.setPixmap(pixmap.scaled(
                        preview.size(), Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    ))
                except Exception as exc:  # noqa: BLE001
                    preview.setText(f"Không lấy được frame: {exc}")

            slider.valueChanged.connect(
                lambda value: time_label.setText(
                    f"Thời gian: {value / 1000.0:.3f}s   |   thả chuột để cập nhật ảnh"
                )
            )
            slider.sliderReleased.connect(render_frame)
            render_frame()
            accepted = dialog.exec() == QDialog.DialogCode.Accepted
            selected_time = slider.value() / 1000.0
        if accepted:
            self._repair_ocr_segments([seg], {seg.line: selected_time})

    def _generate_voice_line(self) -> None:
        """Sinh voice riêng cho dòng đang chọn."""
        if self.need_project():
            return
        seg = self._selected_segment()
        if seg is None:
            return
        text = seg.translation or seg.text
        if (not text.strip()
                or text.strip().casefold().startswith("[ocr chưa đọc được")):
            self.warn("Dòng này chưa có nội dung để đọc.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, unmark_custom_lines,
        )
        if seg.line in load_custom_lines(self.app.projects.current.root):
            if not self.confirm(
                f"Dòng {seg.line} đang KHOÁ voice (nhập tay hoặc đã chốt).\n"
                "Sinh TTS đè lên và mở khoá?"
            ):
                return
            unmark_custom_lines(self.app.projects.current.root, [seg.line])
        selected_voice = (
            "" if self.use_gender_voices.isChecked()
            else self.all_voice_combo.currentText().strip()
        )
        if selected_voice:
            seg.voice = selected_voice
            self.app.projects.current.update_segment(seg)
            self.app.engine.context["segments"] = self._cached_segments
        voice = selected_voice or self._voice_for(seg)
        config = self.app.config
        out = self._voice_path(seg.line)
        project = self.app.projects.current

        def work() -> str:
            VoiceModule().run({
                "project": project, "segments": [seg], "config": config,
            })
            dur = self._wav_seconds(out)
            return f"Dòng {seg.line}: voice {dur:.2f}s (clip {seg.duration:.2f}s)"

        self._run_bg(work)

    def _generate_voice_all(self) -> None:
        """Dùng chung VoiceModule: batch, cache, retry và checkpoint."""
        if self.need_project():
            return
        from vicdub.core.voice_setup import voice_todo  # noqa: PLC0415
        missing_steps = voice_todo(self.app.config)
        if missing_steps:
            if "voice_api" in missing_steps:
                self.warn(
                    "Chưa cấu hình API giọng nói.\n\n"
                    "Vào tab 'Cài đặt' nhập API key/nền tảng giọng nói, "
                    "hoặc đổi về giọng cục bộ rồi cài thành phần cần thiết."
                )
                return
            labels = {
                "torch": "PyTorch (engine sinh giọng)",
                "omnivoice": "Bộ xử lý giọng cục bộ",
                "model": "Model giọng OmniVoice (~3GB)",
            }
            voice_missing = [labels.get(step, step) for step in missing_steps]
            self.warn(
                "Chưa đủ thành phần để sinh giọng:\n- "
                + "\n- ".join(voice_missing)
                + "\n\nMở Cài đặt → Cập nhật ứng dụng để chuẩn bị tự động."
            )
            return
        segments = [
            seg for seg in self._segments()
            if (seg.translation or seg.text).strip()
        ]
        if not segments:
            self.warn("Chưa có dòng nào có nội dung để render voice.")
            return
        selected_voice = (
            "" if self.use_gender_voices.isChecked()
            else self.all_voice_combo.currentText().strip()
        )
        if selected_voice and not self.use_gender_voices.isChecked():
            # Nút tạo toàn bộ luôn dùng đúng lựa chọn đang hiển thị, không rơi về
            # giọng mặc định/giới tính/nhân vật khiến tone thay đổi giữa các câu.
            for seg in segments:
                seg.voice = selected_voice
            self.app.projects.current.save_segments(self._cached_segments)
        self.app.engine.context["segments"] = segments
        self.app.start_pipeline(["voice"], {"segments": segments})

    @staticmethod
    def _voice_file_index(path: Path) -> int | None:
        """Nhận số dòng từ tên voice.

        Hỗ trợ các dạng phổ biến:
        - 1-xxxxx.wav / 001_xxxxx.wav / 001.xxxxx.wav
        - line_001_xxxxx.wav / voice-001-xxxxx.wav / audio 001 xxxxx.wav
        - 0001.wav
        """
        stem = path.stem.strip()
        patterns = (
            r"^\s*0*(\d{1,6})(?=$|[-_.\s])",
            r"(?:^|[-_.\s])(line|voice|audio|sub|seg|segment)[-_.\s]*0*(\d{1,6})(?=$|[-_.\s])",
            r"(?:^|[-_.\s])0*(\d{1,6})(?=$|[-_.\s])",
        )
        for pattern in patterns:
            match = re.search(pattern, stem, flags=re.IGNORECASE)
            if not match:
                continue
            value = match.group(match.lastindex or 1)
            if value and value.isdigit():
                index = int(value)
                return index if index > 0 else None
        return None

    def _scan_voice_folder(self, folder: Path) -> tuple[dict[int, Path], list[Path], list[tuple[int, Path, Path]]]:
        """Quét thư mục voice, trả matched + duplicate + conflict."""
        matched: dict[int, Path] = {}
        ignored: list[Path] = []
        conflicts: list[tuple[int, Path, Path]] = []
        for path in sorted(folder.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in AUDIO_EXTS:
                continue
            index = self._voice_file_index(path)
            if index is None:
                ignored.append(path)
                continue
            if index in matched:
                conflicts.append((index, matched[index], path))
                continue
            matched[index] = path
        return matched, ignored, conflicts

    def _pick_line_voice_file(self) -> None:
        """Chọn MỘT file audio làm voice cho đúng dòng đang chọn (thay TTS).

        File được convert về voices/NNNN.wav và KHOÁ (custom_lines.json) để
        'Sinh giọng' không sinh đè — đây là lựa chọn chủ động của người dùng.
        """
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, f"Chọn file voice cho dòng {seg.line}", "",
            "Audio (*.wav *.mp3 *.m4a *.aac *.flac *.ogg *.opus);;Tất cả (*.*)",
        )
        if not path:
            return
        from vicdub.utils.custom_voices import mark_custom_lines  # noqa: PLC0415

        project = self.app.projects.current
        voices_dir = Path(project.root) / "voices"
        voices_dir.mkdir(parents=True, exist_ok=True)
        dest = voices_dir / f"{seg.line:04d}.wav"
        src = Path(path)
        try:
            if src.suffix.lower() == ".wav":
                if src.resolve() != dest.resolve():
                    shutil.copy2(src, dest)
            else:
                config = self.app.config
                FFmpeg(config.ffmpeg_path, config.ffprobe_path).to_wav(
                    str(src), str(dest))
        except (OSError, FFmpegError) as exc:
            self.warn(f"Không dùng được file audio này: {exc}")
            return
        mark_custom_lines(project.root, [seg.line])
        voice_files = dict(self.app.engine.context.get("voice_files") or {})
        voice_files[seg.line] = str(dest)
        self.app.engine.context["voice_files"] = voice_files
        self.app.show_status(
            f"Dòng {seg.line}: dùng voice nhập tay '{src.name}' (đã khoá, TTS không đè)."
        )
        self.table.load(
            self._cached_segments, self._sync_info(self._cached_segments), self._voices
        )
        self._apply_filter(self.filter_input.text())
        self.table.setCurrentCell(seg.line - 1, 0)

    def _lock_line_voice(self) -> None:
        """Khoá TAY voice hiện tại của dòng — kể cả voice TTS vừa sinh mà ưng ý.

        Bổ trợ cho auto-khoá (chỉ chạy khi nhập file ngoài): sau khi khoá, đổi
        text/giọng rồi 'Sinh giọng' lại hàng loạt cũng không đè lên dòng này.
        """
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, mark_custom_lines,
        )

        project = self.app.projects.current
        wav = Path(project.root) / "voices" / f"{seg.line:04d}.wav"
        if not wav.exists():
            self.warn(
                f"Dòng {seg.line} chưa có voice để khoá. Sinh voice hoặc chọn "
                "file voice trước."
            )
            return
        if seg.line in load_custom_lines(project.root):
            self.app.show_status(f"Dòng {seg.line} đã khoá sẵn.")
            return
        mark_custom_lines(project.root, [seg.line])
        self.app.show_status(
            f"Dòng {seg.line}: đã khoá voice hiện tại — Sinh giọng sẽ giữ nguyên."
        )
        self._update_selected_preview(seg)

    def _remove_line_custom_voice(self) -> None:
        """Mở khoá voice của dòng đang chọn (TTS được sinh lại)."""
        if self.need_project():
            return
        seg = self._current_segment()
        if seg is None:
            self.warn("Chọn một dòng trong bảng trước.")
            return
        from vicdub.utils.custom_voices import (  # noqa: PLC0415
            load_custom_lines, unmark_custom_lines,
        )

        project = self.app.projects.current
        if seg.line not in load_custom_lines(project.root):
            self.warn(f"Dòng {seg.line} không bị khoá voice.")
            return
        if not self.confirm(
            f"Mở khoá voice của dòng {seg.line}?\n"
            "File wav hiện tại được giữ nguyên nhưng lần 'Sinh giọng' tới "
            "TTS sẽ sinh đè lên."
        ):
            return
        unmark_custom_lines(project.root, [seg.line])
        self.app.show_status(f"Dòng {seg.line}: đã mở khoá voice.")
        self._update_selected_preview(seg)

    def _import_voice_folder(self) -> None:
        """Nhập voice đã render sẵn, match theo số thứ tự trong tên file."""
        if self.need_project():
            return
        segments = self._segments()
        if not segments:
            self.warn("Chưa có phụ đề để khớp voice.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục chứa voice")
        if not folder:
            return
        source_dir = Path(folder)

        # rglob + natural matching can take seconds for thousands of files.
        # Keep it entirely off the Qt thread.
        def scan_work():
            matched, ignored, conflicts = self._scan_voice_folder(source_dir)
            valid_lines = {seg.line for seg in segments}
            usable = {
                line: path for line, path in matched.items()
                if line in valid_lines
            }
            return {
                "source_dir": source_dir,
                "segments": segments,
                "matched": matched,
                "ignored": ignored,
                "conflicts": conflicts,
                "usable": usable,
                "overflow": sorted(
                    line for line in matched if line not in valid_lines
                ),
                "missing": sorted(
                    line for line in valid_lines if line not in usable
                ),
            }

        self._run_bg(
            scan_work,
            result_signal=self.voice_scan_done,
            status="Đang quét và khớp file voice ở nền...",
        )

    def _on_voice_scan_done(self, payload: object) -> None:
        if not isinstance(payload, dict):
            self.warn(f"Không quét được thư mục voice: {payload}")
            return
        matched = payload["matched"]
        ignored = payload["ignored"]
        conflicts = payload["conflicts"]
        usable = payload["usable"]
        overflow = payload["overflow"]
        missing = payload["missing"]
        segments = payload["segments"]
        self.app.show_status(
            f"Đã quét {len(matched) + len(ignored)} file; "
            f"khớp {len(usable)}/{len(segments)} dòng."
        )
        if not usable:
            self.warn(
                "Không khớp được file voice nào.\n"
                "Tên file cần có số dòng, ví dụ: 1-xxx.wav, 001_xxx.wav, "
                "line_001_xxx.wav."
            )
            return
        preview_missing = ", ".join(map(str, missing[:12]))
        preview_overflow = ", ".join(map(str, overflow[:12]))
        preview_conflicts = ", ".join(str(line) for line, _old, _new in conflicts[:12])
        message = (
            f"Tìm thấy {len(matched)} file voice có số thứ tự.\n"
            f"Khớp {len(usable)}/{len(segments)} dòng phụ đề.\n"
            f"Bỏ qua {len(ignored)} file không đọc được số thứ tự.\n"
            f"Trùng số: {len(conflicts)}"
        )
        if missing:
            message += f"\nThiếu dòng: {preview_missing}{'...' if len(missing) > 12 else ''}"
        if overflow:
            message += f"\nDư ngoài số dòng sub: {preview_overflow}{'...' if len(overflow) > 12 else ''}"
        if conflicts:
            message += f"\nFile trùng số dòng: {preview_conflicts}{'...' if len(conflicts) > 12 else ''}"
        message += "\n\nÁp dụng voice đã khớp vào project?"
        if not self.confirm(message):
            return

        project = self.app.projects.current
        voices_dir = Path(project.root) / "voices"
        voices_dir.mkdir(parents=True, exist_ok=True)
        config = self.app.config

        def work():
            ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
            imported: dict[int, str] = {}
            converted = 0
            copied = 0
            total = len(usable)
            for position, (line, src) in enumerate(sorted(usable.items()), 1):
                self._studio_cancel.wait(0)
                if self._studio_cancel.is_set():
                    return {
                        "message": "Đã hủy nhập voice.",
                        "sync_info": {},
                    }
                dest = voices_dir / f"{line:04d}.wav"
                if src.suffix.lower() == ".wav":
                    if src.resolve() != dest.resolve():
                        # Không cần copy metadata; copyfile nhẹ hơn rõ rệt khi có
                        # vài nghìn file ngắn.
                        shutil.copyfile(src, dest)
                    copied += 1
                else:
                    ffmpeg.to_wav(str(src), str(dest))
                    converted += 1
                imported[line] = str(dest)
                if position == 1 or position % 25 == 0 or position == total:
                    self.studio_progress.emit(
                        f"Nhập voice {position}/{total} "
                        f"({copied} copy, {converted} convert)..."
                    )
            # Khoá các dòng vừa nhập: 'Sinh giọng' sẽ giữ nguyên, không TTS đè.
            from vicdub.utils.custom_voices import mark_custom_lines  # noqa: PLC0415
            mark_custom_lines(project.root, imported.keys())
            existing = dict(self.app.engine.context.get("voice_files") or {})
            existing.update(imported)
            self.app.engine.context["voice_files"] = existing
            # Tính duration ở worker. Slot giao diện chỉ thay ba cột có sẵn,
            # tuyệt đối không dựng lại bảng phụ đề 3.000+ dòng.
            sync_info = self._sync_info(segments)
            return {
                "message": (
                    f"Đã nhập {len(imported)} voice "
                    f"({copied} copy, {converted} convert) — đã khoá chống TTS đè. "
                    "Có thể bấm Đồng bộ tất cả hoặc xuất video."
                ),
                "sync_info": sync_info,
            }

        self._run_bg(
            work,
            result_signal=self.voice_import_done,
            status=f"Đang nhập {len(usable)} file voice ở nền...",
        )

    def _on_voice_import_done(self, payload: object) -> None:
        if not isinstance(payload, dict):
            self.warn(f"Nhập voice lỗi: {payload}")
            return
        message = str(payload.get("message", "Đã nhập voice."))
        sync_info = payload.get("sync_info") or {}
        self.app.show_status(message)
        if sync_info:
            self.table.update_sync_info(sync_info)
        self._sync_voice_combo()

    def _preview_line(self) -> None:
        """Xem thử dòng chọn, giữ nguyên hình và chỉ co voice dài nếu cần."""
        if self.need_project():
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Chưa chọn video nguồn (tab Video).")
            return
        seg = self._selected_segment()
        if seg is None:
            return
        config = self.app.config
        wav = self._voice_path(seg.line)
        out_dir = Path(project.root) / "output"
        text = seg.translation or seg.text

        def work() -> str:
            ffmpeg = FFmpeg(config.ffmpeg_path, config.ffprobe_path)
            raw = out_dir / "_preview_raw.mp4"
            has_voice = wav.exists() and self._wav_seconds(wav) > 0
            ffmpeg.cut_clip(video, seg.start, seg.end, str(raw),
                            keep_audio=not has_voice)

            current = raw
            note = "audio gốc (chưa có voice)"
            if has_voice:
                voice_dur = self._wav_seconds(wav)
                _video_speed, voice_speed, _ = VideoModule._plan_sync(
                    seg.duration, voice_dur,
                    1.0, config.speed_max, 0, [],
                )
                voice_src = str(wav)
                if voice_speed > 1.005:
                    sped = out_dir / "_preview_voice.wav"
                    ffmpeg.speed_audio(str(wav), voice_speed, str(sped))
                    voice_src = str(sped)
                voiced = out_dir / "_preview_voiced.mp4"
                ffmpeg.mux_voice(str(current), voice_src, str(voiced))
                current = voiced
                note = (
                    f"hình nguyên tốc độ + voice co {voice_speed:.2f}x"
                    if voice_speed > 1.005 else
                    f"hình nguyên tốc độ + voice {voice_dur:.2f}s"
                )

            final = out_dir / f"preview_line_{seg.line:04d}.mp4"
            if text.strip():
                dur = ffmpeg.duration(str(current))
                srt = out_dir / "_preview.srt"
                write_srt([Segment(1, 0.0, dur, text=text)], srt)
                ffmpeg.burn_subtitle(str(current), str(srt), str(final))
            else:
                Path(current).replace(final)
            if os.name == "nt":
                os.startfile(str(final))  # noqa: S606
            return f"Xem thử dòng {seg.line}: {note}, sub đã đóng vào hình"

        self._run_bg(work)

    def _sync_line(self) -> None:
        """Co voice của dòng chọn nếu dài; tuyệt đối không tạo/retime clip hình."""
        if self.need_project():
            return
        project = self.app.projects.current
        video = project.video_path
        if not video or not Path(video).exists():
            self.warn("Chưa chọn video nguồn (tab Video).")
            return
        seg = self._selected_segment()
        if seg is None:
            return
        wav = self._voice_path(seg.line)
        if not wav.exists():
            self.warn("Dòng này chưa có voice. Bấm 'Sinh voice dòng chọn' trước.")
            return
        config = self.app.config
        def work() -> str:
            voice_dur = self._wav_seconds(wav)
            _video_speed, speed, _ = VideoModule._plan_sync(
                seg.duration, voice_dur, 1.0, config.speed_max, seg.line, [],
            )
            if voice_dur <= seg.duration:
                pad = seg.duration - voice_dur
                note = (f"giữ voice gốc, còn {pad:.1f}s lặng" if pad > 0.05
                        else "khớp hoàn hảo")
            else:
                note = (
                    f"sẽ co tối đa {speed:.2f}x và mượn khoảng trống khi xuất"
                )
            return (
                f"Dòng {seg.line}: khung {seg.duration:.2f}s / voice "
                f"{voice_dur:.2f}s — {note}; hình không đổi"
            )

        self._run_bg(work)

    def _sync_all(self) -> None:
        """Đồng bộ toàn bộ voice; không băm hoặc kéo hình."""
        if self.need_project():
            return
        self.app.start_pipeline(["video"])

    def _play_line(self, line: int) -> None:
        """Nút ▶ trên bảng: phát voice của dòng đó ngay trong app."""
        wav = self._voice_path(line)
        if not wav.exists():
            self.app.show_status(
                f"Dòng {line} chưa có voice - chọn dòng rồi bấm "
                "'Sinh voice dòng chọn'."
            )
            return
        self.app.play_audio(str(wav))
        self.app.show_status(
            f"Đang phát voice dòng {line} ({self._wav_seconds(wav):.1f}s)."
        )

    def _play_all_voices(self) -> None:
        """Nối toàn bộ voice đã render theo thứ tự và phát trong app."""
        if self.need_project():
            return
        segments = self._segments()
        wavs = [str(self._voice_path(seg.line)) for seg in segments
                if self._voice_path(seg.line).exists()]
        if not wavs:
            self.warn("Chưa có voice nào được render. Sinh voice trước.")
            return
        config = self.app.config
        out = str(Path(config.data_dir) / "preview_all.wav")

        def work() -> str:
            FFmpeg(config.ffmpeg_path, config.ffprobe_path).concat_audio(wavs, out)
            self.app.play_audio(out)
            total = sum(self._wav_seconds(Path(w)) for w in wavs)
            return (f"Đang phát {len(wavs)} voice liên tục "
                    f"(tổng {total:.0f} giây).")

        self._run_bg(work)

    # ---------- Tìm kiếm ----------

    def _apply_filter(self, needle: str) -> None:
        needle = needle.strip().lower()
        previous = getattr(self, "_last_filter_text", "")
        if not needle and not previous:
            return
        self._last_filter_text = needle
        for row in range(self.table.rowCount()):
            if not needle:
                self.table.setRowHidden(row, False)
                continue
            text_item = self.table.item(row, 5)
            trans_item = self.table.item(row, 6)
            haystack = f"{text_item.text() if text_item else ''} " \
                       f"{trans_item.text() if trans_item else ''}".lower()
            self.table.setRowHidden(row, needle not in haystack)


# ====================================================================
class DraggableSubtitlePreview(QLabel):
    """Video still preview that emits normalized subtitle drop coordinates."""

    position_changed = pyqtSignal(float, float)
    blur_region_changed = pyqtSignal(object)

    def __init__(self, text: str = "") -> None:
        super().__init__(text)
        self._dragging = False
        self._edit_blur = False
        self._blur_start: tuple[float, float] | None = None
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    def set_blur_edit_mode(self, enabled: bool) -> None:
        self._edit_blur = bool(enabled)
        self._dragging = False
        self._blur_start = None
        self.setCursor(
            Qt.CursorShape.CrossCursor if enabled else Qt.CursorShape.OpenHandCursor
        )

    def _normalized_point(self, event) -> tuple[float, float] | None:
        pixmap = self.pixmap()
        if pixmap is None or pixmap.isNull():
            return None
        left = (self.width() - pixmap.width()) / 2.0
        top = (self.height() - pixmap.height()) / 2.0
        x = (event.position().x() - left) / max(1, pixmap.width())
        y = (event.position().y() - top) / max(1, pixmap.height())
        return max(0.0, min(1.0, x)), max(0.0, min(1.0, y))

    def _emit_position(self, event) -> None:
        point = self._normalized_point(event)
        if point is None:
            return
        x, y = point
        self.position_changed.emit(
            max(0.03, min(0.97, x)), max(0.03, min(0.97, y))
        )

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            if self._edit_blur:
                self._blur_start = self._normalized_point(event)
                self._dragging = self._blur_start is not None
                event.accept()
                return
            self._dragging = True
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            self._emit_position(event)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._dragging and event.buttons() & Qt.MouseButton.LeftButton:
            if self._edit_blur:
                event.accept()
                return
            self._emit_position(event)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self._dragging:
            self._dragging = False
            if self._edit_blur:
                end = self._normalized_point(event)
                start, self._blur_start = self._blur_start, None
                if start is not None and end is not None:
                    x0, x1 = sorted((start[0], end[0]))
                    y0, y1 = sorted((start[1], end[1]))
                    if x1 - x0 >= 0.02 and y1 - y0 >= 0.015:
                        self.blur_region_changed.emit((x0, y0, x1, y1))
                event.accept()
                return
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            self._emit_position(event)
            event.accept()
            return
        super().mouseReleaseEvent(event)


class SeriesPage(BasePage):
    """Ghép nhiều video + nhiều sub thành một video/SRT tổng."""

    progress = pyqtSignal(str)
    done = pyqtSignal(bool, str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(
            app,
            "Ghép series",
            "Ghép nhiều video nhỏ và cộng dồn timecode phụ đề thành một bản tổng.",
        )
        self.items: list[dict] = []
        self._known_subs: dict[str, str] = {}
        self._batch_series_dirs: list[str] = []
        self._busy = False

        name_row = QHBoxLayout()
        name_row.addWidget(muted_label("Tên series/dự án:"))
        self.series_name = QLineEdit("series_full")
        self.series_name.setPlaceholderText("Ví dụ: tap_01 hoặc ten_du_an")
        name_row.addWidget(self.series_name, 1)
        self.btn_batch_dirs = QPushButton("Chọn nhiều thư mục series...")
        name_row.addWidget(self.btn_batch_dirs)
        self.body.addLayout(name_row)

        row = QHBoxLayout()
        self.btn_add_videos = QPushButton("Chọn video...")
        self.btn_add_video_dir = QPushButton("Chọn thư mục video...")
        self.btn_add_subs = QPushButton("Chọn SRT...")
        self.btn_add_sub_dir = QPushButton("Chọn thư mục SRT...")
        self.btn_match = QPushButton("Tự khớp theo tên")
        self.btn_clear = QPushButton("Xóa danh sách")
        for btn in (
            self.btn_add_videos, self.btn_add_video_dir, self.btn_add_subs,
            self.btn_add_sub_dir, self.btn_match, self.btn_clear,
        ):
            row.addWidget(btn)
        row.addStretch(1)
        self.body.addLayout(row)

        out_row = QHBoxLayout()
        out_row.addWidget(muted_label("Thư mục xuất:"))
        self.output_dir = QLineEdit(str(Path(self.app.config.projects_dir).parent / "series_output"))
        self.btn_output = QPushButton("Chọn...")
        out_row.addWidget(self.output_dir, 1)
        out_row.addWidget(self.btn_output)
        self.body.addLayout(out_row)

        opt_row = QHBoxLayout()
        self.merge_video_cb = QCheckBox("Xuất video tổng")
        self.merge_video_cb.setChecked(True)
        self.merge_srt_cb = QCheckBox("Xuất SRT gốc tổng")
        self.merge_srt_cb.setChecked(True)
        self.translate_later_cb = QCheckBox("Dịch SRT tổng sau khi ghép")
        self.translate_later_cb.setChecked(False)
        self.split_back_cb = QCheckBox("Tách SRT dịch về từng tập")
        self.split_back_cb.setChecked(False)
        self.split_back_cb.setToolTip(
            "Sau khi dịch bản tổng, tách ngược thành SRT dịch riêng cho từng tập "
            "(theo đúng bảng offset đã ghép) — dùng khi cần đăng lẻ."
        )
        for cb in (self.merge_video_cb, self.merge_srt_cb, self.translate_later_cb,
                   self.split_back_cb):
            cb.setObjectName("seriesOption")
            cb.setMinimumHeight(34)
            cb.setStyleSheet("""
                QCheckBox#seriesOption {
                    background-color: #111827;
                    border: 1px solid #334155;
                    border-radius: 8px;
                    padding: 7px 12px;
                    color: #e5eef8;
                    font-weight: 600;
                    spacing: 10px;
                }
                QCheckBox#seriesOption:hover {
                    border-color: #38bdf8;
                    background-color: #162033;
                }
                QCheckBox#seriesOption:checked {
                    border-color: #1f6feb;
                    background-color: #13213a;
                }
                QCheckBox#seriesOption::indicator {
                    width: 16px;
                    height: 16px;
                    border-radius: 4px;
                    border: 1px solid #64748b;
                    background-color: #0b1220;
                }
                QCheckBox#seriesOption::indicator:checked {
                    border-color: #38bdf8;
                    background-color: #1f6feb;
                }
            """)
        opt_row.addWidget(self.merge_video_cb)
        opt_row.addWidget(self.merge_srt_cb)
        opt_row.addWidget(self.translate_later_cb)
        opt_row.addWidget(self.split_back_cb)
        opt_row.addStretch(1)
        self.body.addLayout(opt_row)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["#", "Video", "SRT", "Duration", "Trạng thái"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.body.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.status = QLabel("Chưa có dữ liệu.")
        self.btn_export = QPushButton("Xuất video + SRT full")
        self.btn_batch_export = QPushButton("Render hàng loạt")
        self.btn_open_output = QPushButton("Mở thư mục xuất")
        bottom.addWidget(self.status, 1)
        bottom.addWidget(self.btn_open_output)
        bottom.addWidget(self.btn_batch_export)
        bottom.addWidget(self.btn_export)
        self.body.addLayout(bottom)

        self.btn_add_videos.clicked.connect(self._add_videos)
        self.btn_add_video_dir.clicked.connect(self._add_video_dir)
        self.btn_add_subs.clicked.connect(self._add_subs)
        self.btn_add_sub_dir.clicked.connect(self._add_sub_dir)
        self.btn_match.clicked.connect(self._auto_match)
        self.btn_clear.clicked.connect(self._clear)
        self.btn_output.clicked.connect(self._choose_output)
        self.btn_open_output.clicked.connect(self._open_output)
        self.btn_export.clicked.connect(self._export)
        self.btn_batch_dirs.clicked.connect(self._choose_batch_series_dirs)
        self.btn_batch_export.clicked.connect(self._export_batch)
        self.progress.connect(self._set_status)
        self.done.connect(self._on_done)

    def refresh(self) -> None:
        self._render()

    def _set_status(self, text: str) -> None:
        self.status.setText(text)
        self.app.show_status(text)

    def _video_exts(self) -> tuple[str, ...]:
        return tuple(e.lower() for e in SUPPORTED_VIDEO_EXTS)

    def _add_videos(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Chọn video", "", VIDEO_FILTER)
        self._append_videos(paths)

    def _add_video_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục video")
        if not folder:
            return
        paths = sort_paths_natural(
            str(p) for p in Path(folder).iterdir()
            if p.is_file() and p.suffix.lower() in self._video_exts()
        )
        self._append_videos(paths)

    def _add_subs(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Chọn SRT", "", SUBTITLE_FILTER)
        self._remember_subs(paths)
        self._auto_match()

    def _add_sub_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục SRT")
        if not folder:
            return
        paths = sort_paths_natural(
            str(p) for p in Path(folder).rglob("*")
            if p.is_file() and p.suffix.lower() in {".srt", ".ass", ".vtt"}
        )
        self._remember_subs(paths)
        self._auto_match()

    def _append_videos(self, paths: list[str]) -> None:
        existing = {str(Path(item["video"]).resolve()).casefold() for item in self.items}
        for raw in paths:
            if not raw:
                continue
            path = str(Path(raw))
            key = str(Path(path).resolve()).casefold()
            if key in existing:
                continue
            self.items.append({"video": path, "sub": "", "duration": 0.0, "status": "Chưa kiểm tra"})
            existing.add(key)
        self._auto_match()

    def _remember_subs(self, paths: list[str]) -> None:
        for raw in paths:
            path = Path(raw)
            if path.suffix.lower() not in {".srt", ".ass", ".vtt"}:
                continue
            for key in self._match_keys(path.stem):
                self._known_subs.setdefault(key, str(path))

    @staticmethod
    def _match_keys(stem: str) -> list[str]:
        """Tạo khóa khớp mềm cho video/sub: exact, tên đã lọc, số đầu file."""
        raw = stem.casefold().strip()
        # Bỏ một số hậu tố hay gặp ở video/sub tải về: không làm mất số tập.
        cleaned = re.sub(
            r"(无字幕版|有字幕版|字幕版|无字幕|有字幕|vietsub|sub|subtitle|translated|bản dịch)",
            "",
            raw,
            flags=re.IGNORECASE,
        )
        cleaned = re.sub(r"[\s._\\-]+", "", cleaned).strip()
        keys = [raw, cleaned]
        # Match theo số đầu file: 01xxx.mp4 ↔ 01.srt / 1.srt.
        m = re.match(r"^\D*0*(\d{1,4})", raw)
        if m:
            keys.append(f"num:{int(m.group(1))}")
        return [k for i, k in enumerate(keys) if k and k not in keys[:i]]

    def _auto_match(self) -> None:
        for item in self.items:
            video = Path(item["video"])
            candidates = [
                video.with_suffix(".srt"),
                video.with_suffix(".ass"),
                video.with_suffix(".vtt"),
            ]
            matched = next((str(p) for p in candidates if p.exists()), "")
            if not matched:
                matched = next(
                    (self._known_subs.get(key, "") for key in self._match_keys(video.stem)
                     if self._known_subs.get(key, "")),
                    "",
                )
            if matched:
                item["sub"] = matched
                item["status"] = "OK"
            elif not item.get("sub"):
                item["status"] = "Thiếu SRT"
        self._render()

    def _clear(self) -> None:
        if self._busy:
            return
        self.items.clear()
        self._known_subs.clear()
        self._render()

    def _choose_output(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất")
        if folder:
            self.output_dir.setText(folder)

    def _open_output(self) -> None:
        folder = Path(self.output_dir.text().strip())
        folder.mkdir(parents=True, exist_ok=True)
        os.startfile(str(folder))

    def _choose_batch_series_dirs(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self,
            "Chọn thư mục cha chứa nhiều series",
        )
        if not folder:
            return
        root = Path(folder)
        dirs = sort_paths_natural(
            str(p) for p in root.iterdir()
            if p.is_dir() and self._collect_series_items(p)
        )
        if not dirs and self._collect_series_items(root):
            dirs = [str(root)]
        self._batch_series_dirs = dirs
        self.status.setText(f"Đã chọn {len(dirs)} series để render hàng loạt.")

    def _render(self) -> None:
        self.table.setRowCount(len(self.items))
        for row, item in enumerate(self.items):
            duration = float(item.get("duration") or 0.0)
            values = [
                str(row + 1),
                Path(item["video"]).name,
                Path(item["sub"]).name if item.get("sub") else "Chưa có",
                self._fmt_duration(duration) if duration else "-",
                item.get("status") or "",
            ]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(value)
                if col == 1:
                    cell.setToolTip(item["video"])
                elif col == 2:
                    cell.setToolTip(item.get("sub", ""))
                self.table.setItem(row, col, cell)
        matched = sum(1 for item in self.items if item.get("sub"))
        self.status.setText(f"{len(self.items)} video | {matched} SRT đã khớp")

    @staticmethod
    def _fmt_duration(seconds: float) -> str:
        total = max(0, int(round(seconds)))
        return f"{total // 3600:02d}:{(total % 3600) // 60:02d}:{total % 60:02d}"

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        for btn in (
            self.btn_add_videos, self.btn_add_video_dir, self.btn_add_subs,
            self.btn_add_sub_dir, self.btn_match, self.btn_clear,
            self.btn_output, self.btn_export, self.btn_batch_dirs, self.btn_batch_export,
        ):
            btn.setEnabled(not busy)

    @staticmethod
    def _safe_name(value: str, fallback: str = "series_full") -> str:
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", value.strip())
        name = re.sub(r"\s+", " ", name).strip(" ._")
        return name or fallback

    def _series_output_name(self) -> str:
        return self._safe_name(self.series_name.text(), "series_full")

    def _collect_series_items(self, folder: Path) -> list[dict]:
        videos = sort_paths_natural(
            p for p in folder.iterdir()
            if p.is_file() and p.suffix.lower() in self._video_exts()
        )
        subs: dict[str, str] = {}
        for p in sort_paths_natural(folder.rglob("*")):
            if not p.is_file() or p.suffix.lower() not in {".srt", ".ass", ".vtt"}:
                continue
            for key in self._match_keys(p.stem):
                subs.setdefault(key, str(p))
        items: list[dict] = []
        for video in videos:
            sub = next(
                (subs.get(key, "") for key in self._match_keys(video.stem)
                 if subs.get(key, "")),
                "",
            )
            items.append({
                "video": str(video),
                "sub": sub,
                "duration": 0.0,
                "status": "OK" if sub else "Thiếu SRT",
            })
        return items

    def _export(self) -> None:
        if self._busy:
            return
        if not self.items:
            self.warn("Chưa có video để ghép.")
            return
        if (
            not self.merge_video_cb.isChecked()
            and not self.merge_srt_cb.isChecked()
            and not self.translate_later_cb.isChecked()
        ):
            self.warn("Chọn ít nhất một đầu ra: video tổng, SRT tổng hoặc SRT dịch.")
            return
        output_dir = Path(self.output_dir.text().strip())
        if not str(output_dir):
            self.warn("Chưa chọn thư mục xuất.")
            return
        items = [dict(item) for item in self.items]
        options = {
            "merge_video": self.merge_video_cb.isChecked(),
            "merge_srt": self.merge_srt_cb.isChecked(),
            "translate": self.translate_later_cb.isChecked(),
            "split_back": self.split_back_cb.isChecked(),
            "name": self._series_output_name(),
        }
        self._set_busy(True)
        self._set_status("Đang chuẩn bị ghép series...")

        def worker() -> None:
            try:
                result = self._export_worker(items, output_dir, options)
                self.done.emit(True, result)
            except Exception as exc:  # noqa: BLE001
                self.done.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _export_batch(self) -> None:
        if self._busy:
            return
        if not self._batch_series_dirs:
            self._choose_batch_series_dirs()
        if not self._batch_series_dirs:
            self.warn("Chưa chọn thư mục series để render hàng loạt.")
            return
        output_dir = Path(self.output_dir.text().strip())
        options = {
            "merge_video": self.merge_video_cb.isChecked(),
            "merge_srt": self.merge_srt_cb.isChecked(),
            "translate": self.translate_later_cb.isChecked(),
            "split_back": self.split_back_cb.isChecked(),
        }
        if (
            not options["merge_video"]
            and not options["merge_srt"]
            and not options["translate"]
        ):
            self.warn("Chọn ít nhất một đầu ra: video tổng, SRT tổng hoặc SRT dịch.")
            return
        dirs = [Path(p) for p in self._batch_series_dirs]
        self._set_busy(True)
        self._set_status(f"Chuẩn bị render hàng loạt {len(dirs)} series...")

        def worker() -> None:
            try:
                outputs: list[str] = []
                for index, folder in enumerate(dirs, start=1):
                    items = self._collect_series_items(folder)
                    if not items:
                        outputs.append(f"{folder.name}: bỏ qua vì không có video")
                        continue
                    name = self._safe_name(folder.name, f"series_{index:03d}")
                    series_out = output_dir / name
                    opts = dict(options)
                    opts["name"] = name
                    self.progress.emit(f"Series {index}/{len(dirs)}: {name}")
                    outputs.append(self._export_worker(items, series_out, opts, quiet=True))
                self.done.emit(True, "Render hàng loạt xong:\n" + "\n\n".join(outputs))
            except Exception as exc:  # noqa: BLE001
                self.done.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _export_worker(
        self, items: list[dict], output_dir: Path, options: dict, quiet: bool = False,
    ) -> str:
        output_dir.mkdir(parents=True, exist_ok=True)
        out_name = self._safe_name(str(options.get("name") or "series_full"), "series_full")
        ffmpeg = FFmpeg(
            self.app.config.ffmpeg_path,
            self.app.config.ffprobe_path,
            timeout_seconds=getattr(self.app.config, "ffmpeg_timeout_seconds", 21600),
        )
        offset = 0.0
        merged_segments: list[Segment] = []
        video_paths: list[str] = []
        episodes: list[tuple[str, float, float]] = []   # (tên tập, offset, duration)
        overrun_notes: list[str] = []
        total = len(items)

        for index, item in enumerate(items, start=1):
            video = str(item["video"])
            if not Path(video).exists():
                raise FileNotFoundError(f"Không thấy video: {video}")
            self.progress.emit(f"Đọc {index}/{total}: {Path(video).name}")
            duration = ffmpeg.duration(video)
            if duration <= 0:
                # Duration hỏng mà cứ đi tiếp thì offset các tập sau sập hết ->
                # toàn bộ sub từ đây lẫn sang nhau. Dừng ngay còn hơn ra file sai.
                raise ValueError(
                    f"Không đọc được thời lượng video (file hỏng?): {Path(video).name}"
                )
            item["duration"] = duration
            video_paths.append(video)
            episodes.append((Path(video).stem, offset, duration))

            sub = str(item.get("sub") or "")
            if sub and Path(sub).exists():
                segments = load_subtitle_file(sub)
                # Sub có dòng BẮT ĐẦU sau khi video hết = gần như chắc ghép nhầm
                # cặp (sub của tập khác). Không chặn, nhưng phải nói to.
                overrun = sub_overrun(segments, duration)
                for seg in segments:
                    text = clean_subtitle_text(seg.text or seg.translation or "")
                    merged_segments.append(Segment(
                        line=len(merged_segments) + 1,
                        start=seg.start + offset,
                        end=seg.end + offset,
                        text=text,
                        translation=seg.translation,
                        speaker=seg.speaker,
                        gender=seg.gender,
                        voice=seg.voice,
                    ))
                nonempty = sum(1 for seg in segments if (seg.text or seg.translation or "").strip())
                if overrun:
                    item["status"] = f"⚠ {overrun} dòng sau khi video hết — sub có đúng tập này?"
                    overrun_notes.append(
                        f"{Path(video).name} ↔ {Path(sub).name}: {overrun} dòng vượt thời lượng"
                    )
                else:
                    item["status"] = f"OK ({nonempty}/{len(segments)} dòng)"
            else:
                item["status"] = "Không có SRT"
            offset += duration

        if (
            (options.get("merge_srt") or options.get("translate"))
            and not any((seg.text or "").strip() for seg in merged_segments)
        ):
            raise ValueError(
                "SRT tổng không có nội dung chữ. Kiểm tra file sub đầu vào hoặc định dạng sub."
            )

        outputs: list[str] = []
        srt_path = output_dir / f"{out_name}.srt"
        if options.get("merge_srt") or options.get("translate"):
            write_srt(merged_segments, srt_path, translated=False)
            outputs.append(str(srt_path))
            # Manifest offset: bằng chứng ghép + đầu vào cho tách ngược sau này.
            manifest_path = output_dir / f"{out_name}.episodes.json"
            manifest_path.write_text(json.dumps({
                "episodes": [
                    {"name": name, "offset": round(off, 3), "duration": round(dur, 3),
                     "video": video_paths[i], "sub": str(items[i].get("sub") or "")}
                    for i, (name, off, dur) in enumerate(episodes)
                ],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            outputs.append(str(manifest_path))

        if options.get("translate"):
            self.progress.emit("Đang dịch SRT tổng...")
            translated_path, translated_rows = self._translate_merged_srt(
                merged_segments, output_dir, out_name)
            outputs.append(str(translated_path))
            if options.get("split_back"):
                self.progress.emit("Đang tách SRT dịch về từng tập...")
                per_dir = output_dir / f"{out_name}_tung_tap"
                per_dir.mkdir(parents=True, exist_ok=True)
                for order, (name, rows) in enumerate(
                        split_by_episodes(translated_rows, episodes), start=1):
                    if not rows:
                        continue
                    write_srt(rows, per_dir / f"{order:03d}_{name}.srt", translated=True)
                outputs.append(str(per_dir))

        if overrun_notes:
            outputs.append("⚠ Kiểm lại các cặp nghi ghép nhầm:\n  " + "\n  ".join(overrun_notes))

        if options.get("merge_video"):
            video_path = output_dir / f"{out_name}.mp4"
            self.progress.emit("Đang ghép video tổng bằng FFmpeg...")
            mode = ffmpeg.concat_auto(video_paths, str(video_path))
            if mode == "copy":
                self.progress.emit("Đã nối nhanh video, không encode lại.")
            else:
                self.progress.emit("Video khác chuẩn hoặc nối nhanh lỗi, đã render lại.")
            outputs.append(str(video_path))

        if not quiet:
            self.items = items
        return f"{out_name}:\n" + "\n".join(outputs)

    def _translate_merged_srt(
        self, segments: list[Segment], output_dir: Path, out_name: str,
    ) -> tuple[Path, list[Segment]]:
        if not segments:
            raise ValueError("Không có dòng phụ đề để dịch.")
        if not str(getattr(self.app.config, "target_language", "") or "").strip():
            raise ValueError("Chưa chọn ngôn ngữ đích ở phần Dịch tự động.")

        from vicdub.api.gemini_client import GeminiClient  # noqa: PLC0415
        from vicdub.modules.translate_module import TranslateModule  # noqa: PLC0415

        work_root = output_dir / ".series_translate"
        (work_root / "subtitles").mkdir(parents=True, exist_ok=True)

        class SeriesProject:
            def __init__(self, root: Path, rows: list[Segment]) -> None:
                self.root = str(root)
                self._segments = rows

            def load_segments(self) -> list[Segment]:
                return self._segments

            def save_segments(self, rows: list[Segment]) -> None:
                self._segments = rows

            def update_segment(self, segment: Segment) -> None:
                if 1 <= segment.line <= len(self._segments):
                    self._segments[segment.line - 1] = segment

            def add_history(self, *_args, **_kwargs) -> None:
                return None

        project = SeriesProject(work_root, segments)
        module = TranslateModule()
        module.attach(
            lambda pct, msg: self.progress.emit(f"Dịch SRT tổng {pct}% - {msg}"),
            threading.Event(),
        )
        result = module.run({
            "project": project,
            "segments": segments,
            "config": self.app.config,
            "tm": self.app.tm,
            "gemini": GeminiClient(self.app.api) if self.app.api.keys else None,
        })
        translated_path = output_dir / f"{out_name}.translated.srt"
        shutil.copyfile(result["translated_srt"], translated_path)
        # Trả cả segments đã dịch (module cập nhật vào project) để tách từng tập.
        return translated_path, project.load_segments()

    def _on_done(self, ok: bool, message: str) -> None:
        self._set_busy(False)
        self._render()
        if ok:
            self.info(message)
            self._set_status("Ghép series xong.")
        else:
            self.warn(f"Ghép series lỗi: {message}")
            self._set_status("Ghép series lỗi.")





# ====================================================================
class ExportPage(BasePage):
    """Studio xuất video: demo + timeline 3 track, điều khiển gọn bên phải."""

    #: Báo từ worker thread (thông điệp) - cập nhật status + timeline.
    bg_done = pyqtSignal(str)
    #: Khung hình preview đã trích xong (đường dẫn ảnh).
    frame_ready = pyqtSignal(str)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Xuất video", "Xem trước, thiết lập và tạo video cuối.")
        self.bg_done.connect(self._on_bg_done)
        self.frame_ready.connect(self._on_frame_ready)
        self._selected_line: int | None = None
        self._timeline_segments: list[Segment] = []
        self._timeline_by_line: dict[int, Segment] = {}
        self._scrub_busy = False
        self._scrub_pending: float | None = None
        self._frame_request_seconds: float | None = None
        self._frame_timer = QTimer(self)
        self._frame_timer.setSingleShot(True)
        self._frame_timer.setInterval(160)
        self._frame_timer.timeout.connect(self._flush_frame_request)
        self._volume_guard = False

        columns = QHBoxLayout()
        self.body.addLayout(columns, 1)

        # ================= Cột trái: demo + timeline =================
        left = QVBoxLayout()
        columns.addLayout(left, 1)

        # Nút bật/tắt bảng tùy chọn xuất - mặc định ẩn cho khung làm việc rộng.
        top_row = QHBoxLayout()
        top_row.addStretch()
        self.btn_toggle_panel = QPushButton("Thiết lập xuất ▸")
        self.btn_toggle_panel.setToolTip(
            "Hiện/ẩn thiết lập âm lượng, phụ đề, thư mục xuất và lệnh xuất video"
        )
        self.btn_toggle_panel.clicked.connect(self._toggle_panel)
        top_row.addWidget(self.btn_toggle_panel)
        left.addLayout(top_row)

        # ----- Khung xem trước video (chữ sub tiếng Việt vẽ luôn lên hình) -----
        self.preview_frame = DraggableSubtitlePreview(
            "(kéo playhead trên thước thời gian\nhoặc click block để xem khung hình)"
        )
        self.preview_frame.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_frame.setMinimumSize(640, 400)
        self.preview_frame.setStyleSheet(
            "background-color: #0f1724; border: 1px solid #223044; "
            "border-radius: 6px; color: #9fb0c2;"
        )
        self.preview_frame.setToolTip(
            "Giữ chuột trái và kéo trên khung hình để đặt vị trí phụ đề."
        )
        self.preview_frame.position_changed.connect(self._on_subtitle_dragged)
        self.preview_frame.blur_region_changed.connect(self._on_blur_region_dragged)
        left.addWidget(self.preview_frame, 3)
        self.preview_meta = muted_label("")
        left.addWidget(self.preview_meta)
        # Khung hình gốc gần nhất + chữ sub hiện tại, để vẽ lại overlay khi
        # đổi vị trí chữ hoặc đổi dòng mà chưa có khung mới.
        self._preview_pixmap: QPixmap | None = None
        self._preview_sub = ""
        self._preview_original = ""

        # ----- Timeline -----
        timeline_head = QHBoxLayout()
        timeline_head.addWidget(title_label("Dòng thời gian"))
        timeline_head.addStretch()
        timeline_head.addWidget(QLabel("Zoom:"))
        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setRange(5, 200)
        self.zoom_slider.setValue(40)
        self.zoom_slider.setFixedWidth(160)
        self.zoom_slider.valueChanged.connect(self._on_zoom)
        timeline_head.addWidget(self.zoom_slider)
        left.addLayout(timeline_head)

        self.timeline = TimelineWidget()
        self.timeline.line_clicked.connect(self._on_timeline_click)
        self.timeline.line_played.connect(self._on_timeline_play)
        self.timeline.time_scrubbed.connect(self._on_scrub)
        scroll = QScrollArea()
        scroll.setWidgetResizable(False)
        scroll.setWidget(self.timeline)
        scroll.setMinimumHeight(170)
        left.addWidget(scroll, 1)

        left.addWidget(muted_label(
            "TÍM = đoạn video | XANH DƯƠNG = phụ đề | "
            "XANH LÁ = giọng khớp | CAM = giọng dài | "
            "XÁM = chưa có."
        ))

        # ================= Cột phải: điều khiển thu gọn =================
        panel = QFrame()
        panel.setObjectName("exportPanelShell")
        panel.setFixedWidth(360)
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)
        panel_scroll = QScrollArea()
        panel_scroll.setObjectName("exportPanelScroll")
        panel_scroll.setWidgetResizable(True)
        panel_scroll.setFrameShape(QFrame.Shape.NoFrame)
        panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        panel_content = QWidget()
        panel_content.setObjectName("exportPanel")
        panel_content.setMinimumWidth(330)
        right = QVBoxLayout(panel_content)
        right.setContentsMargins(12, 12, 12, 16)
        right.setSpacing(12)
        panel_scroll.setWidget(panel_content)
        panel_layout.addWidget(panel_scroll)
        columns.addWidget(panel)
        self.panel = panel
        self._panel_shown = False
        panel.setVisible(False)  # ẩn mặc định, bấm "Thiết lập xuất" mới hiện

        def add_card(title: str) -> QVBoxLayout:
            card = QFrame()
            card.setObjectName("exportSection")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 10, 12, 12)
            card_layout.setSpacing(8)
            card_layout.addWidget(title_label(title))
            right.addWidget(card)
            return card_layout

        output_actions = add_card("Tạo video cuối")
        btn_merge = QPushButton("Xuất video")
        btn_merge.setToolTip(
            "Dùng voice đã render để ghép vào video gốc và chèn phụ đề theo lựa chọn bên dưới."
        )
        btn_merge.setProperty("variant", "primary")
        btn_merge.clicked.connect(lambda: self._run(["merge"]))
        btn_open = QPushButton("Mở thư mục xuất")
        btn_open.clicked.connect(self._open_output)
        for b in (btn_merge, btn_open):
            b.setMinimumHeight(38)
            output_actions.addWidget(b)

        render_card = add_card("Chế độ render")
        self.render_profile_combo = QComboBox()
        self.render_profile_combo.addItem(
            "Tự động — ưu tiên GPU (khuyên dùng)", "auto"
        )
        self.render_profile_combo.addItem("Nhanh — ưu tiên tốc độ", "fast")
        self.render_profile_combo.addItem("Cân bằng — chất lượng / tốc độ", "balanced")
        self.render_profile_combo.addItem("Chất lượng cao — CPU", "quality")
        self.render_profile_combo.setToolTip(
            "Tự động sẽ thử NVIDIA GPU trước; nếu GPU lỗi, ứng dụng tự chuyển "
            "sang CPU và tiếp tục xuất."
        )
        self.render_profile_combo.currentIndexChanged.connect(
            self._on_render_profile
        )
        render_card.addWidget(self.render_profile_combo)
        render_hint = muted_label(
            "Hard-sub cần xử lý lại hình. Không hard-sub và không kéo hình sẽ "
            "giữ nguyên luồng video để xuất nhanh."
        )
        render_hint.setWordWrap(True)
        render_card.addWidget(render_hint)

        audio_card = add_card("Âm lượng")
        self.bg_vol_label = muted_label("")
        self.bg_slider = QSlider(Qt.Orientation.Horizontal)
        self.bg_slider.setRange(0, 100)
        self.bg_slider.valueChanged.connect(self._on_volumes)
        self.voice_vol_label = muted_label("")
        self.voice_slider = QSlider(Qt.Orientation.Horizontal)
        self.voice_slider.setRange(10, 200)
        self.voice_slider.valueChanged.connect(self._on_volumes)
        audio_card.addWidget(self.bg_vol_label)
        audio_card.addWidget(self.bg_slider)
        audio_card.addWidget(self.voice_vol_label)
        audio_card.addWidget(self.voice_slider)
        audio_hint = muted_label("Điều chỉnh âm nền và giọng đọc trong video xuất.")
        audio_hint.setWordWrap(True)
        audio_card.addWidget(audio_hint)

        subtitle_card = add_card("Phụ đề trong video")
        self.radio_none = QRadioButton("Không có phụ đề")
        self.radio_hard = QRadioButton("Cố định trên video")
        self.radio_soft = QRadioButton("Track bật / tắt")
        for radio, mode_name in (
            (self.radio_none, "none"),
            (self.radio_hard, "hard"),
            (self.radio_soft, "soft"),
        ):
            radio.setObjectName("subtitleMode")
            radio.setProperty("mode", mode_name)
            radio.setMinimumHeight(42)
            radio.toggled.connect(self._on_sub_mode_changed)
            subtitle_card.addWidget(radio)
        subtitle_hint = muted_label("Chọn cách hiển thị phụ đề trong video xuất.")
        subtitle_hint.setWordWrap(True)
        subtitle_card.addWidget(subtitle_hint)

        self.sub_x_label = QLabel("Trái ↔ phải: 50%")
        subtitle_card.addWidget(self.sub_x_label)
        self.sub_x_slider = QSlider(Qt.Orientation.Horizontal)
        self.sub_x_slider.setRange(3, 97)
        self.sub_x_slider.setToolTip(
            "Kéo sang trái hoặc phải. Vị trí này dùng giống nhau ở khung xem trước và video xuất."
        )
        self.sub_x_slider.valueChanged.connect(self._on_subtitle_position_sliders)
        subtitle_card.addWidget(self.sub_x_slider)

        self.sub_y_label = QLabel("Lên ↕ xuống: 90%")
        subtitle_card.addWidget(self.sub_y_label)
        self.sub_y_slider = QSlider(Qt.Orientation.Horizontal)
        self.sub_y_slider.setRange(3, 97)
        self.sub_y_slider.setToolTip(
            "Kéo sang trái để đưa chữ lên, kéo sang phải để đưa chữ xuống."
        )
        self.sub_y_slider.valueChanged.connect(self._on_subtitle_position_sliders)
        subtitle_card.addWidget(self.sub_y_slider)

        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Cỡ chữ:"))
        self.sub_font_size = QSpinBox()
        self.sub_font_size.setRange(10, 72)
        self.sub_font_size.setMinimumWidth(110)
        self.sub_font_size.valueChanged.connect(self._on_sub_style)
        size_row.addWidget(self.sub_font_size)
        subtitle_card.addLayout(size_row)

        font_row = QHBoxLayout()
        font_row.addWidget(QLabel("Kiểu chữ:"))
        self.sub_font_name = QFontComboBox()
        self.sub_font_name.setMinimumHeight(34)
        self.sub_font_name.currentFontChanged.connect(self._on_sub_style)
        font_row.addWidget(self.sub_font_name, 1)
        subtitle_card.addLayout(font_row)

        color_row = QHBoxLayout()
        self.sub_text_color_btn = QPushButton("Màu chữ")
        self.sub_text_color_btn.clicked.connect(lambda: self._pick_sub_color("text"))
        self.sub_bg_color_btn = QPushButton("Màu nền")
        self.sub_bg_color_btn.clicked.connect(lambda: self._pick_sub_color("bg"))
        color_row.addWidget(self.sub_text_color_btn)
        color_row.addWidget(self.sub_bg_color_btn)
        subtitle_card.addLayout(color_row)

        self.sub_bg = QCheckBox("Nền hộp mờ sau chữ")
        self.sub_bg.setToolTip("Vẽ nền tối sau chữ cho dễ đọc trên cảnh sáng")
        self.sub_bg.toggled.connect(self._on_sub_style)
        subtitle_card.addWidget(self.sub_bg)
        self.blur_original_sub = QCheckBox("Làm mờ phụ đề gốc")
        self.blur_original_sub.setToolTip(
            "Chỉ làm mờ vùng phụ đề gốc trong đúng thời gian từng câu xuất hiện."
        )
        self.blur_original_sub.toggled.connect(self._on_sub_style)
        subtitle_card.addWidget(self.blur_original_sub)
        blur_size_row = QHBoxLayout()
        self.blur_size_label = QLabel("Độ phủ vùng mờ:")
        self.blur_size = QSpinBox()
        self.blur_size.setRange(80, 250)
        self.blur_size.setMinimumWidth(110)
        self.blur_size.setSingleStep(10)
        self.blur_size.setSuffix("%")
        self.blur_size.setToolTip(
            "100% bám sát chữ; tăng tỷ lệ để vùng mờ phủ rộng hơn quanh câu gốc."
        )
        self.blur_size.valueChanged.connect(self._on_sub_style)
        blur_size_row.addWidget(self.blur_size_label)
        blur_size_row.addWidget(self.blur_size)
        subtitle_card.addLayout(blur_size_row)
        self.btn_edit_blur_region = QPushButton("Khoanh vùng mờ trên ảnh")
        self.btn_edit_blur_region.setCheckable(True)
        self.btn_edit_blur_region.setToolTip(
            "Bật rồi kéo một khung trực tiếp quanh phụ đề gốc. Vùng được lưu riêng cho dự án."
        )
        self.btn_edit_blur_region.toggled.connect(self._on_blur_edit_toggled)
        subtitle_card.addWidget(self.btn_edit_blur_region)
        drag_hint = muted_label(
            "Chế độ thường: kéo chữ để đặt vị trí. Bật nút trên: kéo khung để chỉnh vùng mờ."
        )
        drag_hint.setWordWrap(True)
        subtitle_card.addWidget(drag_hint)

        folder_card = add_card("Thư mục xuất")
        self.export_label = muted_label("")
        self.export_label.setWordWrap(True)
        folder_card.addWidget(self.export_label)
        btn_pick_export = QPushButton("Chọn thư mục xuất...")
        btn_pick_export.clicked.connect(self._pick_export_dir)
        btn_reset_export = QPushButton("Dùng thư mục dự án")
        btn_reset_export.clicked.connect(self._reset_export_dir)
        btn_pick_export.setMinimumHeight(36)
        btn_reset_export.setMinimumHeight(36)
        folder_card.addWidget(btn_pick_export)
        folder_card.addWidget(btn_reset_export)

        self.result_label = muted_label("")
        self.result_label.setWordWrap(True)
        right.addWidget(self.result_label)
        right.addStretch()

    def refresh(self) -> None:
        mode = self.app.config.subtitle_mode
        self.radio_none.setChecked(mode == "none")
        self.radio_hard.setChecked(mode == "hard")
        self.radio_soft.setChecked(mode == "soft")
        profile = str(getattr(self.app.config, "render_profile", "auto") or "auto")
        profile_index = self.render_profile_combo.findData(profile)
        self.render_profile_combo.blockSignals(True)
        self.render_profile_combo.setCurrentIndex(
            profile_index if profile_index >= 0 else 0
        )
        self.render_profile_combo.blockSignals(False)
        export_dir = self.app.config.export_dir
        self.export_label.setText(
            f"Xuất về: {export_dir}" if export_dir
            else "Xuất về: projects\\<tên project>\\output (mặc định)"
        )
        self.sub_x_slider.blockSignals(True)
        self.sub_y_slider.blockSignals(True)
        self.sub_x_slider.setValue(round(
            max(0.03, min(0.97, float(
                getattr(self.app.config, "subtitle_x", 0.5)
            ))) * 100
        ))
        self.sub_y_slider.setValue(round(
            max(0.03, min(0.97, float(
                getattr(self.app.config, "subtitle_y", 0.90)
            ))) * 100
        ))
        self.sub_x_slider.blockSignals(False)
        self.sub_y_slider.blockSignals(False)
        self._refresh_subtitle_position_labels()
        self.sub_font_size.blockSignals(True)
        self.sub_font_size.setValue(int(getattr(self.app.config, "subtitle_font_size", 24)))
        self.sub_font_size.blockSignals(False)
        self.sub_font_name.blockSignals(True)
        self.sub_font_name.setCurrentFont(QFont(str(
            getattr(self.app.config, "subtitle_font_name", "Arial")
        )))
        self.sub_font_name.blockSignals(False)
        self._refresh_sub_color_buttons()
        self.sub_bg.blockSignals(True)
        self.sub_bg.setChecked(bool(getattr(self.app.config, "subtitle_bg", False)))
        self.sub_bg.blockSignals(False)
        self.blur_original_sub.blockSignals(True)
        self.blur_original_sub.setChecked(bool(
            getattr(self.app.config, "subtitle_blur_original", False)
        ))
        self.blur_original_sub.blockSignals(False)
        self.blur_size.blockSignals(True)
        self.blur_size.setValue(int(
            getattr(self.app.config, "subtitle_blur_scale", 140)
        ))
        self.blur_size.blockSignals(False)
        self._update_subtitle_controls()
        self._volume_guard = True
        self.bg_slider.setValue(self.app.config.bg_volume)
        self.voice_slider.setValue(self.app.config.voice_volume)
        self._volume_guard = False
        self._on_volumes()
        final = self.app.engine.context.get("final_video", "")
        if final:
            self.result_label.setText(f"Video hoàn chỉnh: {final}")
        self._refresh_timeline()

    def _refresh_timeline(self) -> None:
        project = self.app.projects.current
        if not project:
            self._timeline_segments = []
            self._timeline_by_line = {}
            self.timeline.set_data([], {}, {})
            return
        segments = project.load_segments()
        self._timeline_segments = segments
        self._timeline_by_line = {s.line: s for s in segments}
        voices: dict[int, tuple[float, bool]] = {}
        clips: dict[int, bool] = {}
        for seg in segments:
            wav = project_voice_path(project.root, seg.line)
            if wav.exists():
                dur = wav_seconds(wav)
                if dur > 0:
                    voices[seg.line] = (dur, dur <= seg.duration + 0.05)
            clips[seg.line] = project_clip_path(project.root, seg.line).exists()
        self.timeline.set_data(segments, voices, clips)

    def _toggle_panel(self) -> None:
        """Hiện/ẩn bảng tùy chọn xuất bên phải để khung làm việc rộng hơn."""
        self._panel_shown = not self._panel_shown
        self.panel.setVisible(self._panel_shown)
        self.btn_toggle_panel.setText(
            "Ẩn thiết lập ◂" if self._panel_shown else "Thiết lập xuất ▸"
        )

    def _on_zoom(self, value: int) -> None:
        self.timeline.set_zoom(float(value))

    def _on_timeline_click(self, line: int) -> None:
        """Click block: hiện chữ sub + khung hình video của dòng đó."""
        project = self.app.projects.current
        if not project:
            return
        seg = self._timeline_by_line.get(line)
        if seg is None:
            return
        self._selected_line = line

        # Chữ sub tiếng Việt vẽ luôn lên khung xem trước.
        self._preview_sub = seg.translation or seg.text
        self._preview_original = seg.text
        self._render_preview()
        wav = project_voice_path(project.root, line)
        voice_note = (f"voice {wav_seconds(wav):.1f}s" if wav.exists()
                      else "chưa có voice")
        self.preview_meta.setText(
            f"Dòng {line} | {seg.speaker} | "
            f"{seg.start:.2f}s - {seg.end:.2f}s ({seg.duration:.1f}s) | "
            f"{voice_note}"
        )
        self.app.show_status(f"Đã chọn dòng {line}.")
        self._request_frame(seg.start + 0.1)

    def _on_scrub(self, seconds: float) -> None:
        """Kéo playhead: preview khung hình + thông tin dòng tại vị trí đó."""
        project = self.app.projects.current
        if not project:
            return
        seg = next((s for s in self._timeline_segments
                    if s.start <= seconds <= s.end), None)
        if seg is not None:
            self._selected_line = seg.line
            self.timeline.select_line(seg.line)
            self._preview_sub = seg.translation or seg.text
            self._preview_original = seg.text
            wav = project_voice_path(project.root, seg.line)
            voice_note = (f"voice {wav_seconds(wav):.1f}s" if wav.exists()
                          else "chưa có voice")
            self.preview_meta.setText(
                f"⏱ {seconds:.2f}s | dòng {seg.line} | {seg.speaker} | "
                f"{voice_note}"
            )
        else:
            self._preview_sub = ""
            self._preview_original = ""
            self.preview_meta.setText(f"⏱ {seconds:.2f}s (khoảng lặng)")
        self._render_preview()
        self._request_frame(seconds)

    def _request_frame(self, seconds: float) -> None:
        self._frame_request_seconds = seconds
        self._frame_timer.start()

    def _flush_frame_request(self) -> None:
        """Trích khung hình ở thread nền, có chống dội khi kéo nhanh."""
        if self._frame_request_seconds is None:
            return
        seconds = self._frame_request_seconds
        self._frame_request_seconds = None
        project = self.app.projects.current
        if not project:
            return
        video = project.video_path
        if not video or not Path(video).exists():
            return
        if self._scrub_busy:
            self._scrub_pending = seconds  # đang bận thì nhớ vị trí mới nhất
            return
        self._scrub_busy = True
        config = self.app.config
        out = str(Path(project.root) / "output" / "_frame.png")

        def work() -> None:
            try:
                FFmpeg(config.ffmpeg_path, config.ffprobe_path).extract_frame_exact(
                    video, max(0.0, seconds), out,
                    str(Path(project.root) / ".frame_index"),
                )
                self.frame_ready.emit(out)
            except Exception:  # noqa: BLE001 - preview lỗi thì thôi
                self.frame_ready.emit("")

        threading.Thread(target=work, daemon=True).start()

    def _on_frame_ready(self, image_path: str) -> None:
        self._scrub_busy = False
        if image_path:
            pixmap = QPixmap(image_path)
            if not pixmap.isNull():
                self._preview_pixmap = pixmap
                self._render_preview()
        if self._scrub_pending is not None:
            pending, self._scrub_pending = self._scrub_pending, None
            self._request_frame(pending)

    def _refresh_subtitle_position_labels(self) -> None:
        self.sub_x_label.setText(f"Trái ↔ phải: {self.sub_x_slider.value()}%")
        self.sub_y_label.setText(f"Lên ↕ xuống: {self.sub_y_slider.value()}%")

    def _on_subtitle_position_sliders(self, _value: int = 0) -> None:
        """Lưu hai tọa độ tự do và vẽ lại đúng cùng một vị trí khi xuất."""
        self.app.config.subtitle_position = "custom"
        self.app.config.subtitle_x = self.sub_x_slider.value() / 100.0
        self.app.config.subtitle_y = self.sub_y_slider.value() / 100.0
        self._refresh_subtitle_position_labels()
        self.app.config.save()
        self._render_preview()

    def _on_sub_mode_changed(self, checked: bool) -> None:
        if not checked:
            return
        self._apply_mode()
        self._update_subtitle_controls()

    def _update_subtitle_controls(self) -> None:
        """Only hard subtitles own appearance/position; soft tracks use player style."""
        hard = self.radio_hard.isChecked()
        for widget in (
            self.sub_x_label, self.sub_x_slider,
            self.sub_y_label, self.sub_y_slider, self.sub_font_size,
            self.sub_font_name, self.sub_text_color_btn, self.sub_bg_color_btn,
            self.sub_bg,
        ):
            widget.setEnabled(hard)
        blur_enabled = self.blur_original_sub.isChecked()
        self.blur_size_label.setEnabled(blur_enabled)
        self.blur_size.setEnabled(blur_enabled)
        self.btn_edit_blur_region.setEnabled(blur_enabled)
        if not blur_enabled and self.btn_edit_blur_region.isChecked():
            self.btn_edit_blur_region.setChecked(False)
        self.preview_frame.setToolTip(
            "Giữ chuột trái và kéo để đặt vị trí phụ đề cố định."
            if hard else
            "Chọn 'Cố định trên video' để kéo thả vị trí phụ đề."
        )

    def _on_subtitle_dragged(self, x: float, y: float) -> None:
        """Save free subtitle coordinates selected directly on the preview."""
        if not self.radio_hard.isChecked():
            return
        self.app.config.subtitle_position = "custom"
        self.app.config.subtitle_x = round(float(x), 4)
        self.app.config.subtitle_y = round(float(y), 4)
        self.sub_x_slider.blockSignals(True)
        self.sub_y_slider.blockSignals(True)
        self.sub_x_slider.setValue(round(self.app.config.subtitle_x * 100))
        self.sub_y_slider.setValue(round(self.app.config.subtitle_y * 100))
        self.sub_x_slider.blockSignals(False)
        self.sub_y_slider.blockSignals(False)
        self._refresh_subtitle_position_labels()
        self.app.config.save()
        self._render_preview()

    def _on_blur_edit_toggled(self, checked: bool) -> None:
        self.preview_frame.set_blur_edit_mode(checked)
        self.btn_edit_blur_region.setText(
            "Đang khoanh vùng mờ — kéo trên ảnh" if checked
            else "Khoanh vùng mờ trên ảnh"
        )
        self._render_preview()

    def _on_blur_region_dragged(self, region: object) -> None:
        project = self.app.projects.current
        if project is None or not isinstance(region, (tuple, list)) or len(region) != 4:
            return
        project.set_blur_region(region)
        self.app.show_status("Đã lưu vùng làm mờ riêng cho dự án.")
        self._render_preview()

    @staticmethod
    def _safe_hex_color(value: str, fallback: str) -> str:
        value = (value or "").strip()
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
            return value.upper()
        return fallback

    def _refresh_sub_color_buttons(self) -> None:
        text_color = self._safe_hex_color(
            getattr(self.app.config, "subtitle_text_color", "#FFFFFF"), "#FFFFFF"
        )
        bg_color = self._safe_hex_color(
            getattr(self.app.config, "subtitle_bg_color", "#000000"), "#000000"
        )
        self.sub_text_color_btn.setText(f"Màu chữ {text_color}")
        self.sub_bg_color_btn.setText(f"Màu nền {bg_color}")
        text_fg = "#000000" if text_color.upper() not in {"#000000", "#111111"} else "#FFFFFF"
        bg_fg = "#000000" if bg_color.upper() not in {"#000000", "#111111"} else "#FFFFFF"
        self.sub_text_color_btn.setStyleSheet(f"background:{text_color}; color:{text_fg};")
        self.sub_bg_color_btn.setStyleSheet(f"background:{bg_color}; color:{bg_fg};")

    def _pick_sub_color(self, target: str) -> None:
        attr = "subtitle_text_color" if target == "text" else "subtitle_bg_color"
        fallback = "#FFFFFF" if target == "text" else "#000000"
        current = QColor(self._safe_hex_color(getattr(self.app.config, attr, fallback), fallback))
        chosen = QColorDialog.getColor(current, self, "Chọn màu phụ đề")
        if not chosen.isValid():
            return
        setattr(self.app.config, attr, chosen.name().upper())
        self._refresh_sub_color_buttons()
        self.app.config.save()
        self._render_preview()

    def _on_sub_style(self, _v: object = None) -> None:
        """Đổi cỡ chữ / nền: lưu config + vẽ lại khung xem trước."""
        self.app.config.subtitle_font_size = self.sub_font_size.value()
        self.app.config.subtitle_font_name = self.sub_font_name.currentFont().family()
        self.app.config.subtitle_bg = self.sub_bg.isChecked()
        self.app.config.subtitle_blur_original = self.blur_original_sub.isChecked()
        self.app.config.subtitle_blur_scale = self.blur_size.value()
        self.blur_size_label.setEnabled(self.blur_original_sub.isChecked())
        self.blur_size.setEnabled(self.blur_original_sub.isChecked())
        self.app.config.save()
        self._render_preview()

    def _render_preview(self) -> None:
        """Vẽ khung hình gốc gần nhất, chồng chữ sub tiếng Việt lên theo vị trí."""
        if self._preview_pixmap is None or self._preview_pixmap.isNull():
            return
        scaled = self._preview_pixmap.scaled(
            self.preview_frame.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        cfg = self.app.config
        project = self.app.projects.current
        fallback_region = (
            project.get_ocr_region(
                getattr(cfg, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
            ) if project else
            (getattr(cfg, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0))
        )
        preview_region = tuple(
            project.get_blur_region(fallback_region) if project else fallback_region
        )
        if (bool(getattr(cfg, "subtitle_blur_original", False))
                and (self._preview_sub or "").strip()):
            self._draw_preview_blur(
                scaled,
                preview_region,
                self._preview_original,
                int(getattr(cfg, "subtitle_blur_scale", 140)),
            )
            if self.btn_edit_blur_region.isChecked():
                self._draw_region_outline(scaled, preview_region)
        text = (self._preview_sub or "").strip()
        if text:
            scaled = QPixmap(scaled)  # bản sao để vẽ đè
            self._draw_subtitle(
                scaled, text,
                "custom",
                int(getattr(cfg, "subtitle_font_size", 24)),
                bool(getattr(cfg, "subtitle_bg", False)),
                float(getattr(cfg, "subtitle_x", 0.5)),
                float(getattr(cfg, "subtitle_y", 0.90)),
                str(getattr(cfg, "subtitle_font_name", "Arial")),
                str(getattr(cfg, "subtitle_text_color", "#FFFFFF")),
                str(getattr(cfg, "subtitle_bg_color", "#000000")),
            )
        self.preview_frame.setPixmap(scaled)

    @staticmethod
    def _draw_region_outline(pixmap: QPixmap, region) -> None:
        x0, y0, x1, y1 = region
        rect = QRect(
            round(float(x0) * pixmap.width()), round(float(y0) * pixmap.height()),
            max(1, round((float(x1) - float(x0)) * pixmap.width())),
            max(1, round((float(y1) - float(y0)) * pixmap.height())),
        )
        painter = QPainter(pixmap)
        pen = painter.pen()
        pen.setColor(QColor("#22d3ee"))
        pen.setWidth(2)
        painter.setPen(pen)
        painter.drawRect(rect)
        painter.end()

    @staticmethod
    def _draw_preview_blur(pixmap: QPixmap, region, text: str,
                           scale_percent: int = 140) -> None:
        """Preview đúng vùng mờ người dùng đã khoanh và tỷ lệ mở rộng."""
        x0, y0, x1, y1 = (max(0.0, min(1.0, float(v))) for v in region)
        x0, x1 = sorted((x0, x1)); y0, y1 = sorted((y0, y1))
        scale = max(0.8, min(2.5, float(scale_percent) / 100.0))
        center_x = pixmap.width() * (x0 + x1) / 2.0
        center_y = pixmap.height() * (y0 + y1) / 2.0
        box_w = min(pixmap.width(), round(pixmap.width() * (x1 - x0) * scale))
        box_h = min(pixmap.height(), round(pixmap.height() * (y1 - y0) * scale))
        left = max(0, min(pixmap.width() - box_w, round(center_x - box_w / 2)))
        top = max(0, min(pixmap.height() - box_h, round(center_y - box_h / 2)))
        rect = QRect(left, top, box_w, box_h)
        crop = pixmap.copy(rect)
        tiny = crop.scaled(
            max(1, crop.width() // 24), max(1, crop.height() // 12),
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        blurred = tiny.scaled(
            crop.size(), Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        painter = QPainter(pixmap)
        painter.drawPixmap(rect.topLeft(), blurred)
        painter.end()

    @staticmethod
    def _draw_subtitle(pixmap: QPixmap, text: str, position: str,
                       font_size: int = 24, background: bool = False,
                       x: float = 0.5, y: float = 0.90,
                       font_name: str = "Arial", text_color: str = "#FFFFFF",
                       bg_color: str = "#000000") -> None:
        """Vẽ chữ phụ đề lên pixmap tại vị trí chọn (mô phỏng cỡ chữ + nền).

        font_size hiểu theo hệ ASS (~cao khung 360) nên quy về pixel theo chiều
        cao khung xem trước cho gần đúng với video xuất ra.
        """
        painter = QPainter(pixmap)
        w, h = pixmap.width(), pixmap.height()
        px = max(9, round(h * font_size / 360.0))
        font = QFont(font_name or "Arial", px)
        font.setBold(True)
        painter.setFont(font)
        fg = QColor(text_color if re.fullmatch(r"#[0-9A-Fa-f]{6}", text_color or "") else "#FFFFFF")
        bg = QColor(bg_color if re.fullmatch(r"#[0-9A-Fa-f]{6}", bg_color or "") else "#000000")
        margin = max(8, h // 28)
        flags = int(Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap)
        usable_w = max(1, w - 2 * margin)
        max_chars = max(14, min(42, int(usable_w / max(1, px) / 0.56)))
        text = wrap_for_box(text, max_chars)
        metrics = QFontMetrics(font)
        longest = max((metrics.horizontalAdvance(line) for line in text.splitlines()), default=1)
        rect_w = min(usable_w, longest + margin)
        bound = painter.boundingRect(QRect(0, 0, rect_w, h), flags, text)
        center_x = round(max(0.03, min(0.97, x)) * w)
        center_y = round(max(0.03, min(0.97, y)) * h)
        left = max(margin, min(w - rect_w - margin, center_x - rect_w // 2))
        top = max(0, min(h - bound.height(), center_y - bound.height() // 2))
        rect = QRect(left, top, rect_w, bound.height())
        if background:
            box = rect.adjusted(-margin // 2, -margin // 4, margin // 2, margin // 4)
            bg.setAlpha(140)
            painter.fillRect(box, bg)
            painter.setPen(fg)
            painter.drawText(rect, flags, text)
        else:
            painter.setPen(QColor(0, 0, 0))
            for dx, dy in ((-2, -2), (-2, 2), (2, -2), (2, 2),
                           (-2, 0), (2, 0), (0, -2), (0, 2)):
                painter.drawText(rect.translated(dx, dy), flags, text)
            painter.setPen(fg)
            painter.drawText(rect, flags, text)
        painter.end()

    def _on_volumes(self, _value: int = 0) -> None:
        """Slider âm lượng đổi: cập nhật nhãn + lưu cấu hình."""
        self.bg_vol_label.setText(f"Âm nền video: {self.bg_slider.value()}%")
        self.voice_vol_label.setText(f"Giọng đọc: {self.voice_slider.value()}%")
        if self._volume_guard:
            return
        self.app.config.bg_volume = self.bg_slider.value()
        self.app.config.voice_volume = self.voice_slider.value()
        self.app.config.save()

    def _on_render_profile(self, _index: int = 0) -> None:
        profile = self.render_profile_combo.currentData() or "auto"
        self.app.config.render_profile = str(profile)
        self.app.config.save()

    def _on_bg_done(self, message: str) -> None:
        self.app.show_status(message)
        self._refresh_timeline()

    def _on_timeline_play(self, line: int) -> None:
        project = self.app.projects.current
        if not project:
            return
        wav = project_voice_path(project.root, line)
        if wav.exists():
            self.app.play_audio(str(wav))
            self.app.show_status(f"Đang phát voice dòng {line}.")
        else:
            self.app.show_status(f"Dòng {line} chưa render voice.")

    def _pick_export_dir(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất video")
        if folder:
            self.app.config.export_dir = folder
            self.app.config.save()
            self.refresh()

    def _reset_export_dir(self) -> None:
        self.app.config.export_dir = ""
        self.app.config.save()
        self.refresh()

    def _apply_mode(self) -> None:
        if self.radio_hard.isChecked():
            self.app.config.subtitle_mode = "hard"
        elif self.radio_soft.isChecked():
            self.app.config.subtitle_mode = "soft"
        else:
            self.app.config.subtitle_mode = "none"
        self.app.config.save()

    def _run(self, steps: list[str]) -> None:
        if self.need_project():
            return
        # Xuất khi đang để không có phụ đề -> nhắc bật chế độ cố định,
        # tránh xuất ra video không có chữ dù preview vẫn hiện chữ.
        if "merge" in steps and self.radio_none.isChecked():
            if self.confirm(
                "Đang để 'Không có phụ đề' nên video xuất ra sẽ không có chữ.\n"
                "Bật 'Cố định trên video' để ghép chữ vào hình?"
            ):
                self.radio_hard.setChecked(True)
        self._apply_mode()
        self.app.start_pipeline(steps)

    def _open_output(self) -> None:
        if self.app.config.export_dir:
            out = Path(self.app.config.export_dir)
        else:
            if self.need_project():
                return
            out = Path(self.app.projects.current.root) / "output"
        out.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(out))  # noqa: S606


# ====================================================================
class ComponentsPage(BasePage):
    """Tab Cập nhật: kiểm tra & tải các thành phần còn thiếu (voice, FFmpeg...).

    App-first: bản cài nhẹ mở được ngay; phần NẶNG (PyTorch, model giọng ~3GB,
    FFmpeg) tải ở đây khi cần — có tiến trình, huỷ được, chọn CPU/GPU.
    """

    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    update_checked = pyqtSignal(object, str, bool)
    update_progress = pyqtSignal(int, str)
    update_downloaded = pyqtSignal(bool, str, object)

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(
            app, "Cập nhật",
            "Chuẩn bị môi trường và giọng nói khi cần. App tự kiểm tra rồi cài "
            "tuần tự từng phần còn thiếu; không cần chạy install_models.bat.",
        )
        self._busy = False
        self._update_busy = False
        self._update_info = None
        self._cancel = threading.Event()
        self._components: list = []

        update_box = QFrame()
        update_box.setFrameShape(QFrame.Shape.StyledPanel)
        update_layout = QVBoxLayout(update_box)
        update_title = title_label("Cập nhật ứng dụng")
        self.app_version_label = QLabel(f"Phiên bản đang dùng: {__import__('vicdub').__version__}")
        self.app_update_status = muted_label("Sẵn sàng kiểm tra phiên bản mới.")
        update_actions = QHBoxLayout()
        self.btn_check_app_update = QPushButton("Kiểm tra cập nhật")
        self.btn_check_app_update.clicked.connect(lambda: self.check_app_update(False))
        self.btn_apply_app_update = QPushButton("Cập nhật ngay")
        self.btn_apply_app_update.setProperty("variant", "primary")
        self.btn_apply_app_update.setEnabled(False)
        self.btn_apply_app_update.clicked.connect(self._download_app_update)
        update_actions.addWidget(self.btn_check_app_update)
        update_actions.addWidget(self.btn_apply_app_update)
        update_actions.addStretch(1)
        self.app_update_bar = QProgressBar()
        self.app_update_bar.setRange(0, 100)
        self.app_update_bar.setValue(0)
        update_layout.addWidget(update_title)
        update_layout.addWidget(self.app_version_label)
        update_layout.addWidget(self.app_update_status)
        update_layout.addLayout(update_actions)
        update_layout.addWidget(self.app_update_bar)
        self.body.addWidget(update_box)

        top = QHBoxLayout()
        self.gpu_checkbox = QCheckBox("Dùng bản GPU (NVIDIA) cho giọng nói")
        self.gpu_checkbox.setToolTip(
            "Máy có card NVIDIA thì sinh giọng nhanh hơn nhiều nhưng phải tải "
            "~9GB; bản CPU chỉ ~0.5GB nhưng chậm."
        )
        top.addWidget(self.gpu_checkbox)
        top.addStretch(1)
        self.btn_refresh = QPushButton("Kiểm tra lại")
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_install_all = QPushButton("Chuẩn bị môi trường && giọng nói")
        self.btn_install_all.setProperty("variant", "primary")
        self.btn_install_all.clicked.connect(lambda: self._install(None))
        self.btn_cancel = QPushButton("Huỷ")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel.set)
        top.addWidget(self.btn_refresh)
        top.addWidget(self.btn_install_all)
        top.addWidget(self.btn_cancel)
        self.body.addLayout(top)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(
            ["Thành phần", "Trạng thái", "Tải về", ""])
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in (1, 2, 3):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.body.addWidget(self.table, 1)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.status_label = muted_label("Chưa kiểm tra.")
        self.body.addWidget(self.progress_bar)
        self.body.addWidget(self.status_label)

        self.progress.connect(self._on_progress)
        self.finished.connect(self._on_finished)
        self.update_checked.connect(self._on_update_checked)
        self.update_progress.connect(self._on_update_progress)
        self.update_downloaded.connect(self._on_update_downloaded)

    def check_app_update(self, silent: bool = False) -> None:
        if self._update_busy:
            return
        source = str(getattr(self.app.config, "update_manifest_url", "") or "").strip()
        source = source or os.environ.get("ANDREWSUB_UPDATE_URL", "").strip()
        if not source:
            if not silent:
                self.warn("Chưa cấu hình kênh cập nhật cho bản phát hành này.")
            return
        self._update_busy = True
        self.btn_check_app_update.setEnabled(False)
        self.app_update_status.setText("Đang kiểm tra phiên bản mới...")

        def worker() -> None:
            try:
                from vicdub import __version__  # noqa: PLC0415
                from vicdub.core.app_update import is_newer, load_manifest  # noqa: PLC0415
                info = load_manifest(source)
                if is_newer(info.version, __version__):
                    self.update_checked.emit(info, "", silent)
                else:
                    self.update_checked.emit(None, "Bạn đang dùng phiên bản mới nhất.", silent)
            except Exception as exc:  # noqa: BLE001
                self.update_checked.emit(None, str(exc), silent)

        threading.Thread(target=worker, daemon=True, name="app-update-check").start()

    def _on_update_checked(self, info, message: str, silent: bool) -> None:
        self._update_busy = False
        self.btn_check_app_update.setEnabled(True)
        self._update_info = info
        if info is None:
            self.btn_apply_app_update.setEnabled(False)
            if message:
                self.app_update_status.setText(message)
            if message and not silent and "mới nhất" not in message:
                self.warn(f"Không kiểm tra được cập nhật: {message}")
            return
        notes = "\n".join(f"• {item}" for item in info.notes)
        self.app_update_status.setText(f"Có phiên bản {info.version}." + (f"\n{notes}" if notes else ""))
        self.btn_apply_app_update.setEnabled(True)
        if silent:
            answer = QMessageBox.question(
                self, "Cập nhật ứng dụng",
                f"Có phiên bản {info.version}.\n\n{notes}\n\nCập nhật ngay?",
            )
            if answer == QMessageBox.StandardButton.Yes:
                self._download_app_update()

    def _download_app_update(self) -> None:
        if self._update_busy or self._update_info is None:
            return
        if self.app.engine.is_running() or getattr(self.app, "_batch_active", False):
            self.warn("Hãy hoàn tất hoặc hủy tác vụ đang chạy trước khi cập nhật.")
            return
        self._update_busy = True
        self._cancel.clear()
        self.btn_apply_app_update.setEnabled(False)
        info = self._update_info
        destination = Path(self.app.config.data_dir) / "updates"

        def worker() -> None:
            try:
                from vicdub.core.app_update import download_update  # noqa: PLC0415
                package = download_update(
                    info, destination,
                    progress=self.update_progress.emit,
                    cancelled=self._cancel.is_set,
                )
                self.update_downloaded.emit(True, str(package), info)
            except Exception as exc:  # noqa: BLE001
                self.update_downloaded.emit(False, str(exc), info)

        threading.Thread(target=worker, daemon=True, name="app-update-download").start()

    def _on_update_progress(self, pct: int, message: str) -> None:
        if pct >= 0:
            self.app_update_bar.setValue(pct)
        self.app_update_status.setText(message)

    def _on_update_downloaded(self, ok: bool, message: str, info) -> None:
        self._update_busy = False
        if not ok:
            self.btn_apply_app_update.setEnabled(True)
            self.warn(f"Tải cập nhật lỗi: {message}")
            return
        try:
            from vicdub.core.app_update import launch_updater  # noqa: PLC0415
            launch_updater(Path(message), info)
        except Exception as exc:  # noqa: BLE001
            self.btn_apply_app_update.setEnabled(True)
            self.warn(str(exc))
            return
        self.app_update_status.setText("Đang đóng ứng dụng để cài cập nhật...")
        QApplication.instance().quit()

    def has_background_task(self) -> bool:
        return self._busy or self._update_busy

    def cancel_background_tasks(self) -> None:
        self._cancel.set()

    def refresh(self) -> None:
        from vicdub.core import bootstrap  # noqa: PLC0415
        from vicdub.core.component_setup import (  # noqa: PLC0415
            estimate_size_gb, has_nvidia_gpu, installable,
        )

        if not self._busy:
            has_gpu = has_nvidia_gpu()
            self.gpu_checkbox.setChecked(has_gpu)
            self.gpu_checkbox.setEnabled(has_gpu)
            if not has_gpu:
                self.gpu_checkbox.setText("Không thấy card NVIDIA — dùng bản CPU")
        self._components = bootstrap.component_status(self.app.config)
        self.table.setRowCount(len(self._components))
        missing_installable = []
        for row, comp in enumerate(self._components):
            self.table.setItem(row, 0, QTableWidgetItem(comp.label))
            state = QTableWidgetItem("✅ Sẵn sàng" if comp.ready else "❌ Thiếu")
            self.table.setItem(row, 1, state)
            size = ""
            if not comp.ready and installable(comp.key):
                size = f"~{estimate_size_gb([comp.key], self.gpu_checkbox.isChecked()):g} GB"
                missing_installable.append(comp.key)
            self.table.setItem(row, 2, QTableWidgetItem(size))
            self.table.setCellWidget(row, 3, None)
            if not comp.ready and installable(comp.key):
                button = QPushButton("Tải && cài")
                button.setEnabled(not self._busy)
                button.clicked.connect(
                    lambda _checked=False, key=comp.key: self._install([key]))
                self.table.setCellWidget(row, 3, button)
            elif not comp.ready:
                hint = QTableWidgetItem(comp.detail or "Cài thủ công")
                self.table.setItem(row, 3, hint)
        self.btn_install_all.setEnabled(bool(missing_installable) and not self._busy)
        if missing_installable:
            total = estimate_size_gb(missing_installable, self.gpu_checkbox.isChecked())
            self.status_label.setText(
                f"Thiếu {len(missing_installable)} thành phần — tổng cần tải ~{total:g} GB."
            )
        else:
            self.status_label.setText("Mọi thành phần đã sẵn sàng. 🎉")

    def _install(self, keys: list | None) -> None:
        if self._busy:
            return
        from vicdub.core import bootstrap  # noqa: PLC0415
        from vicdub.core.component_setup import (  # noqa: PLC0415
            estimate_size_gb, sort_for_install,
        )

        missing_keys = [c.key for c in bootstrap.missing(self.app.config)]
        todo = sort_for_install(missing_keys if keys is None else keys)
        if not todo:
            self.info("Không có gì cần cài.")
            return
        cuda = self.gpu_checkbox.isChecked()
        total_gb = estimate_size_gb(todo, cuda)
        if not self.confirm(
            f"Tải và cài {len(todo)} thành phần (~{total_gb:g} GB)?\n"
            "Có thể huỷ giữa chừng; đã tải xong phần nào giữ phần đó."
        ):
            return

        self._busy = True
        self._cancel.clear()
        self.btn_cancel.setEnabled(True)
        self.btn_install_all.setEnabled(False)
        self.btn_refresh.setEnabled(False)
        config = self.app.config

        def worker() -> None:
            try:
                from vicdub.core.component_setup import install_missing  # noqa: PLC0415
                done = install_missing(
                    config,
                    report=self.progress.emit,
                    is_cancelled=self._cancel.is_set,
                    keys=todo, cuda=cuda,
                )
                self.finished.emit(True, f"Đã cài xong: {', '.join(done) or '—'}")
            except Exception as exc:  # noqa: BLE001 - mọi lỗi phải lên UI
                self.finished.emit(False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _on_progress(self, pct: int, msg: str) -> None:
        if pct >= 0:
            self.progress_bar.setValue(pct)
        self.status_label.setText(msg)

    def _on_finished(self, ok: bool, message: str) -> None:
        self._busy = False
        self.btn_cancel.setEnabled(False)
        self.btn_refresh.setEnabled(True)
        if ok:
            self.progress_bar.setValue(100)
            self.info(message)
        else:
            self.warn(f"Cài thành phần lỗi: {message}")
        self.refresh()


class SettingsPage(BasePage):
    """Cấu hình xử lý video, giọng đọc và dịch vụ trực tuyến."""

    translation_profile_progress = pyqtSignal(str)
    translation_profile_result = pyqtSignal(int, bool, str, str)
    translation_profile_finished = pyqtSignal()
    drive_account_progress = pyqtSignal(str)
    drive_account_result = pyqtSignal(int, bool, str, str)
    drive_account_finished = pyqtSignal()

    API_COLUMNS = ("Tên", "Khóa truy cập", "Chế độ", "Giới hạn", "Ưu tiên", "Bật")
    ASR_COLUMNS = ("Tên", "API key", "Trạng thái", "Bật")
    # Nhãn cho lựa chọn "không đặt giọng mặc định".
    DEFAULT_VOICE_BY_GENDER = "(giọng mặc định hệ thống)"

    def __init__(self, app: "MainWindow") -> None:
        super().__init__(app, "Cài đặt", "Quản lý các thành phần và tùy chọn ứng dụng.")
        # Cài đặt hệ thống và cập nhật nằm chung một nơi. Việc lồng trang cập nhật
        # chỉ thay đổi cách trình bày; toàn bộ signal/worker cũ vẫn được giữ nguyên.
        outer_body = self.body
        self.settings_tabs = QTabWidget()
        self.settings_tabs.setObjectName("settingsTabs")
        config_tab = QWidget()
        config_tab.setObjectName("settingsConfigTab")
        config_body = QVBoxLayout(config_tab)
        config_body.setContentsMargins(0, 0, 0, 0)
        config_body.setSpacing(10)
        self.components_page = ComponentsPage(app)
        self.settings_tabs.addTab(config_tab, "Thiết lập")
        self.settings_tabs.addTab(self.components_page, "Cập nhật ứng dụng")
        self.settings_tabs.currentChanged.connect(self._on_settings_tab_changed)
        outer_body.addWidget(self.settings_tabs, 1)
        self.body = config_body
        self._translation_profile_busy = False
        self._drive_account_busy = False
        self.translation_profile_progress.connect(self.app.show_status)
        self.translation_profile_result.connect(self._on_translation_profile_result)
        self.translation_profile_finished.connect(self._on_translation_profile_finished)
        self.drive_account_progress.connect(self.app.show_status)
        self.drive_account_result.connect(self._on_drive_account_result)
        self.drive_account_finished.connect(self._on_drive_account_finished)

        # ----- Tạo widget cấu hình -----
        self.ffmpeg_input = QLineEdit()
        self.ffprobe_input = QLineEdit()
        self.tts_device = QComboBox()
        self.tts_device.addItems(("auto", "cuda", "cpu"))
        self.tts_num_step = QSpinBox()
        self.tts_num_step.setRange(4, 64)
        self.tts_batch_size = QSpinBox()
        self.tts_batch_size.setRange(1, 32)
        self.tts_provider = QComboBox()
        self.tts_provider.addItem("Giọng cục bộ", "local")
        self.tts_provider.addItem("API giọng nói", "api")
        self.voice_api_type = QComboBox()
        self.voice_api_type.addItem("Dịch vụ tiêu chuẩn", "openai")
        self.voice_api_type.addItem("Dịch vụ cao cấp", "elevenlabs")
        self.voice_api_type.addItem("Dịch vụ đối tác", "vietauto")
        self.voice_api_type.addItem("Máy chủ riêng", "omnivoice_server")
        self.voice_api_type.addItem("Kết nối tùy chỉnh", "custom")
        self.voice_api_key = QLineEdit()
        self.voice_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.voice_api_key.setPlaceholderText("Để trống nếu giữ khóa đã lưu")
        self.voice_api_base_url = QLineEdit()
        self.voice_api_model = QLineEdit()
        self.voice_api_project_id = QLineEdit()
        self.voice_api_project_id.setPlaceholderText("Để trống để hệ thống tự thiết lập")
        self.voice_api_voices_url = QLineEdit()
        self.voice_api_voices_url.setPlaceholderText("Địa chỉ đồng bộ danh sách giọng")
        self.voice_api_synthesis_url = QLineEdit()
        self.voice_api_synthesis_url.setPlaceholderText("Địa chỉ xử lý giọng đọc")
        self.omnivoice_server_mode = QComboBox()
        self.omnivoice_server_mode.addItem("Tự động", "auto")
        self.omnivoice_server_mode.addItem("Thiết kế giọng", "design")
        self.omnivoice_server_mode.addItem("Clone từ audio mẫu", "clone")
        self.omnivoice_server_instruct = QLineEdit()
        self.omnivoice_server_instruct.setPlaceholderText("Ví dụ: nữ, giọng trầm, ấm")
        self.omnivoice_server_ref_audio = QLineEdit()
        self.omnivoice_server_ref_audio.setPlaceholderText("Đường dẫn WAV audio mẫu")
        self.omnivoice_server_ref_text = QLineEdit()
        self.omnivoice_server_ref_text.setPlaceholderText("Lời thoại chính xác của audio mẫu")
        self.omnivoice_api_key = QLineEdit()
        self.omnivoice_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.omnivoice_api_key.setPlaceholderText("Để trống nếu giữ khóa máy chủ đã lưu")
        self.omnivoice_api_base_url = QLineEdit()
        self.omnivoice_api_voices_url = QLineEdit()
        self.omnivoice_api_synthesis_url = QLineEdit()
        self.omnivoice_wake_enabled = QCheckBox("Tự khởi động máy chủ khi đang tắt")
        self.omnivoice_wake_url = QLineEdit()
        self.omnivoice_wake_url.setPlaceholderText("Địa chỉ khởi động máy chủ")
        self.omnivoice_wake_token = QLineEdit()
        self.omnivoice_wake_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.omnivoice_wake_token.setPlaceholderText("Để trống nếu giữ token đã lưu")
        self.omnivoice_wake_timeout = QSpinBox()
        self.omnivoice_wake_timeout.setRange(30, 600)
        self.omnivoice_wake_timeout.setSuffix(" giây")
        self.tts_provider.currentIndexChanged.connect(self._on_voice_source_changed)
        self.voice_api_type.currentIndexChanged.connect(self._voice_api_type_changed)
        self.omnivoice_server_mode.currentIndexChanged.connect(self._update_omnivoice_server_fields)
        self.omnivoice_wake_enabled.toggled.connect(self._update_omnivoice_server_fields)
        # Nhận diện lời thoại (Qwen3-ASR cloud) - pool nhiều key, bảng 4 cột.
        self.asr_table = QTableWidget(0, len(self.ASR_COLUMNS))
        self.asr_table.setHorizontalHeaderLabels(self.ASR_COLUMNS)
        self.asr_table.verticalHeader().setVisible(False)
        self.asr_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.asr_table.setMinimumHeight(130)
        self.asr_lang = QComboBox()
        self.asr_lang.setEditable(True)
        self.asr_lang.addItems(("zh", "en", "ja", "ko", "vi"))
        self.asr_glossary = QLineEdit()
        self.asr_glossary.setPlaceholderText("(Tuỳ chọn) file glossary sửa tên riêng: mỗi dòng sai=đúng")
        self.asr_provider = QComboBox()
        self.asr_provider.addItem("Qwen API", "qwen")
        self.asr_provider.addItem("Máy chủ riêng", "whisper_server")
        self.whisper_api_base_url = QLineEdit()
        self.whisper_api_base_url.setPlaceholderText("http://máy-chủ:8001")
        self.whisper_api_key = QLineEdit()
        self.whisper_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.whisper_api_key.setPlaceholderText("Để trống nếu giữ khóa đã lưu")
        # Giọng mặc định chung cho mọi dòng chưa gán riêng.
        self.default_voice = QComboBox()
        self.default_voice.setEditable(True)
        self.default_voice.setToolTip(
            "Giọng dùng cho mọi dòng chưa gán giọng riêng.\n"
            "Chọn '" + self.DEFAULT_VOICE_BY_GENDER + "' để dùng default của engine."
        )
        self.default_voice.addItem(self.DEFAULT_VOICE_BY_GENDER)
        try:
            self.default_voice.addItems(_voice_choices_for_config(self.app.config))
        except Exception:  # noqa: BLE001 - thiếu OmniVoice vẫn mở được tab
            pass
        self.settings_voice_combo = QComboBox()
        self.settings_sample_input = QLineEdit()
        self.settings_sample_input.setText(
            "Xin chào, tôi là giọng đọc lồng tiếng cho video của bạn."
        )
        self.ocr_lang = QComboBox()
        self.ocr_lang.setEditable(True)
        self.ocr_lang.addItems(("ch", "en", "japan", "korean", "vi"))
        self.ocr_fps = QDoubleSpinBox()
        self.ocr_fps.setRange(0.5, 24.0)
        self.ocr_fps.setSingleStep(0.5)
        self.ocr_min_conf = QDoubleSpinBox()
        self.ocr_min_conf.setRange(0.0, 1.0)
        self.ocr_min_conf.setSingleStep(0.05)
        self.llm_ocr_fps = QDoubleSpinBox()
        self.llm_ocr_fps.setRange(18.0, 25.0)
        self.llm_ocr_fps.setSingleStep(1.0)
        self.llm_ocr_batch = QSpinBox()
        self.llm_ocr_batch.setRange(1, 50)
        self.llm_ocr_lang_hint = QLineEdit()
        self.llm_ocr_lang_hint.setPlaceholderText("Ví dụ: Trung, Nhật, Anh; để trống = tự đoán")
        # --- Drive OCR ---
        self.drive_account_buttons = []
        self.drive_account_paths = []
        self.drive_account_choose_buttons = []
        self.drive_account_check_buttons = []
        self.drive_account_status_labels = []
        for slot in range(1, 5):
            button = QPushButton("Đăng nhập")
            button.setProperty("variant", "primary")
            button.clicked.connect(
                lambda _checked=False, value=slot, btn=button: self._login_drive_ocr(value, btn)
            )
            self.drive_account_buttons.append(button)
            status = muted_label("○ Chưa đăng nhập")
            status.setMinimumWidth(250)
            self.drive_account_status_labels.append(status)
            check_button = QPushButton("Kiểm tra")
            check_button.clicked.connect(
                lambda _checked=False, value=slot: self._check_drive_account(value)
            )
            self.drive_account_check_buttons.append(check_button)
            path_display = QLineEdit()
            path_display.setReadOnly(True)
            account_path = self.app.config.drive_account_credentials_path(slot)
            Path(account_path).parent.mkdir(parents=True, exist_ok=True)
            path_display.setText(account_path)
            path_display.setToolTip("Mỗi tài khoản dùng một thư mục kết nối riêng.")
            self.drive_account_paths.append(path_display)
            choose_button = QPushButton("Chọn file...")
            choose_button.clicked.connect(
                lambda _checked=False, value=slot: self._browse_drive_creds(value)
            )
            self.drive_account_choose_buttons.append(choose_button)
        self.btn_drive_test = QPushButton("Kiểm tra 4 tài khoản tuần tự")
        self.btn_drive_test.setToolTip(
            "Kiểm tra từng tài khoản một để tránh tranh mạng và giới hạn truy cập."
        )
        self.btn_drive_test.clicked.connect(self._check_all_drive_accounts)
        self.vision_api_key = QLineEdit()
        self.vision_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.vision_api_key.setPlaceholderText("Khóa tăng tốc nhận diện (tùy chọn)")
        self.btn_vision_test = QPushButton("Kiểm tra tăng tốc")
        self.btn_vision_test.setToolTip("Kiểm tra khóa tăng tốc nhận diện.")
        self.btn_vision_test.clicked.connect(self._test_vision_ocr)
        self.remote_ocr_url = QLineEdit()
        self.remote_ocr_url.setPlaceholderText("Ví dụ: http://192.168.1.10:8765")
        self.remote_ocr_api_key = QLineEdit()
        self.remote_ocr_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.remote_ocr_api_key.setPlaceholderText("Để trống nếu giữ khóa đã lưu")
        self.remote_ocr_client_id = QLineEdit()
        self.remote_ocr_client_id.setPlaceholderText("Tên máy duy nhất trong hệ thống")
        self.remote_ocr_timeout = QSpinBox()
        self.remote_ocr_timeout.setRange(15, 1800)
        self.remote_ocr_batch = QSpinBox()
        self.remote_ocr_batch.setRange(1, 50)
        self.remote_ocr_batch.setSuffix(" anh/lo")
        self.remote_ocr_parallel = QSpinBox()
        # Không khóa ở 12: máy chủ nhận diện quyết định năng lực thực tế và
        # người vận hành có thể tăng pool khi bổ sung tài khoản/server worker.
        self.remote_ocr_parallel.setRange(1, 9999)
        self.remote_ocr_parallel.setSuffix(" luong")
        self.remote_ocr_timeout.setSuffix(" giây")
        self.btn_remote_ocr_test = QPushButton("Kiểm tra máy chủ")
        self.btn_remote_ocr_test.clicked.connect(self._test_remote_ocr)
        self.translation_source = QComboBox()
        self.translation_source.addItem("Dịch Gemini", "web")
        self.translation_source.addItem("Dịch nhanh", "qwen")
        self.translation_source.addItem("Nguồn dự phòng", "api")
        self.translation_qwen_key = QLineEdit()
        self.translation_qwen_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.translation_qwen_key.setPlaceholderText("Để trống nếu giữ khóa dịch nhanh đã lưu")
        self.translation_qwen_base_url = QLineEdit()
        self.translation_qwen_base_url.setEchoMode(QLineEdit.EchoMode.Password)
        self.translation_qwen_model = QLineEdit()
        self.translation_profile_count = QComboBox()
        self.translation_profile_count.addItem("1 phiên — ổn định", 1)
        self.translation_profile_count.addItem("2 phiên — nhanh hơn", 2)
        self.translation_profile_count.addItem("3 phiên — song song", 3)
        self.translation_profile_count.addItem("4 phiên — tối đa", 4)
        self.translation_api_fallback = QCheckBox("Tự động dùng nguồn dự phòng khi nguồn chính lỗi")
        self.translation_login_buttons = []
        self.translation_check_buttons = []
        self.translation_status_labels = []
        for slot in range(1, 5):
            status = muted_label("Chưa kiểm tra")
            status.setMinimumWidth(260)
            self.translation_status_labels.append(status)
            check_button = QPushButton("Kiểm tra")
            check_button.clicked.connect(
                lambda _checked=False, value=slot:
                self._login_gemini_web_profile(value, interactive=False)
            )
            self.translation_check_buttons.append(check_button)
            login_button = QPushButton("Đăng nhập")
            login_button.clicked.connect(
                lambda _checked=False, value=slot:
                self._login_gemini_web_profile(value, interactive=True)
            )
            self.translation_login_buttons.append(login_button)
        self.btn_check_all_translation = QPushButton("Kiểm tra tất cả tuần tự")
        self.btn_check_all_translation.clicked.connect(
            self._check_all_translation_profiles
        )
        self.batch_size = QSpinBox()
        self.batch_size.setRange(1, 200)
        self.speed_min = QDoubleSpinBox()
        self.speed_min.setRange(0.5, 1.0)
        self.speed_min.setSingleStep(0.01)
        self.speed_max = QDoubleSpinBox()
        self.speed_max.setRange(1.0, 2.0)
        self.speed_max.setSingleStep(0.01)
        self.sub_max_chars = QSpinBox()
        self.sub_max_chars.setRange(20, 300)
        self.sub_max_duration = QDoubleSpinBox()
        self.sub_max_duration.setRange(1.0, 30.0)
        self.sub_max_duration.setSingleStep(0.5)
        self.sub_split_gap = QDoubleSpinBox()
        self.sub_split_gap.setRange(0.1, 3.0)
        self.sub_split_gap.setSingleStep(0.1)
        self.strategy = QComboBox()
        self.strategy.addItems(("priority", "round_robin", "random", "fastest"))
        self.api_table = QTableWidget(0, len(self.API_COLUMNS))
        self.api_table.setHorizontalHeaderLabels(self.API_COLUMNS)
        self.api_table.setColumnHidden(2, True)
        self.api_table.verticalHeader().setVisible(False)
        self.api_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.api_table.setMinimumHeight(120)

        def _form(rows: list[tuple[str, QWidget]]) -> QFormLayout:
            f = QFormLayout()
            f.setContentsMargins(0, 0, 0, 0)
            for label, widget in rows:
                f.addRow(label, widget)
            return f

        # ----- Danh mục bên trái + nội dung riêng từng nhóm -----
        # Không còn một trang cuộn dài; mỗi nhóm chỉ hiện các tùy chọn liên quan.
        settings_shell = QWidget()
        settings_shell.setObjectName("settingsShell")
        settings_shell_layout = QHBoxLayout(settings_shell)
        settings_shell_layout.setContentsMargins(10, 4, 10, 4)
        settings_shell_layout.setSpacing(12)
        self.settings_category_nav = QListWidget()
        self.settings_category_nav.setObjectName("settingsCategoryNav")
        self.settings_category_nav.setFixedWidth(210)
        self.settings_category_nav.addItems((
            "Tổng quan", "Giọng đọc", "Nhận diện phụ đề", "Dịch thuật",
        ))
        self.settings_category_stack = QStackedWidget()
        self.settings_category_stack.setObjectName("settingsCategoryStack")
        settings_shell_layout.addWidget(self.settings_category_nav)
        settings_shell_layout.addWidget(self.settings_category_stack, 1)
        self.body.addWidget(settings_shell, 1)

        def _category_page() -> QVBoxLayout:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            host = QWidget()
            host_layout = QHBoxLayout(host)
            host_layout.setContentsMargins(8, 0, 8, 0)
            host_layout.addStretch(1)
            inner = QWidget()
            inner.setObjectName("settingsContent")
            inner.setMinimumWidth(660)
            inner.setMaximumWidth(1050)
            column = QVBoxLayout(inner)
            column.setContentsMargins(20, 16, 20, 20)
            column.setSpacing(12)
            host_layout.addWidget(inner, 8)
            host_layout.addStretch(1)
            scroll.setWidget(host)
            self.settings_category_stack.addWidget(scroll)
            return column

        general_col = _category_page()
        voice_col = _category_page()
        recognition_col = _category_page()
        translation_col = _category_page()
        connection_col = _category_page()
        self.settings_category_nav.currentRowChanged.connect(
            self.settings_category_stack.setCurrentIndex
        )
        self.settings_category_nav.setCurrentRow(0)

        sec_ff = CollapsibleBox("Xử lý video")
        sec_ff.add_layout(_form([
            ("Bộ xử lý video:", self.ffmpeg_input), ("Bộ đọc thông tin video:", self.ffprobe_input),
        ]))
        btn_check = QPushButton("Kiểm tra thành phần")
        btn_check.clicked.connect(self._check_ffmpeg)
        sec_ff.add_widget(btn_check)
        general_col.addWidget(sec_ff)

        sec_voice = CollapsibleBox("Kết nối giọng đọc")
        sec_voice.add_layout(_form([
            ("Nguồn giọng:", self.tts_provider),
            ("Thiết bị:", self.tts_device),
            ("Chất lượng:", self.tts_num_step),
            ("Số câu xử lý đồng thời:", self.tts_batch_size),
            ("Giọng mặc định:", self.default_voice),
        ]))
        self.voice_api_form = _form([
            ("Loại kết nối:", self.voice_api_type),
            ("Khóa truy cập:", self.voice_api_key),
            ("Địa chỉ dịch vụ:", self.voice_api_base_url),
            ("Cấu hình xử lý:", self.voice_api_model),
            ("Mã không gian làm việc:", self.voice_api_project_id),
            ("Địa chỉ danh sách giọng:", self.voice_api_voices_url),
            ("Địa chỉ tạo giọng:", self.voice_api_synthesis_url),
            ("Khóa máy chủ riêng:", self.omnivoice_api_key),
            ("Địa chỉ máy chủ riêng:", self.omnivoice_api_base_url),
            ("Địa chỉ danh sách giọng riêng:", self.omnivoice_api_voices_url),
            ("Địa chỉ tạo giọng riêng:", self.omnivoice_api_synthesis_url),
            ("Chế độ máy chủ riêng:", self.omnivoice_server_mode),
            ("Mô tả giọng thiết kế:", self.omnivoice_server_instruct),
            ("Audio mẫu clone:", self.omnivoice_server_ref_audio),
            ("Lời thoại audio mẫu:", self.omnivoice_server_ref_text),
            ("Tự khởi động:", self.omnivoice_wake_enabled),
            ("Địa chỉ khởi động:", self.omnivoice_wake_url),
            ("Khóa khởi động:", self.omnivoice_wake_token),
            ("Thời gian chờ tối đa:", self.omnivoice_wake_timeout),
        ])
        sec_voice.add_layout(self.voice_api_form)
        vrow = QHBoxLayout()
        btn_check_omni = QPushButton("Kiểm tra giọng đọc")
        btn_check_omni.clicked.connect(self._check_omnivoice)
        vrow.addWidget(btn_check_omni)
        btn_sync_voices = QPushButton("Đồng bộ danh sách giọng")
        btn_sync_voices.clicked.connect(self._sync_voice_catalog)
        vrow.addWidget(btn_sync_voices)
        vrow.addStretch()
        sec_voice.add_layout(vrow)
        voice_preview_row = QHBoxLayout()
        btn_preview_voice = QPushButton("Nghe thử giọng")
        btn_preview_voice.setProperty("variant", "primary")
        btn_preview_voice.clicked.connect(self._preview_settings_voice)
        voice_preview_row.addWidget(self.settings_voice_combo, 1)
        voice_preview_row.addWidget(self.settings_sample_input, 2)
        voice_preview_row.addWidget(btn_preview_voice)
        sec_voice.add_layout(voice_preview_row)
        voice_col.addWidget(sec_voice)

        sec_asr = CollapsibleBox("Nhận diện bằng âm thanh")
        btn_add_asr = QPushButton("Thêm key")
        btn_add_asr.clicked.connect(self._add_asr_key_row)
        btn_del_asr = QPushButton("Xóa key")
        btn_del_asr.setProperty("variant", "danger")
        btn_del_asr.clicked.connect(self._delete_asr_key_row)
        self.btn_check_asr = QPushButton("Kiểm tra key")
        self.btn_check_asr.clicked.connect(self._check_asr_keys)
        self.btn_check_whisper = QPushButton("Kiểm tra máy chủ")
        self.btn_check_whisper.clicked.connect(self._check_whisper_server)
        sec_asr.add_layout(_form([
            ("Địa chỉ API:", self.whisper_api_base_url),
            ("Khóa truy cập:", self.whisper_api_key),
            ("Ngôn ngữ:", self.asr_lang),
        ]))
        asr_server_row = QHBoxLayout()
        asr_server_row.addWidget(self.btn_check_whisper)
        asr_server_row.addWidget(
            muted_label("Dùng khi chọn “Tách bằng âm thanh” ở tab Dự án."), 1
        )
        sec_asr.add_layout(asr_server_row)
        recognition_col.addWidget(sec_asr)

        sec_ocr = CollapsibleBox("Nhận diện phụ đề")
        sec_ocr.add_layout(_form([
            ("Địa chỉ máy chủ:", self.remote_ocr_url),
            ("Khóa truy cập:", self.remote_ocr_api_key),
            ("Tên máy:", self.remote_ocr_client_id),
            ("Thời gian chờ:", self.remote_ocr_timeout),
            ("So anh moi lo:", self.remote_ocr_batch),
            ("So luong gui:", self.remote_ocr_parallel),
        ]))
        remote_row = QHBoxLayout()
        remote_row.addWidget(self.btn_remote_ocr_test)
        remote_row.addWidget(muted_label("Mỗi máy phải dùng một tên riêng."), 1)
        sec_ocr.add_layout(remote_row)
        recognition_col.addWidget(sec_ocr)

        sec_trans = CollapsibleBox("Dịch & Đồng bộ", collapsed=True)
        sec_trans.add_layout(_form([
            ("Chế độ dịch:", self.translation_source),
            ("Khóa dịch nhanh:", self.translation_qwen_key),
            ("Địa chỉ dịch vụ:", self.translation_qwen_base_url),
            ("Cấu hình xử lý:", self.translation_qwen_model),
            ("Số phiên dịch:", self.translation_profile_count),
            ("Số dòng mỗi lô dịch:", self.batch_size),
            ("Voice co tối đa khi câu dài (vd 1.5):", self.speed_max),
        ]))
        sec_trans.add_widget(self.translation_api_fallback)
        model_hint = muted_label(
            "Các phiên nhận lô động; kết quả luôn được ráp lại theo số dòng gốc."
        )
        model_hint.setWordWrap(True)
        sec_trans.add_widget(model_hint)
        for slot in range(1, 5):
            account_row = QHBoxLayout()
            account_row.addWidget(QLabel(f"Phiên dịch {slot}:"))
            account_row.addWidget(self.translation_status_labels[slot - 1], 1)
            account_row.addWidget(self.translation_check_buttons[slot - 1])
            account_row.addWidget(self.translation_login_buttons[slot - 1])
            sec_trans.add_layout(account_row)
        check_all_row = QHBoxLayout()
        check_all_row.addWidget(self.btn_check_all_translation)
        check_all_row.addStretch()
        sec_trans.add_layout(check_all_row)
        translation_col.addWidget(sec_trans)

        sec_sub = CollapsibleBox("Tách câu phụ đề", collapsed=True)
        sec_sub.add_layout(_form([
            ("Ký tự tối đa/câu:", self.sub_max_chars),
            ("Giây tối đa/câu:", self.sub_max_duration),
            ("Khoảng lặng tách câu (s):", self.sub_split_gap),
        ]))
        translation_col.addWidget(sec_sub)

        sec_api = CollapsibleBox("Kết nối dịch vụ")
        sec_api.add_widget(self.api_table)
        api_row = QHBoxLayout()
        btn_add_key = QPushButton("Thêm kết nối")
        btn_add_key.clicked.connect(self._add_key_row)
        btn_del_key = QPushButton("Xóa kết nối")
        btn_del_key.setProperty("variant", "danger")
        btn_del_key.clicked.connect(self._delete_key_row)
        api_row.addWidget(btn_add_key)
        api_row.addWidget(btn_del_key)
        api_row.addWidget(QLabel("Chế độ sử dụng:"))
        api_row.addWidget(self.strategy)
        api_row.addStretch()
        sec_api.add_layout(api_row)
        connection_col.addWidget(sec_api)

        for category_col in (
            general_col, voice_col, recognition_col, translation_col,
            connection_col,
        ):
            category_col.addStretch()

        # Nút Lưu luôn hiển thị dưới cùng (ngoài vùng cuộn).
        btn_save = QPushButton("Lưu cài đặt")
        btn_save.setProperty("variant", "primary")
        btn_save.setFixedWidth(240)
        btn_save.setMinimumHeight(40)
        btn_save.clicked.connect(self._save)
        save_row = QHBoxLayout()
        save_row.addStretch()
        save_row.addWidget(btn_save)
        save_row.addStretch()
        self.body.addLayout(save_row)
        QTimer.singleShot(700, self._auto_sync_voice_catalog)

    def _on_settings_tab_changed(self, index: int) -> None:
        if index == 1:
            self.components_page.refresh()

    def has_background_task(self) -> bool:
        return self.components_page.has_background_task()

    def cancel_background_tasks(self) -> None:
        self.components_page.cancel_background_tasks()

    def refresh(self) -> None:
        c = self.app.config
        self.ffmpeg_input.setText(c.ffmpeg_path)
        self.ffprobe_input.setText(c.ffprobe_path)
        self.tts_device.setCurrentText(c.tts_device)
        self.tts_num_step.setValue(c.tts_num_step)
        self.tts_batch_size.setValue(c.tts_batch_size)
        old_tts_provider_signals = self.tts_provider.blockSignals(True)
        old_voice_api_type_signals = self.voice_api_type.blockSignals(True)
        try:
            self.tts_provider.setCurrentIndex(max(0, self.tts_provider.findData(
                getattr(c, "tts_provider", "local")
            )))
            self.voice_api_type.setCurrentIndex(max(0, self.voice_api_type.findData(
                getattr(c, "voice_api_type", "openai")
            )))
        finally:
            self.tts_provider.blockSignals(old_tts_provider_signals)
            self.voice_api_type.blockSignals(old_voice_api_type_signals)
        self.voice_api_key.clear()
        self.voice_api_key.setPlaceholderText(
            "Khóa đã lưu an toàn — nhập mới để thay" if getattr(c, "voice_api_key", "")
            else "Nhập khóa API giọng nói"
        )
        self.voice_api_base_url.setText(getattr(c, "voice_api_base_url", ""))
        self.voice_api_model.setText(getattr(c, "voice_api_model", ""))
        self.voice_api_project_id.setText(getattr(c, "voice_api_project_id", ""))
        self.voice_api_voices_url.setText(getattr(c, "voice_api_voices_url", ""))
        self.voice_api_synthesis_url.setText(getattr(c, "voice_api_synthesis_url", ""))
        self.omnivoice_server_mode.setCurrentIndex(max(
            0, self.omnivoice_server_mode.findData(
                getattr(c, "voice_api_omnivoice_mode", "auto")
            )
        ))
        self.omnivoice_server_instruct.setText(
            getattr(c, "voice_api_omnivoice_instruct", "")
        )
        self.omnivoice_server_ref_audio.setText(
            getattr(c, "voice_api_omnivoice_ref_audio", "")
        )
        self.omnivoice_server_ref_text.setText(
            getattr(c, "voice_api_omnivoice_ref_text", "")
        )
        self.omnivoice_api_key.clear()
        self.omnivoice_api_key.setPlaceholderText(
            "Khóa OmniVoice đã lưu an toàn — nhập mới để thay"
            if getattr(c, "voice_api_omnivoice_key", "")
            else "Nhập khóa API của OmniVoice Server"
        )
        self.omnivoice_api_base_url.setText(
            getattr(c, "voice_api_omnivoice_base_url", "")
            or "http://47.84.113.154:8000"
        )
        self.omnivoice_api_voices_url.setText(
            getattr(c, "voice_api_omnivoice_voices_url", "")
            or "http://47.84.113.154:8000/voices"
        )
        self.omnivoice_api_synthesis_url.setText(
            getattr(c, "voice_api_omnivoice_synthesis_url", "")
            or "http://47.84.113.154:8000/tts"
        )
        self.omnivoice_wake_enabled.setChecked(
            bool(getattr(c, "voice_api_wake_enabled", False))
        )
        self.omnivoice_wake_url.setText(
            getattr(c, "voice_api_wake_url", "")
        )
        self.omnivoice_wake_token.clear()
        self.omnivoice_wake_token.setPlaceholderText(
            "Token đã lưu an toàn — nhập mới để thay"
            if getattr(c, "voice_api_wake_token", "")
            else "Để trống nếu chưa dùng token"
        )
        self.omnivoice_wake_timeout.setValue(
            int(getattr(c, "voice_api_wake_timeout", 180) or 180)
        )
        self._update_omnivoice_server_fields()
        try:
            voices = _voice_choices_for_config(self.app.config)
        except Exception:  # noqa: BLE001
            voices = []
        current_default = getattr(c, "default_voice", "") or self.DEFAULT_VOICE_BY_GENDER
        self.default_voice.clear()
        self.default_voice.addItem(self.DEFAULT_VOICE_BY_GENDER)
        self.default_voice.addItems(voices)
        self.default_voice.setCurrentText(current_default)
        current_voice = self.settings_voice_combo.currentText()
        self.settings_voice_combo.clear()
        self.settings_voice_combo.addItems(voices)
        self.settings_voice_combo.setEnabled(bool(voices))
        if current_voice in voices:
            self.settings_voice_combo.setCurrentText(current_voice)
        self.ocr_lang.setCurrentText(getattr(c, "ocr_lang", "ch"))
        self.ocr_fps.setValue(float(getattr(c, "ocr_fps", 3.0)))
        self.ocr_min_conf.setValue(float(getattr(c, "ocr_min_confidence", 0.6)))
        scan_mode = str(getattr(c, "ocr_scan_mode", "fast") or "fast").strip().lower()
        self.llm_ocr_fps.setValue(25.0 if scan_mode == "standard" else 18.0)
        self.llm_ocr_batch.setValue(int(getattr(c, "llm_ocr_batch", 18)))
        self.llm_ocr_lang_hint.setText(getattr(c, "llm_ocr_lang_hint", ""))
        self.vision_api_key.setText(getattr(c, "vision_api_key", ""))
        self.remote_ocr_url.setText(getattr(c, "remote_ocr_url", ""))
        self.remote_ocr_api_key.clear()
        self.remote_ocr_api_key.setPlaceholderText(
            "Khóa đã lưu an toàn — nhập mới để thay"
            if getattr(c, "remote_ocr_api_key", "")
            else "Nhập khóa truy cập máy chủ"
        )
        from vicdub.api.remote_ocr_client import default_client_id  # noqa: PLC0415
        self.remote_ocr_client_id.setText(
            getattr(c, "remote_ocr_client_id", "") or default_client_id()
        )
        self.remote_ocr_timeout.setValue(
            int(getattr(c, "remote_ocr_timeout", 180) or 180)
        )
        self.remote_ocr_batch.setValue(
            int(getattr(c, "remote_ocr_batch", 20) or 20)
        )
        self.remote_ocr_parallel.setValue(
            int(getattr(c, "remote_ocr_parallel", 8) or 8)
        )
        # Nhận diện lời thoại: nạp pool key vào bảng.
        self.asr_lang.setCurrentText(getattr(c, "asr_lang", "zh"))
        self.asr_glossary.setText(getattr(c, "asr_glossary", ""))
        provider_index = self.asr_provider.findData(getattr(c, "asr_provider", "qwen"))
        self.asr_provider.setCurrentIndex(max(0, provider_index))
        self.whisper_api_base_url.setText(
            getattr(c, "whisper_api_base_url", "http://47.84.113.154:8001")
        )
        self.whisper_api_key.clear()
        self.whisper_api_key.setPlaceholderText(
            "Khóa đã lưu an toàn — nhập mới để thay"
            if getattr(c, "whisper_api_key", "")
            else "Nhập khóa máy chủ tách âm"
        )
        self._load_asr_accounts(c)
        index = self.translation_source.findData(getattr(c, "translation_source", "web"))
        self.translation_source.setCurrentIndex(max(0, index))
        self.translation_qwen_key.clear()
        self.translation_qwen_key.setPlaceholderText(
            "Khóa dịch nhanh đã lưu an toàn — nhập mới để thay"
            if getattr(c, "translation_qwen_api_key", "")
            else "Nhập khóa dịch nhanh"
        )
        self.translation_qwen_base_url.setText(
            getattr(c, "translation_qwen_base_url", "")
        )
        self.translation_qwen_model.setText(
            getattr(c, "translation_qwen_model", "qwen-plus")
        )
        count = max(1, min(4, int(getattr(c, "translation_web_profiles", 2))))
        self.translation_profile_count.setCurrentIndex(
            max(0, self.translation_profile_count.findData(count))
        )
        self.translation_api_fallback.setChecked(
            bool(getattr(c, "translation_api_fallback", True))
        )
        translation_accounts = {
            int(item.get("slot", 0)): item
            for item in (getattr(c, "translation_accounts", []) or [])
            if str(item.get("slot", "")).isdigit()
        }
        for slot, label in enumerate(self.translation_status_labels, 1):
            account = translation_accounts.get(slot, {})
            email = str(account.get("email", "")).strip()
            state = str(account.get("status", "")).strip()
            marker = (
                Path(c.data_dir)
                / f"gemini_web_login_translation_{slot}.ok"
            )
            if state == "ready" and marker.exists():
                label.setText(f"✅ {email or 'Đã kết nối'}")
            elif state == "duplicate":
                label.setText(f"⚠️ {email or 'Tài khoản bị trùng'}")
            elif state == "error":
                label.setText(f"⚠️ {email or 'Phiên cần đăng nhập lại'}")
            elif marker.exists():
                label.setText(f"● {email or 'Đã đăng nhập — chưa kiểm tra'}")
            else:
                label.setText("○ Chưa đăng nhập")
        self._set_translation_profile_buttons(not self._translation_profile_busy)
        raw_drive_accounts = [
            dict(item) for item in (c.drive_ocr_accounts or [])
            if isinstance(item, dict) and item.get("token_path")
        ]
        connected = {
            Path(str(a["token_path"])).resolve()
            for a in raw_drive_accounts
            if Path(str(a["token_path"])).exists()
        }
        account_by_token = {
            Path(str(a["token_path"])).resolve(): a
            for a in raw_drive_accounts
        }
        for slot, button in enumerate(self.drive_account_buttons, 1):
            token = Path(c.drive_account_token_path(slot)).resolve()
            account = account_by_token.get(token, {})
            email = str(account.get("email", "")).strip()
            state = str(account.get("status", "")).strip()
            is_connected = token in connected and token.exists()
            label = self.drive_account_status_labels[slot - 1]
            if state == "ready" and is_connected:
                label.setText(f"✅ {email or 'Sẵn sàng'}")
            elif state == "duplicate":
                label.setText(f"⚠️ {email or 'Trùng tài khoản'}")
            elif state == "error":
                label.setText(f"⚠️ {email or 'Cần đăng nhập lại'}")
            elif is_connected:
                label.setText(f"● {email or 'Đã đăng nhập — chưa kiểm tra'}")
            else:
                label.setText("○ Chưa đăng nhập")
            label.setToolTip(str(account.get("last_error", "") or ""))
            button.setText("Đăng nhập lại" if is_connected else "Đăng nhập")
            button.setToolTip(
                f"Tài khoản xử lý {slot}: {email}" if email
                else f"Tài khoản xử lý {slot}; bấm kiểm tra để cập nhật email."
            )
        self._set_drive_account_buttons(not self._drive_account_busy)
        self.batch_size.setValue(c.translate_batch_size)
        self.speed_min.setValue(c.speed_min)
        self.speed_max.setValue(c.speed_max)
        self.sub_max_chars.setValue(c.sub_max_chars)
        self.sub_max_duration.setValue(c.sub_max_duration)
        self.sub_split_gap.setValue(c.sub_split_gap)
        self.strategy.setCurrentText(c.api_pool_strategy)

        keys = self.app.api.to_config()
        self.api_table.setRowCount(len(keys))
        for r, k in enumerate(keys):
            display_name = k["name"]
            if "gemini" in display_name.lower():
                display_name = f"Dịch vụ {r + 1}"
            values = (display_name, "", k["model"], str(k["rpm"]),
                      str(k["priority"]), "1" if k["enabled"] else "0")
            for col, value in enumerate(values):
                self.api_table.setItem(r, col, QTableWidgetItem(value))
            self._set_key_editor(r, k["key"])

    def _check_ffmpeg(self) -> None:
        try:
            FFmpeg(self.ffmpeg_input.text(), self.ffprobe_input.text()).version()
            self.info("Thành phần xử lý video hoạt động bình thường.")
        except FFmpegError as exc:
            self.warn(str(exc))

    def _check_omnivoice(self) -> None:
        """Kiểm tra thư viện OmniVoice, thiết bị và bộ giọng Việt."""
        try:
            self._apply_voice_settings()
            self.info(create_engine(self.app.config).check())
            self.refresh()
        except Exception as exc:  # noqa: BLE001
            self.warn(str(exc))

    def _check_whisper_server(self) -> None:
        """Kiểm tra máy chủ nhận diện riêng mà không chặn giao diện."""
        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415

        config = self.app.config
        config.whisper_api_base_url = (
            self.whisper_api_base_url.text().strip() or "http://47.84.113.154:8001"
        )
        entered = self.whisper_api_key.text().strip()
        if entered:
            config.whisper_api_key = protect_secret(entered)
        bridge = _DriveSelfTestBridge(self)
        self._whisper_check_bridge = bridge
        self.btn_check_whisper.setEnabled(False)

        def finish(message: str) -> None:
            self.btn_check_whisper.setEnabled(True)
            if message.startswith("OK:"):
                self.info(message[3:])
            else:
                self.warn(message)

        bridge.done.connect(finish)

        def worker() -> None:
            try:
                from vicdub.api.whisper_asr_client import check_server  # noqa: PLC0415
                check_server(config)
                bridge.done.emit("OK:Kết nối thành công")
            except Exception as exc:  # noqa: BLE001
                bridge.done.emit(str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _voice_api_type_changed(self) -> None:
        api_index = self.tts_provider.findData("api")
        if api_index >= 0 and self.tts_provider.currentData() != "api":
            self.tts_provider.setCurrentIndex(api_index)
        kind = self.voice_api_type.currentData()
        known = self.voice_api_base_url.text().strip()
        current_synthesis = self.voice_api_synthesis_url.text().strip()
        if kind == "elevenlabs" and (not known or "openai.com" in known or "vietauto.ai" in known):
            self.voice_api_base_url.setText("https://api.elevenlabs.io")
            self.voice_api_model.setText("eleven_v3")
            if "vietauto.ai" in current_synthesis:
                self.voice_api_synthesis_url.clear()
        elif kind == "vietauto" and (not known or "openai.com" in known or "elevenlabs.io" in known):
            self.voice_api_base_url.setText("https://vietauto.ai")
            self.voice_api_model.setText("eleven_v3")
            self.voice_api_synthesis_url.setText("https://vietauto.ai/api/elevenlabs")
        elif kind == "omnivoice_server":
            if not self.omnivoice_api_base_url.text().strip():
                self.omnivoice_api_base_url.setText("http://47.84.113.154:8000")
            if not self.omnivoice_api_voices_url.text().strip():
                self.omnivoice_api_voices_url.setText("http://47.84.113.154:8000/voices")
            if not self.omnivoice_api_synthesis_url.text().strip():
                self.omnivoice_api_synthesis_url.setText("http://47.84.113.154:8000/tts")
        elif kind == "openai" and (not known or "elevenlabs.io" in known or "vietauto.ai" in known):
            self.voice_api_base_url.setText("https://api.openai.com/v1")
            self.voice_api_model.setText("gpt-4o-mini-tts")
            if "vietauto.ai" in current_synthesis:
                self.voice_api_synthesis_url.clear()
        self._update_omnivoice_server_fields()
        self._on_voice_source_changed()

    def _update_omnivoice_server_fields(self) -> None:
        active = self.voice_api_type.currentData() == "omnivoice_server"
        mode = self.omnivoice_server_mode.currentData() or "auto"
        generic_fields = (
            self.voice_api_key, self.voice_api_base_url, self.voice_api_model,
            self.voice_api_project_id, self.voice_api_voices_url,
            self.voice_api_synthesis_url,
        )
        omnivoice_fields = (
            self.omnivoice_api_key, self.omnivoice_api_base_url,
            self.omnivoice_api_voices_url, self.omnivoice_api_synthesis_url,
            self.omnivoice_server_mode, self.omnivoice_server_instruct,
            self.omnivoice_server_ref_audio, self.omnivoice_server_ref_text,
            self.omnivoice_wake_enabled, self.omnivoice_wake_url,
            self.omnivoice_wake_token, self.omnivoice_wake_timeout,
        )
        for field in generic_fields:
            self.voice_api_form.setRowVisible(field, not active)
        for field in omnivoice_fields:
            self.voice_api_form.setRowVisible(field, active)
        self.omnivoice_server_instruct.setEnabled(mode == "design")
        self.omnivoice_server_ref_audio.setEnabled(mode == "clone")
        self.omnivoice_server_ref_text.setEnabled(mode == "clone")
        wake_active = active and self.omnivoice_wake_enabled.isChecked()
        self.omnivoice_wake_url.setEnabled(wake_active)
        self.omnivoice_wake_token.setEnabled(wake_active)
        self.omnivoice_wake_timeout.setEnabled(wake_active)

    def _on_voice_source_changed(self) -> None:
        try:
            self._apply_voice_settings()
            self._refresh_voice_dropdowns()
        except Exception as exc:  # noqa: BLE001
            self.app.show_status(f"Nạp danh sách giọng lỗi: {self._public_message(str(exc))}")

    def _refresh_voice_dropdowns(self) -> None:
        try:
            voices = _voice_choices_for_config(self.app.config)
        except Exception:  # noqa: BLE001
            voices = []
        current_default = self.default_voice.currentText().strip()
        current_preview = self.settings_voice_combo.currentText().strip()
        self.default_voice.clear()
        self.default_voice.addItem(self.DEFAULT_VOICE_BY_GENDER)
        self.default_voice.addItems(voices)
        if current_default and self.default_voice.findText(current_default) >= 0:
            self.default_voice.setCurrentText(current_default)
        self.settings_voice_combo.clear()
        self.settings_voice_combo.addItems(voices)
        if current_preview and self.settings_voice_combo.findText(current_preview) >= 0:
            self.settings_voice_combo.setCurrentText(current_preview)
        self.settings_voice_combo.setEnabled(bool(voices))

    def _apply_voice_settings(self) -> None:
        """Chép riêng phần voice từ form vào config, chưa ghi đĩa."""
        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
        c = self.app.config
        c.tts_provider = self.tts_provider.currentData() or "local"
        c.voice_api_type = self.voice_api_type.currentData() or "openai"
        entered_key = self.voice_api_key.text().strip()
        if entered_key:
            c.voice_api_key = protect_secret(entered_key)
            self.voice_api_key.clear()
            self.voice_api_key.setPlaceholderText("Khóa đã lưu an toàn — nhập mới để thay")
        elif getattr(c, "voice_api_key", "") and not str(c.voice_api_key).startswith(("dpapi:", "base64:")):
            c.voice_api_key = protect_secret(c.voice_api_key)
        c.voice_api_base_url = self.voice_api_base_url.text().strip()
        c.voice_api_model = self.voice_api_model.text().strip()
        c.voice_api_project_id = self.voice_api_project_id.text().strip()
        c.voice_api_voices_url = self.voice_api_voices_url.text().strip()
        c.voice_api_synthesis_url = self.voice_api_synthesis_url.text().strip()
        c.voice_api_omnivoice_mode = self.omnivoice_server_mode.currentData() or "auto"
        c.voice_api_omnivoice_instruct = self.omnivoice_server_instruct.text().strip()
        c.voice_api_omnivoice_ref_audio = self.omnivoice_server_ref_audio.text().strip()
        c.voice_api_omnivoice_ref_text = self.omnivoice_server_ref_text.text().strip()
        entered_omnivoice_key = self.omnivoice_api_key.text().strip()
        if entered_omnivoice_key:
            c.voice_api_omnivoice_key = protect_secret(entered_omnivoice_key)
            self.omnivoice_api_key.clear()
            self.omnivoice_api_key.setPlaceholderText(
                "Khóa OmniVoice đã lưu an toàn — nhập mới để thay"
            )
        c.voice_api_omnivoice_base_url = self.omnivoice_api_base_url.text().strip()
        c.voice_api_omnivoice_voices_url = self.omnivoice_api_voices_url.text().strip()
        c.voice_api_omnivoice_synthesis_url = self.omnivoice_api_synthesis_url.text().strip()
        c.voice_api_wake_enabled = self.omnivoice_wake_enabled.isChecked()
        c.voice_api_wake_url = self.omnivoice_wake_url.text().strip()
        entered_wake_token = self.omnivoice_wake_token.text().strip()
        if entered_wake_token:
            c.voice_api_wake_token = protect_secret(entered_wake_token)
            self.omnivoice_wake_token.clear()
            self.omnivoice_wake_token.setPlaceholderText(
                "Token đã lưu an toàn — nhập mới để thay"
            )
        c.voice_api_wake_timeout = self.omnivoice_wake_timeout.value()

    def _sync_voice_catalog(self) -> None:
        self._apply_voice_settings()
        if self.app.config.tts_provider != "api":
            self.warn("Hãy chọn 'API giọng nói' trước khi đồng bộ.")
            return
        self.app.show_status("Đang đồng bộ danh sách giọng từ nền tảng...")

        def worker() -> None:
            try:
                engine = create_engine(self.app.config)
                voices = engine.list_voices(force=True)
                self.app.show_status(f"Đã đồng bộ {len(voices)} giọng.")
                QTimer.singleShot(0, self.refresh)
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Đồng bộ giọng lỗi: {self._public_message(str(exc))}")

        threading.Thread(target=worker, daemon=True).start()

    def _auto_sync_voice_catalog(self) -> None:
        """Đồng bộ nền mỗi 24 giờ, không bật hộp thoại khi mất mạng."""
        if getattr(self.app.config, "tts_provider", "local") != "api":
            return
        try:
            engine = create_engine(self.app.config)
            if not getattr(engine, "catalog_stale", lambda: False)():
                return
        except Exception:
            return

        def worker() -> None:
            try:
                engine.sync_voices()
                self.app.show_status("Danh sách giọng API đã được cập nhật.")
            except Exception as exc:  # noqa: BLE001
                logger = __import__("logging").getLogger(__name__)
                logger.info("Bỏ qua đồng bộ giọng nền: %s", exc)

        threading.Thread(target=worker, daemon=True).start()

    def _set_translation_profile_buttons(self, enabled: bool) -> None:
        for button in (
            *self.translation_login_buttons,
            *self.translation_check_buttons,
            self.btn_check_all_translation,
        ):
            button.setEnabled(enabled)

    def _translation_profile_client(self, slot: int, interactive: bool):
        from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415

        config = self.app.config
        return GeminiWebClient(
            config.data_dir,
            report=lambda _pct, msg: self.translation_profile_progress.emit(msg),
            login_timeout=getattr(config, "gemini_web_login_timeout", 300),
            response_timeout=getattr(config, "gemini_web_response_timeout", 240),
            profile_name=f"translation_{slot}",
            allow_interactive_login=interactive,
        )

    def _login_gemini_web_profile(
        self, slot: int, interactive: bool = True
    ) -> None:
        """Đăng nhập/kiểm tra đúng một profile; không cho mở nhiều cửa sổ cùng lúc."""
        if self._translation_profile_busy:
            self.app.show_status("Đang xử lý một phiên khác; vui lòng chờ.")
            return
        self._translation_profile_busy = True
        self._set_translation_profile_buttons(False)
        action = "đăng nhập" if interactive else "kiểm tra"
        self.app.show_status(f"Phiên {slot}: đang {action}...")

        def worker() -> None:
            email = ""
            try:
                with self._translation_profile_client(slot, interactive) as client:
                    email = client.account_email()
                self.translation_profile_result.emit(
                    slot, True, email, "Sẵn sàng"
                )
            except Exception as exc:  # noqa: BLE001
                self.translation_profile_result.emit(
                    slot, False, "", self._public_message(str(exc))
                )
            finally:
                self.translation_profile_finished.emit()

        threading.Thread(
            target=worker, daemon=True, name=f"translation-profile-{slot}"
        ).start()

    def _check_all_translation_profiles(self) -> None:
        """Kiểm tra tuần tự để tránh bốn Chrome/profile tranh mạng và khóa file."""
        if self._translation_profile_busy:
            self.app.show_status("Đang xử lý một phiên khác; vui lòng chờ.")
            return
        self._translation_profile_busy = True
        self._set_translation_profile_buttons(False)
        count = 4

        def worker() -> None:
            for slot in range(1, count + 1):
                self.translation_profile_progress.emit(
                    f"Đang kiểm tra phiên {slot}/{count}..."
                )
                email = ""
                try:
                    with self._translation_profile_client(
                        slot, interactive=False
                    ) as client:
                        email = client.account_email()
                    self.translation_profile_result.emit(
                        slot, True, email, "Sẵn sàng"
                    )
                except Exception as exc:  # noqa: BLE001
                    self.translation_profile_result.emit(
                        slot, False, "", self._public_message(str(exc))
                    )
            self.translation_profile_finished.emit()

        threading.Thread(
            target=worker, daemon=True, name="translation-profile-check"
        ).start()

    def _on_translation_profile_result(
        self, slot: int, ok: bool, email: str, message: str
    ) -> None:
        config = self.app.config
        accounts = {
            int(item.get("slot", 0)): dict(item)
            for item in (getattr(config, "translation_accounts", []) or [])
            if str(item.get("slot", "")).isdigit()
        }
        current = accounts.get(slot, {})
        if email:
            current["email"] = email
        duplicate_slot = next(
            (
                other_slot
                for other_slot, item in accounts.items()
                if other_slot != slot
                and email
                and str(item.get("email", "")).strip().casefold()
                == email.strip().casefold()
            ),
            0,
        )
        effective_ok = ok and not duplicate_slot
        current.update({
            "slot": slot,
            "profile_name": f"translation_{slot}",
            "status": (
                "duplicate" if duplicate_slot
                else ("ready" if ok else "error")
            ),
            "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        accounts[slot] = current
        config.translation_accounts = [
            accounts[index] for index in sorted(accounts)
        ]
        config.save()
        shown_email = str(current.get("email", "")).strip()
        self.translation_status_labels[slot - 1].setText(
            f"✅ {shown_email or 'Đã kết nối'}"
            if effective_ok else
            (
                f"⚠️ {shown_email} — trùng phiên {duplicate_slot}"
                if duplicate_slot else
                f"⚠️ {shown_email or 'Cần đăng nhập lại'}"
            )
        )
        detail = (
            f"Trùng tài khoản với phiên {duplicate_slot}; phiên này sẽ không được dùng."
            if duplicate_slot else message
        )
        self.translation_status_labels[slot - 1].setToolTip(detail)
        self.app.show_status(
            f"Phiên {slot}"
            + (f" · {shown_email}" if shown_email else "")
            + (
                ": sẵn sàng." if effective_ok
                else (
                    f": trùng tài khoản với phiên {duplicate_slot}."
                    if duplicate_slot else f": lỗi — {message}"
                )
            )
        )

    def _on_translation_profile_finished(self) -> None:
        self._translation_profile_busy = False
        self._set_translation_profile_buttons(True)

    def _set_drive_account_buttons(self, enabled: bool) -> None:
        for button in (
            *self.drive_account_buttons,
            *self.drive_account_check_buttons,
            *self.drive_account_choose_buttons,
            self.btn_drive_test,
        ):
            button.setEnabled(enabled)

    def _drive_account_for_slot(self, slot: int) -> dict:
        expected = Path(
            self.app.config.drive_account_token_path(slot)
        ).resolve()
        for raw in self.app.config.drive_ocr_accounts or []:
            try:
                if Path(str(raw.get("token_path", ""))).resolve() == expected:
                    return dict(raw)
            except (OSError, RuntimeError, TypeError):
                continue
        return {}

    def _run_drive_account_jobs(
        self, slots: list[int], interactive: bool = False
    ) -> None:
        """Kiểm tra tuần tự; đăng nhập tương tác chỉ áp dụng cho đúng một slot."""
        if self._drive_account_busy:
            self.app.show_status("Đang xử lý một tài khoản khác; vui lòng chờ.")
            return
        self._drive_account_busy = True
        self._set_drive_account_buttons(False)
        config = self.app.config

        def worker() -> None:
            from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
                DriveOcrClient, authorize,
            )

            total = len(slots)
            for position, slot in enumerate(slots, 1):
                creds = config.drive_account_credentials_path(slot)
                token_path = config.drive_account_token_path(slot)
                action = "đăng nhập" if interactive else "kiểm tra"
                self.drive_account_progress.emit(
                    f"Tài khoản {slot} ({position}/{total}): đang {action}..."
                )
                email = ""
                try:
                    if not Path(creds).exists():
                        raise RuntimeError("Chưa có file kết nối.")
                    if interactive:
                        authorize(creds, token_path)
                    elif not Path(token_path).exists():
                        raise RuntimeError("Chưa đăng nhập.")
                    client = DriveOcrClient(creds, token_path)
                    try:
                        email = client.account_email()
                    finally:
                        client.close()
                    self.drive_account_result.emit(
                        slot, True, email, "Sẵn sàng"
                    )
                except Exception as exc:  # noqa: BLE001
                    self.drive_account_result.emit(
                        slot, False, email, self._public_message(str(exc))
                    )
                if position < total:
                    # Không dội bốn lần refresh token cùng lúc trên mạng yếu.
                    time.sleep(0.35)
            self.drive_account_finished.emit()

        threading.Thread(
            target=worker,
            daemon=True,
            name="drive-account-login" if interactive else "drive-account-check",
        ).start()

    def _check_drive_account(self, slot: int) -> None:
        self._run_drive_account_jobs([slot], interactive=False)

    def _check_all_drive_accounts(self) -> None:
        self._run_drive_account_jobs([1, 2, 3, 4], interactive=False)

    def _on_drive_account_result(
        self, slot: int, ok: bool, email: str, message: str
    ) -> None:
        config = self.app.config
        token_path = config.drive_account_token_path(slot)
        credentials_path = config.drive_account_credentials_path(slot)
        expected_token = Path(token_path).resolve()
        accounts = [
            dict(item) for item in (config.drive_ocr_accounts or [])
            if not item.get("token_path")
            or Path(str(item.get("token_path", ""))).resolve() != expected_token
        ]
        current = self._drive_account_for_slot(slot)
        if email:
            current["email"] = email
        duplicate = next(
            (
                item for item in accounts
                if email
                and str(item.get("email", "")).strip().casefold()
                == email.strip().casefold()
            ),
            None,
        )
        duplicate_name = str((duplicate or {}).get("name", "")).strip()
        current.update({
            "name": f"Tài khoản {slot}",
            "credentials_path": credentials_path,
            "token_path": token_path,
            "folder_id": str(current.get("folder_id", "")),
            "enabled": True,
            "status": (
                "duplicate" if ok and duplicate
                else ("ready" if ok else "error")
            ),
            "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "last_error": "" if ok else message,
        })
        accounts.append(current)
        accounts.sort(
            key=lambda item: int(
                re.search(r"account_(\d+)", str(item.get("token_path", ""))).group(1)
            ) if re.search(
                r"account_(\d+)", str(item.get("token_path", ""))
            ) else 99
        )
        config.drive_ocr_accounts = accounts
        config.save()
        shown = str(current.get("email", "")).strip()
        self.app.show_status(
            f"Tài khoản {slot}"
            + (f" · {shown}" if shown else "")
            + (
                f": trùng với {duplicate_name}; sẽ không được dùng."
                if ok and duplicate else
                (": sẵn sàng." if ok else f": lỗi — {message}")
            )
        )
        self.refresh()

    def _on_drive_account_finished(self) -> None:
        self._drive_account_busy = False
        self._set_drive_account_buttons(True)

    def _browse_drive_creds(self, slot: int) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, f"Chọn file kết nối cho tài khoản {slot}", "", "Tệp kết nối (*.json)"
        )
        if path:
            destination = self.app.config.drive_account_credentials_path(slot)
            try:
                Path(destination).parent.mkdir(parents=True, exist_ok=True)
                if Path(path).resolve() != Path(destination).resolve():
                    shutil.copyfile(path, destination)
                self.drive_account_paths[slot - 1].setText(destination)
                self.app.show_status(f"Đã chọn file kết nối cho tài khoản {slot}.")
            except OSError as exc:
                self.warn(f"Không lưu được file kết nối cho tài khoản {slot}: {exc}")

    def _login_drive_ocr(self, slot: int = 1, button: QPushButton | None = None) -> None:
        """Kết nối đúng một tài khoản; không mở nhiều luồng đăng nhập cùng lúc."""
        config = self.app.config
        creds = config.drive_account_credentials_path(slot)
        if not Path(creds).exists():
            self._browse_drive_creds(slot)
        if not Path(creds).exists():
            self.warn(f"Chưa chọn file kết nối cho tài khoản {slot}.")
            return
        self._run_drive_account_jobs([slot], interactive=True)

    def _test_drive_ocr(self) -> None:
        """Kiểm tra tài khoản nhận diện phụ đề."""
        config = self.app.config
        creds = config.resolve_drive_credentials()
        accounts = config.enabled_drive_accounts()
        if not creds and not any(a.get("credentials_path") for a in accounts):
            self.warn("Chưa có file kết nối. Kết nối tài khoản xử lý trước.")
            return
        if not accounts:
            self.warn("Chưa đăng nhập tài khoản xử lý. Bấm kết nối tài khoản trước.")
            return
        self.btn_drive_test.setEnabled(False)
        run_drive_ocr_selftest(
            self, config, on_done=lambda: self.btn_drive_test.setEnabled(True)
        )

    def _preview_settings_voice(self) -> None:
        voice = self.settings_voice_combo.currentText()
        if not voice:
            return
        text = self.settings_sample_input.text().strip() or "Xin chào."
        config = self.app.config

        def worker() -> None:
            try:
                engine = create_engine(config)
                out = preview_wav_path(config.data_dir, "settings", voice)
                engine.synthesize(text, voice, 1.0, out)
                self.app.play_audio(out)
                self.app.show_status(f"Đang phát giọng '{voice}'.")
            except Exception as exc:  # noqa: BLE001
                self.app.show_status(f"Nghe thử lỗi: {exc}")

        threading.Thread(target=worker, daemon=True).start()
        self.app.show_status(f"Đang sinh giọng thử '{voice}'...")
    def _add_key_row(self) -> None:
        row = self.api_table.rowCount()
        self.api_table.insertRow(row)
        defaults = (f"Dịch vụ {row + 1}", "", DEFAULT_GEMINI_MODEL, "15", "1", "1")
        for col, value in enumerate(defaults):
            self.api_table.setItem(row, col, QTableWidgetItem(value))
        self._set_key_editor(row, "")

    def _delete_key_row(self) -> None:
        row = self.api_table.currentRow()
        if row >= 0:
            self.api_table.removeRow(row)

    def _set_key_editor(self, row: int, key: str) -> None:
        editor = QLineEdit()
        editor.setText(key)
        editor.setEchoMode(QLineEdit.EchoMode.Password)
        editor.setPlaceholderText("Nhập khóa truy cập...")
        editor.setClearButtonEnabled(True)
        self.api_table.setCellWidget(row, 1, editor)

    # ---------- Pool key nhận diện lời thoại (Qwen3-ASR) ----------

    def _add_asr_key_row(self, name: str = "", key: str = "",
                         enabled: bool = True, status: str = "—") -> None:
        from vicdub.utils.secret_store import unprotect_secret  # noqa: PLC0415
        row = self.asr_table.rowCount()
        self.asr_table.insertRow(row)
        self.asr_table.setItem(row, 0, QTableWidgetItem(name or f"Key {row + 1}"))
        editor = QLineEdit()
        editor.setEchoMode(QLineEdit.EchoMode.Password)
        editor.setPlaceholderText("Dán API key Model Studio...")
        editor.setClearButtonEnabled(True)
        editor.setText(unprotect_secret(key) if key else "")
        self.asr_table.setCellWidget(row, 1, editor)
        st = QTableWidgetItem(status)
        st.setFlags(st.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.asr_table.setItem(row, 2, st)
        self.asr_table.setItem(row, 3, QTableWidgetItem("1" if enabled else "0"))

    def _delete_asr_key_row(self) -> None:
        row = self.asr_table.currentRow()
        if row >= 0:
            self.asr_table.removeRow(row)

    def _load_asr_accounts(self, config) -> None:
        self.asr_table.setRowCount(0)
        for acc in getattr(config, "asr_accounts", []) or []:
            self._add_asr_key_row(
                acc.get("name", ""), acc.get("key", ""),
                acc.get("enabled", True), "—",
            )
        if self.asr_table.rowCount() == 0:
            self._add_asr_key_row()

    def _collect_asr_accounts(self) -> list:
        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
        accounts = []
        for row in range(self.asr_table.rowCount()):
            editor = self.asr_table.cellWidget(row, 1)
            key = editor.text().strip() if isinstance(editor, QLineEdit) else ""
            if not key:
                continue
            name_item = self.asr_table.item(row, 0)
            en_item = self.asr_table.item(row, 3)
            accounts.append({
                "name": (name_item.text().strip() if name_item else "") or f"Key {row + 1}",
                "key": protect_secret(key),
                "enabled": (en_item.text().strip() if en_item else "1") != "0",
            })
        return accounts

    def _check_asr_keys_legacy(self) -> None:
        """Kiểm tra sống/die từng key (chạy nền, cập nhật cột Trạng thái)."""
        import threading  # noqa: PLC0415

        from vicdub.api.qwen_asr_client import check_key  # noqa: PLC0415
        rows = []
        for row in range(self.asr_table.rowCount()):
            editor = self.asr_table.cellWidget(row, 1)
            key = editor.text().strip() if isinstance(editor, QLineEdit) else ""
            rows.append((row, key))
            item = self.asr_table.item(row, 2)
            if item:
                item.setText("đang kiểm tra..." if key else "—")
        self.btn_check_asr.setEnabled(False)

        bridge = _AsrKeyCheckBridge()
        self._asr_key_check_bridge = bridge

        def apply_results(results) -> None:
            for row, (ok, msg) in results:
                item = self.asr_table.item(row, 2)
                if item:
                    item.setText(("âœ… " if ok else "âŒ ") + msg)
            self.btn_check_asr.setEnabled(True)

        bridge.done.connect(apply_results)

        def apply_results_safe(results) -> None:
            for row, (ok, msg) in results:
                item = self.asr_table.item(row, 2)
                if item:
                    item.setText(("\u2705 " if ok else "\u274c ") + msg)
            self.btn_check_asr.setEnabled(True)

        try:
            bridge.done.disconnect(apply_results)
        except TypeError:
            pass
        bridge.done.connect(apply_results_safe)

        def worker() -> None:
            results = [(row, check_key(key) if key else (False, "trống")) for row, key in rows]

            def apply() -> None:
                for row, (ok, msg) in results:
                    item = self.asr_table.item(row, 2)
                    if item:
                        item.setText(("✅ " if ok else "❌ ") + msg)
                self.btn_check_asr.setEnabled(True)

            bridge.done.emit(results)

        threading.Thread(target=worker, daemon=True).start()

    def _check_asr_keys(self) -> None:
        """Kiểm tra ASR key trong thread nền, cập nhật UI qua Qt signal."""
        import threading  # noqa: PLC0415

        from vicdub.api.qwen_asr_client import check_key  # noqa: PLC0415

        rows = []
        for row in range(self.asr_table.rowCount()):
            editor = self.asr_table.cellWidget(row, 1)
            key = editor.text().strip() if isinstance(editor, QLineEdit) else ""
            rows.append((row, key))
            item = self.asr_table.item(row, 2)
            if item:
                item.setText("đang kiểm tra..." if key else "—")

        self.btn_check_asr.setEnabled(False)
        bridge = _AsrKeyCheckBridge()
        self._asr_key_check_bridge = bridge

        def apply_results(results) -> None:
            for row, (ok, msg) in results:
                item = self.asr_table.item(row, 2)
                if item:
                    item.setText(("\u2705 " if ok else "\u274c ") + msg)
            self.btn_check_asr.setEnabled(True)

        bridge.done.connect(apply_results)

        def worker() -> None:
            results = [
                (row, check_key(key) if key else (False, "trống"))
                for row, key in rows
            ]
            bridge.done.emit(results)

        threading.Thread(target=worker, daemon=True, name="asr-key-check").start()

    def _test_remote_ocr(self) -> None:
        """Lưu tạm thông tin trên form rồi kiểm tra health + heartbeat ở thread nền."""
        url = self.remote_ocr_url.text().strip().rstrip("/")
        entered_key = self.remote_ocr_api_key.text().strip()
        if not url:
            self.warn("Chưa nhập địa chỉ máy chủ nhận diện.")
            return
        if not entered_key and not getattr(self.app.config, "remote_ocr_api_key", ""):
            self.warn("Chưa nhập khóa truy cập máy chủ nhận diện.")
            return
        from copy import copy  # noqa: PLC0415
        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415

        config = copy(self.app.config)
        config.remote_ocr_url = url
        config.remote_ocr_client_id = self.remote_ocr_client_id.text().strip()
        config.remote_ocr_timeout = self.remote_ocr_timeout.value()
        config.remote_ocr_batch = self.remote_ocr_batch.value()
        config.remote_ocr_parallel = self.remote_ocr_parallel.value()
        if entered_key:
            config.remote_ocr_api_key = protect_secret(entered_key)

        bridge = _DriveSelfTestBridge(self)
        self._remote_ocr_test_bridge = bridge
        bridge.progress.connect(self.app.show_status)

        def finished(message: str) -> None:
            self.btn_remote_ocr_test.setEnabled(True)
            self.app.show_status(message)

        bridge.done.connect(finished)
        self.btn_remote_ocr_test.setEnabled(False)
        bridge.progress.emit("Đang kiểm tra máy chủ nhận diện...")

        def worker() -> None:
            try:
                from vicdub.api.remote_ocr_client import RemoteOcrClient  # noqa: PLC0415
                client = RemoteOcrClient(config)
                try:
                    result = client.check_connection()
                finally:
                    client.close()
                bridge.done.emit("Kết nối thành công")
            except Exception as exc:  # noqa: BLE001
                bridge.done.emit(f"Kết nối máy chủ lỗi: {self._public_message(str(exc))}")

        threading.Thread(target=worker, daemon=True, name="remote-ocr-check").start()

    def _test_vision_ocr(self) -> None:
        import threading  # noqa: PLC0415

        key = self.vision_api_key.text().strip()
        if not key:
            self.warn("Chưa nhập khóa tăng tốc.")
            return

        bridge = _DriveSelfTestBridge()          # cùng cầu nối thread-safe
        self._vision_selftest_bridge = bridge

        def on_done_msg(msg: str) -> None:
            self.app.show_status(msg.split(chr(10))[0])
            (self.info if msg.startswith("✅") else self.warn)(msg)
            self.btn_vision_test.setEnabled(True)

        bridge.progress.connect(self.app.show_status)
        bridge.done.connect(on_done_msg)
        self.btn_vision_test.setEnabled(False)
        self.app.show_status("Kiểm tra tăng tốc: chuẩn bị ảnh mẫu...")

        def worker() -> None:
            try:
                from vicdub.api.vision_ocr_client import self_test  # noqa: PLC0415
                good, total, texts = self_test(key, report=bridge.progress.emit)
            except Exception as exc:  # noqa: BLE001 - mọi lỗi phải hiện lên UI
                bridge.done.emit(f"❌ Kiểm tra tăng tốc lỗi: {self._public_message(str(exc))}")
                return
            icon = "✅" if good == total else "⚠️"
            bridge.done.emit(
                f"{icon} Bộ tăng tốc đọc đúng {good}/{total} câu mẫu.\n"
                + "\n".join(f"  {index + 1}. {text or '(rỗng)'}"
                            for index, text in enumerate(texts))
            )

        threading.Thread(target=worker, daemon=True).start()

    def _save(self) -> None:
        c = self.app.config
        c.ffmpeg_path = self.ffmpeg_input.text().strip() or "ffmpeg"
        c.ffprobe_path = self.ffprobe_input.text().strip() or "ffprobe"
        c.tts_device = self.tts_device.currentText()
        c.tts_num_step = self.tts_num_step.value()
        c.tts_batch_size = self.tts_batch_size.value()
        self._apply_voice_settings()
        dv = self.default_voice.currentText().strip()
        c.default_voice = "" if dv == self.DEFAULT_VOICE_BY_GENDER else dv
        c.subtitle_source = "drive"
        c.ocr_lang = self.ocr_lang.currentText().strip() or "ch"
        c.ocr_fps = self.ocr_fps.value()
        c.ocr_min_confidence = self.ocr_min_conf.value()
        c.llm_ocr_fps = self.llm_ocr_fps.value()
        c.ocr_scan_mode = "standard" if c.llm_ocr_fps >= 25.0 else "fast"
        c.llm_ocr_batch = self.llm_ocr_batch.value()
        c.llm_ocr_lang_hint = self.llm_ocr_lang_hint.text().strip()
        c.vision_api_key = self.vision_api_key.text().strip()
        c.remote_ocr_url = self.remote_ocr_url.text().strip().rstrip("/")
        c.remote_ocr_client_id = self.remote_ocr_client_id.text().strip()
        c.remote_ocr_timeout = self.remote_ocr_timeout.value()
        c.remote_ocr_batch = self.remote_ocr_batch.value()
        c.remote_ocr_parallel = self.remote_ocr_parallel.value()
        remote_key = self.remote_ocr_api_key.text().strip()
        if remote_key:
            from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
            c.remote_ocr_api_key = protect_secret(remote_key)
            self.remote_ocr_api_key.clear()
            self.remote_ocr_api_key.setPlaceholderText("Khóa đã lưu an toàn — nhập mới để thay")
        # Nhận diện lời thoại (Qwen3-ASR): pool key, mã hoá DPAPI theo user Windows.
        c.asr_accounts = self._collect_asr_accounts()
        c.asr_provider = "whisper_server"
        c.whisper_api_base_url = (
            self.whisper_api_base_url.text().strip() or "http://47.84.113.154:8001"
        )
        whisper_key = self.whisper_api_key.text().strip()
        if whisper_key:
            from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
            c.whisper_api_key = protect_secret(whisper_key)
        c.asr_lang = self.asr_lang.currentText().strip() or "zh"
        c.asr_glossary = self.asr_glossary.text().strip()
        c.translation_source = self.translation_source.currentData() or "web"
        qwen_key = self.translation_qwen_key.text().strip()
        if qwen_key:
            from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
            c.translation_qwen_api_key = protect_secret(qwen_key)
            self.translation_qwen_key.clear()
            self.translation_qwen_key.setPlaceholderText("Khóa dịch nhanh đã lưu an toàn — nhập mới để thay")
        elif (
            getattr(c, "translation_qwen_api_key", "")
            and not str(c.translation_qwen_api_key).startswith(("dpapi:", "base64:"))
        ):
            from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
            c.translation_qwen_api_key = protect_secret(c.translation_qwen_api_key)
        c.translation_qwen_base_url = (
            self.translation_qwen_base_url.text().strip()
            or "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
        )
        c.translation_qwen_model = self.translation_qwen_model.text().strip() or "qwen-plus"
        c.translation_web_profiles = int(self.translation_profile_count.currentData() or 1)
        c.translation_api_fallback = self.translation_api_fallback.isChecked()
        c.translate_batch_size = self.batch_size.value()
        c.speed_min = self.speed_min.value()
        c.speed_max = self.speed_max.value()
        c.sub_max_chars = self.sub_max_chars.value()
        c.sub_max_duration = self.sub_max_duration.value()
        c.sub_split_gap = self.sub_split_gap.value()
        c.api_pool_strategy = self.strategy.currentText()

        keys = []
        for row in range(self.api_table.rowCount()):
            def cell(col: int) -> str:
                widget = self.api_table.cellWidget(row, col)
                if isinstance(widget, QLineEdit):
                    return widget.text().strip()
                item = self.api_table.item(row, col)
                return item.text().strip() if item else ""
            if not cell(1):
                continue  # bỏ dòng không có key
            try:
                keys.append(ApiKey(
                    name=cell(0) or f"Dịch vụ {row + 1}",
                    key=cell(1),
                    model=cell(2) or DEFAULT_GEMINI_MODEL,
                    rpm=int(cell(3) or 15),
                    priority=int(cell(4) or 1),
                    enabled=cell(5) != "0",
                ).to_dict())
            except ValueError:
                self.warn(f"Dòng {row + 1}: RPM/Priority phải là số.")
                return
        c.api_keys = keys
        c.save()
        self.app.reload_api_manager()
        self.info("Đã lưu cài đặt.")
        self.app.update_right_panel()


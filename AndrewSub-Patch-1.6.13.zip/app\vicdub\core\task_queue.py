"""Task Queue chạy trên worker thread - không block giao diện.

Hỗ trợ: queue tuần tự, retry, pause, resume, cancel, báo tiến độ qua Qt signal.
"""

from __future__ import annotations

import logging
import threading
import traceback
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from vicdub.core.module_base import ModuleCancelled

logger = logging.getLogger(__name__)


class TaskState(Enum):
    PENDING = "Chờ xử lý"
    RUNNING = "Đang chạy"
    DONE = "Hoàn tất"
    FAILED = "Lỗi"
    CANCELLED = "Đã hủy"


@dataclass
class Task:
    """Một đơn vị công việc trong hàng đợi."""

    name: str
    func: Callable[..., Any]           # Hàm thực thi, nhận progress_cb + cancel_event
    max_retry: int = 1
    state: TaskState = TaskState.PENDING
    progress: int = 0
    message: str = ""
    result: Any = None
    error: str = ""
    attempts: int = field(default=0)


class _Worker(QThread):
    """Thread chạy tuần tự các task trong queue."""

    task_started = pyqtSignal(str)
    task_progress = pyqtSignal(str, int, str)   # tên, %, mô tả
    task_finished = pyqtSignal(str, object)     # tên, kết quả
    task_failed = pyqtSignal(str, str)          # tên, lỗi
    queue_finished = pyqtSignal(bool)           # True nếu tất cả thành công

    def __init__(self, tasks: list[Task], pause_event: threading.Event,
                 cancel_event: threading.Event) -> None:
        super().__init__()
        self._tasks = tasks
        self._pause = pause_event
        self._cancel = cancel_event

    def run(self) -> None:  # noqa: D102 - QThread entry
        all_ok = True
        for task in self._tasks:
            # Chờ nếu đang pause (resume bằng cách set lại event).
            while not self._pause.is_set() and not self._cancel.is_set():
                self.msleep(100)

            if self._cancel.is_set():
                task.state = TaskState.CANCELLED
                all_ok = False
                continue

            task.state = TaskState.RUNNING
            self.task_started.emit(task.name)

            def progress_cb(pct: int, msg: str, _task: Task = task) -> None:
                _task.progress = pct
                _task.message = msg
                self.task_progress.emit(_task.name, pct, msg)
                # Điểm pause giữa task: chờ tại đây luôn.
                while not self._pause.is_set() and not self._cancel.is_set():
                    self.msleep(100)

            success = False
            while task.attempts < task.max_retry and not success:
                task.attempts += 1
                try:
                    task.result = task.func(progress_cb, self._cancel)
                    success = True
                except ModuleCancelled:
                    task.state = TaskState.CANCELLED
                    all_ok = False
                    break
                except Exception as exc:  # noqa: BLE001 - báo mọi lỗi lên UI
                    if self._cancel.is_set():
                        task.state = TaskState.CANCELLED
                        all_ok = False
                        break
                    task.error = str(exc)
                    logger.error("Task '%s' lỗi (lần %d/%d): %s\n%s",
                                 task.name, task.attempts, task.max_retry,
                                 exc, traceback.format_exc())

            if success:
                task.state = TaskState.DONE
                task.progress = 100
                self.task_finished.emit(task.name, task.result)
            elif task.state != TaskState.CANCELLED:
                task.state = TaskState.FAILED
                all_ok = False
                self.task_failed.emit(task.name, task.error)
                break  # Pipeline tuần tự: bước sau phụ thuộc bước trước.

        self.queue_finished.emit(all_ok)


class TaskQueue(QObject):
    """Quản lý hàng đợi task, phát tín hiệu Qt cho UI."""

    task_started = pyqtSignal(str)
    task_progress = pyqtSignal(str, int, str)
    task_finished = pyqtSignal(str, object)
    task_failed = pyqtSignal(str, str)
    queue_finished = pyqtSignal(bool)

    def __init__(self) -> None:
        super().__init__()
        self._worker: _Worker | None = None
        self._pause = threading.Event()
        self._cancel = threading.Event()
        self.tasks: list[Task] = []

    # ---------- Điều khiển ----------

    def start(self, tasks: list[Task]) -> None:
        """Chạy danh sách task trên worker thread."""
        if self.is_running():
            raise RuntimeError("Hàng đợi đang chạy")
        self.tasks = tasks
        self._pause.set()      # set = đang chạy, clear = pause
        self._cancel.clear()
        self._worker = _Worker(tasks, self._pause, self._cancel)
        for signal in ("task_started", "task_progress", "task_finished",
                       "task_failed", "queue_finished"):
            getattr(self._worker, signal).connect(getattr(self, signal))
        self._worker.start()

    def pause(self) -> None:
        self._pause.clear()

    def resume(self) -> None:
        self._pause.set()

    def cancel(self) -> None:
        self._cancel.set()
        self._pause.set()  # thoát vòng chờ pause để kết thúc

    def is_running(self) -> bool:
        return self._worker is not None and self._worker.isRunning()

    def is_paused(self) -> bool:
        return self.is_running() and not self._pause.is_set()

"""Client nhận diện lời thoại cho máy chủ Whisper riêng.

Audio được chia khối liên tục trên máy người dùng, gửi tuần tự vì máy chủ chỉ có
một GPU worker. Các đoạn trả về được ráp lại theo offset và lọc theo vùng sở hữu
của từng khối để không lặp ở phần overlap.
"""

from __future__ import annotations

import json
import re
import subprocess
import threading
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable

import requests
import numpy as np

from vicdub.core.module_base import ModuleError
from vicdub.utils.secret_store import unprotect_secret
from vicdub.utils.segmenter import Word


class WhisperAsrError(ModuleError):
    pass


@dataclass
class WhisperTranscript:
    words: list[Word]
    speech_spans: list[tuple[float, float]]
    segment_spans: list[tuple[float, float]] = field(default_factory=list)


def _headers(config) -> dict[str, str]:
    key = unprotect_secret(getattr(config, "whisper_api_key", "") or "").strip()
    if not key:
        raise WhisperAsrError("Chưa nhập khóa truy cập máy chủ tách âm.")
    return {"X-API-Key": key, "Accept": "application/json"}


def _base_url(config) -> str:
    url = str(getattr(config, "whisper_api_base_url", "") or "").strip().rstrip("/")
    if not url:
        raise WhisperAsrError("Chưa nhập địa chỉ máy chủ tách âm.")
    return url


# Whisper (cổng 8001) và OmniVoice (cổng 8000) chạy TRÊN CÙNG MỘT máy chủ GPU tự
# tắt khi rảnh để tiết kiệm chi phí. voice_api.py đã có cơ chế "wake" (đánh thức
# qua Function Compute) cho OmniVoice; ở đây thiếu hẳn nên khi máy đang tắt,
# request tới /transcribe treo tới connect timeout (300s) rồi báo "Gửi âm thanh
# tới máy chủ thất bại: ConnectTimeoutError" - dùng LẠI đúng cấu hình
# voice_api_wake_* (cùng máy, cùng Function Compute) thay vì thêm field mới.
_wake_lock = threading.Lock()
_ready_until: dict[str, float] = {}


def _health_ready(base: str, headers: dict[str, str], timeout: float) -> bool:
    try:
        response = requests.get(f"{base}/health", headers=headers, timeout=timeout)
    except requests.RequestException:
        return False
    if not response.ok:
        return False
    try:
        body = response.json()
    except ValueError:
        return True
    return str(body.get("status", "ok")).lower() in {"ok", "ready", "running", "healthy"}


def _ensure_server_ready(config, base: str, headers: dict[str, str]) -> None:
    if not bool(getattr(config, "voice_api_wake_enabled", False)):
        return
    if time.monotonic() < _ready_until.get(base, 0.0):
        return
    with _wake_lock:
        if time.monotonic() < _ready_until.get(base, 0.0):
            return
        if _health_ready(base, headers, timeout=5):
            _ready_until[base] = time.monotonic() + 30.0
            return
        wake_url = str(getattr(config, "voice_api_wake_url", "") or "").strip()
        if not wake_url:
            raise WhisperAsrError(
                "Đã bật tự khởi động máy chủ nhưng chưa nhập địa chỉ khởi động."
            )
        wake_token = unprotect_secret(
            getattr(config, "voice_api_wake_token", "") or ""
        ).strip()
        wake_headers = {"Accept": "application/json"}
        if wake_token:
            wake_headers["Authorization"] = f"Bearer {wake_token}"
        try:
            response = requests.post(
                wake_url, headers=wake_headers, json={"service": "whisper"}, timeout=15,
            )
        except requests.RequestException as exc:
            raise WhisperAsrError(f"Không gọi được dịch vụ khởi động máy chủ: {exc}") from exc
        if not response.ok:
            raise WhisperAsrError(
                f"Dịch vụ khởi động máy chủ từ chối yêu cầu (HTTP {response.status_code})."
            )
        wake_timeout = max(30, int(getattr(config, "voice_api_wake_timeout", 180) or 180))
        poll = max(1.0, float(getattr(config, "voice_api_wake_poll_seconds", 2.0) or 2.0))
        deadline = time.monotonic() + wake_timeout
        while time.monotonic() < deadline:
            if _health_ready(base, headers, timeout=5):
                _ready_until[base] = time.monotonic() + 30.0
                return
            time.sleep(poll)
        raise WhisperAsrError(f"Máy chủ tách âm chưa sẵn sàng sau {wake_timeout} giây.")


def check_server(config) -> str:
    base = _base_url(config)
    headers = _headers(config)
    _ensure_server_ready(config, base, headers)
    try:
        response = requests.get(
            f"{base}/health",
            headers=headers,
            timeout=max(10, int(getattr(config, "whisper_api_timeout", 180))),
        )
    except requests.RequestException as exc:
        raise WhisperAsrError(f"Không kết nối được máy chủ tách âm: {exc}") from exc
    if response.status_code in {401, 403}:
        raise WhisperAsrError(
            "Máy chủ tách âm từ chối khóa truy cập. Đây là khóa Whisper cổng 8001, "
            "không dùng khóa tạo giọng cổng 8000 hoặc khóa Qwen."
        )
    if not response.ok:
        raise WhisperAsrError(f"Máy chủ tách âm trả lỗi HTTP {response.status_code}.")
    body = response.json()
    return f"Kết nối OK — {body.get('model', 'Whisper')}, {body.get('device', 'server')}"


def _extract_wav(video_path: str, ffmpeg: str, target: Path) -> None:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        [ffmpeg, "-y", "-loglevel", "error", "-i", video_path,
         "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(target)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags,
        timeout=21600, check=False,
    )
    if result.returncode:
        detail = result.stderr.decode("utf-8", errors="replace")[-500:]
        raise WhisperAsrError(f"Không trích được âm thanh từ video: {detail}")


def _write_chunk(source: wave.Wave_read, path: Path, start_frame: int, end_frame: int) -> None:
    source.setpos(start_frame)
    frames = source.readframes(max(0, end_frame - start_frame))
    with wave.open(str(path), "wb") as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(16000)
        out.writeframes(frames)


def _write_pcm(path: Path, pcm: np.ndarray) -> None:
    samples = np.clip(pcm * 32767.0, -32768, 32767).astype("<i2")
    with wave.open(str(path), "wb") as out:
        out.setnchannels(1); out.setsampwidth(2); out.setframerate(16000)
        out.writeframes(samples.tobytes())


def _wave_speech_spans(
    source: wave.Wave_read,
    *,
    frame_ms: int = 20,
    min_pause: float = 0.24,
    max_span: float = 12.0,
) -> list[tuple[float, float]]:
    """Find natural speech turns from the waveform before uploading audio."""
    sample_rate = source.getframerate()
    frame_size = max(1, round(sample_rate * frame_ms / 1000))
    total_frames = source.getnframes()
    source.rewind()
    rms_values: list[float] = []
    peak_values: list[float] = []
    while source.tell() < total_frames:
        raw = source.readframes(min(frame_size, total_frames - source.tell()))
        if not raw:
            break
        pcm = np.frombuffer(raw, dtype="<i2").astype("float32") / 32768.0
        rms_values.append(float(np.sqrt(np.mean(np.square(pcm, dtype="float64")))))
        peak_values.append(float(np.max(np.abs(pcm))) if len(pcm) else 0.0)
    source.rewind()
    if not rms_values:
        return []

    rms = np.asarray(rms_values, dtype="float32")
    peaks = np.asarray(peak_values, dtype="float32")
    noise_floor = float(np.percentile(rms, 20))
    low_level = float(np.percentile(rms, 45))
    threshold = max(0.0012, min(0.030, noise_floor * 2.8, low_level * 1.25))
    active = (rms >= threshold) | (peaks >= max(0.009, threshold * 3.2))

    # Bridge brief holes, but preserve a real pause as a hard cue boundary.
    pause_frames = max(1, round(min_pause * 1000 / frame_ms))
    index = 0
    while index < len(active):
        if active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and not active[end]:
            end += 1
        if index > 0 and end < len(active) and end - index < pause_frames:
            active[index:end] = True
        index = end

    # Remove clicks shorter than 60 ms. Genuine one-word replies remain.
    min_voice_frames = max(1, round(0.06 * 1000 / frame_ms))
    index = 0
    while index < len(active):
        if not active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and active[end]:
            end += 1
        if end - index < min_voice_frames:
            active[index:end] = False
        index = end

    frame_s = frame_size / sample_rate
    total_s = total_frames / sample_rate
    raw_spans: list[tuple[float, float]] = []
    index = 0
    while index < len(active):
        if not active[index]:
            index += 1
            continue
        end = index
        while end < len(active) and active[end]:
            end += 1
        raw_spans.append((index * frame_s, min(total_s, end * frame_s)))
        index = end

    spans: list[tuple[float, float]] = []
    for start, end in raw_spans:
        cursor = start
        while end - cursor > max_span:
            lo = min(len(rms) - 1, max(0, round((cursor + 4.0) / frame_s)))
            hi = min(len(rms), max(lo + 1, round((cursor + max_span) / frame_s)))
            cut_index = lo + int(np.argmin(rms[lo:hi]))
            cut = max(cursor + 4.0, min(end, cut_index * frame_s))
            spans.append((max(0.0, cursor), min(total_s, cut)))
            cursor = cut
        if end - cursor >= 0.06:
            spans.append((max(0.0, cursor), min(total_s, end)))

    voiced = sum(end - start for start, end in spans)
    if not spans or voiced < total_s * 0.01 or voiced > total_s * 0.98:
        return []
    return spans


def _pack_upload_spans(
    spans: list[tuple[float, float]],
    *,
    max_turns: int = 15,
    max_seconds: float = 60.0,
) -> list[tuple[float, float]]:
    """Pack a few detected turns per request while retaining every hard boundary."""
    packed: list[tuple[float, float]] = []
    current: list[tuple[float, float]] = []
    for span in spans:
        candidate_start = current[0][0] if current else span[0]
        candidate_end = span[1]
        if current and (
            len(current) >= max_turns
            or candidate_end - candidate_start > max_seconds
        ):
            packed.append((current[0][0], current[-1][1]))
            current = []
        current.append(span)
    if current:
        packed.append((current[0][0], current[-1][1]))
    return packed


def _align_spans_to_word_gaps(
    words: list[Word],
    spans: list[tuple[float, float]],
    *,
    tolerance: float = 1.20,
) -> list[tuple[float, float]]:
    """Snap waveform cuts to real ASR word gaps; discard cuts inside words."""
    ordered = sorted(words, key=lambda word: (word.start, word.end))
    if len(ordered) < 2 or len(spans) < 2:
        return spans
    word_gaps: list[float] = []
    for left, right in zip(ordered, ordered[1:]):
        gap = right.start - left.end
        # Detailed Whisper timestamps are commonly contiguous (gap == 0).
        # They are still a safe boundary between tokens; only reject a heavy
        # overlap which means two competing hypotheses occupy the same slot.
        if gap >= -0.05:
            word_gaps.append((left.end + right.start) / 2.0)
    if not word_gaps:
        return [(min(spans[0][0], ordered[0].start),
                 max(spans[-1][1], ordered[-1].end))]

    cuts: list[float] = []
    for left, right in zip(spans, spans[1:]):
        proposed = (left[1] + right[0]) / 2.0
        nearest = min(word_gaps, key=lambda value: abs(value - proposed))
        if abs(nearest - proposed) <= tolerance:
            if not cuts or nearest - cuts[-1] >= 0.06:
                cuts.append(nearest)
    start = min(spans[0][0], ordered[0].start)
    finish = max(spans[-1][1], ordered[-1].end)
    points = [start, *cuts, finish]
    return [
        (left, right) for left, right in zip(points, points[1:])
        if right - left >= 0.06
    ]


def _detect_speech_spans(
    video_path: str,
    ffmpeg: str,
    total_s: float,
    noise_db: int = -30,
    min_silence: float = 0.25,
    target_spans: int | None = None,
) -> list[tuple[float, float]]:
    """Lấy biên lượt nói cho Whisper khi server chỉ trả timestamp theo cả cụm."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        [
            ffmpeg, "-hide_banner", "-i", video_path,
            "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}",
            "-f", "null", "-",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=flags,
        timeout=21600,
        check=False,
    )
    detail = result.stderr.decode("utf-8", errors="replace")
    starts = [float(value) for value in re.findall(
        r"silence_start:\s*([0-9.]+)", detail
    )]
    ends = [float(value) for value in re.findall(
        r"silence_end:\s*([0-9.]+)", detail
    )]
    silences = list(zip(starts, ends))
    if target_spans and len(silences) > max(1, target_spans - 1):
        # Nhạc nền làm ngưỡng dB cố định thất bại giữa các video. Giữ các
        # khoảng lặng dài/rõ nhất đủ cho số lượt thoại ước lượng từ lượng chữ,
        # thay vì dùng cùng một ngưỡng cứng cho mọi nguồn âm thanh.
        wanted = max(1, int(target_spans) - 1)
        silences = sorted(
            sorted(silences, key=lambda item: item[1] - item[0], reverse=True)[:wanted]
        )
    spans: list[tuple[float, float]] = []
    cursor = 0.0
    pad = 0.02
    for start, end in silences:
        if start - cursor >= 0.10:
            spans.append((max(0.0, cursor - pad), min(total_s, start + pad)))
        cursor = max(cursor, end)
    if total_s - cursor >= 0.10:
        spans.append((max(0.0, cursor - pad), total_s))
    return spans


def _read_pcm(source: wave.Wave_read, start_s: float, end_s: float) -> np.ndarray:
    start = max(0, round(start_s * 16000))
    end = min(source.getnframes(), round(end_s * 16000))
    source.setpos(start)
    raw = source.readframes(max(0, end - start))
    return np.frombuffer(raw, dtype="<i2").astype("float32") / 32768.0


def _request_result(
    path: Path, base: str, headers: dict[str, str], language: str, timeout: int,
) -> dict:
    try:
        with path.open("rb") as stream:
            response = requests.post(
                f"{base}/transcribe", headers=headers,
                files={"file": (path.name, stream, "audio/wav")},
                data={
                    "language": language,
                    "task": "transcribe",
                    "word_timestamps": "true",
                },
                timeout=timeout,
            )
    except requests.RequestException as exc:
        raise WhisperAsrError(f"Gửi âm thanh tới máy chủ thất bại: {exc}") from exc
    if response.status_code in {401, 403}:
        raise WhisperAsrError(
            "Máy chủ tách âm từ chối khóa truy cập. Đây là khóa Whisper cổng 8001, "
            "không dùng khóa tạo giọng cổng 8000 hoặc khóa Qwen."
        )
    if not response.ok:
        raise WhisperAsrError(
            f"Máy chủ tách âm trả HTTP {response.status_code}: {response.text[:300]}"
        )
    try:
        body = response.json()
        if not isinstance(body, dict):
            raise TypeError("response is not an object")
        return body
    except (json.JSONDecodeError, AttributeError, TypeError) as exc:
        raise WhisperAsrError("Máy chủ tách âm trả dữ liệu không hợp lệ.") from exc


def _number(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _row_confidence(row: dict) -> float:
    """Chuẩn hóa confidence/probability/logprob của nhiều bản server."""
    for key in ("probability", "confidence", "prob"):
        if key in row:
            return max(0.0, min(1.0, _number(row.get(key), 0.0)))
    logprob = row.get("avg_logprob", row.get("logprob"))
    if logprob is not None:
        return max(0.0, min(1.0, float(np.exp(_number(logprob, -20.0)))))
    return 0.0


def _response_words(body: dict, offset: float, source: str) -> list[Word]:
    """Ưu tiên timestamp từng từ; tương thích response chỉ có segments."""
    segments = list(body.get("segments") or [])
    top_words = list(body.get("words") or [])
    rows: list[dict] = []
    if top_words:
        rows = top_words
    elif any(isinstance(seg, dict) and seg.get("words") for seg in segments):
        for seg in segments:
            if isinstance(seg, dict):
                rows.extend(list(seg.get("words") or []))
    else:
        rows = [seg for seg in segments if isinstance(seg, dict)]

    out: list[Word] = []
    for row in rows:
        text = str(row.get("word", row.get("text", "")) or "").strip()
        if not text:
            continue
        begin = offset + max(0.0, _number(row.get("start"), 0.0))
        finish = offset + max(0.0, _number(row.get("end"), 0.0))
        out.append(Word(
            text=text,
            start=begin,
            end=max(begin + 0.04, finish),
            confidence=_row_confidence(row),
            source=source,
        ))
    return out


def _response_spans(body: dict, key: str, offset: float) -> list[tuple[float, float]]:
    """Read VAD/Whisper segment spans and remap them to the video timeline."""
    rows = body.get(key) or []
    out: list[tuple[float, float]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        start = offset + max(0.0, _number(row.get("start"), 0.0))
        end = offset + max(0.0, _number(row.get("end"), 0.0))
        if end > start + 0.02:
            out.append((start, end))
    return out


def _owned_spans(
    spans: list[tuple[float, float]], core_start: float, core_end: float, final: bool,
) -> list[tuple[float, float]]:
    """Assign overlap spans to exactly one upload chunk by midpoint."""
    out: list[tuple[float, float]] = []
    for start, end in spans:
        midpoint = (start + end) / 2.0
        if midpoint < core_start or (midpoint >= core_end and not final):
            continue
        out.append((start, end))
    return out


def _norm_candidate(text: str) -> str:
    return re.sub(r"[^\w\u3400-\u9fff]+", "", text or "").casefold()


def _overlap_ratio(left: Word, right: Word) -> float:
    overlap = max(0.0, min(left.end, right.end) - max(left.start, right.start))
    span = max(0.04, min(left.end - left.start, right.end - right.start))
    return overlap / span


def _candidate_score(word: Word) -> tuple[float, int, float]:
    return (
        float(getattr(word, "confidence", 0.0) or 0.0),
        len(_norm_candidate(word.text)),
        max(0.0, word.end - word.start),
    )


def _reconcile_candidates(words: list[Word]) -> list[Word]:
    """Không giữ hai giả thuyết ASR cạnh tranh trong cùng một ô thời gian."""
    accepted: list[Word] = []
    for candidate in sorted(words, key=lambda w: (w.start, w.end, -len(w.text))):
        resolved = False
        for index in range(max(0, len(accepted) - 4), len(accepted)):
            previous = accepted[index]
            left = _norm_candidate(previous.text)
            right = _norm_candidate(candidate.text)
            ratio = _overlap_ratio(previous, candidate)
            same_slot = (
                abs(previous.start - candidate.start) <= 0.08
                and abs(previous.end - candidate.end) <= 0.08
            )
            same_text = bool(left and right and left == right)
            contains = bool(left and right and (left in right or right in left))
            if same_text and ratio >= 0.45:
                winner = max((previous, candidate), key=_candidate_score)
                winner.start = min(previous.start, candidate.start)
                winner.end = max(previous.end, candidate.end)
                accepted[index] = winner
                resolved = True
                break
            if ratio >= 0.80 and contains:
                accepted[index] = max((previous, candidate), key=_candidate_score)
                resolved = True
                break
            if same_slot and left != right:
                winner = max((previous, candidate), key=_candidate_score)
                winner.warning = (
                    "ASR: nhiều giả thuyết cùng thời gian, đã chọn bản tin cậy hơn"
                )
                accepted[index] = winner
                resolved = True
                break
        if not resolved:
            accepted.append(candidate)
    return sorted(accepted, key=lambda w: (w.start, w.end))


def _is_single_cjk(text: str) -> bool:
    compact = _norm_candidate(text)
    return len(compact) == 1 and "\u3400" <= compact <= "\u9fff"


def _stitch_cjk_fragments(words: list[Word], max_gap: float = 0.45) -> list[Word]:
    """Ghép chữ Hán bị vỡ nếu tuần tự và không vượt dấu kết câu."""
    out: list[Word] = []
    for word in sorted(words, key=lambda w: (w.start, w.end)):
        if out:
            previous = out[-1]
            gap = word.start - previous.end
            terminal = previous.text.rstrip().endswith(("。", "！", "？", "!", "?", "…"))
            if (
                -0.04 <= gap <= max_gap and not terminal
                and _is_single_cjk(previous.text) and _is_single_cjk(word.text)
                and _overlap_ratio(previous, word) < 0.50
            ):
                previous.text = previous.text.rstrip("，, ") + word.text
                previous.end = max(previous.end, word.end)
                if previous.confidence > 0 and word.confidence > 0:
                    previous.confidence = min(previous.confidence, word.confidence)
                else:
                    previous.confidence = max(previous.confidence, word.confidence)
                if word.warning and word.warning not in previous.warning:
                    previous.warning = "; ".join(filter(None, (previous.warning, word.warning)))
                continue
        out.append(word)
    return out


def _mark_repeated_hallucinations(words: list[Word]) -> list[Word]:
    """Đánh dấu chuỗi lặp máy móc; không xóa vì hội thoại có thể lặp thật."""
    start = 0
    while start < len(words):
        norm = _norm_candidate(words[start].text)
        end = start + 1
        while end < len(words):
            gap = words[end].start - words[end - 1].end
            if _norm_candidate(words[end].text) != norm or gap > 0.20:
                break
            end += 1
        if norm and end - start >= 3:
            warning = "ASR: cụm lặp liên tục bất thường, cần nghe lại"
            for index in range(start, end):
                if warning not in words[index].warning:
                    words[index].warning = "; ".join(
                        filter(None, (words[index].warning, warning))
                    )
        start = end
    return words


def _clean_timeline(words: list[Word], *, stitch_fragments: bool = True) -> list[Word]:
    cleaned = _reconcile_candidates(words)
    if stitch_fragments:
        cleaned = _stitch_cjk_fragments(cleaned)
    return _mark_repeated_hallucinations(cleaned)


def _retry_regions(
    source: wave.Wave_read, words: list[Word], total_s: float, ratio: float,
) -> list[tuple[float, float]]:
    """Chọn vùng có năng lượng nhưng không có chữ, giới hạn theo tỷ lệ video."""
    limit = total_s * max(0.0, min(0.20, ratio))
    if limit < 0.25:
        return []
    ordered = sorted(words, key=lambda word: word.start)
    gaps: list[tuple[float, float]] = []
    cursor = 0.0
    for word in ordered:
        if word.start - cursor >= 0.25:
            gaps.append((cursor, word.start))
        cursor = max(cursor, word.end)
    if total_s - cursor >= 0.25:
        gaps.append((cursor, total_s))

    candidates: list[tuple[float, float, float]] = []
    for gap_start, gap_end in gaps:
        window_start = gap_start
        while gap_end - window_start >= 0.25:
            # Cửa sổ 2 giây giúp ngân sách nhỏ vẫn cắt đúng vùng có năng lượng;
            # cửa sổ 6 giây có thể bị crop từ đầu và bỏ mất tiếng nằm cuối vùng.
            window_end = min(gap_end, window_start + 2.0)
            start = max(0.0, window_start - 0.35)
            end = min(total_s, window_end + 0.35)
            pcm = _read_pcm(source, start, end)
            if len(pcm):
                rms = float(np.sqrt(np.mean(np.square(pcm, dtype="float64"))))
                peak = float(np.max(np.abs(pcm)))
                # Giữ được thoại nhỏ nhưng loại khoảng im lặng số tuyệt đối.
                if rms >= 0.0015 or peak >= 0.010:
                    candidates.append((rms * 20.0 + peak * 2.0, start, end))
            window_start = window_end

    selected: list[tuple[float, float]] = []
    used = 0.0
    for _score, start, end in sorted(candidates, reverse=True):
        remaining = limit - used
        if remaining < 0.25:
            break
        if end - start > remaining:
            end = start + remaining
        selected.append((start, end))
        used += end - start
    return sorted(selected)


def transcribe_video(
    video_path: str,
    config,
    report: Callable[[int, str], None] = lambda _p, _m: None,
    is_cancelled: Callable[[], bool] = lambda: False,
    _vad_sink: list[tuple[float, float]] | None = None,
    _segment_sink: list[tuple[float, float]] | None = None,
) -> list[Word]:
    base = _base_url(config)
    headers = _headers(config)
    report(1, "Đang kiểm tra máy chủ nhận diện...")
    _ensure_server_ready(config, base, headers)
    ffmpeg = str(getattr(config, "ffmpeg_path", "") or "ffmpeg")
    language = str(getattr(config, "asr_lang", "") or "").strip()
    timeout = max(30, int(getattr(config, "whisper_api_timeout", 180)))
    chunk_s = max(30.0, min(300.0, float(getattr(config, "asr_chunk_seconds", 120.0))))
    overlap_s = max(0.0, min(3.0, float(getattr(config, "asr_chunk_overlap", 1.5))))

    with TemporaryDirectory(prefix="andrewsub_whisper_") as tmp:
        root = Path(tmp)
        full_wav = root / "audio.wav"
        report(2, "Đang chuẩn bị âm thanh cho máy chủ nhận diện...")
        _extract_wav(video_path, ffmpeg, full_wav)
        words: list[Word] = []
        with wave.open(str(full_wav), "rb") as source:
            total_frames = source.getnframes()
            total_s = total_frames / 16000.0
            cores = []
            start = 0.0
            while start < total_s:
                end = min(total_s, start + chunk_s)
                cores.append((start, end))
                start = end

            for index, (core_start, core_end) in enumerate(cores):
                if is_cancelled():
                    raise WhisperAsrError("Đã hủy tách âm.")
                # Audio extraction/wave analysis can outlive the server's idle
                # window. Re-check immediately before every upload so the first
                # request never targets a machine that went back to sleep.
                _ensure_server_ready(config, base, headers)
                audio_start = max(0.0, core_start - overlap_s)
                audio_end = min(total_s, core_end + overlap_s)
                chunk = root / f"chunk_{index:04d}.wav"
                _write_chunk(source, chunk, round(audio_start * 16000), round(audio_end * 16000))
                report(
                    5 + int(90 * index / max(1, len(cores))),
                    f"Tách âm {index + 1}/{len(cores)} bằng máy chủ riêng...",
                )
                body = _request_result(chunk, base, headers, language, timeout)
                final = index == len(cores) - 1
                if _vad_sink is not None:
                    _vad_sink.extend(_owned_spans(
                        _response_spans(body, "vad_spans", audio_start),
                        core_start, core_end, final,
                    ))
                if _segment_sink is not None:
                    _segment_sink.extend(_owned_spans(
                        _response_spans(body, "segments", audio_start),
                        core_start, core_end, final,
                    ))
                chunk_words = _response_words(body, audio_start, f"main:{index}")
                for word in chunk_words:
                    midpoint = (word.start + word.end) / 2.0
                    if midpoint < core_start or (midpoint >= core_end and not final):
                        continue
                    words.append(word)

            words = _clean_timeline(words)

            if bool(getattr(config, "asr_retry_enabled", True)):
                ratio = float(getattr(config, "asr_retry_ratio", 0.15))
                regions = _retry_regions(source, words, total_s, ratio)
                if regions:
                    from vicdub.api.qwen_asr_client import (  # noqa: PLC0415
                        _normalize_retry_pcm,
                    )
                    retry_words: list[Word] = []
                    gain = float(getattr(config, "asr_retry_gain_db", 6.0))
                    report(96, f"Pass phụ: kiểm tra {len(regions)} vùng nói nhỏ/thiếu chữ...")
                    for index, (start, end) in enumerate(regions):
                        if is_cancelled():
                            raise WhisperAsrError("Đã hủy tách âm.")
                        _ensure_server_ready(config, base, headers)
                        pcm = _normalize_retry_pcm(_read_pcm(source, start, end), gain)
                        chunk = root / f"retry_{index:04d}.wav"
                        _write_pcm(chunk, pcm)
                        body = _request_result(chunk, base, headers, language, timeout)
                        retry_words.extend(
                            _response_words(body, start, f"retry:{index}")
                        )
                        report(
                            96 + int(3 * (index + 1) / len(regions)),
                            f"Pass phụ {index + 1}/{len(regions)} — đã bổ sung "
                            f"{len(retry_words)} đoạn nghi ngờ",
                        )
                    # Đưa cả hai pass vào cùng lattice. _clean_timeline sẽ chọn
                    # bằng confidence/timestamp; không âm thầm bỏ giả thuyết
                    # pass phụ chỉ vì nó trùng thời gian với pass chính.
                    words = _clean_timeline(words + retry_words)
        report(99, f"Máy chủ nhận diện xong {len(words)} đoạn lời thoại sau hai pass.")
        return sorted(words, key=lambda word: (word.start, word.end))


def transcribe_video_with_spans(
    video_path: str,
    config,
    report: Callable[[int, str], None] = lambda _p, _m: None,
    is_cancelled: Callable[[], bool] = lambda: False,
) -> WhisperTranscript:
    """Nhận diện và bổ sung biên lời nói cục bộ cho response Whisper thô."""
    server_vad_spans: list[tuple[float, float]] = []
    server_segment_spans: list[tuple[float, float]] = []
    words = transcribe_video(
        video_path, config, report, is_cancelled,
        _vad_sink=server_vad_spans,
        _segment_sink=server_segment_spans,
    )
    if not words:
        return WhisperTranscript(words=[], speech_spans=[])
    if server_vad_spans:
        report(
            99,
            f"Máy chủ trả {len(server_vad_spans)} lượt nói Silero; đang căn biên câu.",
        )
        return WhisperTranscript(
            words=words,
            speech_spans=sorted(server_vad_spans),
            segment_spans=sorted(server_segment_spans),
        )
    compact_lengths = [
        len(re.sub(r"[^\w\u3400-\u9fff]+", "", word.text or ""))
        for word in words
    ]
    detailed_ratio = (
        sum(0 < length <= 2 for length in compact_lengths)
        / max(1, len(compact_lengths))
    )
    if len(words) >= 8 and detailed_ratio >= 0.80:
        # Server mới đã trả timestamp thật từng từ/ký tự. Không chạy VAD cục
        # bộ và không phân bố chữ ước lượng đè lên dữ liệu chính xác này.
        report(99, "Đã nhận timestamp chi tiết từng từ từ máy chủ.")
        return WhisperTranscript(words=words, speech_spans=[])
    ffmpeg = str(getattr(config, "ffmpeg_path", "") or "ffmpeg")
    configured_db = int(getattr(config, "asr_silence_db", -30) or -30)
    compact_chars = sum(
        len(re.sub(r"[^\w\u3400-\u9fff]+", "", word.text or ""))
        for word in words
    )
    target_spans = max(len(words), round(compact_chars / 5.0))
    target_spans = min(max(1, target_spans), max(len(words), len(words) * 3))
    # Pass riêng cho Whisper dùng ngưỡng dò rộng, sau đó chỉ giữ các khoảng
    # nghỉ rõ nhất theo target. Cách này thích nghi với cả audio sạch lẫn nhạc
    # nền dày mà không thay cấu hình Qwen/API khác.
    noise_db = max(-24, configured_db)
    min_silence = 0.10
    report(99, "Đang căn lại ranh giới câu theo khoảng nghỉ giọng nói...")
    spans = _detect_speech_spans(
        video_path, ffmpeg, max(word.end for word in words) + 0.10,
        noise_db=noise_db, min_silence=min_silence,
        target_spans=target_spans,
    )
    return WhisperTranscript(words=words, speech_spans=spans)

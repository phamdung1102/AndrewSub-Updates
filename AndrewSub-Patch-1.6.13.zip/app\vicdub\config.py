﻿"""Cấu hình toàn cục của ứng dụng.

Mọi cấu hình lưu ở data/settings.json - không hardcode trong code nghiệp vụ.
"""

from __future__ import annotations

import json
import logging
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

def _app_root() -> Path:
    """Thư mục gốc của app khi chạy source hoặc exe đã đóng gói."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


APP_ROOT = _app_root()


@dataclass
class AppConfig:
    """Cấu hình ứng dụng, tự nạp/lưu JSON."""

    # Đường dẫn công cụ
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"

    # TTS: OmniVoice (k2-fsa) chạy ngay trong app - pip install omnivoice.
    tts_device: str = "auto"   # auto | cuda | cpu
    tts_num_step: int = 16     # bước diffusion (16 = nhanh, 32 = nét hơn)
    tts_batch_size: int = 8    # số câu sinh cùng lúc một lô (nhanh hơn nhiều)
    # Giọng mặc định cho MỌI dòng chưa gán giọng riêng (nhân vật/dòng).
    # Rỗng = dùng giọng mặc định của engine; đặt 1 preset để cả video dùng chung một giọng.
    default_voice: str = ""
    # Giọng theo giới tính cho dòng chưa gán voice riêng. Nếu để trống sẽ rơi
    # về default_voice rồi mới tới giọng mặc định của engine.
    default_male_voice: str = ""
    default_female_voice: str = ""
    use_gender_voices: bool = False
    # Nguồn giọng: local | api. API hỗ trợ OpenAI-compatible, ElevenLabs,
    # VietAuto và REST tùy chỉnh; catalog giọng được cache trong data/voice_catalog.json.
    tts_provider: str = "local"
    voice_api_type: str = "openai"  # openai | elevenlabs | vietauto | omnivoice_server | custom
    voice_api_key: str = ""          # DPAPI, gắn với user Windows
    voice_api_base_url: str = "https://api.openai.com/v1"
    voice_api_model: str = "gpt-4o-mini-tts"
    voice_api_project_id: str = ""
    voice_api_voices_url: str = ""
    voice_api_synthesis_url: str = ""
    voice_api_auth_header: str = "Authorization"
    voice_api_auth_prefix: str = "Bearer"
    voice_api_timeout: int = 90
    voice_api_retry: int = 3
    voice_api_concurrency: int = 4     # số lô voice API chạy song song
    voice_api_batch_size: int = 5      # mỗi lô API gom khoảng 4-5 câu để quản lý tiến độ
    voice_catalog_auto_sync_hours: int = 24
    voice_api_omnivoice_mode: str = "auto"  # auto | design | clone
    voice_api_omnivoice_instruct: str = ""
    voice_api_omnivoice_ref_audio: str = ""
    voice_api_omnivoice_ref_text: str = ""
    voice_api_omnivoice_key: str = ""  # DPAPI, độc lập với API voice khác
    voice_api_omnivoice_base_url: str = "http://47.84.113.154:8000"
    voice_api_omnivoice_voices_url: str = "http://47.84.113.154:8000/voices"
    voice_api_omnivoice_synthesis_url: str = "http://47.84.113.154:8000/tts"
    voice_api_wake_enabled: bool = False
    voice_api_wake_url: str = ""
    voice_api_wake_token: str = ""  # DPAPI, token của dịch vụ đánh thức
    voice_api_wake_timeout: int = 180
    voice_api_wake_poll_seconds: float = 2.0

    # Preset quy trình hàng loạt ở tab Dự án. Dict để bổ sung lựa chọn mới mà
    # không làm hỏng settings cũ; UI luôn trộn với bộ mặc định trước khi dùng.
    batch_workflow_plan: dict = field(default_factory=dict)

    # OCR tách sub gắn cứng (hard sub) - dùng cho phim đã burn phụ đề sẵn.
    # Nguồn tách sub chính: Google Drive OCR với pool tài khoản 1-4.
    # Gemini Web chỉ là nguồn dự phòng khi người dùng chủ động chọn.
    subtitle_source: str = "drive"
    ocr_lang: str = "ch"           # ch = Trung+Anh; en, japan, korean...
    # Vùng phụ đề trên khung hình theo tỷ lệ (x0, y0, x1, y1). Mặc định dải đáy.
    ocr_region: list = field(default_factory=lambda: [0.05, 0.78, 0.95, 1.0])
    ocr_color_filter_enabled: bool = False
    ocr_picked_colors: list = field(default_factory=list)
    ocr_color_tolerance: int = 45
    ocr_fps: float = 4.0           # khung/giây lấy mẫu (cao = bắt sub nhanh tốt hơn, chậm hơn)
    ocr_min_confidence: float = 0.6  # bỏ dòng OCR tin cậy thấp hơn ngưỡng
    ocr_sim_threshold: float = 0.7   # độ giống để coi 2 khung là cùng một câu
    ocr_min_duration: float = 0.12   # giữ sub rất nhanh; thấp hơn dễ bắt flash subtitle
    # Khung gần y hệt khung vừa OCR (sai khác pixel trung bình <= ngưỡng) thì
    # tái dùng kết quả, không OCR lại - tăng tốc mạnh khi sub đứng yên nhiều
    # khung. Nhỏ hơn = nhạy hơn (OCR nhiều hơn, an toàn hơn).
    ocr_dedup_threshold: float = 0.015

    # LLM-OCR: đọc phụ đề gắn cứng bằng Gemini vision - hợp khi font khó.
    # Gemini Web là nguồn OCR AI duy nhất; không dùng API key để gửi ảnh.
    llm_ocr_fps: float = 20.0       # 16 nhẹ | 20 ưu tiên không sót hội thoại nhanh
    llm_ocr_batch: int = 20        # Drive ổn định; lỗi marker sẽ tự chia 20 -> 10 -> 5
    llm_ocr_lang_hint: str = ""    # gợi ý ngôn ngữ chữ (vd "Trung"); rỗng = tự đoán
    gemini_web_login_timeout: int = 300
    gemini_web_response_timeout: int = 240
    gemini_web_profiles: int = 2    # số Chrome profile riêng chuẩn bị cho OCR Web song song

    # Drive OCR: tách sub gắn cứng bằng OCR chính thức của Google Drive (upload
    # montage -> convert Google Docs kèm ocrLanguage -> export text). Hợp ToS,
    # ổn định hơn Gemini Web. Chọn bằng subtitle_source = "drive".
    drive_ocr_credentials: str = ""   # đường dẫn credentials.json (OAuth Desktop)
    drive_ocr_token: str = ""         # đường dẫn token.json; rỗng = data/drive_ocr_token.json
    drive_ocr_folder_id: str = ""     # (tuỳ chọn) thư mục Drive chứa file OCR tạm

    # Vision OCR: Cloud Vision API. Nhanh hơn Drive nhiều (1 request = 16 ảnh
    # montage, thay vì 3 lần gọi/ảnh) và trả TOẠ ĐỘ PIXEL nên ánh xạ câu chính xác
    # tuyệt đối, khỏi marker "@@@". Auth chỉ cần API key. Có key -> tự ưu tiên dùng,
    # rỗng -> vẫn chạy Drive OCR như cũ.
    vision_api_key: str = ""
    # Máy chủ OCR dùng chung. Khóa được mã hóa bằng DPAPI khi lưu từ giao diện.
    remote_ocr_url: str = ""
    remote_ocr_api_key: str = ""
    remote_ocr_client_id: str = ""
    remote_ocr_timeout: int = 180
    remote_ocr_batch: int = 10
    remote_ocr_parallel: int = 5

    # Nhận diện lời thoại (Qwen3-ASR, Alibaba Model Studio) - dịch vụ CLOUD nhẹ,
    # KHÔNG cài model vào máy. Chọn bằng subtitle_source = "voice" (radio "Nhận
    # diện lời thoại"). Nhiều key -> pool song song + tự đổi key khi lỗi/limit.
    # Pool key: mỗi phần tử {name, key (DPAPI), enabled}. Nhiều key -> chạy
    # song song + tự đổi key khi lỗi/limit.
    asr_accounts: list = field(default_factory=list)
    asr_provider: str = "qwen"     # qwen | whisper_server
    whisper_api_base_url: str = "http://47.84.113.154:8001"
    # Khóa dịch vụ nhận diện riêng; khi lưu settings sẽ được chuyển sang DPAPI.
    whisper_api_key: str = "whisper_kien_2026_w7Q2r9"
    whisper_api_timeout: int = 300
    asr_lang: str = "zh"           # ngôn ngữ nguồn mặc định: zh (Trung), đổi được
    asr_glossary: str = ""         # (tuỳ chọn) file glossary sửa tên riêng đồng âm
    asr_max_chars: int = 16        # độ dài tối đa 1 dòng phụ đề gốc (CJK)
    # Chia dòng: cắt ở dấu phẩy khi cụm >= asr_soft_chars (nhỏ = chia nhiều hơn;
    # đặt 1 = cắt ở MỌI dấu phẩy). Khoảng lặng > asr_gap_split (giây) = tách lượt.
    asr_soft_chars: int = 7
    asr_gap_split: float = 0.55
    asr_max_duration: float = 5.0  # 1 cue tối đa bao nhiêu giây
    asr_mp3_kbps: int = 32         # nén audio gửi API (16k mono, 32 đủ cho ASR)
    asr_max_payload_mb: float = 8.0  # ngưỡng/khối -> tự chia khối cho video dài
    asr_chunk_seconds: float = 120.0  # pass chính: audio liên tục mỗi khối
    asr_chunk_overlap: float = 1.5    # ngữ cảnh hai đầu, không nhân đôi word
    asr_silence_db: int = -30      # ngưỡng dB coi là im lặng (VAD ffmpeg)
    asr_min_silence: float = 0.35  # im lặng ngắn hơn (giây) thì không cắt
    asr_retry_enabled: bool = True
    asr_retry_ratio: float = 0.15   # pass phụ chỉ gửi lại tối đa ~15% audio nghi ngờ
    asr_retry_gain_db: float = 6.0  # tăng nhẹ vùng nói nhỏ trước khi gửi ASR lại
    asr_min_word_duration: float = 0.04  # chặn timestamp từ đơn bằng 0 từ API
    asr_min_cue_duration: float = 0.35   # thời lượng hiển thị tối thiểu sau gom
    asr_tiny_cue_duration: float = 0.12  # mảnh timestamp đủ ngắn để xét gộp
    asr_tiny_merge_gap: float = 0.08     # chỉ gộp mảnh gần như liền nhau

    # VideoSubFinder: bộ phát hiện phụ đề chính xác (giống AIO). Có exe -> tự dùng
    # thay cho trích keyframe tự chế; timing tới ms, hết sót/lặp/lệch.
    vsf_path: str = ""                # đường dẫn VideoSubFinderWXW.exe; rỗng = tự tìm
    vsf_num_threads: int = 4
    vsf_use_cuda: bool = False
    # Pool tài khoản Drive OCR. Mỗi phần tử: {name, token_path, folder_id, enabled}.
    # Danh sách rỗng sẽ tự dùng cấu hình token/folder cũ để tương thích.
    drive_ocr_accounts: list = field(default_factory=list)

    # Dịch phụ đề: Web profile là nguồn chính; API có thể bật làm dự phòng.
    translation_source: str = "web"       # web | api | qwen
    translation_web_profiles: int = 2      # 1..4; các profile lấy lô động
    translation_api_fallback: bool = True
    translation_qwen_api_key: str = ""      # DPAPI, DashScope/Model Studio key
    translation_qwen_base_url: str = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
    translation_qwen_model: str = "qwen-plus"
    translation_qwen_timeout: int = 90
    translation_qwen_retry: int = 3
    translation_parallel: int = 4          # số lô dịch API chạy song song cho 1 video
    translation_chunk_chars: int = 3500    # chặn lô theo ký tự để tránh cắt output
    translation_chunk_lines: int = 450     # chặn lô theo dòng để khớp max_tokens
    translation_character_sheet: bool = True
    translation_mode: str = "balanced"       # fast | balanced | quality
    translation_genre: str = "neutral"
    translation_shorten_pass: bool = False # chỉ cảnh báo dòng dài, không tự rút gọn
    asr_gender_from_audio: bool = True
    # Nhãn/trạng thái không nhạy cảm để UI cho biết tài khoản dịch nào đang dùng.
    # Cookie đăng nhập vẫn chỉ nằm trong thư mục Chrome profile riêng.
    translation_accounts: list = field(default_factory=list)

    # Kênh cập nhật ứng dụng. Khi có URL manifest HTTPS, app kiểm tra nền lúc
    # khởi động và cho phép cài bản vá mà không đụng dữ liệu người dùng.
    update_manifest_url: str = (
        "https://raw.githubusercontent.com/phamdung1102/"
        "AndrewSub-Updates/refs/heads/main/update.json"
    )
    auto_check_updates: bool = True

    # Phiên bản cấu hình - tăng khi đổi bộ mặc định để tự migrate.
    config_version: int = 50

    # Tách sub theo chuẩn phụ đề phim (Netflix/BBC: ~42 ký tự, 1-5 giây,
    # mỗi sub một lượt thoại). Dựa word-level timestamp / sóng voice.
    sub_max_chars: int = 42        # số ký tự tối đa một sub
    sub_max_duration: float = 5.0  # thời lượng tối đa một sub (giây)
    sub_split_gap: float = 0.4     # khoảng lặng (giây) coi là hết lượt thoại
    sub_min_chars: int = 10        # sub ngắn hơn sẽ gộp vào sub bên cạnh
    sub_min_duration: float = 0.8  # thời lượng tối thiểu một sub (giây)
    sub_pad: float = 0.15          # đệm biên sub vào khoảng lặng (giây)

    # Ước tính lồng tiếng: tốc độ đọc TTS tiếng Việt (ký tự/giây).
    # Dùng để cảnh báo câu dịch dài đọc không kịp thời lượng clip.
    tts_chars_per_second: float = 15.0

    # Dịch
    # Rỗng ở lần đầu: người dùng phải chủ động chọn ngay trong hộp Dịch tự động.
    target_language: str = ""
    translate_batch_size: int = 30
    # conversational | concise | cinematic | faithful | custom
    translation_style: str = "conversational"
    translation_style_custom: str = ""
    # Gửi người nói/giới tính và quy tắc xưng hô nhất quán trong mọi lô dịch.
    translation_addressing_enabled: bool = True

    # Đồng bộ voice nhưng luôn giữ nguyên hình/timeline video.
    speed_min: float = 0.95   # chỉ giữ để tương thích dự án cũ
    speed_max: float = 1.50   # voice tăng tốc nhanh nhất (cap)
    merge_max_audio_shift: float = 0.75  # cho phép mượn khoảng trống trước/sau
    merge_accept_overlap: float = 0.12
    merge_warn_overlap: float = 0.25
    merge_min_gap: float = 0.03
    # Voice NGẮN hơn slot: giữ nguyên tốc độ, phần dư là khoảng lặng tự nhiên
    # (đã thử giãn chậm — nghe tệ, bỏ). Chỉ voice DÀI mới được tăng tốc nhẹ.
    merge_voice_speed_max: float = 1.50  # fallback; merge ưu tiên speed_max trên UI
    merge_video_stretch_enabled: bool = False  # legacy, runtime không kéo hình
    merge_video_speed_min: float = 0.92
    merge_video_hold_max: float = 0.40
    # auto: ưu tiên NVIDIA NVENC, lỗi tự rơi về CPU; fast/balanced/quality
    # là ba mức người dùng chọn trong tab Xuất video.
    render_profile: str = "auto"
    ffmpeg_timeout_seconds: int = 21600  # 6 giờ; tránh lệnh FFmpeg treo vô hạn
    subtitle_mode: str = "none"  # none | hard | soft
    subtitle_position: str = "bottom"  # bottom | center | top | custom
    subtitle_x: float = 0.5       # tâm chữ theo chiều ngang (0..1)
    subtitle_y: float = 0.90      # tâm chữ theo chiều dọc (0..1)
    subtitle_font_size: int = 24  # cỡ chữ phụ đề khi vẽ lên video (Fontsize)
    subtitle_font_name: str = "Arial"
    subtitle_text_color: str = "#FFFFFF"
    subtitle_bg_color: str = "#000000"
    subtitle_bg: bool = False     # True = nền hộp mờ sau chữ; False = chỉ viền
    subtitle_blur_original: bool = False  # làm mờ vùng hard-sub gốc trước khi chèn
    subtitle_blur_scale: int = 140  # độ phủ hộp blur theo kích thước chữ gốc (%)
    # Thư mục xuất Final.mp4 (rỗng = để trong projects/<tên>/output).
    export_dir: str = ""
    # Trộn âm: % âm nền video gốc (0 = tắt) và % âm lượng voice.
    bg_volume: int = 0
    voice_volume: int = 100

    # Thư mục dữ liệu
    data_dir: str = str(APP_ROOT / "data")
    projects_dir: str = str(APP_ROOT / "projects")
    log_dir: str = str(APP_ROOT / "logs")

    # API keys (danh sách dict, quản lý bởi ApiManager)
    api_keys: list = field(default_factory=list)
    api_pool_strategy: str = "priority"  # priority | round_robin | random | fastest

    # ---------- Nạp / lưu ----------

    @classmethod
    def settings_file(cls) -> Path:
        return APP_ROOT / "data" / "settings.json"

    @classmethod
    def load(cls) -> "AppConfig":
        """Nạp cấu hình từ file, thiếu trường nào dùng mặc định."""
        path = cls.settings_file()
        config = cls()
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                for key, value in raw.items():
                    if hasattr(config, key):
                        setattr(config, key, value)
                # Migrate: settings cũ (v1) mang bộ tách sub dài - reset về
                # chuẩn phụ đề phim mới rồi lưu lại.
                version = int(raw.get("config_version", 1))
                if version < 2:
                    defaults = cls()
                    for key in ("sub_max_chars", "sub_max_duration",
                                "sub_split_gap", "sub_min_chars",
                                "sub_min_duration", "sub_pad"):
                        setattr(config, key, getattr(defaults, key))
                    logger.info("Đã migrate cấu hình tách sub sang chuẩn phim (v2)")
                if version < 3:
                    config.tts_num_step = 16  # tăng tốc sinh voice
                    logger.info("Đã migrate TTS sang chế độ nhanh (v3)")
                if version < 4:
                    logger.info("Đã bổ sung cấu hình OCR tách sub gắn cứng (v4)")
                if version < 5:
                    # Cơ chế đồng bộ mới: video floor 0.95 + tăng tốc voice.
                    defaults = cls()
                    config.speed_min = defaults.speed_min
                    config.speed_max = defaults.speed_max
                    logger.info("Đã migrate đồng bộ voice/video sang cơ chế mới (v5)")
                if version < 6:
                    # OCR nhanh hơn và bớt bỏ qua nhầm khi sub đổi rất nhanh trên cùng nền.
                    defaults = cls()
                    config.ocr_fps = defaults.ocr_fps
                    config.ocr_min_duration = defaults.ocr_min_duration
                    config.ocr_dedup_threshold = defaults.ocr_dedup_threshold
                    logger.info("Đã migrate OCR sang chế độ bắt sub nhanh (v6)")
                if version < 7:
                    # Bổ sung nguồn tách sub LLM-OCR (Gemini vision).
                    logger.info("Đã bổ sung cấu hình LLM-OCR (Gemini vision) (v7)")
                if version < 8:
                    # Gemini Web là nguồn OCR AI ưu tiên; không ép đổi lựa chọn
                    # hiện có của người dùng khi migrate settings cũ.
                    logger.info("Đã bổ sung nguồn Gemini Web ưu tiên (v8)")
                    config.config_version = 8
                    config.save()
                if version < 9:
                    # Xóa nguồn OCR ảnh qua Gemini API; mọi cấu hình cũ dùng
                    # llm_ocr chuyển sang Gemini Web để không gọi nhầm API.
                    if config.subtitle_source == "llm_ocr":
                        config.subtitle_source = "gemini_web"
                    config.config_version = 9
                    logger.info("Đã chuyển OCR AI API sang Gemini Web (v9)")
                    config.save()
                if version < 10:
                    # Siết LLM-OCR Web để giảm số montage và tránh sát trần keyframe.
                    if float(getattr(config, "ocr_dedup_threshold", 0.006)) <= 0.006:
                        config.ocr_dedup_threshold = 0.015
                    if float(getattr(config, "llm_ocr_fps", 2.0)) >= 2.0:
                        config.llm_ocr_fps = 1.5
                    config.gemini_web_response_timeout = max(
                        int(getattr(config, "gemini_web_response_timeout", 180)), 240
                    )
                    config.config_version = 10
                    logger.info("Đã tối ưu LLM-OCR Web: dedup mạnh hơn, FPS thấp hơn (v10)")
                    config.save()
                if version < 11:
                    # Ưu tiên không bỏ sót hard-sub nhảy nhanh. Việc gộp sau OCR
                    # đã xét khoảng trống thời gian nên có thể lấy mẫu dày hơn.
                    if float(getattr(config, "llm_ocr_fps", 1.5)) <= 1.5:
                        config.llm_ocr_fps = 3.0
                    config.config_version = 11
                    logger.info("Đã migrate OCR Web sang chế độ ít bỏ sót sub nhanh (v11)")
                    config.save()
                if version < 12:
                    # Đối thoại nhanh cần bắt dày hơn; montage batching vẫn giữ
                    # số request thấp hơn nhiều so với OCR từng frame.
                    if float(getattr(config, "llm_ocr_fps", 3.0)) <= 3.0:
                        config.llm_ocr_fps = 4.0
                    config.config_version = 12
                    logger.info("Đã migrate OCR Web sang 4 fps cho hội thoại nhanh (v12)")
                    config.save()
                if version < 13:
                    # Sub flash/đối thoại rất nhanh có thể hiện dưới 250ms,
                    # nên 4 fps vẫn bỏ lọt giữa hai mẫu. 8 fps bắt mỗi 125ms.
                    if float(getattr(config, "llm_ocr_fps", 4.0)) <= 4.0:
                        config.llm_ocr_fps = 8.0
                    config.config_version = 13
                    logger.info("Đã migrate OCR Web sang 8 fps cho sub nhảy rất nhanh (v13)")
                    config.save()
                if version < 14:
                    # Phim dài cần giảm số lượt Gemini Web. 30 panel/montage
                    # giảm khoảng 40% request so với 18 mà vẫn chưa quá dài.
                    if int(getattr(config, "llm_ocr_batch", 18)) <= 18:
                        config.llm_ocr_batch = 30
                    config.config_version = 14
                    logger.info("Đã migrate OCR Web sang batch 30 cho phim dài (v14)")
                    config.save()
                if version < 15:
                    # Bỏ nguồn OCR local để giảm dependency trong bản đóng gói.
                    if getattr(config, "subtitle_source", "gemini_web") == "ocr":
                        config.subtitle_source = "gemini_web"
                    config.config_version = 15
                    logger.info("Đã bỏ nguồn OCR local; chuyển cấu hình cũ sang Gemini Web (v15)")
                    config.save()
                if version < 16:
                    # Bỏ offline speech recognition để giảm dung lượng.
                    config.subtitle_source = "gemini_web"
                    config.config_version = 16
                    logger.info("Đã bỏ nhận diện sub offline; nguồn tách sub chuyển sang Gemini Web (v16)")
                    config.save()
                if version < 17:
                    config.gemini_web_profiles = max(
                        2, int(getattr(config, "gemini_web_profiles", 1))
                    )
                    config.config_version = 17
                    logger.info("Đã bổ sung 2 profile Gemini Web riêng (v17)")
                    config.save()
                if version < 18:
                    # Bổ sung nguồn Drive OCR (OCR chính thức Google Drive).
                    config.config_version = 18
                    logger.info("Đã bổ sung nguồn Drive OCR (v18)")
                    config.save()
                if version < 19:
                    # Recall-first: 20 fps, không dùng temporal majority làm cổng
                    # loại vì hard-sub đối thoại có thể chỉ tồn tại 1-2 frame.
                    config.llm_ocr_fps = 20.0
                    config.config_version = 19
                    logger.info("Đã chuyển OCR sang quét recall-first 20 fps (v19)")
                    config.save()
                if version < 20:
                    # Không thay lựa chọn đã dùng; chỉ bỏ mặc định cứng cho cấu hình mới.
                    config.config_version = 20
                    logger.info("Đã bổ sung lựa chọn ngôn ngữ đích tại hộp dịch (v20)")
                    config.save()
                if version < 21:
                    # Vị trí tự do và làm mờ hard-sub gốc khi xuất video.
                    config.config_version = 21
                    logger.info("Đã bổ sung kéo thả phụ đề và làm mờ sub gốc (v21)")
                    config.save()
                if version < 22:
                    config.subtitle_blur_scale = max(
                        100, int(getattr(config, "subtitle_blur_scale", 140))
                    )
                    config.config_version = 22
                    logger.info("Đã bổ sung chỉnh độ phủ vùng làm mờ phụ đề (v22)")
                    config.save()
                if version < 23:
                    # Nhận diện video phải dùng pool Drive OCR 1-4. Trình duyệt
                    # chỉ dành cho nguồn dự phòng, không tự bật khi tách sub.
                    config.subtitle_source = "drive"
                    config.config_version = 23
                    logger.info("Đã chuyển nguồn nhận diện chính sang Drive OCR (v23)")
                    config.save()
                if version < 24:
                    # Cấu hình cũ đã lưu chuỗi rỗng nên sẽ che mất URL mặc định.
                    # Chỉ điền kênh chính thức khi người dùng chưa tự đặt kênh khác.
                    if not str(getattr(config, "update_manifest_url", "") or "").strip():
                        config.update_manifest_url = cls().update_manifest_url
                    config.config_version = 24
                    logger.info("Đã kết nối kênh cập nhật chính thức (v24)")
                    config.save()
                if version < 25:
                    # Montage 30 dễ rụng mốc trên Drive. Pool mới tự chia nhỏ khi
                    # lỗi và giữ checkpoint để thay tài khoản rồi tiếp tục.
                    if int(getattr(config, "llm_ocr_batch", 30)) > 20:
                        config.llm_ocr_batch = 20
                    config.config_version = 25
                    logger.info("Đã bật OCR tiếp tục theo checkpoint và batch thích ứng (v25)")
                    config.save()
                if version < 26:
                    config.config_version = 26
                    logger.info("Đã bổ sung nguồn API giọng nói mở rộng (v26)")
                    config.save()
                if version < 27:
                    config.render_profile = "auto"
                    config.merge_video_stretch_enabled = True
                    config.merge_video_speed_min = 0.92
                    config.merge_video_hold_max = 0.40
                    config.config_version = 27
                    logger.info("Đã bật render GPU tự động và pipeline xuất một lượt (v27)")
                    config.save()
                if version < 28:
                    # Giữ nguyên hình: voice tự dịch thời điểm, co tốc độ giữ cao
                    # độ và mix overlap. Chế độ nhanh ưu tiên NVENC preset thấp.
                    config.merge_video_stretch_enabled = False
                    config.merge_max_audio_shift = 0.75
                    config.merge_accept_overlap = 0.12
                    config.merge_voice_speed_max = max(
                        1.50, float(getattr(config, "speed_max", 1.50))
                    )
                    config.speed_max = max(
                        1.50, float(getattr(config, "speed_max", 1.50))
                    )
                    config.render_profile = "fast"
                    config.config_version = 28
                    logger.info("Đã chuyển sang đồng bộ voice linh hoạt, giữ nguyên hình (v28)")
                    config.save()
                if version < 29:
                    # URL /main của raw.githubusercontent.com có thể giữ cache
                    # manifest cũ. refs/heads/main cập nhật ổn định hơn.
                    config.update_manifest_url = cls().update_manifest_url
                    config.config_version = 29
                    logger.info("Đã chuyển sang kênh manifest chống cache (v29)")
                    config.save()
                if version < 30:
                    config.config_version = 30
                    logger.info("Đã bổ sung giọng nam/nữ và khóa xưng hô khi dịch (v30)")
                    config.save()
                if version < 31:
                    config.config_version = 31
                    logger.info("Đã bổ sung nguồn nhận diện lời thoại Qwen3-ASR (v31)")
                    config.save()
                if version < 32:
                    config.asr_min_silence = 0.35
                    config.asr_gap_split = min(float(getattr(config, "asr_gap_split", 0.35)), 0.35)
                    config.config_version = 32
                    logger.info("Đã chuyển tách lời thoại sang profile thoại nhanh (v32)")
                    config.save()
                if version < 33:
                    config.asr_retry_enabled = True
                    config.asr_retry_ratio = 0.15
                    config.asr_retry_gain_db = 6.0
                    config.config_version = 33
                    logger.info("Đã bật ASR pass phụ cho vùng thoại nghi ngờ (v33)")
                    config.save()
                if version < 34:
                    config.asr_min_word_duration = 0.04
                    config.asr_min_cue_duration = 0.35
                    config.asr_tiny_cue_duration = 0.12
                    config.asr_tiny_merge_gap = 0.08
                    config.config_version = 34
                    logger.info("Đã bật kiểm tra cuối timestamp và câu ASR (v34)")
                    config.save()
                if version < 35:
                    config.translation_qwen_base_url = (
                        getattr(config, "translation_qwen_base_url", "")
                        or cls().translation_qwen_base_url
                    )
                    config.translation_qwen_model = (
                        getattr(config, "translation_qwen_model", "")
                        or cls().translation_qwen_model
                    )
                    config.config_version = 35
                    logger.info("Đã bổ sung nguồn dịch Qwen API (v35)")
                    config.save()
                if version < 36:
                    config.translation_parallel = max(1, min(4, int(getattr(config, "translation_parallel", 4))))
                    config.translation_chunk_chars = int(getattr(config, "translation_chunk_chars", 3500) or 3500)
                    config.translation_chunk_lines = int(getattr(config, "translation_chunk_lines", 450) or 450)
                    config.translation_character_sheet = bool(getattr(config, "translation_character_sheet", True))
                    config.translation_shorten_pass = False
                    config.asr_gender_from_audio = bool(getattr(config, "asr_gender_from_audio", True))
                    config.config_version = 36
                    logger.info("Đã tối ưu nguồn dịch Qwen song song và chống lọt text gốc (v36)")
                    config.save()
                if version < 37:
                    if str(getattr(config, "voice_api_type", "openai") or "openai") not in {
                        "openai", "elevenlabs", "vietauto", "omnivoice_server", "custom"
                    }:
                        config.voice_api_type = "openai"
                    config.config_version = 37
                    logger.info("Đã bổ sung nền tảng VietAuto API cho giọng nói (v37)")
                    config.save()
                if version < 38:
                    if str(getattr(config, "voice_api_model", "") or "").strip() == "eleven_multilingual_v3":
                        config.voice_api_model = "eleven_v3"
                    config.config_version = 38
                    logger.info("Đã sửa model ElevenLabs v3 sang ID chính thức eleven_v3 (v38)")
                    config.save()
                if version < 39:
                    config.config_version = 39
                    logger.info("Đã bổ sung kết nối OmniVoice Server API (v39)")
                    config.save()
                if version < 40:
                    config.config_version = 40
                    logger.info("Đã bổ sung tự đánh thức máy chủ voice (v40)")
                    config.save()
                if version < 41:
                    if str(getattr(config, "voice_api_type", "")) == "omnivoice_server":
                        if not getattr(config, "voice_api_omnivoice_key", ""):
                            config.voice_api_omnivoice_key = getattr(config, "voice_api_key", "")
                        config.voice_api_omnivoice_base_url = (
                            getattr(config, "voice_api_base_url", "")
                            or config.voice_api_omnivoice_base_url
                        )
                        config.voice_api_omnivoice_voices_url = (
                            getattr(config, "voice_api_voices_url", "")
                            or config.voice_api_omnivoice_voices_url
                        )
                        config.voice_api_omnivoice_synthesis_url = (
                            getattr(config, "voice_api_synthesis_url", "")
                            or config.voice_api_omnivoice_synthesis_url
                        )
                    config.config_version = 41
                    logger.info("Đã tách cấu hình OmniVoice Server khỏi API voice khác (v41)")
                    config.save()
                if version < 42:
                    # Chỉ chuyển endpoint chính thức cũ; không ghi đè máy chủ riêng
                    # mà người dùng đã tự cấu hình.
                    old_host = "http://47.237.14.252:8000"
                    new_host = "http://43.98.167.97:8000"
                    for field_name, suffix in (
                        ("voice_api_omnivoice_base_url", ""),
                        ("voice_api_omnivoice_voices_url", "/voices"),
                        ("voice_api_omnivoice_synthesis_url", "/tts"),
                    ):
                        current = str(getattr(config, field_name, "") or "").rstrip("/")
                        if not current or current == (old_host + suffix).rstrip("/"):
                            setattr(config, field_name, new_host + suffix)
                    config.config_version = 42
                    logger.info("Đã chuyển máy chủ giọng riêng sang endpoint mới (v42)")
                    config.save()
                if version < 43:
                    config.asr_chunk_seconds = 120.0
                    config.asr_chunk_overlap = 1.5
                    config.asr_retry_enabled = True
                    config.asr_retry_ratio = max(
                        0.10, min(0.20, float(getattr(config, "asr_retry_ratio", 0.15)))
                    )
                    config.config_version = 43
                    logger.info("Đã chuyển ASR sang audio liên tục có overlap (v43)")
                    config.save()
                if version < 44:
                    config.asr_provider = str(getattr(config, "asr_provider", "qwen") or "qwen")
                    config.whisper_api_base_url = str(
                        getattr(config, "whisper_api_base_url", "")
                        or "http://43.98.167.97:8001"
                    )
                    config.whisper_api_timeout = max(
                        30, int(getattr(config, "whisper_api_timeout", 300) or 300)
                    )
                    old_update_url = (
                        "https://raw.githubusercontent.com/phamdung1102/"
                        "AndrewSub-Updates/refs/heads/main/update.json"
                    )
                    if str(getattr(config, "update_manifest_url", "") or "") == old_update_url:
                        config.update_manifest_url = (
                            "https://raw.githubusercontent.com/phamdung1102/"
                            "AndrewSub-Updates/main/update.json"
                        )
                    config.config_version = 44
                    logger.info("Đã bổ sung máy chủ riêng làm nguồn tách âm (v44)")
                    config.save()
                if version < 45:
                    # Endpoint chính thức dùng khóa riêng, tuyệt đối không dùng
                    # khóa TTS cổng 8000 hay khóa Qwen. Sửa luôn cấu hình thử
                    # nghiệm cũ để máy đã cài không tiếp tục gửi nhầm khóa.
                    official = "http://43.98.167.97:8001"
                    if str(getattr(config, "whisper_api_base_url", "") or "").rstrip("/") == official:
                        from vicdub.utils.secret_store import protect_secret  # noqa: PLC0415
                        config.whisper_api_key = protect_secret("whisper_kien_2026_w7Q2r9")
                    config.config_version = 45
                    logger.info("Đã tách khóa máy chủ nhận diện khỏi khóa tạo giọng (v45)")
                    config.save()
                if version < 46:
                    # Elastic IP chính thức: đổi cả cấu hình mặc định cũ nhưng
                    # không ghi đè máy chủ tùy chỉnh mà người dùng tự khai báo.
                    old_voice_hosts = {
                        "http://47.237.14.252:8000",
                        "http://43.98.167.97:8000",
                    }
                    new_voice_host = "http://47.84.113.154:8000"
                    for field_name, suffix in (
                        ("voice_api_omnivoice_base_url", ""),
                        ("voice_api_omnivoice_voices_url", "/voices"),
                        ("voice_api_omnivoice_synthesis_url", "/tts"),
                    ):
                        current = str(getattr(config, field_name, "") or "").rstrip("/")
                        legacy = {(host + suffix).rstrip("/") for host in old_voice_hosts}
                        if not current or current in legacy:
                            setattr(config, field_name, new_voice_host + suffix)
                    legacy_generic = str(
                        getattr(config, "voice_api_base_url", "") or ""
                    ).rstrip("/")
                    if legacy_generic in old_voice_hosts:
                        config.voice_api_base_url = new_voice_host
                    old_whisper_hosts = {
                        "http://43.98.167.97:8001",
                        "http://47.237.14.252:8001",
                    }
                    if str(
                        getattr(config, "whisper_api_base_url", "") or ""
                    ).rstrip("/") in old_whisper_hosts:
                        config.whisper_api_base_url = "http://47.84.113.154:8001"
                    # LƯU Ý: "vvxitzvqfm" không phải subdomain thật của Function Compute -
                    # gọi vào đó bị nền tảng trả InvalidArgument (subdomain invalid). Subdomain
                    # ĐÚNG và đang hoạt động là "xvxitzvqfm" (xác nhận qua console + test call
                    # trực tiếp trả 200). Xem migration v48 bên dưới để tự sửa các cấu hình đã
                    # bị đưa nhầm sang giá trị chết này.
                    current_wake = str(getattr(config, "voice_api_wake_url", "") or "").rstrip("/")
                    if current_wake == "https://omnivoice-wake-vvxitzvqfm.ap-southeast-1.fcapp.run":
                        config.voice_api_wake_url = (
                            "https://omnivoice-wake-xvxitzvqfm.ap-southeast-1.fcapp.run"
                        )
                    config.config_version = 46
                    logger.info("Đã chuyển dịch vụ giọng và tách âm sang Elastic IP cố định (v46)")
                    config.save()
                if version < 47:
                    config.translation_mode = str(
                        getattr(config, "translation_mode", "balanced") or "balanced"
                    )
                    config.translation_genre = str(
                        getattr(config, "translation_genre", "neutral") or "neutral"
                    )
                    config.ocr_color_filter_enabled = bool(
                        getattr(config, "ocr_color_filter_enabled", False)
                    )
                    config.ocr_picked_colors = list(
                        getattr(config, "ocr_picked_colors", []) or []
                    )
                    config.ocr_color_tolerance = max(
                        5, min(120, int(getattr(config, "ocr_color_tolerance", 45)))
                    )
                    config.config_version = 47
                    config.save()
                if version < 48:
                    # v46 từng đưa nhầm voice_api_wake_url sang subdomain "vvxitzvqfm" -
                    # subdomain này KHÔNG tồn tại trên Function Compute (nền tảng trả
                    # {"ErrorCode":"InvalidArgument","ErrorMessage":"Subdomain ... is
                    # invalid"} nên khi Sinh giọng người dùng thấy lỗi "Dịch vụ khởi động
                    # máy chủ từ chối yêu cầu (HTTP 400)"). Subdomain đúng, đã xác nhận còn
                    # hoạt động qua console Function Compute + gọi thử trực tiếp (200
                    # {"status":"Starting"}), là "xvxitzvqfm". Tự sửa lại cho các cấu hình
                    # đã lỡ dính giá trị chết này.
                    if str(getattr(config, "voice_api_wake_url", "") or "").rstrip("/") == (
                        "https://omnivoice-wake-vvxitzvqfm.ap-southeast-1.fcapp.run"
                    ):
                        config.voice_api_wake_url = (
                            "https://omnivoice-wake-xvxitzvqfm.ap-southeast-1.fcapp.run"
                        )
                        logger.info("Đã sửa lại Wake URL bị trỏ nhầm sang subdomain đã hỏng (v48)")
                    config.config_version = 48
                    config.save()
                if version < 49:
                    # Bộ chia cũ quá nhạy: gặp dấu phẩy sau 2 chữ hoặc nghỉ 0.35s
                    # là cắt, làm Whisper sinh nhiều cue một ký tự. Chỉ đổi đúng
                    # bộ mặc định cũ; giá trị người dùng tùy chỉnh vẫn được giữ.
                    if int(getattr(config, "asr_soft_chars", 2) or 2) <= 2:
                        config.asr_soft_chars = 7
                    if float(getattr(config, "asr_gap_split", 0.35) or 0.35) <= 0.35:
                        config.asr_gap_split = 0.55
                    config.config_version = 49
                    config.save()
                if version < 50:
                    # /main/update.json của raw.githubusercontent.com có thể
                    # trả manifest cũ do CDN cache. Dùng refs/heads/main ổn
                    # định hơn và để updater tự thêm cache-buster mỗi lần đọc.
                    old_update_urls = {
                        "https://raw.githubusercontent.com/phamdung1102/"
                        "AndrewSub-Updates/main/update.json",
                        "https://raw.githubusercontent.com/phamdung1102/"
                        "AndrewSub-Updates/refs/heads/main/update.json",
                    }
                    if str(getattr(config, "update_manifest_url", "") or "") in old_update_urls:
                        config.update_manifest_url = cls().update_manifest_url
                    config.config_version = 50
                    logger.info("Đã chuyển kênh cập nhật sang URL chống cache (v50)")
                    config.save()
            except (json.JSONDecodeError, OSError) as exc:
                logger.error("Không đọc được settings.json: %s", exc)
        config._autodetect_ffmpeg()
        config.ensure_dirs()
        return config

    def _autodetect_ffmpeg(self) -> None:
        """Tự nhận FFmpeg kèm trong thư mục app (ffmpeg/ hoặc ffmpeg/bin/).

        Chấp nhận cả đường dẫn tới file lẫn thư mục. Nếu cấu hình cũ không còn
        tồn tại sau khi chuyển/cài lại app, tự tìm bản nằm cạnh ứng dụng.
        """
        def resolve(value: str, tool: str) -> Path | None:
            raw = str(value or "").strip()
            if raw and raw not in ("ffmpeg", "ffprobe"):
                path = Path(raw)
                if path.is_file():
                    return path
                if path.is_dir():
                    for rel in (f"{tool}.exe", f"bin/{tool}.exe"):
                        found = path / rel
                        if found.is_file():
                            return found
            return None

        configured_ffmpeg = resolve(self.ffmpeg_path, "ffmpeg")
        configured_ffprobe = resolve(self.ffprobe_path, "ffprobe")
        if configured_ffmpeg:
            self.ffmpeg_path = str(configured_ffmpeg)
        if configured_ffprobe:
            self.ffprobe_path = str(configured_ffprobe)

        candidates = (
            APP_ROOT / "ffmpeg",
            APP_ROOT / "ffmpeg" / "bin",
            APP_ROOT / "data" / "ffmpeg",
            Path(sys.executable).resolve().parent / "ffmpeg",
        )
        for folder in candidates:
            exe = folder / "ffmpeg.exe"
            probe = folder / "ffprobe.exe"
            if not configured_ffmpeg and exe.is_file():
                self.ffmpeg_path = str(exe)
                logger.info("Dùng FFmpeg kèm app: %s", exe)
                configured_ffmpeg = exe
            if not configured_ffprobe and probe.is_file():
                self.ffprobe_path = str(probe)
                configured_ffprobe = probe

    def save(self) -> None:
        """Lưu cấu hình ra JSON."""
        path = self.settings_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def ensure_dirs(self) -> None:
        """Tạo các thư mục dữ liệu nếu chưa có."""
        for folder in (self.data_dir, self.projects_dir, self.log_dir):
            Path(folder).mkdir(parents=True, exist_ok=True)

    def drive_ocr_token_path(self) -> str:
        """Đường dẫn token.json cho Drive OCR (mặc định trong data/)."""
        if self.drive_ocr_token.strip():
            return self.drive_ocr_token.strip()
        return str(Path(self.data_dir) / "drive_ocr_token.json")

    def asr_keys_list(self) -> list[str]:
        """Các API key ASR đã bật (giải mã DPAPI)."""
        from vicdub.utils.secret_store import unprotect_secret  # noqa: PLC0415
        keys: list[str] = []
        for acc in self.asr_accounts or []:
            if not acc.get("enabled", True):
                continue
            key = unprotect_secret(acc.get("key", "") or "").strip()
            if key:
                keys.append(key)
        return keys

    def asr_configured(self) -> bool:
        """True nếu nguồn nhận diện lời thoại đang chọn đã đủ cấu hình."""
        if str(self.asr_provider or "qwen").strip().lower() == "whisper_server":
            from vicdub.utils.secret_store import unprotect_secret  # noqa: PLC0415
            return bool(
                str(self.whisper_api_base_url or "").strip()
                and unprotect_secret(self.whisper_api_key or "").strip()
            )
        return bool(self.asr_keys_list())

    def enabled_drive_accounts(self) -> list[dict]:
        """Trả các tài khoản OCR đã bật, tự tương thích token cấu hình cũ."""
        accounts: list[dict] = []
        for index, raw in enumerate(self.drive_ocr_accounts or []):
            if (
                not isinstance(raw, dict)
                or not raw.get("enabled", True)
                or str(raw.get("status", "")).strip() == "duplicate"
            ):
                continue
            token = str(raw.get("token_path", "")).strip()
            if token:
                accounts.append({
                    "name": str(raw.get("name") or f"Tài khoản {index + 1}"),
                    "email": str(raw.get("email", "")).strip(),
                    "credentials_path": str(raw.get("credentials_path", "")).strip(),
                    "token_path": token,
                    "folder_id": str(raw.get("folder_id", "")).strip(),
                    "enabled": True,
                    "status": str(raw.get("status", "")).strip(),
                    "checked_at": str(raw.get("checked_at", "")).strip(),
                    "last_error": str(raw.get("last_error", "")).strip(),
                })
        if not accounts:
            token = self.drive_ocr_token_path()
            if Path(token).exists():
                accounts.append({
                    "name": "Tài khoản 1",
                    "email": "",
                    "token_path": token,
                    "folder_id": self.drive_ocr_folder_id.strip(),
                    "enabled": True,
                })
        return accounts

    def drive_account_token_path(self, slot: int) -> str:
        """Token riêng cho slot OAuth (slot bắt đầu từ 1)."""
        return str(Path(self.data_dir) / "drive_accounts" / f"account_{slot}" / "token.json")

    def drive_account_credentials_path(self, slot: int) -> str:
        """OAuth credentials riêng trong thư mục của từng tài khoản."""
        return str(
            Path(self.data_dir) / "drive_accounts" / f"account_{slot}" / "credentials.json"
        )

    def default_drive_credentials(self) -> str:
        """Vị trí mặc định để đặt credentials.json (dùng chung mọi dự án)."""
        return str(Path(self.data_dir) / "credentials.json")

    def resolve_vsf_exe(self) -> str:
        """Tìm VideoSubFinderWXW.exe: cấu hình -> tools/VideoSubFinder/ ... '' nếu không."""
        from vicdub.utils.vsf_scanner import find_vsf_exe  # noqa: PLC0415
        return find_vsf_exe(self.vsf_path, APP_ROOT)

    def resolve_drive_credentials(self) -> str:
        """Tìm credentials.json Drive OCR mà KHÔNG cần người dùng chọn.

        Ưu tiên: cấu hình đã lưu -> data/credentials.json ->
        data/drive_credentials.json -> credentials.json cạnh app. Trả "" nếu
        chưa có file nào (khi đó UI mới yêu cầu chọn).
        """
        candidates = [
            self.drive_ocr_credentials.strip(),
            str(Path(self.data_dir) / "credentials.json"),
            str(Path(self.data_dir) / "drive_credentials.json"),
            str(APP_ROOT / "credentials.json"),
        ]
        for path in candidates:
            if path and Path(path).exists():
                return path
        return ""

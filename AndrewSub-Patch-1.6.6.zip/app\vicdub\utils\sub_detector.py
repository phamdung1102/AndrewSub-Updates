"""Phát hiện phụ đề gắn cứng bằng STREAMING + STATE MACHINE (VSF-lite thuần Python).

Thay cho extract_keyframes cũ (lấy mẫu + edge-mask thô, hay sót/lặp/lệch). Ý chính:
  1. Stream vùng phụ đề trực tiếp từ FFmpeg (crop trong FFmpeg, đọc rawvideo qua
     pipe) - KHÔNG ghi hàng nghìn PNG ra đĩa.
  2. Máy trạng thái IDLE/ACTIVE gom frame thành câu, có GAP-TOLERANCE: detect rớt
     vài frame giữa câu thì KHÔNG đóng câu (bắc cầu) -> không tạo vết tách giả ->
     hết lặp mà timing vẫn khít.
  3. Mỗi câu chọn REPRESENTATIVE FRAME theo điểm chất lượng (nét nhất) để OCR.

Tín hiệu "frame có chữ" và "cùng một câu" dựa trên mặt nạ nét chữ (text mask) như
VideoSubFinder; hàm dùng lại từ llm_ocr_subtitles để nhất quán.
"""

from __future__ import annotations

import logging
import subprocess
from functools import lru_cache
from dataclasses import dataclass, field
from typing import Callable, Iterator

logger = logging.getLogger(__name__)

from vicdub.utils.process_utils import hidden_process_kwargs


# ---------- Tín hiệu detect: NÉT CHỮ TRẮNG (ổn định qua nền động) ----------
#
# Phụ đề gắn cứng gần như luôn là chữ SÁNG (trắng/vàng) có viền tối. Nền video
# phía sau đổi mỗi frame nhưng nét chữ trắng ĐỨNG YÊN -> bám vào "bright stroke"
# (điểm sáng nằm cạnh biên mạnh = nét chữ) cho mask ổn định, khác hẳn cạnh chung
# vốn nhiễu theo nền. Đây là mấu chốt để hết tách giả (lặp) và bớt báo nhầm.

def _bright_stroke_mask(img):
    import numpy as np  # noqa: PLC0415
    a = np.asarray(img, dtype="float32")
    if a.ndim == 3:
        gray = a[..., :3] @ np.array([0.299, 0.587, 0.114], dtype="float32")
    else:
        gray = a
    if gray.size and gray.max() > 1.5:
        gray = gray / 255.0
    if gray.shape[0] < 2 or gray.shape[1] < 2:
        return np.zeros_like(gray, dtype=bool)
    gy = np.abs(np.diff(gray, axis=0)); gy = np.pad(gy, ((0, 1), (0, 0)))
    gx = np.abs(np.diff(gray, axis=1)); gx = np.pad(gx, ((0, 0), (0, 1)))
    mag = gy + gx
    bright = gray > 0.62          # điểm sáng (chữ trắng/vàng nhạt)
    edge = mag > 0.08             # mép glyph vẫn sống sau nén H.264
    # Subtitle burn-in thường có viền/bóng tối sát nét sáng. Chỉ giữ điểm sáng
    # có pixel tối trong bán kính 2 px: triệt phần lớn đèn, da, áo và cảnh nền
    # sáng từng đánh lừa detector, nhưng giữ nguyên glyph trên nền sáng.
    dark = gray < 0.42
    padded = np.pad(dark, 2)
    height, width = dark.shape
    dark_near = np.logical_or.reduce([
        padded[dy:dy + height, dx:dx + width]
        for dy in range(5) for dx in range(5)
    ])
    return bright & edge & dark_near


def _selected_color_stroke_mask(img, colors, tolerance: int = 45):
    """Mask glyphs close to user-picked RGB colors, still constrained to edges."""
    import numpy as np  # noqa: PLC0415
    if not colors:
        return _bright_stroke_mask(img)
    rgb = np.asarray(img, dtype="int16")[..., :3]
    if rgb.ndim != 3 or rgb.shape[2] < 3:
        return _bright_stroke_mask(img)
    selected = np.zeros(rgb.shape[:2], dtype=bool)
    limit = max(5, min(120, int(tolerance)))
    for value in colors:
        try:
            color = np.asarray(value[:3], dtype="int16")
        except (TypeError, ValueError):
            continue
        selected |= np.max(np.abs(rgb - color), axis=2) <= limit
    gray = rgb.astype("float32") @ np.array([0.299, 0.587, 0.114], dtype="float32")
    gray /= 255.0
    gy = np.abs(np.diff(gray, axis=0)); gy = np.pad(gy, ((0, 1), (0, 0)))
    gx = np.abs(np.diff(gray, axis=1)); gx = np.pad(gx, ((0, 0), (0, 1)))
    return selected & ((gx + gy) > 0.045)


@lru_cache(maxsize=64)
def _split_bounds(length: int, n: int):
    """Ranh giới ô GIỐNG HỆT np.array_split (rem ô đầu dài hơn 1 px)."""
    import numpy as np  # noqa: PLC0415
    n = min(n, length)
    div, rem = divmod(length, n)
    sizes = np.array([div + 1] * rem + [div] * (n - rem), dtype="int64")
    starts = np.concatenate(([0], np.cumsum(sizes)[:-1]))
    return starts, sizes


def _pool(mask, gh: int, gw: int):
    import numpy as np  # noqa: PLC0415
    arr = np.asarray(mask)
    if arr.ndim != 2 or arr.size == 0:
        return np.zeros((gh, gw), dtype="float32")
    h, w = arr.shape
    rs, rsz = _split_bounds(h, gh)
    cs, csz = _split_bounds(w, gw)
    # Cộng theo KHỐI bằng reduceat (tầng C) thay cho ~1000 lần .mean() ở Python mỗi
    # frame -> cùng ranh giới ô, cùng kết quả, nhanh hơn hàng chục lần. Mask bool
    # cộng bằng int32 nên tổng CHÍNH XÁC tuyệt đối (không sai số dồn float).
    base = arr.astype("int32") if arr.dtype == np.bool_ else arr.astype("float32", copy=False)
    s = np.add.reduceat(np.add.reduceat(base, rs, axis=0), cs, axis=1)
    area = (rsz[:, None] * csz[None, :]).astype("float32")
    return (s / area).astype("float32")


def text_signature(img, grid: tuple[int, int] = (14, 72)):
    """Chữ ký mật độ NÉT CHỮ TRẮNG trên lưới cố định (0..1).

    Lưới mịn ngang (72 cột) để hai câu khác BỐ CỤC chữ cho chữ ký khác nhau ->
    không bị coi là 'cùng câu' rồi gộp nhầm.
    """
    return _pool(_bright_stroke_mask(img), grid[0], grid[1])


def sig_has_text(sig, min_density: float = 0.006, max_density: float = 0.6,
                 min_col_cov: float = 0.08) -> bool:
    """Chữ ký này có giống một DÒNG CHỮ (trắng, trải ngang) không?"""
    import numpy as np  # noqa: PLC0415
    if sig is None or getattr(sig, "size", 0) == 0:
        return False
    density = float(sig.mean())
    if density < min_density or density > max_density:
        return False
    col = sig.mean(axis=0)
    peak = float(col.max())
    if peak <= 0:
        return False
    col_cov = float((col > 0.25 * peak).mean())   # chữ trải nhiều cột ngang
    return col_cov >= min_col_cov


def sig_same(a, b, threshold: float = 0.025) -> bool:
    """Hai chữ ký nét-chữ-trắng có phải cùng một câu (bố cục nét gần y hệt)?"""
    import numpy as np  # noqa: PLC0415
    if a is None or b is None or a.shape != b.shape:
        return False
    return float(np.mean(np.abs(a - b))) <= threshold


def _update_reference(reference, current, weight: float = 0.18):
    """Cập nhật chậm chữ ký của cùng một track để triệt nhiễu nền tích lũy.

    Chỉ gọi sau khi hai chữ ký đã vượt kiểm tra ``sig_same`` nên reference không
    thể trôi sang một câu mới. Đây là bản nhẹ của bước restore-still-lines trong
    detector kiểu VSF/AIO.
    """
    return reference * (1.0 - weight) + current * weight

ProgressFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]


def effective_detector_fps(source_fps: float, requested_fps: float) -> float:
    """Resolve scan rate; level 20 scans source frames but never above 25 fps."""
    requested = max(16.0, min(20.0, float(requested_fps)))
    source = max(0.0, float(source_fps))
    if requested >= 20.0 and source > 0:
        return min(source, 25.0)
    return min(source, requested) if source > 0 else requested


@dataclass
class DetectedSub:
    """Một câu phụ đề: mốc thời gian + ảnh đại diện (nét nhất) để OCR."""
    start: float
    end: float
    image: object = None          # PIL.Image (frame đại diện)


@dataclass
class _Active:
    """Câu đang mở trong state machine."""
    start: float
    end: float
    ref_sig: object
    best_img: object
    best_q: float


def frame_quality(sig) -> float:
    """Điểm chất lượng frame: mật độ nét chữ (nét rõ/đầy = chữ hiện trọn, không mờ)."""
    import numpy as np  # noqa: PLC0415
    if sig is None or getattr(sig, "size", 0) == 0:
        return 0.0
    # Vừa thưởng mật độ nét, vừa thưởng độ trải ngang (chữ đủ dòng, không cụt).
    density = float(sig.mean())
    col_cov = float((sig.mean(axis=0) > 0).mean())
    return density * (0.5 + col_cov)


def _dilate_one(mask):
    """Binary dilation by one pixel, implemented with NumPy only."""
    import numpy as np  # noqa: PLC0415
    source = np.asarray(mask, dtype=bool)
    padded = np.pad(source, 1)
    h, w = source.shape
    return np.logical_or.reduce([
        padded[dy:dy + h, dx:dx + w]
        for dy in range(3) for dx in range(3)
    ])


def stroke_overlap(first, second) -> float:
    """Return alignment-tolerant overlap of bright subtitle strokes (0..1)."""
    import numpy as np  # noqa: PLC0415
    a = _bright_stroke_mask(first)
    b = _bright_stroke_mask(second)
    total = int(a.sum()) + int(b.sum())
    if total <= 0:
        return 0.0
    # Symmetric containment with one-pixel tolerance. Stable subtitle glyphs stay
    # aligned while scene/background edges change underneath them.
    return float(
        (np.logical_and(a, _dilate_one(b)).sum()
         + np.logical_and(b, _dilate_one(a)).sum()) / total
    )


def collapse_local_duplicate_tracks(
    subs: list[DetectedSub], *, max_gap: float = 0.35, min_overlap: float = 0.72,
) -> tuple[list[DetectedSub], int]:
    """Collapse adjacent detector splits of the same on-screen subtitle.

    This runs before OCR and only joins continuous tracks whose fixed bright
    strokes strongly overlap. It never compares non-adjacent repeated dialogue.
    """
    collapsed: list[DetectedSub] = []
    removed = 0
    last_raw_image = None
    for sub in subs:
        previous = collapsed[-1] if collapsed else None
        gap = sub.start - previous.end if previous else float("inf")
        same_visible_text = (
            previous is not None and gap <= max_gap and last_raw_image is not None
            and stroke_overlap(last_raw_image, sub.image) >= min_overlap
        )
        if same_visible_text:
            previous.end = max(previous.end, sub.end)
            if frame_quality(text_signature(sub.image)) > frame_quality(text_signature(previous.image)):
                previous.image = sub.image
            removed += 1
        else:
            collapsed.append(DetectedSub(sub.start, sub.end, sub.image))
        last_raw_image = sub.image
    return collapsed, removed


def stream_roi_frames(
    ffmpeg_bin: str,
    video_path: str,
    crop: tuple[int, int, int, int],
    fps: float,
    is_cancelled: CancelFn | None = None,
) -> Iterator[tuple[float, object]]:
    """Stream vùng ROI đã crop từ FFmpeg, yield (thời_gian_giây, ảnh_PIL_RGB).

    crop = (w, h, x, y). Đọc rawvideo rgb24 qua pipe, không ghi file.
    """
    from PIL import Image  # noqa: PLC0415

    w, h, x, y = (int(v) for v in crop)
    if w <= 0 or h <= 0:
        return
    # ``crop`` defaults to ``exact=0`` for subsampled formats such as yuv420p.
    # FFmpeg then silently rounds an odd ROI (for example 431x59) down to an
    # even size, while ``frame_bytes`` below still uses the requested size.
    # Reading that shorter raw frame consumes bytes from the following frame
    # and progressively tears every OCR image into horizontal/diagonal slices.
    # Subtitle boxes drawn by the user commonly have odd dimensions, so force
    # FFmpeg to preserve the exact ROI instead of relying on chroma rounding.
    vf = f"crop={w}:{h}:{x}:{y}:exact=1,fps={fps:g},format=rgb24"
    cmd = [
        ffmpeg_bin, "-nostdin", "-loglevel", "error",
        "-i", video_path, "-an", "-vf", vf,
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-",
    ]
    frame_bytes = w * h * 3
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        **hidden_process_kwargs(),
    )
    idx = 0
    try:
        assert proc.stdout is not None
        while True:
            if is_cancelled and is_cancelled():
                break
            buf = proc.stdout.read(frame_bytes)
            if not buf or len(buf) < frame_bytes:
                break
            img = Image.frombytes("RGB", (w, h), buf)
            yield idx / fps, img
            idx += 1
    finally:
        try:
            if proc.stdout:
                proc.stdout.close()
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            proc.kill()


def temporal_majority_stream(frames, *, include_raw: bool = False):
    """Stabilise stroke masks with a centred 2-of-3 temporal majority.

    A subtitle glyph stays at the same pixels for at least two sampled frames;
    scene/background edges normally occur in only one. The first/last masks are
    duplicated so every input timestamp is emitted and timing is not shifted.
    Each input item is ``(time, original_image, binary_mask)``. With
    ``include_raw=True`` each output also includes the original centre mask so
    the caller can retain a strong one-frame subtitle as a rescue candidate.
    """
    import numpy as np  # noqa: PLC0415

    def majority(a, b, c):
        a = np.asarray(a, dtype=bool)
        b = np.asarray(b, dtype=bool)
        c = np.asarray(c, dtype=bool)
        # A glyph edge can move one pixel between decoded frames because of
        # compression/antialiasing. Count it as the same temporal stroke when a
        # neighbouring pixel exists in another mask; isolated one-frame noise
        # still has no temporal partner and disappears.
        # Preserve only strokes belonging to the centre frame. A centre stroke
        # survives when either neighbour contains it within one pixel. This avoids
        # thickening/unioning edges, which would make signatures noisier again.
        return b & (_dilate_one(a) | _dilate_one(c))

    iterator = iter(frames)
    try:
        first = next(iterator)
    except StopIteration:
        return
    try:
        second = next(iterator)
    except StopIteration:
        yield ((first[0], first[1], first[2], first[2]) if include_raw else first)
        return

    # Centred value for the first timestamp: [first, first, second].
    stable = majority(first[2], first[2], second[2])
    yield ((first[0], first[1], stable, first[2]) if include_raw
           else (first[0], first[1], stable))
    previous, current = first, second
    for following in iterator:
        stable = majority(previous[2], current[2], following[2])
        yield ((current[0], current[1], stable, current[2]) if include_raw
               else (current[0], current[1], stable))
        previous, current = current, following
    # Centred value for the final timestamp: [previous, current, current].
    stable = majority(previous[2], current[2], current[2])
    yield ((current[0], current[1], stable, current[2]) if include_raw
           else (current[0], current[1], stable))


def run_state_machine(
    frames: Iterator,
    *,
    frame_dur: float,
    enter_frames: int = 2,
    change_frames: int = 2,
    max_gap_frames: int = 4,
    mask_threshold: float = 0.025,
    min_text_density: float = 0.006,
    min_duration: float = 0.12,
    on_candidate: Callable[[DetectedSub], None] | None = None,
    on_near_miss: Callable[[DetectedSub], None] | None = None,
) -> list[DetectedSub]:
    """Máy trạng thái gom frame -> câu, có gap-tolerance. THUẦN (test được).

    frames: iterable ``(t, img, sig, has_text[, legacy_flash_flag])``. Cờ flash
    cũ bị bỏ qua: ở 20–25 fps, một điểm sáng chỉ tồn tại đúng một frame không đủ
    bằng chứng là phụ đề và từng tạo hàng nghìn track rác.
    phần stream để unit-test bằng chuỗi tín hiệu giả, không cần video.
    """
    subs: list[DetectedSub] = []
    active: _Active | None = None
    enter_count = 0
    enter_sig = None
    enter_start = 0.0
    enter_best_img = None
    enter_best_q = 0.0
    gap_count = 0
    # Khi ACTIVE gặp mask khác, không tách ngay. Chờ `change_frames` frame liên
    # tiếp giống nhau để xác nhận đây là câu mới chứ không phải nhiễu nền.
    change_count = 0
    change_sig = None
    change_start = 0.0
    change_best_img = None
    change_best_q = 0.0

    def reset_enter() -> None:
        nonlocal enter_count, enter_sig, enter_start, enter_best_img, enter_best_q
        enter_count = 0
        enter_sig = None
        enter_start = 0.0
        enter_best_img = None
        enter_best_q = 0.0

    def emit_enter_near_miss() -> None:
        """Giữ track chữ nhanh chưa đủ hai frame, không buộc quét lại video.

        Một frame mask đã qua temporal-majority thực tế có bằng chứng ở ít nhất
        hai frame nguồn. Nó chưa đủ chắc để đưa thẳng vào timeline, nhưng đủ tốt
        để OCR theo lô ở cuối lượt quét.
        """
        if on_near_miss is None or enter_count <= 0 or enter_best_img is None:
            return
        on_near_miss(DetectedSub(
            start=round(enter_start, 3),
            end=round(
                enter_start + max(frame_dur, (enter_count + 1) * frame_dur),
                3,
            ),
            image=enter_best_img,
        ))

    def reset_change() -> None:
        nonlocal change_count, change_sig, change_start, change_best_img, change_best_q
        change_count = 0
        change_sig = None
        change_start = 0.0
        change_best_img = None
        change_best_q = 0.0

    def close(a: _Active) -> None:
        if a.end - a.start >= min_duration:
            candidate = DetectedSub(
                start=round(a.start, 3),
                end=round(a.end, 3),
                image=a.best_img,
            )
            subs.append(candidate)
            # A candidate is immutable after close().  Consumers may therefore
            # persist and OCR it immediately while the decoder keeps scanning.
            if on_candidate is not None:
                on_candidate(candidate)

    for frame in frames:
        t, img, sig, has_text = frame[:4]

        if active is None:
            if has_text:
                q = frame_quality(sig)
                if enter_sig is not None and sig_same(enter_sig, sig, mask_threshold):
                    enter_count += 1
                    enter_sig = _update_reference(enter_sig, sig)
                    if q > enter_best_q:
                        enter_best_q, enter_best_img = q, img
                else:
                    # Hai frame đều "có chữ" nhưng mask khác nhau không đủ để mở
                    # track. Bắt đầu lại chuỗi xác nhận từ frame hiện tại.
                    emit_enter_near_miss()
                    enter_count = 1
                    enter_sig = sig
                    enter_start = t
                    enter_best_img = img
                    enter_best_q = q
                if enter_count >= enter_frames:
                    active = _Active(
                        start=enter_start, end=t + frame_dur, ref_sig=enter_sig,
                        best_img=enter_best_img, best_q=enter_best_q,
                    )
                    reset_enter()
                    gap_count = 0
            else:
                emit_enter_near_miss()
                reset_enter()
            continue

        # đang ACTIVE
        if has_text and sig_same(active.ref_sig, sig, mask_threshold):
            active.end = t + frame_dur
            active.ref_sig = _update_reference(active.ref_sig, sig)
            gap_count = 0
            reset_change()  # frame lạ trước đó chỉ là nhiễu một-frame
            q = frame_quality(sig)
            if q > active.best_q:            # giữ frame nét nhất làm đại diện
                active.best_q, active.best_img = q, img
        elif has_text:
            # Mask khác câu đang chạy: chỉ tách khi mask mới ổn định liên tiếp.
            q = frame_quality(sig)
            if change_sig is not None and sig_same(change_sig, sig, mask_threshold):
                change_count += 1
                change_sig = _update_reference(change_sig, sig)
                if q > change_best_q:
                    change_best_q, change_best_img = q, img
            else:
                change_count = 1
                change_sig = sig
                change_start = t
                change_best_img = img
                change_best_q = q

            if change_count >= change_frames:
                close(active)
                active = _Active(
                    start=change_start, end=t + frame_dur, ref_sig=change_sig,
                    best_img=change_best_img, best_q=change_best_q,
                )
                reset_change()
            gap_count = 0
        else:
            # không có chữ: có thể chỉ rớt vài frame -> BẮC CẦU, chưa đóng câu
            reset_change()
            gap_count += 1
            if gap_count > max_gap_frames:
                close(active)
                active = None
                reset_enter()
                gap_count = 0
    if active is not None:
        close(active)
    else:
        emit_enter_near_miss()
    return subs


def detect_subtitles(
    ffmpeg_bin: str,
    video_path: str,
    crop: tuple[int, int, int, int],
    scan_fps: float = 12.0,
    mask_threshold: float = 0.025,
    min_text_density: float = 0.006,
    min_col_coverage: float = 0.08,
    min_duration: float = 0.12,
    enter_frames: int = 2,
    change_frames: int = 2,
    max_gap_seconds: float = 0.30,
    report: ProgressFn | None = None,
    is_cancelled: CancelFn | None = None,
    duration: float = 0.0,
    on_candidate: Callable[[DetectedSub], None] | None = None,
    on_near_miss: Callable[[DetectedSub], None] | None = None,
    picked_colors: list | None = None,
    color_tolerance: int = 45,
) -> list[DetectedSub]:
    """Phát hiện toàn bộ câu phụ đề trong video (streaming, một lượt)."""
    frame_dur = 1.0 / scan_fps if scan_fps > 0 else 0.125
    max_gap_frames = max(1, int(round(max_gap_seconds * scan_fps)))

    def raw_mask_stream():
        last_report = [0.0]
        for t, img in stream_roi_frames(
            ffmpeg_bin, video_path, crop, scan_fps, is_cancelled
        ):
            if report and duration > 0 and t - last_report[0] >= 1.0:
                last_report[0] = t
                report(6 + int(34 * min(1.0, t / duration)),
                       f"Quét phụ đề {t:.0f}/{duration:.0f}s...")
            yield t, img, _selected_color_stroke_mask(
                img, picked_colors, color_tolerance
            )

    def signal_stream():
        # Ổn định mask bằng đa số thời gian 2/3 (bỏ nhiễu nền chỉ hiện 1 frame)
        # TRƯỚC khi chấm has_text. Hàm này trước đây tồn tại nhưng raw stream lại
        # được đưa thẳng xuống state machine, khiến mọi cạnh sáng một-frame có thể
        # mở/tách một track mới khi quét FPS cao.
        for t, img, stable_mask in temporal_majority_stream(raw_mask_stream()):
            stable_sig = _pool(stable_mask, 14, 72)
            stable_has = sig_has_text(
                stable_sig, min_density=min_text_density,
                min_col_cov=min_col_coverage,
            )
            yield t, img, stable_sig, stable_has

    subs = run_state_machine(
        signal_stream(),
        frame_dur=frame_dur,
        enter_frames=enter_frames,
        change_frames=change_frames,
        max_gap_frames=max_gap_frames,
        mask_threshold=mask_threshold,
        min_text_density=min_text_density,
        min_duration=min_duration,
        on_candidate=on_candidate,
        on_near_miss=on_near_miss,
    )
    # GOM over-split TRƯỚC OCR: gộp track liền kề CÙNG chữ (nét trùng cao) -> giảm
    # mạnh số ảnh gửi OCR mà KHÔNG mất câu (recall giữ, precision tăng). Đây là
    # mảnh làm "recall-first" khả thi.
    raw_count = len(subs)
    # min_overlap=0.50: mask nét-chữ dao động nhẹ giữa các frame nên cùng-một-câu
    # có overlap ~0.55-0.72; câu KHÁC nhau <0.45. Ngưỡng 0.72 mặc định quá chặt
    # (bỏ sót gom -> còn nhiều mảnh vụn); 0.50 nằm giữa vùng an toàn.
    # Recall-first: do not merge candidates before OCR. Similar masks can be
    # different very-short subtitles; exact-text merge happens after OCR.
    # Chốt an toàn TRÊN SỐ ĐÃ GOM (ứng viên thô cao là bình thường với recall-first;
    # chỉ chặn khi SAU khi gom vẫn vô lý -> vùng OCR sai / nền động thật sự).
    if duration > 5 and len(subs) / duration > 2.0:
        raise RuntimeError(
            f"Phát hiện quá nhiều ứng viên phụ đề: {len(subs)} câu trong "
            f"{duration:.0f}s ({len(subs) / duration:.1f} câu/giây) — bất thường. "
            "Hãy khoanh HẸP đúng dải phụ đề (vùng OCR) rồi tách lại."
        )
    if report:
        report(40, f"Phát hiện {len(subs)} câu ứng viên (quét {scan_fps:g} fps, lọc ổn định theo thời gian).")
    return subs

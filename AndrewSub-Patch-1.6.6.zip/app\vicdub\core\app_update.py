"""Kiểm tra, tải và bàn giao bản cập nhật cho updater độc lập."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from vicdub.config import APP_ROOT


class UpdateError(RuntimeError):
    """Manifest hoặc gói cập nhật không hợp lệ."""


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    package_type: str
    url: str
    sha256: str
    notes: tuple[str, ...]
    required: bool = False


def _version_tuple(value: str) -> tuple[int, ...]:
    parts: list[int] = []
    for item in str(value).strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in item if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple((parts + [0, 0, 0])[:4])


def is_newer(candidate: str, current: str) -> bool:
    return _version_tuple(candidate) > _version_tuple(current)


def _read_source(source: str, timeout: int = 12) -> tuple[bytes, str]:
    source = str(source or "").strip()
    if not source:
        raise UpdateError("Chưa cấu hình kênh cập nhật.")
    parsed = urllib.parse.urlparse(source)
    if parsed.scheme in ("https", "http"):
        if parsed.scheme != "https" and parsed.hostname not in ("localhost", "127.0.0.1"):
            raise UpdateError("Kênh cập nhật phải dùng HTTPS.")
        request = urllib.request.Request(
            source, headers={"User-Agent": "AndrewSub-AutoUpdate/1"}
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
            return response.read(), response.geturl()
    if parsed.scheme == "file":
        path = Path(urllib.request.url2pathname(parsed.path))
    else:
        path = Path(source).expanduser()
    if not path.is_file():
        raise UpdateError(f"Không tìm thấy manifest cập nhật: {path}")
    return path.read_bytes(), str(path.resolve())


def load_manifest(source: str, timeout: int = 12) -> UpdateInfo:
    raw, resolved_source = _read_source(source, timeout)
    try:
        data = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError("Manifest cập nhật không phải JSON UTF-8 hợp lệ.") from exc
    if not isinstance(data, dict):
        raise UpdateError("Manifest cập nhật không hợp lệ.")
    version = str(data.get("version", "")).strip()
    package_type = str(data.get("type", "patch")).strip().lower()
    package_url = str(data.get("url", "")).strip()
    sha256 = str(data.get("sha256", "")).strip().lower()
    if not version or package_type not in ("patch", "installer") or not package_url:
        raise UpdateError("Manifest thiếu version, type hoặc url.")
    if len(sha256) != 64 or any(ch not in "0123456789abcdef" for ch in sha256):
        raise UpdateError("Manifest thiếu SHA256 hợp lệ.")
    parsed = urllib.parse.urlparse(resolved_source)
    if parsed.scheme in ("https", "http", "file"):
        package_url = urllib.parse.urljoin(resolved_source, package_url)
    elif not urllib.parse.urlparse(package_url).scheme:
        package_url = str((Path(resolved_source).parent / package_url).resolve())
    notes_raw = data.get("notes", [])
    if isinstance(notes_raw, str):
        notes = (notes_raw.strip(),) if notes_raw.strip() else ()
    elif isinstance(notes_raw, list):
        notes = tuple(str(item).strip() for item in notes_raw if str(item).strip())
    else:
        notes = ()
    return UpdateInfo(
        version=version,
        package_type=package_type,
        url=package_url,
        sha256=sha256,
        notes=notes,
        required=bool(data.get("required", False)),
    )


def download_update(
    info: UpdateInfo,
    destination: Path,
    progress: Callable[[int, str], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    suffix = ".exe" if info.package_type == "installer" else ".zip"
    final_path = destination / f"AndrewSubAI-{info.version}{suffix}"
    temp_path = final_path.with_suffix(final_path.suffix + ".part")
    temp_path.unlink(missing_ok=True)
    parsed = urllib.parse.urlparse(info.url)
    digest = hashlib.sha256()
    received = 0

    def consume(stream, total: int) -> None:
        nonlocal received
        with temp_path.open("wb") as output:
            while True:
                if cancelled and cancelled():
                    raise UpdateError("Đã hủy tải cập nhật.")
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
                digest.update(chunk)
                received += len(chunk)
                pct = int(received * 100 / total) if total > 0 else -1
                if progress:
                    progress(pct, f"Đang tải bản {info.version}...")

    try:
        if parsed.scheme in ("https", "http"):
            if parsed.scheme != "https" and parsed.hostname not in ("localhost", "127.0.0.1"):
                raise UpdateError("Gói cập nhật phải tải qua HTTPS.")
            request = urllib.request.Request(
                info.url, headers={"User-Agent": "AndrewSub-AutoUpdate/1"}
            )
            with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310
                consume(response, int(response.headers.get("Content-Length", "0") or 0))
        else:
            source = Path(urllib.request.url2pathname(parsed.path) if parsed.scheme == "file" else info.url)
            if not source.is_file():
                raise UpdateError(f"Không tìm thấy gói cập nhật: {source}")
            with source.open("rb") as stream:
                consume(stream, source.stat().st_size)
        if digest.hexdigest().lower() != info.sha256:
            raise UpdateError("Gói cập nhật sai SHA256; đã hủy để bảo vệ ứng dụng.")
        os.replace(temp_path, final_path)
        if progress:
            progress(100, "Đã tải và xác minh bản cập nhật.")
        return final_path
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def launch_updater(package: Path, info: UpdateInfo) -> None:
    """Mở updater ngoài process; caller phải thoát app ngay sau đó."""
    shell_root = APP_ROOT.parent
    agent = shell_root / "updater" / "update_agent.py"
    pythonw = shell_root / "python" / "pythonw.exe"
    launcher = shell_root / "bootstrap" / "launch.py"
    if not (agent.is_file() and pythonw.is_file() and launcher.is_file()):
        raise UpdateError("Bản đang chạy chưa hỗ trợ tự cập nhật; hãy dùng installer mới một lần.")
    status_path = shell_root / "update_status.json"
    args = [
        str(pythonw), str(agent),
        "--package", str(package),
        "--type", info.package_type,
        "--app-dir", str(APP_ROOT),
        "--pid", str(os.getpid()),
        "--launch", str(launcher),
        "--status", str(status_path),
        "--version", info.version,
    ]
    flags = 0
    if os.name == "nt":
        flags = (
            subprocess.CREATE_NEW_PROCESS_GROUP
            | 0x00000008
            | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        )
    subprocess.Popen(args, cwd=str(shell_root), creationflags=flags)  # noqa: S603

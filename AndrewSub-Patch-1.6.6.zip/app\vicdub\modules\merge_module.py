"""Merge Module - lồng tiếng theo timeline SRT rồi phủ lên VIDEO GỐC.

Cách làm (theo omnivoice-vi): KHÔNG cắt/kéo video. Dựng một track audio lồng
tiếng dài bằng video: im lặng ở mọi chỗ, đặt voice của từng dòng đúng mốc thời
gian gốc của phụ đề. Voice dài hơn khoảng tới câu kế thì giữ nguyên, tràn nhẹ
sang sau; câu sau mix đè lên tail câu trước và tail cũ bị hạ âm lượng.

Nhờ vậy giữ nguyên hình + thời lượng + mọi khoảng lặng của video gốc.

Output: final_video (đường dẫn Final.mp4)
"""

from __future__ import annotations

import os
import time
import wave
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import (
    Segment, write_blur_mask_ass, write_positioned_ass, write_srt,
)

DUB_SR = 24000  # OmniVoice xuất 24 kHz


class MergeModule(BaseModule):
    """Lồng tiếng theo timeline + phủ lên video gốc + chèn phụ đề."""

    name = "Ghép video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        voice_files: dict[int, str] = data.get("voice_files") or {}
        video_path = data.get("video_path") or project.video_path

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video gốc để lồng tiếng.")
        if not segments:
            raise ModuleError("Chưa có phụ đề.")

        # Ưu tiên voice trong context (có thể đã được đồng bộ/tăng tốc), rồi mới
        # rơi về voice gốc trong project.
        voices_dir = Path(project.root) / "voices"
        resolved: dict[int, str] = {}
        for seg in segments:
            p = voices_dir / f"{seg.line:04d}.wav"
            cand = voice_files.get(seg.line)
            if cand and Path(cand).exists():
                resolved[seg.line] = cand
            elif p.exists():
                resolved[seg.line] = str(p)
        voice_files = resolved
        if not voice_files:
            raise ModuleError("Chưa có voice. Chạy bước 'Sinh giọng nói' trước.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
            render_profile=getattr(config, "render_profile", "auto"),
        )
        output_dir = Path(project.root) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            video_dur = ffmpeg.duration(video_path)
        except FFmpegError as exc:
            raise ModuleError(f"Không đọc được video: {exc}") from exc

        started_at = time.monotonic()
        # Video luôn giữ nguyên timeline. Voice tự mượn khoảng trống, tăng tốc
        # giữ cao độ và overlap/mix khi thật sự cần. Không tạo trim/setpts/tpad
        # theo từng câu: cách đó làm filter graph phình ra hàng trăm nhánh và
        # khiến NVENC phải chờ CPU dù trạng thái vẫn ghi "GPU NVIDIA".
        self.report(5, "Giữ nguyên hình; tự co và sắp voice theo timeline...")

        # 1. Dựng track voice trước; không encode hình ở bước này.
        self.report(10, "Dựng track lồng tiếng theo timeline...")
        dub_wav = output_dir / "_dub.wav"
        warnings = self._build_dub_audio(
            segments, voice_files, video_dur, dub_wav, ffmpeg, config, output_dir,
        )
        for w in warnings:
            self.logger.warning(w)

        # 2. Chuẩn bị phụ đề/mask rồi render thẳng ra đích trong một lượt.
        self.check_cancelled()
        mode = getattr(config, "subtitle_mode", "none")
        blur_original = bool(getattr(config, "subtitle_blur_original", False))
        ocr_region = project.get_ocr_region(
            getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
        )
        blur_region = tuple(project.get_blur_region(ocr_region))
        # Blur chỉ xuất hiện đúng lúc hard-sub gốc hiện trên hình. Không phủ một
        # dải mờ cố định xuyên suốt các khoảng không có thoại.
        blur_intervals = [
            (segment.start, segment.end) for segment in segments
            if (segment.text or "").strip()
        ]
        blur_mask = output_dir / "_blur_mask.ass"
        if blur_original:
            write_blur_mask_ass(
                segments, blur_mask, region=blur_region,
                scale_percent=int(getattr(config, "subtitle_blur_scale", 140)),
            )
        has_text = any((s.translation or s.text).strip() for s in segments)
        subtitle_path: Path | None = None
        if mode in ("hard", "soft") and has_text:
            if mode == "hard":
                subtitle_path = output_dir / "_sub_positioned.ass"
                write_positioned_ass(
                    segments, subtitle_path,
                    x=float(getattr(config, "subtitle_x", 0.5)),
                    y=float(getattr(config, "subtitle_y", 0.90)),
                    font_size=int(getattr(config, "subtitle_font_size", 24)),
                    background=bool(getattr(config, "subtitle_bg", False)),
                    translated=True,
                )
            else:
                subtitle_path = output_dir / "_sub.srt"
                write_srt(segments, subtitle_path, translated=True)
        elif mode in ("hard", "soft"):
            mode = "none"

        export_dir = str(getattr(config, "export_dir", "") or "").strip()
        if export_dir:
            final_path = Path(export_dir) / f"{project.name}.mp4"
        else:
            final_path = output_dir / "Final.mp4"
        try:
            final_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            final_path = output_dir / "Final.mp4"
            self.logger.warning("Không tạo được thư mục xuất; dùng thư mục dự án: %s", exc)
        partial_path = final_path.with_name(
            f".{final_path.stem}.partial{final_path.suffix}"
        )
        partial_path.unlink(missing_ok=True)

        encoder = ffmpeg.encoder_label()
        picture_copy = mode != "hard" and not blur_original
        action = (
            "Ghép audio, giữ nguyên hình"
            if picture_copy else
            f"Render một lượt bằng {encoder}"
        )
        self.report(55, f"{action}...")

        def render_progress(fraction: float, detail: str) -> None:
            percent = 55 + int(max(0.0, min(1.0, fraction)) * 44)
            self.report(percent, f"{action} — {detail}")

        ffmpeg.set_progress(video_dur, render_progress)
        render_started = time.monotonic()
        try:
            ffmpeg.render_final(
                video_path, str(dub_wav), str(partial_path),
                target_duration=video_dur,
                subtitle_mode=mode,
                subtitle_path=str(subtitle_path) if subtitle_path else None,
                blur_region=blur_region if blur_original else None,
                blur_intervals=blur_intervals if blur_original else None,
                blur_mask_ass=str(blur_mask) if blur_original else None,
                bg_volume=getattr(config, "bg_volume", 0) / 100.0,
                voice_volume=getattr(config, "voice_volume", 100) / 100.0,
            )
            self.report(99, "Kiểm tra luồng hình, âm thanh và thời lượng file xuất...")
            ffmpeg.validate_output(
                str(partial_path), expected_duration=video_dur,
                require_video=True, require_audio=True,
            )
            os.replace(partial_path, final_path)
        except FFmpegError as exc:
            partial_path.unlink(missing_ok=True)
            raise ModuleError(f"Xuất video thất bại: {exc}") from exc
        finally:
            ffmpeg.clear_progress()
            dub_wav.unlink(missing_ok=True)

        note = f" ({len(warnings)} câu tràn nhẹ)" if warnings else ""
        elapsed = time.monotonic() - started_at
        render_elapsed = max(0.001, time.monotonic() - render_started)
        realtime = video_dur / render_elapsed
        self.report(
            100,
            f"Hoàn tất sau {elapsed / 60:.1f} phút "
            f"({realtime:.2f}x thời gian thực): {final_path}{note}",
        )
        return {"final_video": str(final_path)}

    # ---------- Dựng audio timeline ----------

    def _build_dub_audio(self, segments: list[Segment],
                         voice_files: dict[int, str], video_dur: float,
                         out_wav: Path, ffmpeg: FFmpeg, config: Any,
                         tmp_dir: Path) -> list[str]:
        """Dựng track audio dài bằng video: im lặng + đặt voice đúng mốc SRT.

        Voice dài hơn nhẹ thì giữ nguyên và tràn sang sau. Voice overlap vừa/lớn
        được xử lý theo cụm liền kề: tận dụng khoảng trống gần đó, tăng speed nhẹ,
        phần còn dư mới overlap/mix thay vì bị cắt.
        Nếu câu sau chồng lên tail câu trước, mix thêm câu sau để cả hai cùng nghe được.
        Trả danh sách cảnh báo câu tràn.
        """
        import numpy as np  # noqa: PLC0415 - có sẵn theo torch

        accept_overlap = float(getattr(config, "merge_accept_overlap", 0.10))
        warn_overlap = float(getattr(config, "merge_warn_overlap", 0.25))
        min_gap = float(getattr(config, "merge_min_gap", 0.04))
        max_shift = float(getattr(config, "merge_max_audio_shift", 0.20))
        # Dùng đúng tùy chọn "Voice co tối đa" trên giao diện. Tăng tốc bằng
        # atempo nên giữ cao độ; không kéo hình hoặc cắt khoảng lặng trong voice.
        mild_speed_max = max(1.0, min(2.0, float(
            getattr(
                config, "speed_max",
                getattr(config, "merge_voice_speed_max", 1.50),
            )
        )))
        ordered = sorted(
            (s for s in segments
             if voice_files.get(s.line) and Path(voice_files[s.line]).exists()),
            key=lambda s: s.start,
        )
        if not ordered:
            raise ModuleError("Không có dòng nào có voice để lồng tiếng.")

        total_len = max(1, int(round((video_dur + 0.5) * DUB_SR)))
        merged = np.zeros(total_len, dtype=np.float32)
        warnings: list[str] = []
        missing = [s.line for s in segments if s.line not in voice_files]
        if missing:
            preview = ", ".join(map(str, missing[:20]))
            warnings.append(
                f"Thiếu file voice ở {len(missing)} dòng ({preview}); các dòng này không có tiếng."
            )
        items = []

        for i, seg in enumerate(ordered):
            self.check_cancelled()
            wav = voice_files[seg.line]
            audio = self._load_wav_mono(wav)
            dur = len(audio) / DUB_SR
            items.append({
                "seg": seg,
                "wav": wav,
                "audio": audio,
                "dur": dur,
                "source_dur": dur,
                "start": float(seg.start),
                "speed": 1.0,
            })

        # Voice NGẮN hơn slot: giữ nguyên tốc độ — phần dư là khoảng lặng tự
        # nhiên của track (đã thử giãn chậm, nghe tệ nên bỏ hẳn). Chỉ voice DÀI
        # mới được resolver xử lý: mượn khoảng trống rồi tăng tốc nhẹ.
        self._resolve_voice_overlaps(
            items, video_dur, ffmpeg, tmp_dir, warnings, accept_overlap,
            warn_overlap, min_gap, max_shift, mild_speed_max,
        )

        for item in items:
            seg = item["seg"]
            audio = item["audio"]
            start = int(round(item["start"] * DUB_SR))
            if item["speed"] > 1.01:
                warnings.append(
                    f"Dòng {seg.line}: tăng speed nhẹ {item['speed']:.2f}x "
                    "để giảm overlap."
                )
            if abs(item["start"] - seg.start) > 0.001:
                warnings.append(
                    f"Dòng {seg.line}: dịch audio {item['start'] - seg.start:+.2f}s "
                    "để giảm overlap."
                )

            audio = self._fade_edges(audio)
            # Không hạ mất tail của câu trước. Các bước shift/speed đã giảm
            # overlap trước; phần còn lại được cộng đủ rồi qua limiter mềm.
            merged = self._mix_audio(merged, audio, start, duck_existing=1.0)

        peak = float(np.max(np.abs(merged))) if merged.size else 0.0
        if peak > 1.0:
            # Limiter mềm cục bộ: overlap lớn không kéo nhỏ âm lượng của cả video.
            hot = np.abs(merged) > 0.98
            merged[hot] = np.tanh(merged[hot])
        pcm = (np.clip(merged, -1.0, 1.0) * 32767.0).astype("<i2")
        with wave.open(str(out_wav), "wb") as f:
            f.setnchannels(1)
            f.setsampwidth(2)
            f.setframerate(DUB_SR)
            f.writeframes(pcm.tobytes())
        return warnings

    def _resolve_voice_overlaps(self, items: list[dict], video_dur: float,
                                ffmpeg: FFmpeg, tmp_dir: Path, warnings: list[str],
                                accept_overlap: float, warn_overlap: float,
                                min_gap: float, max_shift: float,
                                mild_speed_max: float) -> None:
        """Giảm overlap theo cụm hội thoại liền kề, không coi overlap nhỏ là lỗi."""
        if not items:
            return

        def source_duration(item: dict) -> float:
            return max(
                0.001,
                float(item.get("source_dur", item["dur"] * item.get("speed", 1.0))),
            )

        def speed_to(item: dict, target_dur: float, cap: float, suffix: str) -> bool:
            """Co từ file voice gốc tới duration đích, giữ cao độ bằng atempo."""
            target_dur = max(0.15, float(target_dur))
            speed = min(source_duration(item) / target_dur, cap)
            if speed <= item.get("speed", 1.0) + 0.015 or speed <= 1.02:
                return False
            sped = tmp_dir / f"_smart_fit_{item['seg'].line}_{suffix}.wav"
            try:
                ffmpeg.speed_audio(item["wav"], speed, str(sped))
                item["audio"] = self._load_wav_mono(str(sped))
                item["dur"] = len(item["audio"]) / DUB_SR
                item["speed"] = speed
                return True
            except FFmpegError as exc:
                warnings.append(
                    f"Dòng {item['seg'].line}: tăng speed tự động lỗi: {exc}"
                )
                return False
            finally:
                sped.unlink(missing_ok=True)

        for pass_no in range(6):
            changed = False
            for i in range(len(items) - 1):
                self.check_cancelled()
                left = items[i]
                right = items[i + 1]
                overlap = (left["start"] + left["dur"]) - right["start"]
                if overlap <= accept_overlap:
                    continue

                need = overlap - accept_overlap

                # 1) Tận dụng khoảng trống trước câu đang tràn bằng cách cho nó vào sớm nhẹ.
                prev_end = (
                    items[i - 1]["start"] + items[i - 1]["dur"]
                    if i > 0 else 0.0
                )
                earliest = max(prev_end + min_gap, left["seg"].start - max_shift, 0.0)
                shift_left = min(need, max(0.0, left["start"] - earliest))
                if shift_left > 0.005:
                    left["start"] -= shift_left
                    need -= shift_left
                    changed = True

                # 2) Tận dụng khoảng trống sau câu kế bằng cách cho câu kế vào muộn nhẹ.
                next_start = items[i + 2]["start"] if i + 2 < len(items) else video_dur
                latest = min(
                    right["seg"].start + max_shift,
                    max(right["start"], next_start - right["dur"] - min_gap),
                )
                shift_right = min(need, max(0.0, latest - right["start"]))
                if shift_right > 0.005:
                    right["start"] += shift_right
                    need -= shift_right
                    changed = True

                # 3) Tăng speed nhẹ câu trước để giảm tail dài.
                overlap = (left["start"] + left["dur"]) - right["start"]
                if overlap > accept_overlap:
                    target_dur = max(0.15, right["start"] + accept_overlap - left["start"])
                    if speed_to(left, target_dur, mild_speed_max, str(pass_no)):
                        changed = True

            if not changed:
                break

        # Bảo vệ mép cuối video: đẩy câu cuối vào khoảng trống phía trước trước khi
        # để muxer -shortest cắt mất đuôi. Nếu vẫn không đủ, tăng tốc nhẹ câu cuối.
        last = items[-1]
        overflow = last["start"] + last["dur"] - video_dur
        if overflow > 0.01:
            prev_end = (
                items[-2]["start"] + items[-2]["dur"] + min_gap
                if len(items) > 1 else 0.0
            )
            earliest = max(prev_end, last["seg"].start - max_shift, 0.0)
            shift = min(overflow, max(0.0, last["start"] - earliest))
            if shift > 0.005:
                last["start"] -= shift
                overflow -= shift
            if overflow > 0.01:
                speed_to(last, video_dur - last["start"], mild_speed_max, "last")

            # Nếu trần speed thường vẫn chưa đủ, dùng thêm khoảng trước câu cuối,
            # kể cả phải overlap. Đây là lựa chọn duy nhất để giữ nguyên hình mà
            # không cắt đuôi voice.
            overflow = last["start"] + last["dur"] - video_dur
            if overflow > 0.01:
                last["start"] = max(0.0, last["start"] - overflow)

            # Trường hợp cực đoan: co khẩn cấp tối đa 2x để bảo vệ đuôi.
            overflow = last["start"] + last["dur"] - video_dur
            if overflow > 0.01:
                speed_to(last, video_dur - last["start"], 2.0, "last_emergency")

        final_overflow = items[-1]["start"] + items[-1]["dur"] - video_dur
        if final_overflow > 0.01:
            warnings.append(
                f"Dòng {items[-1]['seg'].line}: voice vượt cuối video "
                f"{final_overflow:.2f}s dù đã co tối đa; cần rút gọn câu để tránh mất đuôi."
            )

        for i in range(len(items) - 1):
            left = items[i]
            right = items[i + 1]
            overlap = (left["start"] + left["dur"]) - right["start"]
            if overlap <= accept_overlap:
                continue
            ms = int(round(overlap * 1000))
            pair = f"dòng {left['seg'].line} -> {right['seg'].line}"
            if overlap <= warn_overlap:
                warnings.append(f"Cảnh báo overlap {pair}: {ms}ms, vẫn trong mức tạm chấp nhận.")
            else:
                warnings.append(
                    f"Lỗi overlap {pair}: {ms}ms sau auto xử lý. "
                    "Hai voice vẫn được giữ đủ và mix chồng; nên rút gọn câu nếu nghe khó."
                )

    @staticmethod
    def _fade_edges(audio, fade_ms: float = 12.0):
        """Fade ngắn đầu/cuối voice để tránh tiếng cắt khi overlap."""
        import numpy as np  # noqa: PLC0415

        if len(audio) < 2:
            return audio
        fade_len = min(int(DUB_SR * fade_ms / 1000.0), len(audio) // 2)
        if fade_len <= 1:
            return audio
        out = audio.astype(np.float32, copy=True)
        ramp = np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
        out[:fade_len] *= ramp
        out[-fade_len:] *= ramp[::-1]
        return out

    @staticmethod
    def _mix_audio(merged, audio, start: int, duck_existing: float = 1.0):
        """Đặt voice vào timeline bằng mix, không overwrite khi tràn/overlap.

        Khi câu mới chồng lên tail cũ, cộng hai waveform để cả hai âm còn nghe được.
        Peak tổng được normalize cuối track để tránh vỡ tiếng.
        """
        import numpy as np  # noqa: PLC0415

        if start < 0:
            audio = audio[-start:]
            start = 0
        if len(audio) == 0:
            return merged

        end = start + len(audio)
        if end > len(merged):
            merged = np.pad(merged, (0, end - len(merged)))

        target = merged[start:end]
        overlap = (np.abs(target) > 1e-4) & (np.abs(audio) > 1e-4)
        if duck_existing < 0.999 and np.any(overlap):
            target[overlap] *= duck_existing
        target += audio
        merged[start:end] = target
        return merged

    @staticmethod
    def _load_wav_mono(path: str):
        """Đọc wav -> np.float32 mono ở DUB_SR bằng soundfile."""
        import numpy as np  # noqa: PLC0415

        with wave.open(str(path), "rb") as f:
            n_ch = f.getnchannels()
            rate = f.getframerate()
            width = f.getsampwidth()
            frames = f.readframes(f.getnframes())
        dtype = {1: np.int8, 2: np.int16, 4: np.int32}.get(width, np.int16)
        data = np.frombuffer(frames, dtype=dtype).astype(np.float32)
        if width == 1:      # 8-bit PCM là unsigned, giữa ở 128
            data = (data - 128.0) / 128.0
        else:
            data = data / float(1 << (8 * width - 1))
        if n_ch > 1:
            data = data.reshape(-1, n_ch).mean(axis=1)
        if rate != DUB_SR and len(data) > 1:
            # Resample tuyến tính đơn giản (voice OmniVoice vốn đã 24 kHz).
            new_n = int(round(len(data) * DUB_SR / rate))
            data = np.interp(
                np.linspace(0, len(data) - 1, new_n, dtype=np.float32),
                np.arange(len(data), dtype=np.float32), data,
            ).astype(np.float32)
        return data

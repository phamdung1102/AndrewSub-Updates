"""Targeted ASR rescue for uncertain OCR subtitle candidates.

OCR remains the source of truth.  This module only sends a compact audio made
from a small set of suspicious time ranges, then maps ASR word timestamps back
to the original video.  It must never turn a normal OCR run into a full-video
ASR job.
"""

from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable, Iterable

from vicdub.utils.segmenter import Word
from vicdub.utils.subtitles import Segment

logger = logging.getLogger(__name__)

_CJK_RE = re.compile(r"[\u3400-\u9fff]")


@dataclass(frozen=True)
class RescueWindow:
    source_start: float
    source_end: float
    compact_start: float
    compact_end: float


def _normalise_cjk(value: str) -> str:
    return "".join(_CJK_RE.findall(value or ""))


def visual_micro_scan_windows(
    segments: list[Segment],
    mapped_words: list[Word],
    *,
    max_windows: int = 20,
    max_total: float = 36.0,
) -> list[tuple[float, float]]:
    """Return tiny visual re-scan windows for speech OCR does not explain.

    ASR is only a selector here.  A word is ignored when an overlapping OCR
    row already explains it.  Remaining spans are padded just enough for the
    visual detector to see the caption before and after the suspected change.
    The strict time budget prevents this optional pass becoming a second scan
    of the movie.
    """
    if not segments or not mapped_words:
        return []

    ranked: list[tuple[float, float, float]] = []
    for word in mapped_words:
        spoken = _normalise_cjk(word.text)
        start = max(0.0, float(word.start))
        end = max(start, float(word.end))
        if not spoken or end <= start or end - start > 3.5:
            continue
        overlapping = [
            segment for segment in segments
            if segment.end > start - 0.08 and segment.start < end + 0.08
        ]
        explained = False
        for segment in overlapping:
            visual = _normalise_cjk(segment.text)
            if not visual:
                continue
            similarity = SequenceMatcher(None, spoken, visual).ratio()
            if spoken in visual or visual in spoken or similarity >= 0.76:
                explained = True
                break
        if explained:
            continue

        # Short replies are the main target.  A word inside a long OCR row is
        # also valuable because that row can hide several quick hard captions.
        score = 4.0 / max(1, len(spoken))
        if not overlapping:
            score += 2.0
        elif any(segment.duration >= 1.15 for segment in overlapping):
            score += 1.5
        ranked.append((score, max(0.0, start - 0.32), end + 0.32))

    # A long visual row may already "explain" one ASR phrase while hiding two
    # or more quick captions around it.  The word-by-word selector above then
    # has no reason to revisit the whole row.  Add only rows with independent
    # speech evidence for at least two distinct phrases.  This remains a tiny
    # selector: the visual/OCR pass below is still the final judge.
    for segment in segments:
        duration = float(segment.end) - float(segment.start)
        if duration < 1.45 or duration > 6.5:
            continue
        visual = _normalise_cjk(segment.text)
        words = [
            word for word in mapped_words
            if float(word.end) > float(segment.start) - 0.10
            and float(word.start) < float(segment.end) + 0.10
            and _normalise_cjk(word.text)
        ]
        distinct = []
        for word in words:
            spoken = _normalise_cjk(word.text)
            if spoken and spoken not in distinct:
                distinct.append(spoken)
        if len(distinct) < 2:
            continue
        unexplained = [
            spoken for spoken in distinct
            if not visual
            or (
                spoken not in visual
                and visual not in spoken
                and SequenceMatcher(None, spoken, visual).ratio() < 0.76
            )
        ]
        if not unexplained:
            continue
        score = 5.0 + min(3.0, duration / 2.0) + min(2.0, len(unexplained) * 0.5)
        ranked.append((
            score,
            max(0.0, float(segment.start) - 0.24),
            float(segment.end) + 0.24,
        ))

    # Select by value first, then restore timeline order and merge only truly
    # adjacent words.  This keeps late-film one-word cues from being starved.
    selected: list[tuple[float, float]] = []
    used = 0.0
    for _score, start, end in sorted(ranked, reverse=True):
        length = end - start
        if selected and used + length > max_total:
            continue
        selected.append((start, end))
        used += length
        if len(selected) >= max_windows:
            break
    selected.sort()

    merged: list[list[float]] = []
    for start, end in selected:
        if merged and start - merged[-1][1] <= 0.18 and end - merged[-1][0] <= 3.2:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [(start, end) for start, end in merged]


def _merged_candidate_score(sub, text: str) -> float:
    """Rank text-bearing visual tracks that may hide several fast captions.

    A normal hard-sub cue has a fairly stable relationship between visible
    character count and duration.  A long track containing very little OCR
    text is worth listening to because the representative frame may contain
    only one of several captions that changed inside that visual track.

    This is deliberately only a request selector.  It never changes OCR text
    by itself; the ASR result must later prove an internal pause and agree with
    at least one OCR phrase.
    """
    duration = max(0.0, float(sub.end) - float(sub.start))
    cjk = _normalise_cjk(text)
    if duration < 1.0 or not cjk:
        return 0.0
    seconds_per_char = duration / max(1, len(cjk))
    if duration < 2.8 and seconds_per_char < 0.26:
        return 0.0
    return (
        min(4.0, duration) * 0.55
        + min(1.2, seconds_per_char) * 2.4
        + (0.7 if duration >= 2.8 else 0.0)
    )


def _take_ranked_candidates(
    ranked: Iterable[tuple[float, int]],
    subs,
    *,
    limit: int,
    audio_budget: float,
    padding: float = 0.8,
) -> list[int]:
    """Take highest-value candidates before restoring timeline order.

    ``_merge_ranges`` sorts by timestamp.  Capping only after that sort used to
    let early low-value rows consume the whole audio budget, starving strong
    candidates near the end of a long film.
    """
    selected: list[int] = []
    used = 0.0
    for _score, index in sorted(ranked, reverse=True):
        if index in selected:
            continue
        duration = max(0.0, float(subs[index].end) - float(subs[index].start))
        estimated = duration + padding * 2.0
        if selected and used + estimated > audio_budget:
            continue
        selected.append(index)
        used += estimated
        if len(selected) >= limit:
            break
    return selected


def _merge_ranges(
    ranges: Iterable[tuple[float, float]],
    *,
    padding: float = 0.8,
    join_gap: float = 1.0,
    max_window: float = 14.0,
    max_total: float = 90.0,
) -> list[tuple[float, float]]:
    expanded = sorted(
        (max(0.0, float(start) - padding), max(0.0, float(end) + padding))
        for start, end in ranges
        if float(end) > float(start)
    )
    merged: list[list[float]] = []
    for start, end in expanded:
        if (
            merged
            and start - merged[-1][1] <= join_gap
            and end - merged[-1][0] <= max_window
        ):
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, min(end, start + max_window)])

    kept: list[tuple[float, float]] = []
    used = 0.0
    for start, end in merged:
        remaining = max_total - used
        if remaining <= 0:
            break
        end = min(end, start + remaining)
        if end - start >= 0.25:
            kept.append((start, end))
            used += end - start
    return kept


def _build_compact_audio(
    video_path: str,
    ffmpeg_bin: str,
    ranges: list[tuple[float, float]],
    output_path: Path,
    *,
    separator: float = 0.6,
) -> list[RescueWindow]:
    """Extract all ranges in one ffmpeg process and return timeline mapping."""
    if not ranges:
        return []

    filters: list[str] = []
    concat_inputs: list[str] = []
    windows: list[RescueWindow] = []
    compact_cursor = 0.0
    for index, (start, end) in enumerate(ranges):
        duration = max(0.0, end - start)
        filters.append(
            f"[0:a]atrim=start={start:.6f}:end={end:.6f},"
            f"asetpts=PTS-STARTPTS,aresample=16000,"
            f"aformat=sample_fmts=s16:channel_layouts=mono[a{index}]"
        )
        concat_inputs.append(f"[a{index}]")
        windows.append(
            RescueWindow(
                source_start=start,
                source_end=end,
                compact_start=compact_cursor,
                compact_end=compact_cursor + duration,
            )
        )
        compact_cursor += duration
        if index < len(ranges) - 1:
            filters.append(
                f"anullsrc=r=16000:cl=mono:d={separator:.3f}[s{index}]"
            )
            concat_inputs.append(f"[s{index}]")
            compact_cursor += separator

    filters.append(
        "".join(concat_inputs)
        + f"concat=n={len(concat_inputs)}:v=0:a=1[out]"
    )
    command = [
        ffmpeg_bin or "ffmpeg",
        "-hide_banner", "-loglevel", "error", "-y",
        "-i", video_path,
        "-filter_complex", ";".join(filters),
        "-map", "[out]",
        "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le",
        str(output_path),
    ]
    kwargs = {}
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    subprocess.run(command, check=True, capture_output=True, **kwargs)
    return windows


def _map_words_to_source(
    words: Iterable[Word], windows: list[RescueWindow]
) -> list[Word]:
    mapped: list[Word] = []
    for word in words:
        midpoint = (float(word.start) + float(word.end)) / 2.0
        window = next(
            (
                item for item in windows
                if item.compact_start <= midpoint <= item.compact_end
            ),
            None,
        )
        if window is None:
            continue
        offset = window.source_start - window.compact_start
        start = max(window.source_start, float(word.start) + offset)
        end = min(window.source_end, float(word.end) + offset)
        if end <= start:
            continue
        mapped.append(
            Word(
                text=word.text,
                start=start,
                end=end,
                confidence=float(getattr(word, "confidence", 0.0) or 0.0),
                source="ocr_asr_rescue",
                warning=str(getattr(word, "warning", "") or ""),
            )
        )
    return sorted(mapped, key=lambda item: (item.start, item.end))


def _assign_words_once(
    mapped_words: Iterable[Word],
    candidate_indexes: Iterable[int],
    subs,
    *,
    edge_tolerance: float = 0.12,
) -> dict[int, list[Word]]:
    """Give every ASR token to at most one visual candidate.

    The old overlap query could reuse one broad ASR token for two neighbouring
    rows, producing fragments such as ``A...`` and ``...A``.  Midpoint
    ownership is deterministic and prevents that duplication.
    """
    indexes = sorted({int(index) for index in candidate_indexes})
    owned: dict[int, list[Word]] = {index: [] for index in indexes}
    for word in mapped_words:
        midpoint = (float(word.start) + float(word.end)) / 2.0
        choices: list[tuple[float, float, int]] = []
        for index in indexes:
            sub = subs[index]
            start = float(sub.start)
            end = float(sub.end)
            if midpoint < start - edge_tolerance or midpoint > end + edge_tolerance:
                continue
            center = (start + end) / 2.0
            overlap = max(
                0.0,
                min(float(word.end), end) - max(float(word.start), start),
            )
            choices.append((-overlap, abs(midpoint - center), index))
        if choices:
            _neg_overlap, _distance, owner = min(choices)
            owned[owner].append(word)
    return owned


def _split_extra_words(words: list[Word]) -> list[list[Word]]:
    """Split only ASR text outside the OCR-matching span.

    Punctuation is the strongest boundary.  A short timestamp gap is accepted
    when either side is already a multi-character phrase, while adjacent
    one-character name tokens stay together (for example ``顾`` + ``太``).
    """
    if not words:
        return []
    groups: list[list[Word]] = []
    current: list[Word] = []
    punctuation = "，。！？!?；;：:"
    for word in words:
        if current:
            previous = current[-1]
            gap = float(word.start) - float(previous.end)
            previous_text = str(previous.text or "").strip()
            previous_cjk = _normalise_cjk(previous_text)
            current_cjk = _normalise_cjk(word.text)
            boundary = (
                previous_text.endswith(tuple(punctuation))
                or (
                    gap >= 0.14
                    and (len(previous_cjk) >= 2 or len(current_cjk) >= 2)
                )
            )
            if boundary:
                groups.append(current)
                current = []
        current.append(word)
    if current:
        groups.append(current)
    return groups


def _split_word_sentences(word: Word) -> list[Word]:
    """Split an ASR span containing several punctuated sentences.

    Some providers return ``累死了。我也想冲一下。`` as one word span.
    Preserve both captions and estimate the internal boundary proportionally;
    the result remains marked for review by the caller.
    """
    raw = str(word.text or "").strip()
    parts = [item.strip() for item in re.split(r"(?<=[。！？!?])", raw) if item.strip()]
    if len(parts) < 2:
        return [word]
    weights = [max(1, len(_normalise_cjk(item))) for item in parts]
    total = sum(weights)
    duration = max(0.0, float(word.end) - float(word.start))
    cursor = float(word.start)
    output: list[Word] = []
    for index, (part, weight) in enumerate(zip(parts, weights)):
        end = float(word.end) if index == len(parts) - 1 else cursor + duration * weight / total
        output.append(
            Word(
                text=part,
                start=cursor,
                end=end,
                confidence=float(getattr(word, "confidence", 0.0) or 0.0),
                source=str(getattr(word, "source", "") or ""),
                warning=str(getattr(word, "warning", "") or ""),
            )
        )
        cursor = end
    return output


def _canonical_short_text(value: str) -> str:
    value = _normalise_cjk(value)
    return value.translate(str.maketrans("〇一二三四五六七八九", "0123456789"))


def _extra_is_redundant(value: str, source: str, neighbours: Iterable[str]) -> bool:
    """Reject ASR fragments already represented by OCR around the cue."""
    cjk = _normalise_cjk(value)
    if not cjk:
        return True
    # One-character recovered rows are extremely noisy.  Keep only common
    # standalone spoken interjections; numbers/names require visual OCR.
    if len(cjk) == 1 and cjk not in "喂嗯啊哦哎唉哼哈":
        return True
    canonical = _canonical_short_text(value)
    comparisons = [source, *neighbours]
    for other in comparisons:
        other_canonical = _canonical_short_text(other)
        if not other_canonical:
            continue
        if canonical in other_canonical or other_canonical in canonical:
            return True
        similarity = SequenceMatcher(None, canonical, other_canonical).ratio()
        if len(canonical) >= 3 and len(other_canonical) >= 3:
            # ASR commonly substitutes the first character of a Chinese name
            # (浩/灏) while the rest of the phrase is clearly the same.
            similarity = max(
                similarity,
                SequenceMatcher(None, canonical[1:], other_canonical[1:]).ratio(),
            )
        if similarity >= 0.76:
            return True
    return False


def _transcribe_compact(
    audio_path: str,
    config,
    report: Callable[[int, str], None],
    cancelled: Callable[[], bool],
):
    provider = str(getattr(config, "asr_provider", "qwen") or "qwen")
    if provider == "whisper_server":
        from vicdub.api.whisper_asr_client import (  # noqa: PLC0415
            transcribe_video_with_spans,
        )
    else:
        from vicdub.api.qwen_asr_client import (  # noqa: PLC0415
            transcribe_video_with_spans,
        )
    return transcribe_video_with_spans(audio_path, config, report, cancelled)


def rescue_ocr_candidates(
    *,
    video_path: str,
    ffmpeg_bin: str,
    config,
    subs,
    texts: list[str],
    warnings: list[str],
    failed_indexes: Iterable[int],
    likely_blank_scores: dict[int, float],
    progress: Callable[[int, str], None],
    cancelled: Callable[[], bool],
) -> tuple[list[str], list[str], set[int], list[Word]]:
    """Recover strong blank candidates and return ASR words for split checks."""
    if config is None or cancelled():
        return texts, warnings, set(), []
    configured = getattr(config, "asr_configured", None)
    if not callable(configured) or not configured():
        return texts, warnings, set(), []

    failed_set = {int(index) for index in failed_indexes}
    ranked_blanks = sorted(
        (
            (float(score), int(index))
            for index, score in likely_blank_scores.items()
            if int(index) in failed_set
            and float(score) > 0.0
            and 0.20 <= float(subs[int(index)].end) - float(subs[int(index)].start) <= 2.50
        ),
        reverse=True,
    )
    max_blank_candidates = max(6, min(40, int(len(subs) * 0.06) + 1))
    blank_indexes = _take_ranked_candidates(
        ranked_blanks,
        subs,
        limit=max_blank_candidates,
        audio_budget=62.0,
    )
    blank_set = set(blank_indexes)

    # OCR-filled rows were previously invisible to the rescue pass.  Include a
    # small, separately-budgeted lane for tracks whose duration/text ratio
    # suggests that several very fast captions may have been collapsed into
    # one representative frame.
    ranked_merges = [
        (_merged_candidate_score(sub, texts[index]), index)
        for index, sub in enumerate(subs)
        if index not in failed_set and index < len(texts)
    ]
    ranked_merges = [item for item in ranked_merges if item[0] > 0.0]
    merge_indexes = _take_ranked_candidates(
        ranked_merges,
        subs,
        # Even a two-hour film normally contributes only 1–3 minutes here.
        # Cover the whole timeline instead of keeping only the earliest/top
        # handful, otherwise a valid one-word cue late in the film is missed.
        limit=64,
        audio_budget=175.0,
    )
    candidate_indexes = sorted(set(blank_indexes + merge_indexes))
    ranges = _merge_ranges(
        ((subs[index].start, subs[index].end) for index in candidate_indexes),
        max_total=220.0,
    )
    if not ranges:
        return texts, warnings, set(), []

    try:
        with TemporaryDirectory(prefix="vicdub_ocr_asr_") as work:
            compact = Path(work) / "repair.wav"
            progress(97, "Đang kiểm tra các vùng nhận diện chưa chắc chắn bằng âm thanh...")
            windows = _build_compact_audio(
                video_path, ffmpeg_bin, ranges, compact,
            )
            transcript = _transcribe_compact(
                str(compact),
                config,
                lambda _pct, _message: None,
                cancelled,
            )
            mapped_words = _map_words_to_source(transcript.words, windows)
    except Exception as exc:  # OCR output must survive an optional ASR failure.
        logger.warning("Bỏ qua lượt ASR cứu OCR: %s", exc)
        return texts, warnings, set(), []

    rescued: set[int] = set()
    owned_words = _assign_words_once(mapped_words, candidate_indexes, subs)
    for index in sorted(blank_set):
        sub = subs[index]
        matching = owned_words.get(index, [])
        if not matching:
            continue
        # Reject a broad phrase whose timestamp spills across neighbouring
        # visual rows.  It cannot be divided safely without character timing.
        spoken_start = min(float(word.start) for word in matching)
        spoken_end = max(float(word.end) for word in matching)
        if (
            spoken_start < float(sub.start) - 0.25
            or spoken_end > float(sub.end) + 0.25
        ):
            continue
        value = "".join(word.text.strip() for word in matching if word.text.strip())
        cjk = _normalise_cjk(value)
        if not cjk:
            continue
        # Audio is a selector, never sufficient evidence for a one-glyph final
        # subtitle.  Those rows must be confirmed by the later visual micro
        # pass, preventing isolated ASR/OCR noise from entering the timeline.
        if len(cjk) == 1:
            continue
        # A visual detector candidate plus overlapping speech is enough to
        # restore the row, but it remains red for human verification.
        texts[index] = value.strip()
        warnings[index] = (
            "Khôi phục từ âm thanh tại vùng OCR rỗng; cần kiểm tra lại chữ."
        )
        rescued.add(index)
    return texts, warnings, rescued, mapped_words


def split_strongly_confirmed_merges(
    segments: list[Segment], mapped_words: list[Word]
) -> tuple[list[Segment], int]:
    """Recover text hidden before/after an OCR phrase without shredding it.

    ASR token timestamps often contain artificial 0.15–0.30s gaps inside one
    sentence.  Treating every gap as a subtitle boundary produced fragments.
    Instead, align a contiguous ASR token span to the exact OCR phrase and only
    emit genuinely extra tokens before/after it.  A full-row split is retained
    only for a much stronger (>=0.48s) pause.
    """
    if not mapped_words:
        return segments, 0
    output: list[Segment] = []
    changed = 0
    for segment_index, segment in enumerate(segments):
        source = _normalise_cjk(segment.text)
        if segment.duration < 1.0 or not source:
            output.append(segment)
            continue
        words = [
            word for word in mapped_words
            if word.end > segment.start and word.start < segment.end
        ]
        words = [
            word for word in words
            if _normalise_cjk(word.text)
        ]
        words = [piece for word in words for piece in _split_word_sentences(word)]
        if len(words) < 2:
            output.append(segment)
            continue

        token_texts = [_normalise_cjk(word.text) for word in words]
        full_text = "".join(token_texts)

        # Find the contiguous token span that best explains the OCR string.
        # Prefer the closest length when similarities tie, so a broad sentence
        # cannot swallow a short exact OCR phrase.
        best_key: tuple[float, int, int, int] | None = None
        best_span: tuple[int, int] | None = None
        for start_index in range(len(words)):
            value = ""
            for stop_index in range(start_index + 1, len(words) + 1):
                value += token_texts[stop_index - 1]
                similarity = SequenceMatcher(None, source, value).ratio()
                key = (
                    similarity,
                    -abs(len(value) - len(source)),
                    -(stop_index - start_index),
                    -start_index,
                )
                if best_key is None or key > best_key:
                    best_key = key
                    best_span = (start_index, stop_index)
        if best_key is None or best_span is None:
            output.append(segment)
            continue
        best_similarity = best_key[0]
        match_start, match_end = best_span
        prefix = words[:match_start]
        matched = words[match_start:match_end]
        suffix = words[match_end:]
        extra_text = _normalise_cjk(
            "".join(word.text for word in [*prefix, *suffix])
        )
        supplemental = (
            segment.duration >= 1.20
            and best_similarity >= 0.78
            and bool(extra_text)
            and len(full_text) >= len(source) + 1
        )

        groups: list[tuple[list[Word], str, bool]] = []
        if supplemental:
            for group in _split_extra_words(prefix):
                groups.append((group, "".join(word.text.strip() for word in group), True))
            groups.append((matched, segment.text.strip(), False))
            for group in _split_extra_words(suffix):
                groups.append((group, "".join(word.text.strip() for word in group), True))
        else:
            # If ASR and OCR describe exactly the same text, split only at a
            # real pause.  This preserves the older safe long-row correction
            # without treating tokenization gaps as subtitle boundaries.
            full_similarity = SequenceMatcher(None, source, full_text).ratio()
            if full_similarity < 0.62:
                output.append(segment)
                continue
            paused_groups: list[list[Word]] = []
            current: list[Word] = []
            for word in words:
                if current and word.start - current[-1].end >= 0.48:
                    paused_groups.append(current)
                    current = []
                current.append(word)
            if current:
                paused_groups.append(current)
            if len(paused_groups) < 2:
                output.append(segment)
                continue
            groups = [
                (group, "".join(word.text.strip() for word in group), False)
                for group in paused_groups
            ]

        replacements: list[Segment] = []
        neighbour_texts = [
            segments[index].text
            for index in (segment_index - 1, segment_index + 1)
            if 0 <= index < len(segments)
        ]
        for group, text, is_extra in groups:
            if is_extra and _extra_is_redundant(text, source, neighbour_texts):
                continue
            start = max(segment.start, group[0].start)
            end = min(segment.end, group[-1].end)
            if not text or end - start < 0.08:
                continue
            replacements.append(
                Segment(
                    line=0,
                    start=start,
                    end=end,
                    text=text,
                    speaker=segment.speaker,
                    gender=segment.gender,
                    voice=segment.voice,
                    ocr_warning=(
                        "Đã tách câu OCR nghi gộp theo mốc âm thanh; cần kiểm tra."
                    ),
                )
            )
        if len(replacements) >= 2:
            output.extend(replacements)
            changed += 1
        else:
            output.append(segment)

    output.sort(key=lambda item: (item.start, item.end))
    for line, segment in enumerate(output, 1):
        segment.line = line
    return output, changed

"""
Shared HTTP response handling for CapCut API calls.
"""

from typing import Any, Dict

from capcut_tts_api.exceptions import CapCutAPIError

_SECRET_KEYS = frozenset(
    {"access_key_id", "secret_access_key", "session_token", "token", "auth"}
)


def redact(obj: Any) -> Any:
    """Mask credential-bearing fields so they never reach logs or tracebacks."""
    if isinstance(obj, dict):
        return {
            k: ("***" if k.lower() in _SECRET_KEYS and v else redact(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    return obj


def checked_json_response(resp: Any, label: str) -> Dict[str, Any]:
    """Return the decoded JSON body, raising CapCutAPIError on any failure."""
    try:
        data = resp.json()
    except Exception as exc:
        raise CapCutAPIError(
            f"{label} returned non-JSON HTTP {resp.status_code}: {resp.text[:500]}",
            status_code=resp.status_code,
        ) from exc
    if resp.status_code >= 400:
        raise CapCutAPIError(
            f"{label} HTTP {resp.status_code}: {redact(data)}",
            status_code=resp.status_code,
            response_data=data,
        )
    # The API answers HTTP 200 with a business status in `ret`; "0" means success.
    ret = str(data.get("ret", "0"))
    if ret not in ("0", ""):
        raise CapCutAPIError(
            f"{label} API error ret={ret}: {data.get('errmsg') or redact(data)}",
            status_code=resp.status_code,
            response_data=data,
        )
    return data

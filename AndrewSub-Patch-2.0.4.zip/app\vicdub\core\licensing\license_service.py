"""AndrewSub license service: machine id, local store, online activation."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import subprocess
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

import requests

from vicdub import __version__
from vicdub.config import APP_ROOT, AppConfig
from vicdub.core.licensing.license_token import LicenseError, parse_datetime, verify_token


class LicenseService:
    """Validate and persist machine-locked AndrewSub licenses."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.machine_id = self._build_machine_id()
        self.store_path = Path(config.data_dir) / "license.json"
        self.heartbeat_path = Path(config.data_dir) / "license_heartbeat.json"

    def status(self) -> dict[str, Any]:
        token = self._read_token()
        result: dict[str, Any] = {
            "machine_id": self.machine_id,
            "valid": False,
            "status": "inactive",
            "message": "Chưa kích hoạt bản quyền.",
            "license": {},
        }
        if not token:
            return result
        try:
            payload = verify_token(token, self._public_key(), self.machine_id)
            result.update(
                valid=True,
                status="active",
                message="License hợp lệ.",
                license=payload,
            )
            return result
        except LicenseError as exc:
            result.update(status="invalid", message=str(exc))
            return result
        except Exception as exc:  # noqa: BLE001
            result.update(status="invalid", message=f"Không kiểm tra được license: {exc}")
            return result

    def activate_token(self, raw_token: str) -> dict[str, Any]:
        payload = verify_token(raw_token, self._public_key(), self.machine_id)
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self.store_path.write_text(
            json.dumps(
                {
                    "token": raw_token.strip(),
                    "activatedAt": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
                    "machineId": self.machine_id,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return payload

    def activate_code(self, code: str) -> dict[str, Any]:
        endpoint = self._activation_endpoint()
        if not endpoint:
            raise LicenseError("Chưa cấu hình Google Sheet/Web App cấp phép.")
        resp = requests.post(
            endpoint,
            json={
                "action": "issue",
                "code": str(code or "").strip(),
                "machineId": self.machine_id,
                "appId": "andrewsub",
                "appVersion": __version__,
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("ok"):
            raise LicenseError(str(data.get("error") or "Không cấp được license."))
        token = str(data.get("license") or data.get("token") or "")
        if not token:
            raise LicenseError("Máy chủ cấp phép không trả về license.")
        payload = self.activate_token(token)
        self.track_event("activate")
        return payload

    def clear(self) -> None:
        self.store_path.unlink(missing_ok=True)

    def track_event(self, event: str) -> None:
        endpoint = self._activation_endpoint()
        if not endpoint:
            return
        try:
            requests.post(
                endpoint,
                json={
                    "action": str(event or "heartbeat"),
                    "machineId": self.machine_id,
                    "appId": "andrewsub",
                    "appVersion": __version__,
                    "status": self.status().get("status"),
                },
                timeout=8,
            )
        except Exception:
            return

    def track_daily_heartbeat(self) -> None:
        today = date.today().isoformat()
        try:
            if self.heartbeat_path.is_file():
                data = json.loads(self.heartbeat_path.read_text(encoding="utf-8"))
                if data.get("date") == today:
                    return
            self.track_event("heartbeat")
            self.heartbeat_path.parent.mkdir(parents=True, exist_ok=True)
            self.heartbeat_path.write_text(
                json.dumps({"date": today}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            return

    def _read_token(self) -> str:
        try:
            if not self.store_path.is_file():
                return ""
            return str(json.loads(self.store_path.read_text(encoding="utf-8")).get("token") or "")
        except Exception:
            return ""

    def _public_key(self) -> bytes:
        candidates = [
            APP_ROOT / "config" / "license-public.pem",
            Path.cwd() / "config" / "license-public.pem",
            Path(__file__).resolve().parents[3] / "config" / "license-public.pem",
        ]
        for path in candidates:
            if path.is_file():
                return path.read_bytes()
        raise LicenseError("Thiếu public key bản quyền trong thư mục config.")

    def _activation_endpoint(self) -> str:
        env_value = str(os.getenv("ANDREWSUB_LICENSE_ENDPOINT") or "").strip()
        if env_value:
            return env_value
        for path in (
            Path(self.config.data_dir) / "license_config.json",
            APP_ROOT / "config" / "telemetry.json",
        ):
            if not path.is_file():
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                endpoint = str(data.get("activationEndpoint") or data.get("endpoint") or "").strip()
                if endpoint:
                    return endpoint
            except Exception:
                continue
        return ""

    def _build_machine_id(self) -> str:
        parts = []
        if platform.system().lower() == "windows":
            try:
                out = subprocess.check_output(
                    [
                        "reg",
                        "query",
                        r"HKLM\SOFTWARE\Microsoft\Cryptography",
                        "/v",
                        "MachineGuid",
                    ],
                    text=True,
                    stderr=subprocess.DEVNULL,
                    timeout=4,
                )
                for line in out.splitlines():
                    if "MachineGuid" in line:
                        parts.append(line.split()[-1])
                        break
            except Exception:
                pass
        parts.extend([socket.gethostname(), platform.platform(), platform.machine()])
        digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest().upper()[:16]
        grouped = "-".join(digest[i:i + 4] for i in range(0, 16, 4))
        return f"ASUB-{grouped}"


def format_license_until(payload: dict[str, Any]) -> str:
    try:
        return parse_datetime(str(payload.get("expiresAt", ""))).strftime("%Y-%m-%d")
    except Exception:
        return "-"

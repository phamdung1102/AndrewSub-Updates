# Hướng dẫn cấp license AndrewSub qua Google Sheet

## Cột cần điền

- `code`: bắt buộc. Đây là mã khách nhập trong app, ví dụ `KHACH001`.
- `customerName`: nên điền để nhớ khách/máy nào.
- `email`: không bắt buộc.
- `plan`: không bắt buộc, ví dụ `standard`, `pro`, `vip`.
- `days`: bắt buộc. Số ngày dùng, ví dụ `7`, `30`, `365`.

## Cột không điền tay

- `used`: app tự ghi `yes` sau khi kích hoạt.
- `machineId`: app tự ghi mã máy khách sau khi kích hoạt.
- `issuedAt`: app tự ghi ngày cấp.
- `expiresAt`: app tự ghi ngày hết hạn.

## Máy khách kích hoạt

1. Khách mở AndrewSub.
2. Vào tab `Bản quyền`.
3. Nhập `code`.
4. Bấm kích hoạt.

Mỗi `code` chỉ dùng được một lần cho một mã máy.

"""Dialog chọn vùng phụ đề trên khung hình video cho OCR.

Người dùng kéo một khung chữ nhật quanh dải phụ đề; dialog trả về toạ độ theo
tỷ lệ (x0, y0, x1, y1) trong khoảng 0-1 để lưu vào cấu hình và dùng cho crop.
"""

from __future__ import annotations

from typing import Callable

from PyQt6.QtCore import QPoint, QRect, QSize, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QImage, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QSlider, QSpinBox, QVBoxLayout, QWidget,
)

# Bề rộng hiển thị tối đa của khung xem trước.
_DISPLAY_WIDTH = 760
_DISPLAY_HEIGHT_FALLBACK = 620


def _fit_width(pixmap: QPixmap) -> QPixmap:
    """Thu ảnh về bề rộng hiển thị tối đa (không phóng to ảnh nhỏ hơn)."""
    scale = min(1.0, _DISPLAY_WIDTH / max(1, pixmap.width()))
    if scale < 1.0:
        return pixmap.scaledToWidth(
            int(pixmap.width() * scale),
            Qt.TransformationMode.SmoothTransformation,
        )
    return pixmap


def _max_canvas_size() -> QSize:
    """Kích thước preview tối đa theo màn hình hiện tại."""
    screen = QApplication.primaryScreen()
    if screen is None:
        return QSize(_DISPLAY_WIDTH, _DISPLAY_HEIGHT_FALLBACK)
    area = screen.availableGeometry()
    return QSize(
        min(_DISPLAY_WIDTH, max(360, area.width() - 160)),
        max(260, area.height() - 210),
    )


def _fit_preview(pixmap: QPixmap, max_size: QSize) -> QPixmap:
    """Thu ảnh theo cả chiều rộng và cao để dialog không vượt màn hình."""
    if pixmap.isNull():
        return pixmap
    if pixmap.width() <= max_size.width() and pixmap.height() <= max_size.height():
        return pixmap
    return pixmap.scaled(
        max_size,
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )


class _Canvas(QLabel):
    """Ảnh khung hình + lớp phủ cho phép kéo chọn khung chữ nhật."""

    color_picked = pyqtSignal(object)

    def __init__(self, pixmap: QPixmap, region: tuple[float, float, float, float]):
        super().__init__()
        self._max_size = _max_canvas_size()
        self._original_pix = pixmap
        self._zoom_percent = 100
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._start: QPoint | None = None
        self._rect = self._region_to_rect(region)
        self._pick_color = False
        self._preview_pix: QPixmap | None = None

    def begin_color_pick(self) -> None:
        self._pick_color = True
        self.setCursor(Qt.CursorShape.CrossCursor)

    def set_mask_preview(self, colors: list[list[int]], tolerance: int, enabled: bool) -> None:
        self._preview_pix = None
        if enabled and colors:
            import numpy as np  # noqa: PLC0415
            image = self._original_pix.toImage().convertToFormat(QImage.Format.Format_RGB888)
            width, height = image.width(), image.height()
            ptr = image.bits()
            ptr.setsize(image.bytesPerLine() * height)
            raw = np.frombuffer(ptr, dtype=np.uint8).reshape(height, image.bytesPerLine())
            rgb = raw[:, :width * 3].reshape(height, width, 3).astype("int16")
            mask = np.zeros((height, width), dtype=bool)
            for color in colors:
                c = np.asarray(color[:3], dtype="int16")
                mask |= np.max(np.abs(rgb - c), axis=2) <= int(tolerance)
            out = np.zeros((height, width, 3), dtype=np.uint8)
            out[mask] = 255
            qimg = QImage(out.data, width, height, width * 3, QImage.Format.Format_RGB888).copy()
            self._preview_pix = QPixmap.fromImage(qimg)
        self._update_pix()

    def _update_pix(self) -> None:
        region = self.region()
        source = self._preview_pix or self._original_pix
        self._pix = _fit_preview(source, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._rect = self._region_to_rect(region)
        self.update()

    def _scaled_max_size(self) -> QSize:
        factor = max(0.35, min(2.0, self._zoom_percent / 100.0))
        return QSize(
            max(1, int(self._max_size.width() * factor)),
            max(1, int(self._max_size.height() * factor)),
        )

    def set_zoom(self, percent: int) -> None:
        region = self.region()
        self._zoom_percent = max(35, min(200, int(percent)))
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._rect = self._region_to_rect(region)
        self.update()

    def set_frame(self, pixmap: QPixmap) -> None:
        """Đổi ảnh khung hình đang xem, giữ nguyên vùng đang khoanh.

        Các khung của cùng một video có cùng kích thước nên vùng (theo pixel
        hiển thị) vẫn hợp lệ sau khi đổi khung.
        """
        region = self.region()
        self._original_pix = pixmap
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._rect = self._region_to_rect(region)
        self.update()

    # ----- Chuyển đổi tỷ lệ <-> pixel hiển thị -----

    def _region_to_rect(self, region: tuple[float, float, float, float]) -> QRect:
        w, h = self._pix.width(), self._pix.height()
        x0, y0, x1, y1 = region
        return QRect(
            QPoint(int(x0 * w), int(y0 * h)),
            QPoint(int(x1 * w), int(y1 * h)),
        ).normalized()

    def region(self) -> tuple[float, float, float, float]:
        """Trả vùng đang chọn theo tỷ lệ 0-1."""
        w, h = max(1, self._pix.width()), max(1, self._pix.height())
        r = self._rect.normalized()
        return (
            max(0.0, r.left() / w), max(0.0, r.top() / h),
            min(1.0, r.right() / w), min(1.0, r.bottom() / h),
        )

    # ----- Kéo chuột -----

    def mousePressEvent(self, event) -> None:
        if self._pick_color:
            x = max(0, min(self._original_pix.width() - 1,
                           round(event.position().x() * self._original_pix.width() / max(1, self._pix.width()))))
            y = max(0, min(self._original_pix.height() - 1,
                           round(event.position().y() * self._original_pix.height() / max(1, self._pix.height()))))
            color = self._original_pix.toImage().pixelColor(x, y)
            self._pick_color = False
            self.unsetCursor()
            self.color_picked.emit([color.red(), color.green(), color.blue()])
            return
        self._start = event.pos()
        self._rect = QRect(self._start, self._start)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._start is not None:
            self._rect = QRect(self._start, event.pos()).normalized()
            self.update()

    def mouseReleaseEvent(self, event) -> None:
        if self._start is not None:
            self._rect = QRect(self._start, event.pos()).normalized()
            self._start = None
            self.update()

    # ----- Vẽ -----

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if self._rect.isNull():
            return
        painter = QPainter(self)
        # Làm tối phần ngoài vùng chọn cho dễ nhìn.
        overlay = QColor(0, 0, 0, 110)
        full = self.rect()
        r = self._rect.intersected(full)
        for area in (
            QRect(full.left(), full.top(), full.width(), r.top() - full.top()),
            QRect(full.left(), r.bottom(), full.width(), full.bottom() - r.bottom()),
            QRect(full.left(), r.top(), r.left() - full.left(), r.height()),
            QRect(r.right(), r.top(), full.right() - r.right(), r.height()),
        ):
            painter.fillRect(area, overlay)
        pen = QPen(QColor(0, 200, 120), 2)
        painter.setPen(pen)
        painter.drawRect(r)


class OcrRegionDialog(QDialog):
    """Hộp thoại kéo chọn vùng phụ đề, trả tỷ lệ (x0,y0,x1,y1)."""

    def __init__(self, frame_png: str,
                 region: tuple[float, float, float, float],
                 parent: QWidget | None = None,
                 frame_provider: Callable[[], str | None] | None = None,
                 seek_frame_provider: Callable[[float], str | None] | None = None,
                 duration_seconds: float | None = None,
                 initial_seconds: float | None = None,
                 picked_colors: list | None = None,
                 color_filter_enabled: bool = False,
                 color_tolerance: int = 45):
        super().__init__(parent)
        self.setWindowTitle("Chọn vùng phụ đề (kéo chuột quanh dòng chữ)")
        self._frame_provider = frame_provider
        self._seek_frame_provider = seek_frame_provider
        self._duration_seconds = max(0.0, float(duration_seconds or 0.0))
        layout = QVBoxLayout(self)
        hint = "Kéo chuột để chọn vùng chứa phụ đề."
        if frame_provider is not None:
            hint += (" Nếu khung này chưa hiện phụ đề, bấm 'Đổi khung hình' "
                     "để xem cảnh khác.")
        layout.addWidget(QLabel(hint))
        self._canvas = _Canvas(QPixmap(frame_png), region)
        self._picked_colors = [list(value[:3]) for value in (picked_colors or [])]
        self._canvas.color_picked.connect(self._add_color)

        zoom_row = QHBoxLayout()
        zoom_row.addWidget(QLabel("Kích thước preview:"))
        self._zoom_label = QLabel("100%")
        self._zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self._zoom_slider.setRange(45, 160)
        self._zoom_slider.setValue(100)
        self._zoom_slider.setSingleStep(5)
        self._zoom_slider.valueChanged.connect(self._set_zoom)
        btn_fit = QPushButton("Vừa màn hình")
        btn_fit.clicked.connect(lambda: self._zoom_slider.setValue(100))
        zoom_row.addWidget(self._zoom_slider, 1)
        zoom_row.addWidget(self._zoom_label)
        zoom_row.addWidget(btn_fit)
        layout.addLayout(zoom_row)

        if self._seek_frame_provider is not None and self._duration_seconds > 0:
            seek_row = QHBoxLayout()
            seek_row.addWidget(QLabel("Tua video:"))
            self._seek_slider = QSlider(Qt.Orientation.Horizontal)
            self._seek_slider.setRange(0, max(1, int(round(self._duration_seconds * 1000))))
            self._seek_slider.setSingleStep(500)
            self._seek_slider.setPageStep(5000)
            start_ms = int(round(max(0.0, min(
                self._duration_seconds, float(initial_seconds or 0.0)
            )) * 1000))
            self._seek_slider.setValue(start_ms)
            self._seek_label = QLabel(self._format_time(start_ms / 1000.0))
            btn_seek = QPushButton("Lấy khung tại đây")
            self._seek_slider.valueChanged.connect(
                lambda value: self._seek_label.setText(self._format_time(value / 1000.0))
            )
            self._seek_slider.sliderReleased.connect(self._load_seek_frame)
            btn_seek.clicked.connect(self._load_seek_frame)
            seek_row.addWidget(self._seek_slider, 1)
            seek_row.addWidget(self._seek_label)
            seek_row.addWidget(btn_seek)
            layout.addLayout(seek_row)

        color_row = QHBoxLayout()
        self._color_enabled = QCheckBox("Lọc theo màu chữ")
        self._color_enabled.setChecked(bool(color_filter_enabled))
        self._color_preview = QCheckBox("Xem mặt nạ")
        self._color_swatches = QWidget()
        self._color_swatches_layout = QHBoxLayout(self._color_swatches)
        self._color_swatches_layout.setContentsMargins(2, 0, 2, 0)
        self._color_swatches_layout.setSpacing(6)
        self._color_tolerance = QSpinBox()
        self._color_tolerance.setRange(5, 120)
        self._color_tolerance.setValue(max(5, min(120, int(color_tolerance))))
        btn_pick = QPushButton("Chấm màu trên ảnh")
        btn_clear = QPushButton("Xóa màu")
        btn_pick.clicked.connect(self._canvas.begin_color_pick)
        btn_clear.clicked.connect(self._clear_colors)
        self._color_preview.toggled.connect(self._refresh_mask_preview)
        self._color_tolerance.valueChanged.connect(self._refresh_mask_preview)
        color_row.addWidget(self._color_enabled)
        color_row.addWidget(btn_pick)
        color_row.addWidget(btn_clear)
        color_row.addWidget(QLabel("Sai số:"))
        color_row.addWidget(self._color_tolerance)
        color_row.addWidget(self._color_preview)
        color_row.addWidget(self._color_swatches, 1)
        layout.addLayout(color_row)
        self._update_color_label()

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(False)
        self._scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._scroll.setWidget(self._canvas)
        max_size = _max_canvas_size()
        self._scroll.setMaximumSize(max_size.width() + 26, max_size.height() + 26)
        layout.addWidget(self._scroll)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        if frame_provider is not None:
            btn_other = buttons.addButton(
                "Đổi khung hình", QDialogButtonBox.ButtonRole.ActionRole
            )
            btn_other.setToolTip("Xem một khung hình khác của video")
            btn_other.clicked.connect(self._load_other_frame)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _set_zoom(self, value: int) -> None:
        self._canvas.set_zoom(value)
        self._zoom_label.setText(f"{value}%")

    def _load_other_frame(self) -> None:
        """Lấy khung hình khác từ frame_provider và nạp vào canvas."""
        if self._frame_provider is None:
            return
        try:
            path = self._frame_provider()
        except Exception:  # noqa: BLE001 - lỗi trích khung không được làm sập dialog
            path = None
        if not path:
            return
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            self._canvas.set_frame(pixmap)
            self._refresh_mask_preview()

    @staticmethod
    def _format_time(seconds: float) -> str:
        seconds = max(0.0, float(seconds))
        total = int(seconds)
        ms = int(round((seconds - total) * 1000))
        minute, sec = divmod(total, 60)
        hour, minute = divmod(minute, 60)
        if hour:
            return f"{hour:d}:{minute:02d}:{sec:02d}.{ms:03d}"
        return f"{minute:02d}:{sec:02d}.{ms:03d}"

    def _load_seek_frame(self) -> None:
        """Load a video frame at the timestamp selected by the user."""
        if self._seek_frame_provider is None or not hasattr(self, "_seek_slider"):
            return
        at = max(0.0, min(self._duration_seconds, self._seek_slider.value() / 1000.0))
        try:
            path = self._seek_frame_provider(at)
        except Exception:  # noqa: BLE001 - keep region dialog open on frame errors
            path = None
        if not path:
            return
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            self._canvas.set_frame(pixmap)
            self._refresh_mask_preview()

    def _add_color(self, color: object) -> None:
        value = list(color) if isinstance(color, (list, tuple)) else []
        if len(value) == 3 and value not in self._picked_colors:
            self._picked_colors.append(value)
        self._update_color_label()
        self._refresh_mask_preview()

    def _clear_colors(self) -> None:
        self._picked_colors.clear()
        self._update_color_label()
        self._refresh_mask_preview()

    def _update_color_label(self) -> None:
        while self._color_swatches_layout.count():
            item = self._color_swatches_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        if not self._picked_colors:
            self._color_swatches_layout.addWidget(QLabel("Chưa chọn màu"))
        else:
            for color in self._picked_colors:
                hex_value = "#%02X%02X%02X" % tuple(color)
                swatch = QLabel()
                swatch.setFixedSize(18, 18)
                swatch.setToolTip(hex_value)
                swatch.setStyleSheet(
                    f"background-color: {hex_value}; border: 1px solid #64748b; "
                    "border-radius: 3px;"
                )
                code = QLabel(hex_value)
                code.setToolTip(f"Màu chữ đã chọn: {hex_value}")
                self._color_swatches_layout.addWidget(swatch)
                self._color_swatches_layout.addWidget(code)
        self._color_swatches_layout.addStretch(1)

    def _refresh_mask_preview(self, *_args) -> None:
        self._canvas.set_mask_preview(
            self._picked_colors,
            self._color_tolerance.value(),
            self._color_preview.isChecked(),
        )

    def selected_region(self) -> tuple[float, float, float, float]:
        return self._canvas.region()

    def selected_colors(self) -> list[list[int]]:
        return [list(value) for value in self._picked_colors]

    def color_filter_enabled(self) -> bool:
        return self._color_enabled.isChecked() and bool(self._picked_colors)

    def color_tolerance(self) -> int:
        return self._color_tolerance.value()

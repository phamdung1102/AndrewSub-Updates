"""Nguồn giọng CapCut cho VoiceApiEngine.

API không chính thức: không cần khóa, xác thực bằng dấu vân tay thiết bị.
Mỗi máy dùng device id riêng (config.voice_api_capcut_device_id) để không
chia sẻ vân tay với máy khác - dùng chung rất dễ bị chặn theo cụm.

Hạn chế đã đo trên API thật: máy chủ bỏ qua thẻ <prosody rate>, nên tham số
speed không có tác dụng. VICDub luôn gọi speed=1.0 rồi co giãn bằng atempo ở
bước đồng bộ video, nên điều này không ảnh hưởng pipeline.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

from vicdub.core.module_base import ModuleError, PermanentVoiceError

logger = logging.getLogger(__name__)

CAPCUT_VOICE_VERSION = "capcut-catalog-v1"

# Lỗi thuộc về nội dung câu, retry bao nhiêu lần cũng vẫn hỏng. Hay gặp nhất là
# TTSInvalidText: giọng không đọc được ngôn ngữ của câu (ví dụ giọng Việt nhận
# câu tiếng Trung chưa dịch), hoặc câu chỉ có ký hiệu/nhạc hiệu.
_PERMANENT_ERR_CODES = frozenset({40402002})
_PERMANENT_ERR_MARKERS = ("invalidtext", "text too long", "invalid text")


def _ensure_vendor_import_path() -> None:
    """Cho phép bản patch chạy CapCut SDK đi kèm app mà không cần pip install."""
    app_root = Path(__file__).resolve().parents[2]
    candidates = (
        app_root / "capcut-tts-api",
        app_root / "vendor" / "capcut-tts-api",
    )
    for path in candidates:
        if (path / "capcut_tts_api" / "__init__.py").is_file():
            value = str(path)
            if value not in sys.path:
                sys.path.insert(0, value)
            return


_ensure_vendor_import_path()

__all__ = [
    "CAPCUT_VOICE_VERSION",
    "DEFAULT_FEMALE_VOICE",
    "DEFAULT_MALE_VOICE",
    "PermanentVoiceError",
    "build_client",
    "catalog_rows",
    "synthesize_mp3",
    "voice_gender",
]

DEFAULT_FEMALE_VOICE = "BV421_vivn_streaming"
DEFAULT_MALE_VOICE = "BV075_streaming"

# Catalog CapCut không có trường giới tính. Bảng dưới suy ra từ voice_type,
# đã đối chiếu tay với display_name tiếng Việt.
_MALE_VOICE_TYPES = frozenset(
    {
        "BV075_streaming",
        "BV075_streaming_dsp",
        "BV075_streaming_vibrato_dsp",
        "BV075_streaming_demon_dsp",
        "BV075_streaming_robot_dsp",
        "BV560_streaming",
        "vi-VN-NamMinhNeural",
        "multi_male_felipe_uranus_bigtts",
        # display_name "Nam bản tin" tuy voice_type mang tiền tố multi_female_
        "multi_female_xinwenjieshuo_uranus_bigtts",
    }
)


def voice_gender(voice_type: str) -> str:
    """Trả 'male' | 'female' | '' cho một voice_type CapCut."""
    vt = str(voice_type or "").strip()
    if not vt:
        return ""
    if vt in _MALE_VOICE_TYPES:
        return "male"
    lowered = vt.lower()
    if lowered.startswith("multi_male_") or "_male_" in lowered:
        return "male"
    if lowered.startswith(("multi_female_", "vi_female_")) or "_female_" in lowered:
        return "female"
    return "female"


def build_client(config: Any) -> Any:
    """Tạo CapCutClient gắn với device id riêng của máy này."""
    try:
        from capcut_tts_api import CapCutClient
    except ImportError as exc:  # pragma: no cover - phụ thuộc tùy chọn
        raise ModuleError(
            "Chưa cài thư viện capcut-tts-api. Chạy: pip install -e ./capcut-tts-api"
        ) from exc

    device_id = str(getattr(config, "voice_api_capcut_device_id", "") or "").strip()
    if not device_id:
        from vicdub.config import new_capcut_device_id

        device_id = new_capcut_device_id()
        config.voice_api_capcut_device_id = device_id
        try:
            config.save()
        except OSError as exc:
            logger.warning("Không lưu được device id CapCut: %s", exc)
    return CapCutClient(device={"device_id": device_id, "iid": device_id, "tdid": device_id})


def catalog_rows(client: Any, lang: str = "vi-VN") -> list[dict]:
    """Đổi catalog CapCut sang dạng {'id','name'} mà VoiceApiEngine dùng."""
    voices = client.list_voices(lang=lang) or client.list_voices()
    rows: list[dict] = []
    for v in voices:
        rows.append(
            {
                "id": v.voice_type,
                "name": v.display_name or v.voice_type,
                "gender": voice_gender(v.voice_type),
            }
        )
    return rows


def _is_permanent(exc: Exception) -> bool:
    """Phân biệt lỗi nội dung (bỏ qua câu) với lỗi tạm thời (đáng retry)."""
    if getattr(exc, "err_code", 0) in _PERMANENT_ERR_CODES:
        return True
    text = f"{getattr(exc, 'err_msg', '')} {exc}".lower()
    return any(marker in text for marker in _PERMANENT_ERR_MARKERS)


def synthesize_mp3(client: Any, text: str, voice_type: str, timeout: float) -> bytes:
    """Sinh giọng và trả về mp3 thô; phần đổi sang WAV để _write_wav lo."""
    from capcut_tts_api import CapCutError

    if not str(text or "").strip():
        raise PermanentVoiceError("Câu rỗng, không sinh giọng được.")
    try:
        query = client.generate_speech(
            text, voice=voice_type, wait=True, poll_interval=1.0, timeout=timeout
        )
        segments = client.extract_speech(query)
    except CapCutError as exc:
        if _is_permanent(exc):
            raise PermanentVoiceError(
                f"CapCut từ chối câu này ({getattr(exc, 'err_msg', '') or exc}). "
                "Thường do câu không đúng ngôn ngữ của giọng đã chọn."
            ) from exc
        raise ModuleError(f"CapCut TTS lỗi: {exc}") from exc
    if not segments:
        raise ModuleError("CapCut TTS không trả về audio.")
    segment = segments[0]
    if not segment.ssml_supported:
        logger.debug("CapCut bỏ qua SSML (rate) cho đoạn: %s", text[:40])
    response = client.session.get(segment.speech_url, timeout=timeout)
    if response.status_code >= 400:
        raise ModuleError(f"Không tải được audio CapCut (HTTP {response.status_code}).")
    return response.content

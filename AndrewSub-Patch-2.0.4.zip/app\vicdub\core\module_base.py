"""Lớp cơ sở cho mọi module pipeline.

Nguyên tắc kiến trúc:
- Mỗi module độc lập, chỉ nhận input (dict) và trả output (dict).
- Module KHÔNG được gọi trực tiếp module khác.
- Workflow Engine chịu trách nhiệm điều phối và truyền dữ liệu.
"""

from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from typing import Any, Callable

# Callback tiến độ: (phần trăm 0-100, mô tả ngắn)
ProgressCallback = Callable[[int, str], None]


class ModuleError(Exception):
    """Lỗi nghiệp vụ của module - thông điệp hiển thị được cho người dùng."""


class PermanentVoiceError(ModuleError):
    """Câu này không sinh giọng được dù thử lại - do chính nội dung câu.

    Sinh voice bắt lỗi này để bỏ qua đúng câu đó và chạy tiếp, thay vì để một
    câu hỏng làm sập cả job lồng tiếng dài hàng trăm dòng.
    """


class ModuleCancelled(Exception):
    """Người dùng hủy giữa chừng."""


class BaseModule(ABC):
    """Module pipeline cơ sở.

    Subclass chỉ cần cài đặt `name`, `run()`.
    Trong run() gọi `self.report(pct, msg)` để báo tiến độ
    và `self.check_cancelled()` tại các điểm dừng an toàn.
    """

    #: Tên hiển thị (tiếng Việt) - subclass ghi đè.
    name: str = "Module"

    def __init__(self) -> None:
        self.logger = logging.getLogger(f"vicdub.module.{type(self).__name__}")
        self._progress_cb: ProgressCallback | None = None
        self._cancel_event: threading.Event | None = None

    # ---------- Được Workflow Engine gắn trước khi chạy ----------

    def attach(self, progress_cb: ProgressCallback, cancel_event: threading.Event) -> None:
        """Engine gắn callback tiến độ và cờ hủy trước khi gọi run()."""
        self._progress_cb = progress_cb
        self._cancel_event = cancel_event

    # ---------- Tiện ích cho subclass ----------

    def report(self, percent: int, message: str) -> None:
        """Báo tiến độ về engine (an toàn khi chưa gắn callback)."""
        self.logger.info("[%d%%] %s", percent, message)
        if self._progress_cb is not None:
            self._progress_cb(percent, message)

    def check_cancelled(self) -> None:
        """Ném ModuleCancelled nếu người dùng đã bấm hủy/pause."""
        if self._cancel_event is not None and self._cancel_event.is_set():
            raise ModuleCancelled(f"{self.name}: đã hủy theo yêu cầu")

    # ---------- API chính ----------

    @abstractmethod
    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        """Chạy module.

        Args:
            data: ngữ cảnh pipeline (đường dẫn video, segments, config...).

        Returns:
            dict các khóa mới/cập nhật để engine gộp vào ngữ cảnh.

        Raises:
            ModuleError: lỗi nghiệp vụ có thông điệp rõ ràng.
        """

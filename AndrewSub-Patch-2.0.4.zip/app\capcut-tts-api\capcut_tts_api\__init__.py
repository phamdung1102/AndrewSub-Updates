"""
CapCut TTS API Python SDK & Package.

Pure Python client for CapCut Text-to-Speech (TTS), Speech-to-Text (STT),
and VOD chunked audio upload workflows.
"""

from capcut_tts_api.client import CapCutClient
from capcut_tts_api.exceptions import (
    CapCutAPIError,
    CapCutError,
    CapCutSignError,
    CapCutTaskError,
    CapCutUploadError,
)
from capcut_tts_api.models import (
    DeviceConfig,
    SpeechSegment,
    SubtitleResult,
    UploadResult,
    Utterance,
    VoiceInfo,
    Word,
)
from capcut_tts_api.uploader import VODUploader

__version__ = "1.0.0"

__all__ = [
    "CapCutClient",
    "VODUploader",
    "DeviceConfig",
    "UploadResult",
    "SpeechSegment",
    "SubtitleResult",
    "Utterance",
    "Word",
    "VoiceInfo",
    "CapCutError",
    "CapCutAPIError",
    "CapCutUploadError",
    "CapCutSignError",
    "CapCutTaskError",
    "__version__",
]

"""Signed license token helpers.

Token format:
    ASUB1.<base64url-json-payload>.<base64url-rsa-sha256-signature>
"""

from __future__ import annotations

import base64
import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any

APP_ID = "andrewsub"
TOKEN_PREFIX = "ASUB1"

SHA256_DER_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


class LicenseError(ValueError):
    """Raised when a license token is invalid or not usable."""


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(text: str) -> bytes:
    pad = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode((text + pad).encode("ascii"))


def utc_now() -> datetime:
    return datetime.now(UTC).replace(microsecond=0)


def parse_datetime(value: str) -> datetime:
    if not value:
        raise LicenseError("Thiếu thời hạn license.")
    text = str(value).replace("Z", "+00:00")
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def make_payload(
    machine_id: str,
    *,
    customer_name: str = "",
    email: str = "",
    days: int | None = 365,
    expires_at: str | None = None,
    plan: str = "standard",
    features: dict[str, Any] | None = None,
) -> dict[str, Any]:
    issued = utc_now()
    if expires_at:
        expires = parse_datetime(expires_at)
    elif days is None or days <= 0:
        expires = datetime(2099, 12, 31, 23, 59, 59, tzinfo=UTC)
    else:
        expires = issued + timedelta(days=int(days))
    return {
        "appId": APP_ID,
        "machineId": machine_id,
        "customerName": customer_name,
        "email": email,
        "issuedAt": issued.isoformat().replace("+00:00", "Z"),
        "expiresAt": expires.replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "plan": plan or "standard",
        "features": features or {},
    }


def sign_token(payload: dict[str, Any], private_key_pem: bytes | str) -> str:
    # Admin-only helper. The customer app must not require cryptography just to start.
    from cryptography.hazmat.primitives import hashes, serialization  # noqa: PLC0415
    from cryptography.hazmat.primitives.asymmetric import padding  # noqa: PLC0415

    key = serialization.load_pem_private_key(
        private_key_pem.encode("utf-8") if isinstance(private_key_pem, str) else private_key_pem,
        password=None,
    )
    payload_encoded = _b64url_encode(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    )
    signature = key.sign(
        payload_encoded.encode("ascii"),
        padding.PKCS1v15(),
        hashes.SHA256(),
    )
    return f"{TOKEN_PREFIX}.{payload_encoded}.{_b64url_encode(signature)}"


def verify_token(raw_token: str, public_key_pem: bytes | str, machine_id: str) -> dict[str, Any]:
    token = str(raw_token or "").strip()
    parts = token.split(".")
    if len(parts) != 3 or parts[0] != TOKEN_PREFIX:
        raise LicenseError("License không đúng định dạng AndrewSub.")
    payload_encoded, signature_encoded = parts[1], parts[2]
    try:
        _verify_rsa_sha256_pkcs1v15(
            public_key_pem.encode("utf-8") if isinstance(public_key_pem, str) else public_key_pem,
            payload_encoded.encode("ascii"),
            _b64url_decode(signature_encoded),
        )
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("Chữ ký license không hợp lệ.") from exc
    try:
        payload = json.loads(_b64url_decode(payload_encoded).decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise LicenseError("Không đọc được nội dung license.") from exc
    if payload.get("appId") != APP_ID:
        raise LicenseError("License không dành cho AndrewSub.")
    if str(payload.get("machineId", "")).strip().upper() != machine_id.strip().upper():
        raise LicenseError("License không khớp mã máy này.")
    if parse_datetime(str(payload.get("expiresAt", ""))) < utc_now():
        raise LicenseError("License đã hết hạn.")
    return payload


def _pem_to_der(pem: bytes) -> bytes:
    text = pem.decode("ascii", errors="ignore")
    body = "".join(line.strip() for line in text.splitlines() if not line.startswith("-----"))
    return base64.b64decode(body)


class _DerReader:
    def __init__(self, data: bytes) -> None:
        self.data = data
        self.pos = 0

    def read_tlv(self) -> tuple[int, bytes]:
        tag = self.data[self.pos]
        self.pos += 1
        length = self.data[self.pos]
        self.pos += 1
        if length & 0x80:
            n = length & 0x7F
            length = int.from_bytes(self.data[self.pos:self.pos + n], "big")
            self.pos += n
        value = self.data[self.pos:self.pos + length]
        self.pos += length
        return tag, value


def _read_int(reader: _DerReader) -> int:
    tag, value = reader.read_tlv()
    if tag != 0x02:
        raise LicenseError("Public key không hợp lệ.")
    return int.from_bytes(value, "big", signed=False)


def _parse_public_numbers(public_key_pem: bytes) -> tuple[int, int]:
    outer = _DerReader(_pem_to_der(public_key_pem))
    tag, seq = outer.read_tlv()
    if tag != 0x30:
        raise LicenseError("Public key không hợp lệ.")
    seq_reader = _DerReader(seq)
    seq_reader.read_tlv()  # algorithm identifier
    tag, bit_string = seq_reader.read_tlv()
    if tag != 0x03 or not bit_string:
        raise LicenseError("Public key không hợp lệ.")
    key_reader = _DerReader(bit_string[1:])  # skip unused-bits byte
    tag, key_seq = key_reader.read_tlv()
    if tag != 0x30:
        raise LicenseError("Public key không hợp lệ.")
    numbers = _DerReader(key_seq)
    return _read_int(numbers), _read_int(numbers)


def _verify_rsa_sha256_pkcs1v15(public_key_pem: bytes, message: bytes, signature: bytes) -> None:
    modulus, exponent = _parse_public_numbers(public_key_pem)
    key_size = (modulus.bit_length() + 7) // 8
    if len(signature) != key_size:
        raise LicenseError("Chữ ký license không hợp lệ.")
    encoded = pow(int.from_bytes(signature, "big"), exponent, modulus).to_bytes(key_size, "big")
    digest_info = SHA256_DER_PREFIX + hashlib.sha256(message).digest()
    expected_prefix = b"\x00\x01"
    if not encoded.startswith(expected_prefix):
        raise LicenseError("Chữ ký license không hợp lệ.")
    try:
        sep = encoded.index(b"\x00", 2)
    except ValueError as exc:
        raise LicenseError("Chữ ký license không hợp lệ.") from exc
    if sep < 10 or encoded[2:sep] != b"\xff" * (sep - 2):
        raise LicenseError("Chữ ký license không hợp lệ.")
    if encoded[sep + 1:] != digest_info:
        raise LicenseError("Chữ ký license không hợp lệ.")

"""Generate AndrewSub machine-locked licenses.

Usage:
  python tools/license_admin.py ASUB-XXXX-XXXX-XXXX-XXXX --days 365 --name "Khach A"
  python tools/license_admin.py ASUB-XXXX-XXXX-XXXX-XXXX --lifetime
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from vicdub.core.licensing.license_token import make_payload, sign_token  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="AndrewSub License Admin")
    parser.add_argument("machine_id", help="Mã máy ASUB-... lấy trong tab Bản quyền")
    parser.add_argument("--name", default="", help="Tên khách/máy")
    parser.add_argument("--email", default="", help="Email khách")
    parser.add_argument("--plan", default="standard", help="Gói license")
    parser.add_argument("--days", type=int, default=365, help="Số ngày dùng")
    parser.add_argument("--lifetime", action="store_true", help="Cấp tới 2099-12-31")
    parser.add_argument("--private-key", default=str(ROOT / ".local" / "license-private.pem"))
    parser.add_argument("--out", default="", help="Ghi license ra file")
    args = parser.parse_args()

    private_key = Path(args.private_key)
    if not private_key.is_file():
        raise SystemExit(f"Không thấy private key: {private_key}")
    payload = make_payload(
        args.machine_id,
        customer_name=args.name,
        email=args.email,
        plan=args.plan,
        days=None if args.lifetime else args.days,
    )
    token = sign_token(payload, private_key.read_bytes())
    if args.out:
        Path(args.out).write_text(token, encoding="utf-8")
        print(f"Đã ghi license: {args.out}")
    else:
        print(token)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

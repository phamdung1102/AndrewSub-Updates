﻿"""Cửa sổ chính - nav trên, vùng làm việc chính, status bar.

MainWindow là "composition root": tạo services (ProjectManager, ApiManager,
TranslationMemory, WorkflowEngine) và nối chúng với UI. Business logic nằm
trong module/engine, không nằm ở đây.
"""

from __future__ import annotations

import logging
import json
import os
import re
import threading
import time
from pathlib import Path

from PyQt6.QtCore import QTimer, Qt, QUrl, pyqtSignal
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (
    QLabel, QListView, QListWidget, QMainWindow, QMessageBox, QProgressBar,
    QPushButton, QStackedWidget, QVBoxLayout, QWidget,
)

from vicdub import APP_NAME, __version__
from vicdub.api.api_manager import ApiManager
from vicdub.api.gemini_client import GeminiClient
from vicdub.config import APP_ROOT, AppConfig
from vicdub.core.licensing.license_service import LicenseService
from vicdub.core.project_manager import Project, ProjectManager
from vicdub.core.workflow_engine import (
    PIPELINE_STEPS, WorkflowEngine, format_elapsed,
)
from vicdub.modules.character_module import CharacterModule
from vicdub.modules.import_module import ImportModule
from vicdub.modules.merge_module import MergeModule
from vicdub.modules.subtitle_module import SubtitleModule
from vicdub.modules.subtitle_style_module import SubtitleStyleModule
from vicdub.modules.translate_module import TranslateModule
from vicdub.modules.video_module import CutModule, VideoModule
from vicdub.modules.voice_module import VoiceModule
from vicdub.ui.pages import (
    ExportPage, ProjectPage, SettingsPage, SubtitlePage,
)
from vicdub.ui.license_page import LicensePage
from vicdub.ui.theme import DARK_QSS
from vicdub.utils.translation_memory import TranslationMemory

logger = logging.getLogger(__name__)

NAV_ITEMS = ("Dự án", "Phụ đề", "Xuất video", "Cài đặt", "Bản quyền")


class MainWindow(QMainWindow):
    """Cửa sổ chính của AndrewSub."""

    #: Phát từ worker thread để phát audio trên GUI thread (thread-safe).
    audio_ready = pyqtSignal(str)

    def __init__(self, config: AppConfig) -> None:
        super().__init__()
        self.config = config
        self._sound = None  # giữ tham chiếu player đang phát
        self.audio_ready.connect(self._play_audio)

        # ---------- Services ----------
        self.projects = ProjectManager(config.projects_dir)
        self.tm = TranslationMemory(config.data_dir)
        self.api = ApiManager(config.api_keys, config.api_pool_strategy)
        self.license_service = LicenseService(config)
        self.engine = WorkflowEngine()
        self._register_modules()
        self._batch_queue: list[str] = []
        self._batch_results: list[tuple[str, bool, str]] = []
        self._batch_current = ""
        self._batch_total = 0
        self._batch_original_project = ""
        self._batch_last_error = ""
        self._batch_active = False
        self._batch_cancelled = False
        self._batch_steps: list[str] | str = "ALL"
        self._batch_action_label = "trọn quy trình"
        self._batch_plan: dict = {}
        self._batch_config_snapshot: dict = {}
        self._batch_current_steps: list[str] = []
        self._batch_failed_step = ""
        self._batch_fallback_attempted: set[tuple[str, str]] = set()
        self._batch_fallback_log: list[str] = []
        self._step_wall_started = 0.0
        self._current_step_key = ""
        self._current_step_pct = 0
        self._current_step_message = ""

        # ---------- Cửa sổ ----------
        self.setWindowTitle(f"{APP_NAME} v{__version__}")
        icon_path = APP_ROOT / "assets" / "icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.resize(1360, 800)
        self.setMinimumSize(1100, 700)
        self.setStyleSheet(DARK_QSS)
        self._build_ui()
        self._connect_engine()
        self._runtime_timer = QTimer(self)
        self._runtime_timer.setInterval(1000)
        self._runtime_timer.timeout.connect(self._refresh_elapsed_status)
        self._ocr_heartbeat_busy = False
        self._ocr_heartbeat_timer = QTimer(self)
        self._ocr_heartbeat_timer.setInterval(20_000)
        self._ocr_heartbeat_timer.timeout.connect(self._send_ocr_heartbeat)
        self._ocr_heartbeat_timer.start()
        self.refresh_all()
        self.show_status("Sẵn sàng")
        if bool(getattr(self.config, "auto_check_updates", True)):
            QTimer.singleShot(2500, self._check_updates_on_startup)
        QTimer.singleShot(700, self._show_update_result)
        QTimer.singleShot(1200, self._send_ocr_heartbeat)
        QTimer.singleShot(1500, self._show_license_state_on_startup)
        QTimer.singleShot(2200, self._send_license_heartbeat)

    def _send_ocr_heartbeat(self) -> None:
        """Giữ máy hiện Online trên bảng quản trị mà không chặn giao diện."""
        if self._ocr_heartbeat_busy:
            return
        if not (str(getattr(self.config, "remote_ocr_url", "") or "").strip()
                and str(getattr(self.config, "remote_ocr_api_key", "") or "").strip()):
            return
        self._ocr_heartbeat_busy = True

        def worker() -> None:
            try:
                from vicdub.api.remote_ocr_client import RemoteOcrClient
                client = RemoteOcrClient(self.config)
                try:
                    client.check_connection()
                finally:
                    client.close()
            except Exception as exc:  # noqa: BLE001
                logger.debug("OCR heartbeat lỗi: %s", exc)
            finally:
                self._ocr_heartbeat_busy = False

        threading.Thread(target=worker, daemon=True).start()

    def _check_updates_on_startup(self) -> None:
        page = getattr(getattr(self, "settings_page", None), "components_page", None)
        checker = getattr(page, "check_app_update", None)
        if callable(checker):
            checker(True)

    def _show_update_result(self) -> None:
        status_path = APP_ROOT.parent / "update_status.json"
        if not status_path.is_file():
            return
        try:
            data = json.loads(status_path.read_text(encoding="utf-8"))
            status_path.unlink(missing_ok=True)
            message = str(data.get("message", "")).strip()
            version = str(data.get("version", "")).strip()
            if data.get("ok"):
                QMessageBox.information(
                    self, APP_NAME, f"Đã cập nhật thành công lên phiên bản {version}."
                )
            else:
                QMessageBox.warning(
                    self, APP_NAME, f"Cập nhật không thành công.\n\n{message}"
                )
        except Exception:  # noqa: BLE001
            logger.exception("Không đọc được kết quả cập nhật")

    # ================= Services =================

    def _register_modules(self) -> None:
        """Đăng ký 8 module vào engine - điểm duy nhất nối pipeline."""
        self.engine.register("import", ImportModule())
        self.engine.register("subtitle", SubtitleModule())
        self.engine.register("translate", TranslateModule())
        self.engine.register("character", CharacterModule())
        self.engine.register("voice", VoiceModule())
        self.engine.register("video", VideoModule())
        self.engine.register("cut", CutModule())
        self.engine.register("subtitle_style", SubtitleStyleModule())
        self.engine.register("merge", MergeModule())

    def reload_api_manager(self) -> None:
        """Gọi sau khi lưu cài đặt API."""
        self.api = ApiManager(self.config.api_keys, self.config.api_pool_strategy)

    # ================= UI =================

    def _build_ui(self) -> None:
        # ----- Nav trên: trả lại chiều ngang cho vùng làm việc -----
        self.nav = QListWidget()
        self.nav.setObjectName("topNav")
        self.nav.addItems(NAV_ITEMS)
        self.nav.setFlow(QListView.Flow.LeftToRight)
        self.nav.setWrapping(False)
        self.nav.setFixedHeight(48)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.currentRowChanged.connect(self._on_nav_changed)

        # ----- Vùng làm việc chính -----
        self.stack = QStackedWidget()
        self.project_page = ProjectPage(self)
        self.subtitle_page = SubtitlePage(self)
        self.export_page = ExportPage(self)
        self.settings_page = SettingsPage(self)
        self.license_page = LicensePage(self)
        self.pages = [
            self.project_page, self.subtitle_page,
            self.export_page, self.settings_page, self.license_page,
        ]
        for page in self.pages:
            self.stack.addWidget(page)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.nav)
        layout.addWidget(self.stack, 1)
        self.setCentralWidget(container)

        # ----- Status bar gọn: thông báo | thông tin project | tiến độ -----
        self.status_label = QLabel("")
        self.statusBar().addWidget(self.status_label, 1)
        self.info_compact = QLabel("")
        self.info_compact.setMaximumWidth(260)
        self.statusBar().addPermanentWidget(self.info_compact)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFixedWidth(180)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("0%")
        self.statusBar().addPermanentWidget(self.progress_bar)
        self._current_step_label = ""
        self.btn_pause = QPushButton("⏸  Tạm dừng")
        self.btn_resume = QPushButton("▶  Tiếp tục")
        self.btn_cancel = QPushButton("■  Hủy tác vụ")
        self.btn_pause.setObjectName("pipelinePause")
        self.btn_resume.setObjectName("pipelineResume")
        self.btn_cancel.setObjectName("pipelineCancel")
        for btn, width, tip in (
            (self.btn_pause, 112, "Tạm dừng pipeline"),
            (self.btn_resume, 106, "Tiếp tục"),
            (self.btn_cancel, 124, "Hủy pipeline"),
        ):
            btn.setFixedWidth(width)
            btn.setFixedHeight(30)
            btn.setToolTip(tip)
            btn.setEnabled(False)
            self.statusBar().addPermanentWidget(btn)
        self.btn_pause.clicked.connect(self._pause_clicked)
        self.btn_resume.clicked.connect(self._resume_clicked)
        self.btn_cancel.clicked.connect(self._cancel_clicked)

        self.nav.setCurrentRow(0)

    def _connect_engine(self) -> None:
        self.engine.step_started.connect(self._on_step_started)
        self.engine.step_progress.connect(self._on_step_progress)
        self.engine.step_finished.connect(self._on_step_finished)
        self.engine.step_failed.connect(self._on_step_failed)
        self.engine.pipeline_finished.connect(self._on_pipeline_finished)

    def _ensure_license_valid(self) -> bool:
        status = self.license_service.status()
        if status.get("valid"):
            return True
        if hasattr(self, "license_page"):
            self.license_page.refresh()
        self.nav.setCurrentRow(len(NAV_ITEMS) - 1)
        QMessageBox.warning(
            self,
            APP_NAME,
            "AndrewSub chưa được kích hoạt hoặc license không hợp lệ.\n\n"
            f"Mã máy: {status.get('machine_id')}\n"
            f"Lý do: {status.get('message')}",
        )
        return False

    def _show_license_state_on_startup(self) -> None:
        status = self.license_service.status()
        if status.get("valid"):
            payload = status.get("license") or {}
            expires = str(payload.get("expiresAt") or "")[:10]
            self.show_status("License hợp lệ" + (f" — hạn {expires}" if expires else ""))
            return
        if hasattr(self, "license_page"):
            self.license_page.refresh()
        self.nav.setCurrentRow(len(NAV_ITEMS) - 1)
        self.show_status(f"Chưa kích hoạt bản quyền — {status.get('machine_id')}")

    def _send_license_heartbeat(self) -> None:
        if not self.license_service.status().get("valid"):
            return
        threading.Thread(
            target=self.license_service.track_daily_heartbeat,
            daemon=True,
        ).start()

    # ================= Điều phối pipeline =================

    def start_pipeline(self, steps: list[str] | str,
                       extra: dict | None = None) -> bool:
        """Chạy pipeline trên worker thread. steps="ALL" để chạy trọn bộ.

        extra: dữ liệu bổ sung (subtitle_path, translated_subtitle_path...).
        """
        if not self._ensure_license_valid():
            return False
        project = self.projects.current
        if project is None:
            QMessageBox.warning(self, APP_NAME, "Vui lòng mở một dự án.")
            return False
        if self.engine.is_running():
            QMessageBox.warning(self, APP_NAME,
                                "Một tác vụ đang chạy. Vui lòng chờ hoặc hủy tác vụ.")
            return False

        context = {
            "project": project,
            "config": self.config,
            "tm": self.tm,
            "gemini": GeminiClient(self.api) if self.api.keys else None,
            "video_path": project.video_path,
        }
        # Giữ kết quả các bước trước (segments, voice_files, clip_files...).
        for key in ("segments", "voice_files", "clip_files",
                    "subtitle_mode", "subtitle_for_merge"):
            if key in self.engine.context:
                context[key] = self.engine.context[key]
        context.update(extra or {})

        # Các thao tác Studio có thể đã lưu sub/dịch trực tiếp xuống DB sau lần
        # pipeline trước. Khi chạy voice/translate/video, ưu tiên dữ liệu mới nhất
        # từ project để không dùng context cũ còn thiếu cột "Bản dịch".
        if not extra or "segments" not in extra:
            if any(step in (steps if steps != "ALL" else ["ALL"])
                   for step in ("translate", "voice", "video", "subtitle_style", "ALL")):
                context["segments"] = project.load_segments()

        # Studio có thể đã sinh voice/clip từng dòng ra ổ đĩa (khác phiên chạy)
        # - quét lại để pipeline dùng luôn, không bắt làm lại từ đầu.
        if "voice_files" not in context:
            found_voices = self._scan_numbered(
                Path(project.root) / "voices", ".wav"
            )
            if found_voices:
                context["voice_files"] = found_voices
        if "clip_files" not in context:
            found_clips = {
                line: path
                for line, path in self._scan_numbered(
                    Path(project.root) / "clips", ".mp4"
                ).items()
                if "_" not in Path(path).stem  # bỏ file tạm 001_raw.mp4
            }
            if found_clips:
                context["clip_files"] = found_clips

        if steps == "ALL":
            keys = ["import"] + [k for k, _ in PIPELINE_STEPS]
        else:
            keys = list(steps)
            # Các bước cần video đều phải qua import để kiểm tra file.
            if keys[0] in ("subtitle", "video") and not context.get("subtitle_path"):
                keys = ["import"] + keys

        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0%")
        self._set_pipeline_running(True)
        try:
            self.engine.run_steps(keys, context)
        except (RuntimeError, ValueError) as exc:
            self._set_pipeline_running(False)
            QMessageBox.warning(self, APP_NAME, str(exc))
            return False
        self.show_status("Đang xử lý...")
        return True

    # ================= Hàng đợi nhiều dự án =================

    def is_batch_running(self) -> bool:
        return self._batch_active

    def _normalize_batch_subtitle_source(
        self, source: str, project: Project | None = None
    ) -> str:
        """Chuẩn hoá nguồn tách sub trong hàng loạt.

        Giá trị cũ "drive"/"ocr" trong preset trước đây từng trỏ về Google Drive
        nội bộ. UI hiện tại dùng OCR máy chủ cho "OCR phụ đề trong hình", nên
        batch phải đi cùng nhánh với chạy thủ công: remote_ocr.
        """
        value = str(source or "project")
        if value == "project":
            mode = ""
            if project is not None:
                mode = str(project.get_meta("subtitle_extraction_mode", "") or "")
            if not mode:
                mode = str(getattr(self.config, "subtitle_source", "") or "")
            if mode == "audio":
                return "voice"
            if mode in {"remote_ocr", "ocr", "drive", ""}:
                return "remote_ocr"
            return mode
        if value in {"ocr", "drive"}:
            return "remote_ocr"
        return value

    @staticmethod
    def _parse_batch_voice_source(source: str) -> tuple[str, str]:
        """Trả về (tts_provider, voice_api_type). Hỗ trợ cả plan cũ api/local."""
        value = str(source or "").strip()
        if value in {"", "none"}:
            return "none", ""
        if value == "local":
            return "local", ""
        if value == "api":
            return "api", "current"
        if value.startswith("api:"):
            return "api", value.split(":", 1)[1].strip() or "current"
        return value, "current" if value == "api" else ""

    def _apply_batch_voice_source(self, source: str) -> str:
        """Áp nguồn voice cho batch và trả nhãn ngắn để ghi log."""
        provider, api_type = self._parse_batch_voice_source(source)
        if provider == "none":
            return "Không"
        self.config.tts_provider = provider
        if provider == "api" and api_type and api_type != "current":
            self.config.voice_api_type = api_type
        if provider == "local":
            return "giọng cục bộ"
        active_api = (
            api_type if api_type != "current"
            else str(getattr(self.config, "voice_api_type", "") or "current")
        )
        labels = {
            "current": "API giọng hiện tại",
            "vietauto": "API giọng đối tác",
            "omnivoice_server": "API máy chủ riêng",
            "capcut": "Giọng CapCut",
            "openai": "API giọng tiêu chuẩn",
            "elevenlabs": "API giọng cao cấp",
            "custom": "API tùy chỉnh",
        }
        return labels.get(active_api, active_api)

    def start_project_batch(self, names: list[str], plan: dict | None = None) -> None:
        """Validate and run the selected workflow sequentially for projects."""
        if not self._ensure_license_valid():
            return
        if self.engine.is_running() or self._batch_active:
            QMessageBox.warning(self, APP_NAME, "Một hàng đợi đang chạy.")
            return
        plan = dict(plan or {})
        steps = [
            key for key in plan.get("steps", ["subtitle", "translate", "voice", "merge"])
            if key in {"subtitle", "translate", "voice", "merge"}
        ]
        if not steps:
            QMessageBox.warning(self, APP_NAME, "Chưa chọn bước nào trong quy trình.")
            return
        if "translate" in steps and not str(
            getattr(self.config, "target_language", "") or ""
        ).strip():
            QMessageBox.warning(
                self, APP_NAME,
                "Chưa chọn ngôn ngữ đích. Vào tab Phụ đề → Dịch tự động để chọn trước.",
            )
            return

        invalid_video: list[str] = []
        missing_region: list[str] = []
        missing_asr: list[str] = []
        valid: list[str] = []
        for name in names:
            root = self.projects.projects_dir / name
            try:
                project = Project(root)
            except Exception:  # noqa: BLE001
                invalid_video.append(name)
                continue
            try:
                if not project.video_path or not Path(project.video_path).exists():
                    invalid_video.append(name)
                else:
                    source = self._normalize_batch_subtitle_source(
                        str(plan.get("subtitle_primary", "project") or "project"),
                        project,
                    )
                    fallback_source = self._normalize_batch_subtitle_source(
                        str(plan.get("subtitle_fallback", "none") or "none"),
                        project,
                    )
                    if "subtitle" not in steps:
                        valid.append(name)
                    elif source == "voice":
                        if self.config.asr_configured():
                            valid.append(name)
                        elif (
                            fallback_source == "remote_ocr"
                            and project.has_ocr_region
                            and str(getattr(self.config, "remote_ocr_url", "") or "").strip()
                        ):
                            valid.append(name)
                        else:
                            missing_asr.append(name)
                    elif source == "remote_ocr":
                        if project.has_ocr_region and str(
                            getattr(self.config, "remote_ocr_url", "") or ""
                        ).strip():
                            valid.append(name)
                        elif fallback_source == "voice" and self.config.asr_configured():
                            valid.append(name)
                        else:
                            missing_region.append(name)
                    elif not project.has_ocr_region:
                        if (
                            fallback_source == "voice"
                            and self.config.asr_configured()
                        ):
                            valid.append(name)
                        else:
                            missing_region.append(name)
                    else:
                        valid.append(name)
            finally:
                project.close()
        preflight_failures: list[tuple[str, bool, str]] = []
        if invalid_video or missing_region or missing_asr:
            lines = []
            if invalid_video:
                lines.append("Chưa có video hợp lệ: " + ", ".join(invalid_video))
                preflight_failures.extend(
                    (name, False, "Chưa có video hợp lệ") for name in invalid_video
                )
            if missing_region:
                lines.append("Chưa khoanh vùng phụ đề: " + ", ".join(missing_region))
                preflight_failures.extend(
                    (name, False, "Chưa khoanh vùng phụ đề") for name in missing_region
                )
            if missing_asr:
                lines.append(
                    "Dự án chọn nhận diện lời thoại nhưng chưa có API key: "
                    + ", ".join(missing_asr)
                )
                preflight_failures.extend(
                    (name, False, "Chưa cấu hình API nhận diện lời thoại")
                    for name in missing_asr
                )
            QMessageBox.warning(
                self, APP_NAME,
                "Một số dự án chưa thể chạy:\n\n" + "\n".join(lines)
                + ("\n\nCác dự án này sẽ được bỏ qua; hàng đợi tiếp tục với dự án hợp lệ."
                   if valid and str(plan.get("error_policy", "continue")) == "continue"
                   else ""),
            )
            if str(plan.get("error_policy", "continue")) == "stop":
                return
        if not valid:
            return

        self._batch_original_project = (
            self.projects.current.name if self.projects.current else ""
        )
        self._batch_queue = list(valid)
        self._batch_results = preflight_failures
        self._batch_total = len(valid) + len(preflight_failures)
        self._batch_current = ""
        self._batch_last_error = ""
        self._batch_steps = list(steps)
        self._batch_action_label = "trọn quy trình"
        self._batch_plan = plan
        fields = (
            "subtitle_source", "translation_source", "tts_provider",
            "voice_api_type", "default_voice", "render_profile",
        )
        self._batch_config_snapshot = {
            field: getattr(self.config, field) for field in fields
        }
        self._batch_active = True
        self._batch_cancelled = False
        project_page = self.pages[0] if getattr(self, "pages", None) else None
        if project_page and callable(getattr(project_page, "prepare_batch_rows", None)):
            project_page.prepare_batch_rows(valid)
            for failed_name, _ok, detail in preflight_failures:
                project_page.set_project_runtime(
                    failed_name, "Kiểm tra đầu vào", 0, detail, "error"
                )
        self._set_project_batch_status(
            f"Đã xếp hàng {self._batch_total} dự án — đang chuẩn bị..."
        )
        self._run_next_batch_project()

    def start_export_batch(self, names: list[str]) -> None:
        """Render/export checked projects that already have video, subtitles and voices."""
        if not self._ensure_license_valid():
            return
        if self.engine.is_running() or self._batch_active:
            QMessageBox.warning(self, APP_NAME, "Một hàng đợi đang chạy.")
            return

        invalid: list[str] = []
        missing_sub: list[str] = []
        missing_voice: list[str] = []
        valid: list[str] = []
        for name in names:
            root = self.projects.projects_dir / name
            try:
                project = Project(root)
            except Exception:  # noqa: BLE001
                invalid.append(name)
                continue
            try:
                if not project.video_path or not Path(project.video_path).exists():
                    invalid.append(name)
                    continue
                segments = project.load_segments()
                if not segments:
                    missing_sub.append(name)
                    continue
                voices = self._scan_numbered(Path(project.root) / "voices", ".wav")
                absent = [seg.line for seg in segments if seg.line not in voices]
                if absent:
                    preview = ", ".join(map(str, absent[:8]))
                    suffix = "..." if len(absent) > 8 else ""
                    missing_voice.append(
                        f"{name} thiếu {len(absent)}/{len(segments)} voice "
                        f"(dòng {preview}{suffix})"
                    )
                    continue
                valid.append(name)
            finally:
                project.close()
        if invalid or missing_sub or missing_voice:
            lines = []
            if invalid:
                lines.append("Chưa có video hợp lệ: " + ", ".join(invalid))
            if missing_sub:
                lines.append("Chưa có phụ đề: " + ", ".join(missing_sub))
            if missing_voice:
                lines.append("Thiếu voice:\n" + "\n".join(missing_voice))
            QMessageBox.warning(
                self, APP_NAME,
                "Chưa thể xuất hàng loạt:\n\n" + "\n".join(lines),
            )
            return
        if not valid:
            return

        self._batch_original_project = (
            self.projects.current.name if self.projects.current else ""
        )
        self._batch_queue = list(valid)
        self._batch_results = []
        self._batch_total = len(valid)
        self._batch_current = ""
        self._batch_last_error = ""
        self._batch_steps = ["merge"]
        self._batch_action_label = "xuất video"
        self._batch_plan = {}
        self._batch_config_snapshot = {}
        self._batch_active = True
        self._batch_cancelled = False
        self._set_project_batch_status(
            f"Đã xếp hàng xuất video {self._batch_total} dự án — đang chuẩn bị..."
        )
        self._run_next_batch_project()

    def _run_next_batch_project(self) -> None:
        if not self._batch_active:
            return
        if self._batch_cancelled or not self._batch_queue:
            self._finish_project_batch()
            return
        name = self._batch_queue.pop(0)
        self._batch_current = name
        self._batch_last_error = ""
        self._batch_failed_step = ""
        self._batch_fallback_attempted = set()
        self._batch_fallback_log = []
        index = len(self._batch_results) + 1
        try:
            self.projects.open(name)
        except ValueError as exc:
            self._batch_results.append((name, False, str(exc)))
            page = self.pages[0]
            if callable(getattr(page, "set_project_runtime", None)):
                page.set_project_runtime(name, "Mở dự án", 0, str(exc), "error")
            QTimer.singleShot(0, self._run_next_batch_project)
            return
        self.on_project_changed()
        self._apply_batch_plan_for_project(self.projects.current)
        steps = self._effective_batch_steps(self.projects.current)
        self._batch_current_steps = list(steps)
        self._set_project_batch_status(
            f"Dự án {index}/{self._batch_total}: {name} — bắt đầu {self._batch_action_label}..."
        )
        page = self.pages[0]
        if callable(getattr(page, "set_project_runtime", None)):
            page.set_project_runtime(name, "Chuẩn bị", 0, "Đang khởi động", "running")
        if not steps:
            self._batch_results.append((name, True, "Đã có đủ kết quả — bỏ qua"))
            if callable(getattr(page, "set_project_runtime", None)):
                page.set_project_runtime(name, "Hoàn tất", 100, "Đã có đủ kết quả", "complete")
            QTimer.singleShot(0, self._run_next_batch_project)
            return
        if not self.start_pipeline(steps, {"batch_mode": True, "batch_plan": dict(self._batch_plan)}):
            self._batch_results.append((name, False, "Không khởi động được pipeline"))
            if callable(getattr(page, "set_project_runtime", None)):
                page.set_project_runtime(
                    name, "Khởi động", 0, "Không khởi động được pipeline", "error"
                )
            QTimer.singleShot(0, self._run_next_batch_project)

    def _apply_batch_plan_for_project(self, project: Project | None) -> None:
        """Áp snapshot cho project hiện tại nhưng không ghi đè settings người dùng."""
        if project is None or not self._batch_plan:
            return
        source = self._normalize_batch_subtitle_source(
            str(self._batch_plan.get("subtitle_primary", "project") or "project"),
            project,
        )
        fallback = self._normalize_batch_subtitle_source(
            str(self._batch_plan.get("subtitle_fallback", "none") or "none"),
            project,
        )
        if source == "remote_ocr" and not project.has_ocr_region and fallback == "voice" and self.config.asr_configured():
            source = "voice"
            self._batch_fallback_log.append("Tách phụ đề dùng ASR vì dự án chưa có vùng OCR")
        elif source == "voice" and not self.config.asr_configured() and fallback == "remote_ocr" and project.has_ocr_region:
            source = "remote_ocr"
            self._batch_fallback_log.append("Tách phụ đề dùng OCR máy chủ vì ASR chưa được cấu hình")
        self.config.subtitle_source = source
        self.config.translation_source = str(
            self._batch_plan.get("translation_primary", self.config.translation_source)
        )
        self._apply_batch_voice_source(
            str(self._batch_plan.get("voice_primary", self.config.tts_provider) or "")
        )
        voice = str(self._batch_plan.get("voice_name", "") or "").strip()
        if voice:
            self.config.default_voice = voice
        self.config.render_profile = str(
            self._batch_plan.get("render_profile", self.config.render_profile)
        )

    def _effective_batch_steps(self, project: Project | None) -> list[str]:
        steps = list(self._batch_steps) if self._batch_steps != "ALL" else [
            key for key, _label in PIPELINE_STEPS
        ]
        if project is None or not bool(self._batch_plan.get("skip_completed", True)):
            return steps
        segments = project.load_segments()
        completed: set[str] = set()
        if segments:
            completed.add("subtitle")
            translatable = [
                seg for seg in segments
                if (seg.text or "").strip()
                and not (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được")
            ]
            if translatable and all((seg.translation or "").strip() for seg in translatable):
                completed.add("translate")
            voices = self._scan_numbered(Path(project.root) / "voices", ".wav")
            if segments and all(seg.line in voices for seg in segments):
                completed.add("voice")
        export_dir = str(getattr(self.config, "export_dir", "") or "").strip()
        final_video = (
            Path(export_dir) / f"{project.name}.mp4"
            if export_dir else Path(project.root) / "output" / "Final.mp4"
        )
        if final_video.is_file() and final_video.stat().st_size > 0:
            completed.add("merge")
        effective: list[str] = []
        upstream_will_change = False
        for step in steps:
            if upstream_will_change or step not in completed:
                effective.append(step)
                upstream_will_change = True
        return effective

    def _set_project_batch_status(self, message: str) -> None:
        page = self.pages[0] if getattr(self, "pages", None) else None
        if page and callable(getattr(page, "set_batch_status", None)):
            page.set_batch_status(message)
        self.show_status(message)

    def _finish_project_batch(self) -> None:
        cancelled = self._batch_cancelled
        results = list(self._batch_results)
        total = self._batch_total
        self._batch_active = False
        self._batch_queue = []
        self._batch_current = ""
        for field, value in self._batch_config_snapshot.items():
            setattr(self.config, field, value)
        self._batch_config_snapshot = {}
        self._batch_plan = {}
        self._batch_current_steps = []
        if self._batch_original_project:
            try:
                self.projects.open(self._batch_original_project)
                self.on_project_changed()
            except ValueError:
                pass
        ok_count = sum(success for _name, success, _detail in results)
        message = (
            f"Đã hủy hàng đợi — hoàn tất {len(results)}/{total} dự án."
            if cancelled else
            f"Hoàn tất hàng đợi: {ok_count}/{total} dự án thành công."
        )
        self._set_project_batch_status(message)
        failures = [f"• {name}: {detail}" for name, ok, detail in results if not ok]
        detail = message + (("\n\n" + "\n".join(failures)) if failures else "")
        if failures or cancelled:
            QMessageBox.warning(self, APP_NAME, detail)
        else:
            QMessageBox.information(self, APP_NAME, detail)

    @staticmethod
    def _scan_numbered(folder: Path, ext: str) -> dict[int, str]:
        """Quét file dạng số (0001.wav, 001.mp4) -> {line: đường dẫn}."""
        result: dict[int, str] = {}
        if folder.is_dir():
            for p in sorted(folder.glob(f"*{ext}")):
                try:
                    result[int(p.stem)] = str(p)
                except ValueError:
                    continue  # bỏ file không phải dạng số
        return result

    # ================= Slots =================

    def _on_nav_changed(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        if 0 <= index < len(self.pages):
            self.pages[index].refresh()

    def _pause_clicked(self) -> None:
        self.engine.pause()
        self.btn_pause.setEnabled(False)
        self.btn_resume.setEnabled(True)
        self.show_status("Đã yêu cầu tạm dừng - bấm 'Tiếp tục' để chạy tiếp.")

    def _resume_clicked(self) -> None:
        self.engine.resume()
        self.btn_pause.setEnabled(True)
        self.btn_resume.setEnabled(False)
        self.show_status("Đã tiếp tục tác vụ.")

    def _cancel_clicked(self) -> None:
        if self._batch_active:
            self._batch_cancelled = True
            self._batch_queue.clear()
            self._set_project_batch_status("Đang hủy toàn bộ hàng đợi dự án...")
        self.engine.cancel()

    def _set_pipeline_running(self, running: bool) -> None:
        self.btn_pause.setEnabled(running)
        self.btn_resume.setEnabled(False)
        self.btn_cancel.setEnabled(running)

    def _on_step_started(self, key: str) -> None:
        label = dict(PIPELINE_STEPS).get(key, key)
        self._current_step_key = key
        self._current_step_label = label
        self._current_step_pct = 0
        self._current_step_message = ""
        self._step_wall_started = time.monotonic()
        self._runtime_timer.start()
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0% · 0:00")
        self.show_status(f"{self._activity_status(key)} · 0 giây")
        if self._batch_active and self._batch_current:
            page = self.pages[0]
            if callable(getattr(page, "set_project_runtime", None)):
                page.set_project_runtime(
                    self._batch_current, label, 0, "Đang xử lý", "running"
                )

    def _on_step_progress(self, key: str, pct: int, msg: str) -> None:
        pct = max(0, min(100, int(pct)))
        self._current_step_pct = pct
        self._current_step_message = msg
        self.progress_bar.setValue(pct)
        self._refresh_elapsed_status()
        if self._batch_active and self._batch_current:
            index = len(self._batch_results) + 1
            page = self.pages[0]
            if callable(getattr(page, "set_batch_status", None)):
                elapsed = max(0.0, time.monotonic() - self._step_wall_started)
                label = self._current_step_label or dict(PIPELINE_STEPS).get(key, key)
                page.set_batch_status(
                    f"Dự án {index}/{self._batch_total}: {self._batch_current} — "
                    f"{label} {pct}% · {format_elapsed(elapsed)}"
                )
                if callable(getattr(page, "set_project_runtime", None)):
                    page.set_project_runtime(
                        self._batch_current, label, pct,
                        msg or f"Đang xử lý {pct}%", "running",
                    )

    def _refresh_elapsed_status(self) -> None:
        if not self._step_wall_started or not self.engine.is_running():
            return
        elapsed = max(0.0, time.monotonic() - self._step_wall_started)
        self.progress_bar.setFormat(
            f"{self._current_step_pct}% · {format_elapsed(elapsed, compact=True)}"
        )
        activity = self._activity_status(
            self._current_step_key,
            self._current_step_message,
        )
        self.show_status(f"{activity} · {format_elapsed(elapsed)}")

    @staticmethod
    def _activity_status(key: str, message: str = "") -> str:
        """Chỉ công khai công việc đang làm, không lộ số liệu/cơ chế nội bộ."""
        step = str(key or "").strip().lower()
        detail = str(message or "").strip().lower()
        if step == "subtitle":
            if any(word in detail for word in (
                "trích âm", "âm thanh", "audio", "asr", "voice",
            )):
                return "Đang nhận diện âm thanh..."
            if any(word in detail for word in (
                "ocr", "máy chủ", "đọc ảnh", "đọc phụ đề", "nhận diện đồng thời",
            )):
                return "Đang nhận diện phụ đề..."
            if any(word in detail for word in (
                "kiểm tra", "làm sạch", "hoàn thiện", "lọc", "gộp", "cứu",
            )):
                return "Đang hoàn thiện phụ đề..."
            if any(word in detail for word in (
                "quét", "scan", "phát hiện", "dò vùng", "candidate",
            )):
                return "Đang quét video..."
            return "Đang tách phụ đề..."
        return {
            "import": "Đang nhập video...",
            "translate": "Đang dịch phụ đề...",
            "character": "Đang phân vai...",
            "voice": "Đang tạo giọng đọc...",
            "merge": "Đang xuất video...",
            "video": "Đang xuất video...",
        }.get(step, "Đang xử lý...")

    def _on_step_finished(self, key: str) -> None:
        elapsed = self.engine.step_timings.get(key, 0.0)
        label = dict(PIPELINE_STEPS).get(key, key)
        if key in {"subtitle", "translate", "character", "voice"}:
            subtitle_page = self.pages[1] if len(self.pages) > 1 else None
            invalidate = getattr(subtitle_page, "invalidate", None)
            if callable(invalidate):
                invalidate()
        self.progress_bar.setValue(100)
        self.progress_bar.setFormat(
            f"100% · {format_elapsed(elapsed, compact=True)}"
        )
        self.show_status(
            f"Đã hoàn tất {label.lower()} · {format_elapsed(elapsed)}"
        )
        self._step_wall_started = 0.0

    def _timing_summary(self) -> str:
        labels = dict(PIPELINE_STEPS)
        parts = [
            f"{labels.get(key, key)}: {format_elapsed(seconds)}"
            for key, seconds in self.engine.step_timings.items()
        ]
        if len(parts) > 1 and self.engine.pipeline_elapsed:
            parts.append(f"Tổng: {format_elapsed(self.engine.pipeline_elapsed)}")
        return " | ".join(parts)

    def _on_step_failed(self, key: str, error: str) -> None:
        self._runtime_timer.stop()
        self._step_wall_started = 0.0
        # Không đổ traceback/command line trình duyệt dài hàng nghìn ký tự vào UI.
        public_error = str(error).split("Browser logs:", 1)[0].strip()
        public_error = re.sub(
            r"BrowserType\.launch_persistent_context:[^;\n]*",
            "Không thể khởi động phiên trình duyệt",
            public_error,
        )
        public_error = self._public_status(public_error)
        if self._batch_active:
            self._batch_failed_step = key
            self._batch_last_error = public_error
            self._set_project_batch_status(
                f"Dự án {self._batch_current} lỗi ở {dict(PIPELINE_STEPS).get(key, key)}; "
                "đang kiểm tra nguồn dự phòng."
            )
            page = self.pages[0]
            if callable(getattr(page, "set_project_runtime", None)):
                page.set_project_runtime(
                    self._batch_current,
                    dict(PIPELINE_STEPS).get(key, key),
                    self._current_step_pct,
                    f"Lỗi: {public_error}",
                    "error",
                )
            return
        QMessageBox.critical(
            self, APP_NAME, f"Không thể hoàn tất bước xử lý:\n\n{public_error}"
        )

    def _on_pipeline_finished(self, success: bool) -> None:
        self._runtime_timer.stop()
        self._step_wall_started = 0.0
        self._set_pipeline_running(False)
        self.update_right_panel()
        current = self.stack.currentWidget()
        if hasattr(current, "refresh"):
            current.refresh()
        if self._batch_active:
            if not success and self._try_batch_fallback():
                return
            timing = self._timing_summary()
            detail = self._batch_last_error or ("Hoàn tất" if success else "Đã dừng")
            if self._batch_fallback_log:
                detail += " — " + "; ".join(self._batch_fallback_log)
            if timing:
                detail += f" — {timing}"
            self._batch_results.append((self._batch_current, success, detail))
            page = self.pages[0]
            if callable(getattr(page, "set_project_runtime", None)):
                if success:
                    page.set_project_runtime(
                        self._batch_current, "Hoàn tất", 100, "Hoàn tất", "complete"
                    )
                else:
                    page.set_project_runtime(
                        self._batch_current,
                        dict(PIPELINE_STEPS).get(self._batch_failed_step, self._batch_failed_step or "Lỗi"),
                        self._current_step_pct,
                        self._batch_last_error or "Đã dừng",
                        "error",
                    )
            if (
                not success
                and str(self._batch_plan.get("error_policy", "continue")) == "stop"
            ):
                self._batch_cancelled = True
                self._batch_queue.clear()
            if self._batch_cancelled:
                self._finish_project_batch()
            else:
                QTimer.singleShot(200, self._run_next_batch_project)
            return
        if success:
            timing = self._timing_summary()
            total_elapsed = max(0.0, float(self.engine.pipeline_elapsed or 0.0))
            self.show_status(
                f"Hoàn tất · {format_elapsed(total_elapsed)}"
                if total_elapsed else "Hoàn tất"
            )
            final = self.engine.context.get("final_video")
            if final:
                QMessageBox.information(
                    self, APP_NAME,
                    f"Video hoàn chỉnh:\n{final}"
                    + (f"\n\nThời gian xử lý:\n{timing}" if timing else ""),
                )
            elif timing:
                QMessageBox.information(
                    self, APP_NAME, f"Hoàn tất xử lý.\n\n{timing}"
                )
        else:
            self.show_status("Tác vụ đã dừng")

    def _try_batch_fallback(self) -> bool:
        """Đổi nguồn rồi chạy lại từ đúng bước lỗi; kết quả bước trước được giữ."""
        step = self._batch_failed_step
        if not step or not self._batch_plan:
            return False
        source = ""
        label = ""
        if step == "subtitle":
            source = self._normalize_batch_subtitle_source(
                str(self._batch_plan.get("subtitle_fallback", "none") or "none"),
                self.projects.current,
            )
            if source in {"none", str(self.config.subtitle_source)}:
                return False
            if source == "voice" and not self.config.asr_configured():
                return False
            if source == "remote_ocr":
                project = self.projects.current
                if (
                    not project
                    or not project.has_ocr_region
                    or not str(getattr(self.config, "remote_ocr_url", "") or "").strip()
                ):
                    return False
            self.config.subtitle_source = source
            label = "ASR âm thanh" if source == "voice" else "OCR máy chủ"
        elif step == "translate":
            source = str(self._batch_plan.get("translation_fallback", "none") or "none")
            if source in {"none", str(self.config.translation_source)}:
                return False
            self.config.translation_source = source
            label = {"qwen": "Dịch nhanh", "web": "Dịch Gemini", "api": "API cũ"}.get(source, source)
        elif step == "voice":
            source = str(self._batch_plan.get("voice_fallback", "none") or "none")
            provider, api_type = self._parse_batch_voice_source(source)
            if provider == "none":
                return False
            current_source = (
                "local" if str(self.config.tts_provider) == "local"
                else f"api:{getattr(self.config, 'voice_api_type', 'current')}"
            )
            target_api = (
                api_type if api_type != "current"
                else str(getattr(self.config, "voice_api_type", "current") or "current")
            )
            target_source = "local" if provider == "local" else f"api:{target_api}"
            if target_source == current_source:
                return False
            label = self._apply_batch_voice_source(source)
        elif step == "merge":
            source = "quality"
            if str(self.config.render_profile) == source:
                return False
            self.config.render_profile = source
            label = "CPU chất lượng cao"
        else:
            return False

        attempt_key = (step, source)
        if attempt_key in self._batch_fallback_attempted:
            return False
        self._batch_fallback_attempted.add(attempt_key)
        self._batch_fallback_log.append(
            f"{dict(PIPELINE_STEPS).get(step, step)} chuyển sang {label}"
        )
        project = self.projects.current
        if project is not None:
            try:
                project.add_history(step, "fallback", f"Chuyển sang {label}")
            except Exception:  # noqa: BLE001
                logger.exception("Không ghi được lịch sử fallback")
        try:
            index = self._batch_current_steps.index(step)
            retry_steps = self._batch_current_steps[index:]
        except ValueError:
            retry_steps = [step]
        self._batch_last_error = ""
        self._batch_failed_step = ""
        self._set_project_batch_status(
            f"Dự án {self._batch_current}: thử lại từ {dict(PIPELINE_STEPS).get(step, step)} "
            f"bằng {label}..."
        )
        page = self.pages[0]
        if callable(getattr(page, "set_project_runtime", None)):
            page.set_project_runtime(
                self._batch_current,
                dict(PIPELINE_STEPS).get(step, step),
                0,
                f"Đang chuyển sang {label}",
                "running",
            )

        def restart() -> None:
            if not self.start_pipeline(
                retry_steps,
                {"batch_mode": True, "batch_retry": True, "batch_plan": dict(self._batch_plan)},
            ):
                self._batch_last_error = "Không khởi động được nguồn dự phòng"
                self._batch_results.append((self._batch_current, False, self._batch_last_error))
                QTimer.singleShot(0, self._run_next_batch_project)

        QTimer.singleShot(250, restart)
        return True

    # ================= Cập nhật UI =================

    def on_project_changed(self) -> None:
        """Gọi sau khi tạo/mở project."""
        self.engine.context = {}
        self.refresh_all()
        project = self.projects.current
        if project:
            self.show_status(f"Dự án: {project.name}")

    def refresh_all(self) -> None:
        self.update_right_panel()
        current = self.stack.currentWidget()
        if hasattr(current, "refresh"):
            current.refresh()

    def update_right_panel(self) -> None:
        """Cập nhật dải thông tin gọn ở status bar (giữ tên cũ để tương thích)."""
        project = self.projects.current
        if project:
            video = (Path(project.video_path).name if project.video_path
                     else "chưa chọn video")
            self.info_compact.setText(
                f"{project.name} | {video} | "
                f"{len(project.load_segments())} phụ đề"
            )
        else:
            self.info_compact.setText("Chưa mở dự án")

    def show_status(self, message: str) -> None:
        self.status_label.setText(self._public_status(str(message)))

    @staticmethod
    def _public_status(message: str) -> str:
        """Ẩn tên nhà cung cấp/cơ chế khỏi status và popup lỗi."""
        text = str(message)
        replacements = (
            (r"Gemini(?:\s+Web)?|Google\s+Drive|Drive\s+OCR|Cloud\s+Vision|Vision\s+OCR|Vision\s+API|Vision|Google|Qwen(?:3)?|Alibaba|OpenAI|ElevenLabs|VietAuto|OmniVoice", "dịch vụ trực tuyến"),
            (r"VideoSubFinder|VSF|detector|state machine", "bộ nhận diện"),
            (r"credentials\.json|credential[s]?", "file kết nối"),
            (r"token\.json|token", "phiên đăng nhập"),
            (r"API\s*key|API", "khóa truy cập"),
            (r"montage|panel", "ảnh mẫu"),
            (r"Chrome|Playwright|browser|profile", "trình duyệt"),
            (r"FFmpeg|ffprobe", "thành phần xử lý video"),
        )
        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    # ================= Phát audio trong app =================

    def play_audio(self, path: str) -> None:
        """Gọi được từ mọi thread - phát wav ngay trong app."""
        self.audio_ready.emit(path)

    def _play_audio(self, path: str) -> None:
        try:
            from PyQt6.QtMultimedia import QSoundEffect  # noqa: PLC0415

            self._sound = QSoundEffect(self)
            self._sound.setSource(QUrl.fromLocalFile(path))
            self._sound.setVolume(1.0)
            self._sound.play()
        except Exception:  # noqa: BLE001 - thiếu QtMultimedia thì mở player ngoài
            logger.exception("Không phát được audio trong app")
            if os.name == "nt":
                os.startfile(path)  # noqa: S606

    # ================= Đóng app =================

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        engine_was_running = self.engine.is_running()
        background_pages = [
            page for page in self.pages
            if callable(getattr(page, "has_background_task", None))
            and page.has_background_task()
        ]
        if engine_was_running or background_pages:
            answer = QMessageBox.question(
                self, APP_NAME,
                "Một tác vụ đang chạy và sẽ bị hủy nếu thoát. Bạn có muốn tiếp tục?",
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.engine.cancel()
            for page in background_pages:
                page.cancel_background_tasks()
        self.config.save()
        if engine_was_running or background_pages:
            # requests/ThreadPoolExecutor có thể đang kẹt trong socket và Python
            # sẽ chờ các worker non-daemon ở lúc shutdown. Cho chúng 2 giây dọn
            # tài liệu tạm, sau đó kết thúc process để cửa sổ đóng thực sự.
            def force_exit_if_needed() -> None:
                import time  # noqa: PLC0415
                time.sleep(2.0)
                if (self.engine.is_running()
                        or any(page.has_background_task() for page in background_pages)):
                    os._exit(0)  # noqa: SLF001 - điểm thoát cuối khi worker mạng treo

            threading.Thread(
                target=force_exit_if_needed, daemon=True, name="vicdub-exit-watchdog"
            ).start()
        event.accept()

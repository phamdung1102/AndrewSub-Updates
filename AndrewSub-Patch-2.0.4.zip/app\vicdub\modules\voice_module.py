﻿"""Voice Module - sinh giọng nói bằng OmniVoice (k2-fsa) chạy NGAY TRONG APP.

OmniVoice (https://github.com/k2-fsa/OmniVoice) là model TTS zero-shot
600+ ngôn ngữ, cài bằng `pip install omnivoice` (cần torch). Không cần
app ngoài - model nạp một lần trong process rồi tái sử dụng.

Voice chọn qua preset tiếng Việt trong data/vi_voices.

Voice được giữ đủ tự nhiên; bước đồng bộ sau đó xử lý chênh lệch thời lượng.
Cache bất biến theo hash nội dung; file theo số dòng chỉ là bản xuất để ghép.
"""

from __future__ import annotations

import hashlib
import logging
import os
import json
import shutil
import threading
import wave
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError, PermanentVoiceError
from vicdub.utils.subtitles import Segment, normalize_gender
from vicdub.utils.voice_registry import (
    DEFAULT_VOICE as DEFAULT_VI_VOICE, VI_VOICES, resolve_voice,
)

logger = logging.getLogger(__name__)

SAMPLE_RATE = 24000  # OmniVoice xuất 24 kHz

#: Ép ngôn ngữ khi sinh voice. KHÔNG truyền thì OmniVoice tự đoán, thỉnh thoảng
#: đoán nhầm -> đọc câu tiếng Việt bằng ngữ âm tiếng khác ("nhảy sang tiếng
#: khác"). Ép "vietnamese" (tên hợp lệ trong supported_language_names) cho chắc.
TTS_LANGUAGE = "vietnamese"

#: 6 giọng NỮ tiếng Việt THẬT (clone prompt tính sẵn data/vi_voices/<stem>.pt
#: từ dataset STBack23/omnivoice-vi) - nay lấy từ voice_registry để nguồn danh
#: sách giọng chỉ có một chỗ. VI_VOICES, DEFAULT_VI_VOICE import ở đầu file.

#: CHỈ dùng 6 giọng Việt của OmniVoice-vi. Không còn giọng OmniVoice tổng hợp
#: (auto / instruct) vì chúng hay đọc nhảy sang tiếng khác và giọng không ổn.
DESIGN_PRESETS: dict[str, str] = {}
PRESET_SEEDS: dict[str, int] = {}

#: Stem file .pt của giọng mặc định (dùng khi nhãn không khớp preset nào).
DEFAULT_VI_STEM = VI_VOICES[DEFAULT_VI_VOICE]

class TTSEngine(ABC):
    """Giao diện engine TTS - điểm mở rộng plugin."""

    default_voices: dict[str, str] = {}

    @abstractmethod
    def synthesize(self, text: str, voice: str, speed: float, out_wav: str,
                   duration: float | None = None) -> None:
        """Sinh file wav từ text. duration = thời lượng đích (giây, tùy chọn)."""

    @abstractmethod
    def list_voices(self) -> list[str]:
        """Danh sách voice khả dụng."""

    def synthesize_batch(self, texts: list[str], voice: str, speed: float,
                         out_wavs: list[str]) -> None:
        """Sinh nhiều câu CÙNG GIỌNG một lượt.

        Mặc định chạy tuần tự; engine hỗ trợ batch thật thì ghi đè
        (nhanh hơn nhiều trên GPU).
        """
        for text, out in zip(texts, out_wavs):
            self.synthesize(text, voice, speed, out)

    def default_voice(self, gender: str) -> str:
        return (self.default_voices.get(gender)
                or next(iter(self.default_voices.values()), "auto"))


class OmniVoiceLocalEngine(TTSEngine):
    """OmniVoice (k2-fsa) chạy in-process.

    Model nạp lười (lần synthesize đầu tiên) và cache theo process -
    lần đầu sẽ tự tải checkpoint từ HuggingFace (~vài GB).
    """

    # Dataset chỉ có giọng nữ Việt -> mọi giới tính mặc định về giọng Việt.
    default_voices = {
        "male": DEFAULT_VI_VOICE,
        "female": DEFAULT_VI_VOICE,
        "neutral": DEFAULT_VI_VOICE,
    }

    # Model dùng chung toàn app - nạp 1 lần, khóa khi sinh (không thread-safe).
    _model = None
    _model_device = ""
    _model_lock = threading.Lock()

    def __init__(self, device: str = "auto", num_step: int = 32,
                 vi_voices_dir: str | Path = "") -> None:
        self.device = device
        self.num_step = max(4, int(num_step))
        self.vi_voices_dir = Path(vi_voices_dir) if vi_voices_dir else None
        self._prompt_cache: dict[str, Any] = {}  # stem -> VoiceClonePrompt

    # ---------- Model ----------

    @classmethod
    def _resolve_device(cls, device: str) -> str:
        if device != "auto":
            return device
        try:
            import torch  # noqa: PLC0415
            return "cuda:0" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"

    def _get_model(self):
        cls = OmniVoiceLocalEngine
        device = self._resolve_device(self.device)
        if cls._model is not None and cls._model_device == device:
            return cls._model
        with cls._model_lock:
            if cls._model is not None and cls._model_device == device:
                return cls._model
            try:
                import torch  # noqa: PLC0415
                from omnivoice import OmniVoice  # noqa: PLC0415
            except ImportError as exc:
                raise ModuleError(
                    "Chưa cài OmniVoice. Chạy: pip install omnivoice\n"
                    "(cần torch - đã có nếu mày cài OmniVoice rồi)"
                ) from exc
            if cls._model is not None and cls._model_device != device:
                cls._model = None
                cls._model_device = ""
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            dtype = torch.float16 if device.startswith("cuda") else torch.float32
            model_source = self._local_omnivoice_snapshot() or "k2-fsa/OmniVoice"
            source_note = "cache local" if Path(model_source).is_dir() else "HuggingFace"
            logger.info("Nạp model OmniVoice (%s) từ %s...", device, source_note)
            cls._model = OmniVoice.from_pretrained(
                model_source, device_map=device, dtype=dtype,
            )
            cls._model_device = device
            return cls._model

    @staticmethod
    def _local_omnivoice_snapshot() -> str:
        """Trả về snapshot local của k2-fsa/OmniVoice nếu cache đã đủ."""
        hf_home = Path(os.environ.get("HF_HOME", "")).expanduser()
        if not hf_home:
            return ""
        repo_dir = hf_home / "hub" / "models--k2-fsa--OmniVoice"
        ref = repo_dir / "refs" / "main"
        if not ref.exists():
            return ""
        revision = ref.read_text(encoding="utf-8").strip()
        snapshot = repo_dir / "snapshots" / revision
        required = (
            snapshot / "config.json",
            snapshot / "model.safetensors",
            snapshot / "tokenizer.json",
            snapshot / "audio_tokenizer" / "config.json",
            snapshot / "audio_tokenizer" / "model.safetensors",
            snapshot / "audio_tokenizer" / "preprocessor_config.json",
        )
        if snapshot.is_dir() and all(path.exists() for path in required):
            return str(snapshot)
        return ""

    # ---------- Voice ----------

    def _clone_prompt(self, stem: str):
        """Nạp VoiceClonePrompt tính sẵn (data/vi_voices/<stem>.pt), có cache.

        Audio đã token hóa sẵn trong .pt nên KHÔNG cần nạp file audio -> né lỗi
        decoder video/audio ngoài mà vẫn clone được giọng thật.
        """
        if stem in self._prompt_cache:
            return self._prompt_cache[stem]
        import torch  # noqa: PLC0415
        from omnivoice.models.omnivoice import VoiceClonePrompt  # noqa: PLC0415
        if self.vi_voices_dir is None:
            raise ModuleError("Chưa cấu hình thư mục giọng Việt (vi_voices).")
        path = self.vi_voices_dir / f"{stem}.pt"
        if not path.exists():
            raise ModuleError(
                f"Thiếu file giọng '{stem}.pt' trong {self.vi_voices_dir}. "
                "Tải lại từ dataset STBack23/omnivoice-vi."
            )
        data = torch.load(path, map_location="cpu", weights_only=True)
        prompt = VoiceClonePrompt(
            ref_audio_tokens=data["ref_audio_tokens"],
            ref_text=data["ref_text"],
            ref_rms=data["ref_rms"],
        )
        self._prompt_cache[stem] = prompt
        return prompt

    def _build_kwargs(self, voice: str) -> dict[str, Any]:
        """Đổi tên voice thành tham số generate() - chỉ dùng preset giọng Việt."""
        voice = (voice or "").strip()
        if voice in VI_VOICES:  # 6 giọng nữ Việt thật (clone prompt tính sẵn)
            return {"voice_clone_prompt": self._clone_prompt(VI_VOICES[voice])}
        # auto / rỗng / tên cũ (Nam.../instruct) -> giọng Việt mặc định.
        return {"voice_clone_prompt": self._clone_prompt(DEFAULT_VI_STEM)}

    @staticmethod
    def _normalize_instruct(voice: str) -> str:
        """Chuẩn hóa instruct cũ/nhập tay sang token OmniVoice hỗ trợ."""
        replacements = {
            "male, young": "male, young adult",
            "female, young": "female, young adult",
            "young": "young adult",
        }
        return replacements.get(voice.strip(), voice)

    # ---------- TTS ----------

    @staticmethod
    def _seed_for_voice(voice: str) -> None:
        """Cố định RNG theo giọng chuẩn để giọng ổn định giữa các dòng.

        Giọng không phải preset thì không đụng seed.
        """
        seed = PRESET_SEEDS.get((voice or "").strip())
        if seed is None:
            return
        import torch  # noqa: PLC0415
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    def synthesize(self, text: str, voice: str, speed: float, out_wav: str,
                   duration: float | None = None) -> None:
        model = self._get_model()
        kwargs = self._build_kwargs(voice)
        kwargs["num_step"] = self.num_step
        kwargs["language"] = TTS_LANGUAGE  # ép tiếng Việt, tránh đọc nhầm tiếng
        if duration and duration > 0:
            kwargs["duration"] = round(float(duration), 3)  # duration đè speed
        elif speed and abs(speed - 1.0) > 0.005:
            kwargs["speed"] = float(speed)

        with OmniVoiceLocalEngine._model_lock:
            try:
                self._seed_for_voice(voice)  # giọng chuẩn -> cố định seed
                audio_list = model.generate(text=text, **kwargs)
            except Exception as exc:  # noqa: BLE001 - lỗi model báo rõ lên UI
                raise ModuleError(f"OmniVoice sinh giọng lỗi: {exc}") from exc

        if not audio_list:
            raise ModuleError("OmniVoice không trả về audio.")
        self._write_wav(audio_list[0], out_wav)

    @staticmethod
    def _write_wav(samples, out_wav: str) -> None:
        """Ghi WAV qua file tạm, kiểm tra rồi thay thế nguyên tử."""
        import numpy as np  # noqa: PLC0415 - có sẵn theo torch

        pcm = (np.clip(np.asarray(samples), -1.0, 1.0) * 32767.0).astype("<i2")
        destination = Path(out_wav)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.name + ".tmp")
        with wave.open(str(temporary), "wb") as f:
            f.setnchannels(1)
            f.setsampwidth(2)
            f.setframerate(SAMPLE_RATE)
            f.writeframes(pcm.tobytes())
        if not VoiceModule.valid_wav(temporary):
            temporary.unlink(missing_ok=True)
            raise ModuleError("File WAV vừa sinh không hợp lệ.")
        os.replace(temporary, destination)

    def synthesize_batch(self, texts: list[str], voice: str, speed: float,
                         out_wavs: list[str]) -> None:
        """Sinh cả lô câu cùng giọng trong MỘT lần gọi model - nhanh hơn
        nhiều lần so với từng câu. Bản omnivoice không nhận list thì tự
        rơi về chạy tuần tự."""
        # Giọng chuẩn (preset) phải cố định seed cho TỪNG dòng; gộp lô sẽ làm
        # RNG lệch dần khiến mỗi dòng ra một giọng khác -> sinh tuần tự.
        if (voice or "").strip() in PRESET_SEEDS:
            for text, out in zip(texts, out_wavs):
                self.synthesize(text, voice, speed, out)
            return

        model = self._get_model()
        kwargs = self._build_kwargs(voice)
        kwargs["num_step"] = self.num_step
        kwargs["language"] = TTS_LANGUAGE  # ép tiếng Việt cho cả lô
        if speed and abs(speed - 1.0) > 0.005:
            kwargs["speed"] = float(speed)

        audio_list = None
        with OmniVoiceLocalEngine._model_lock:
            try:
                audio_list = model.generate(text=list(texts), **kwargs)
            except TypeError:
                audio_list = None  # API không nhận list
            except Exception as exc:  # noqa: BLE001
                raise ModuleError(f"OmniVoice sinh giọng lỗi: {exc}") from exc

        if audio_list is not None and len(audio_list) == len(texts):
            for samples, out in zip(audio_list, out_wavs):
                self._write_wav(samples, out)
            return
        # Fallback tuần tự.
        for text, out in zip(texts, out_wavs):
            self.synthesize(text, voice, speed, out)

    def list_voices(self) -> list[str]:
        """Danh sách giọng có thể chọn: preset giọng Việt có sẵn."""
        return [
            name for name, stem in VI_VOICES.items()
            if self.vi_voices_dir and (self.vi_voices_dir / f"{stem}.pt").exists()
        ]

    # ---------- Chẩn đoán cho tab Cài đặt ----------

    def check(self) -> str:
        """Kiểm tra cài đặt, trả mô tả trạng thái (không nạp model)."""
        try:
            import omnivoice  # noqa: F401, PLC0415
        except ImportError as exc:
            raise ModuleError(
                "Chưa cài OmniVoice. Chạy: pip install omnivoice"
            ) from exc
        device = self._resolve_device(self.device)
        n_vi = sum(1 for stem in VI_VOICES.values()
                   if self.vi_voices_dir and (self.vi_voices_dir / f"{stem}.pt").exists())
        loaded = "đã nạp" if OmniVoiceLocalEngine._model is not None else \
            "sẽ nạp khi sinh voice lần đầu (tự tải model từ HuggingFace)"
        return (f"OmniVoice OK - thiết bị: {device}, {n_vi}/6 giọng Việt, "
                f"model {loaded}.")


def create_engine(config: Any) -> TTSEngine:
    """Factory: tạo engine TTS theo cấu hình."""
    if str(getattr(config, "tts_provider", "local")) == "api":
        from vicdub.api.voice_api import VoiceApiEngine  # noqa: PLC0415
        return VoiceApiEngine(config)
    data_dir = Path(getattr(config, "data_dir", "data"))
    return OmniVoiceLocalEngine(
        device=getattr(config, "tts_device", "auto"),
        num_step=getattr(config, "tts_num_step", 32),
        vi_voices_dir=data_dir / "vi_voices",
    )


class VoiceModule(BaseModule):
    """Sinh voice cho từng dòng phụ đề đã dịch."""

    name = "Sinh giọng nói"

    def __init__(self, engine: TTSEngine | None = None) -> None:
        super().__init__()
        self._engine = engine

    def _get_engine(self, data: dict[str, Any]) -> TTSEngine:
        if self._engine is not None:
            return self._engine
        return create_engine(data["config"])

    #: Đổi khi thay cơ chế sinh voice (ép tiếng Việt, preset Việt) để voice
    #: cũ trong cache bị coi là khác -> tự sinh lại đúng cách mới.
    CACHE_VERSION = "v3-vi-hash"

    @staticmethod
    def valid_wav(path: str | Path) -> bool:
        """Cache chỉ hợp lệ khi WAV mở được, mono 24 kHz và có audio."""
        try:
            with wave.open(str(path), "rb") as audio:
                return (
                    audio.getnchannels() == 1
                    and audio.getsampwidth() == 2
                    and audio.getframerate() == SAMPLE_RATE
                    and audio.getnframes() > 0
                )
        except (OSError, EOFError, wave.Error):
            return False

    @staticmethod
    def _publish_voice(cache_wav: Path, line_wav: Path) -> None:
        """Xuất bản file theo số dòng từ cache bất biến, không ghi đè cache."""
        line_wav.parent.mkdir(parents=True, exist_ok=True)
        temporary = line_wav.with_name(line_wav.name + ".tmp")
        shutil.copyfile(cache_wav, temporary)
        os.replace(temporary, line_wav)

    @staticmethod
    def cache_key(text: str, voice: str, speed: float,
                  duration: float | None = None) -> str:
        """Khóa cache: input giống nhau -> không sinh lại."""
        raw = (f"{VoiceModule.CACHE_VERSION}|{text}|{voice}|"
               f"{speed:.2f}|{duration or 0:.2f}")
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        if not segments:
            raise ModuleError("Chưa có phụ đề đã dịch để sinh giọng.")

        # Voice đọc BẢN DỊCH tiếng Việt - chưa dịch thì chặn lại, báo rõ.
        if not any(s.translation.strip() for s in segments):
            raise ModuleError(
                "Chưa có bản dịch - voice đọc cột 'Bản dịch' (tiếng Việt).\n"
                "Vào tab Phụ đề: bấm 'Dịch tự động' hoặc "
                "'Tải bản dịch SRT lên' trước.\n"
                "(Sub gốc đã là tiếng Việt? Tải chính file đó lên ở nút "
                "'Tải bản dịch SRT lên'.)"
            )

        engine = self._get_engine(data)
        voices_dir = Path(project.root) / "voices"
        cache_dir = Path(project.root) / "voice_cache"
        checkpoint_dir = Path(project.root) / ".voice_checkpoint"
        cache_dir.mkdir(parents=True, exist_ok=True)
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        speed = 1.0
        # Giọng mặc định chung: dòng nào không gán riêng thì dùng giọng này.
        # Rỗng -> dùng default của engine.
        default_voice = (getattr(data["config"], "default_voice", "") or "").strip()
        male_voice = (getattr(data["config"], "default_male_voice", "") or "").strip()
        female_voice = (getattr(data["config"], "default_female_voice", "") or "").strip()
        use_gender_voices = bool(
            getattr(data["config"], "use_gender_voices", False)
        )

        # Giọng theo NHÂN VẬT: bảng characters lưu voice_id mỗi nhân vật (bước
        # 'Phân vai' tự gán khác nhau). Dòng không gán riêng sẽ theo giọng này.
        char_voice = {
            c.get("name", ""): (c.get("voice_id") or "")
            for c in project.load_characters()
        }
        available = engine.list_voices()

        source_name = "API giọng nói" if getattr(data["config"], "tts_provider", "local") == "api" else "bộ giọng cục bộ"
        self.report(1, f"Chuẩn bị {source_name}...")

        # Dòng dùng voice NHẬP TAY (người dùng tự chọn file) được khoá lại:
        # TTS không sinh đè — đây là lựa chọn chủ động của người dùng.
        from vicdub.utils.custom_voices import load_custom_lines  # noqa: PLC0415
        custom_lines = load_custom_lines(project.root)

        # Bước 1: dòng nào cache hit dùng lại, còn lại xếp hàng chờ sinh.
        voice_files: dict[int, str] = {}
        cached_count = 0
        kept_custom = 0
        pending: list[tuple[int, str, str, Path, Path, str]] = []
        # line, text, voice, line_wav, cache_wav, key
        has_translated_text = any((seg.translation or "").strip() for seg in segments)
        for seg in segments:
            text = seg.translation if has_translated_text else seg.text
            if (not text.strip()
                    or text.strip().casefold().startswith("[ocr chưa đọc được")):
                continue
            if seg.line in custom_lines:
                custom_wav = voices_dir / f"{seg.line:04d}.wav"
                if self.valid_wav(custom_wav):
                    voice_files[seg.line] = str(custom_wav)
                    kept_custom += 1
                    continue
                # File khoá nhưng wav mất/hỏng -> sinh lại bình thường.
            # Ưu tiên: voice riêng của dòng > giọng của NHÂN VẬT > mặc định chung
            # > giọng đầu khả dụng. Chỉ trả nhãn hợp lệ (bỏ nhãn cũ/không tồn tại).
            gender = normalize_gender(getattr(seg, "gender", "neutral"))
            gender_default = ""
            if use_gender_voices:
                if gender == "male":
                    gender_default = male_voice
                elif gender == "female":
                    gender_default = female_voice
            voice = resolve_voice(
                seg.voice, getattr(seg, "speaker", ""), char_voice,
                default=gender_default or default_voice, available=available,
            )
            signature = getattr(engine, "provider_signature", "local:omnivoice")
            key = self.cache_key(text, f"{signature}|{voice}", speed)
            cached = Path(project.cache_get(key) or "")
            cache_wav = cache_dir / f"{key}.wav"
            line_wav = voices_dir / f"{seg.line:04d}.wav"
            # Chỉ tin cache v3 bất biến theo hash; bỏ cache cũ trỏ vào 0001.wav.
            if cached == cache_wav and self.valid_wav(cached):
                self._publish_voice(cached, line_wav)
                voice_files[seg.line] = str(line_wav)
                cached_count += 1
                continue
            pending.append((seg.line, text, voice, line_wav, cache_wav, key))

        # Bước 2: gom TOÀN BỘ dòng cùng giọng, không bắt buộc nằm liên tiếp.
        # Local OmniVoice giữ cách cũ. API voice chạy nhiều lô song song vì nút thắt
        # là network/server queue; mỗi câu vẫn ghi WAV riêng để không lệch timeline.
        api_mode = str(getattr(data["config"], "tts_provider", "local") or "local") == "api"
        batch_size = max(1, int(getattr(
            data["config"],
            "voice_api_batch_size" if api_mode else "tts_batch_size",
            5 if api_mode else 8,
        )))
        concurrency = max(1, int(getattr(data["config"], "voice_api_concurrency", 4)))
        concurrency = min(concurrency, 8)
        if api_mode and getattr(engine, "kind", "") == "capcut":
            # API không chính thức, xác thực bằng vân tay thiết bị: bắn dồn dập
            # rất dễ bị chặn. Hạ mức song song riêng cho nguồn này.
            batch_size = 15
            concurrency = max(1, min(
                concurrency,
                int(getattr(data["config"], "voice_api_capcut_concurrency", 2)),
            ))
        if api_mode and getattr(engine, "kind", "") == "omnivoice_server":
            # Spec hiện tại dùng một GPU T4 và xử lý tuần tự. Xếp hàng ở client
            # để không dội nhiều request đồng thời làm đầy VRAM/server timeout.
            concurrency = 1
            ensure_ready = getattr(engine, "_ensure_omnivoice_server_ready", None)
            if pending and callable(ensure_ready) and bool(
                getattr(data["config"], "voice_api_wake_enabled", False)
            ):
                self.report(1, "Đang khởi động máy chủ giọng nói…")
                ensure_ready()
                self.report(2, "Máy chủ giọng nói đã sẵn sàng.")
        done = 0
        by_voice: dict[str, list[tuple[int, str, str, Path, Path, str]]] = {}
        for item in pending:
            by_voice.setdefault(item[2], []).append(item)

        if api_mode and getattr(engine, "kind", "") == "vietauto":
            # Lấy project_id trước khi bung luồng để tránh nhiều worker cùng tạo project.
            resolver = getattr(engine, "_vietauto_project_id", None)
            if callable(resolver):
                resolver()

        usage = None
        usage_service = (
            "vietauto-voice" if api_mode and getattr(engine, "kind", "") == "vietauto"
            else "voice-api" if api_mode
            else ""
        )
        usage_cost = sum(len(item[1]) for item in pending)
        if api_mode and usage_service:
            try:
                from vicdub.api.usage_controller import UsageController  # noqa: PLC0415
                usage = UsageController.from_config(data["config"])
                if usage is not None:
                    usage.check(usage_service, usage_cost, f"voice {len(pending)} lines")
            except Exception as exc:  # noqa: BLE001
                raise ModuleError(str(exc)) from exc

        skipped: dict[int, str] = {}
        skipped_lock = threading.Lock()

        def render_group(group) -> None:
            """Batch lỗi thì chia đôi tới từng câu để không mất cả lô."""
            self.check_cancelled()
            try:
                engine.synthesize_batch(
                    [item[1] for item in group], group[0][2], speed,
                    [str(item[4]) for item in group],
                )
                if not all(self.valid_wav(item[4]) for item in group):
                    raise ModuleError("Batch sinh ra WAV thiếu hoặc không hợp lệ.")
            except PermanentVoiceError as exc:
                if len(group) > 1:
                    middle = len(group) // 2
                    render_group(group[:middle])
                    render_group(group[middle:])
                    return
                # Câu này hỏng vì chính nội dung của nó: bỏ qua để job chạy tiếp
                # thay vì đánh sập cả lượt lồng tiếng.
                with skipped_lock:
                    skipped[group[0][0]] = str(exc)
            except Exception:
                if len(group) <= 1:
                    raise
                middle = len(group) // 2
                render_group(group[:middle])
                render_group(group[middle:])

        groups: list[list[tuple[int, str, str, Path, Path, str]]] = []
        for _voice, items in by_voice.items():
            for start in range(0, len(items), batch_size):
                groups.append(items[start:start + batch_size])

        def commit_group(group) -> None:
            for line, _text, _voice, line_wav, cache_wav, key in group:
                if line in skipped:
                    continue
                self._publish_voice(cache_wav, line_wav)
                project.cache_put(key, str(cache_wav))
                voice_files[line] = str(line_wav)
                manifest = checkpoint_dir / f"line_{line:06d}.json"
                temp = manifest.with_suffix(".tmp")
                temp.write_text(json.dumps({
                    "line": line, "key": key, "cache": str(cache_wav)
                }, ensure_ascii=False), encoding="utf-8")
                os.replace(temp, manifest)

        if api_mode and concurrency > 1 and len(groups) > 1:
            self.report(2, f"Sinh voice API song song {concurrency} luồng, "
                           f"mỗi lô tối đa {batch_size} câu...")
            with ThreadPoolExecutor(max_workers=concurrency) as pool:
                future_map = {pool.submit(render_group, group): group for group in groups}
                for future in as_completed(future_map):
                    self.check_cancelled()
                    group = future_map[future]
                    future.result()
                    commit_group(group)
                    done += len(group)
                    pct = max(2, int(100 * done / max(1, len(pending))))
                    voice = group[0][2]
                    self.report(pct, f"Sinh voice API {done}/{len(pending)} câu "
                                     f"({concurrency} luồng, lô {len(group)}, {voice})...")
        else:
            for group in groups:
                pct = max(2, int(100 * done / max(1, len(pending))))
                voice = group[0][2]
                self.report(pct, f"Sinh lô {len(group)} câu ({voice}) - "
                                 f"{done}/{len(pending)} câu...")
                render_group(group)
                commit_group(group)
                done += len(group)

        if not voice_files:
            raise ModuleError("Không sinh được file giọng nào.")

        if skipped:
            for line, reason in sorted(skipped.items())[:5]:
                logger.warning("Bỏ qua dòng %s khi sinh giọng: %s", line, reason)
            self.report(99, f"Bỏ qua {len(skipped)} câu không sinh được giọng "
                            f"(dòng {', '.join(str(n) for n in sorted(skipped)[:8])}).")

        if usage is not None:
            billed_cost = sum(
                len(text)
                for line, text, _voice, _line_wav, _cache_wav, _key in pending
                if line not in skipped
            )
            try:
                usage.report(usage_service, billed_cost, f"voice {len(voice_files)} files")
            except Exception as exc:  # noqa: BLE001
                raise ModuleError(str(exc)) from exc

        suffix = f", giữ {kept_custom} voice nhập tay" if kept_custom else ""
        skip_note = f", bỏ qua {len(skipped)} câu" if skipped else ""
        self.report(100, f"Sinh {len(voice_files)} voice "
                         f"({cached_count} từ cache{suffix}{skip_note})")
        return {"voice_files": voice_files}

    # ---------- Preview cho UI ----------

    def preview(self, data: dict[str, Any], text: str, voice: str) -> str:
        """Sinh nhanh 1 câu để nghe thử, trả đường dẫn wav."""
        engine = self._get_engine(data)
        safe_voice = "".join(c if c.isalnum() or c in "._-" else "_" for c in (voice or "voice"))
        out_dir = Path(data["config"].data_dir) / "previews"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"module_{safe_voice}_{int(time.time() * 1000)}.wav"
        engine.synthesize(text, voice, 1.0, str(out))
        return str(out)

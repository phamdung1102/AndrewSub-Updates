"""Client cho máy chủ OCR dùng chung.

Contract ``read_images`` giống VisionOcrClient để cắm thẳng vào detector hiện có.
Kết quả luôn được ráp theo candidate_id, không phụ thuộc thứ tự worker hoàn thành.
"""

from __future__ import annotations

import base64
import hashlib
import io
import ipaddress
import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable
from urllib.parse import urlparse, urlunparse

import requests
from PIL import Image

from vicdub.utils.secret_store import unprotect_secret


class RemoteOcrError(RuntimeError):
    pass


def default_client_id() -> str:
    return socket.gethostname().strip() or "andrewsub-client"


def _local_addresses() -> set[str]:
    addresses = {"127.0.0.1", "localhost", "::1"}
    try:
        hostname = socket.gethostname()
        addresses.add(hostname.lower())
        for info in socket.getaddrinfo(hostname, None):
            addresses.add(str(info[4][0]).lower())
    except OSError:
        pass
    return addresses


def _is_this_machine_host(host: str) -> bool:
    host = str(host or "").strip().lower().strip("[]")
    if not host:
        return False
    if host in _local_addresses():
        return True
    try:
        address = ipaddress.ip_address(host)
        return address.is_loopback or str(address).lower() in _local_addresses()
    except ValueError:
        return False


def _loopback_url(url: str) -> str:
    parsed = urlparse(str(url or ""))
    if not _is_this_machine_host(parsed.hostname or ""):
        return str(url or "")
    port = f":{parsed.port}" if parsed.port else ""
    return urlunparse(parsed._replace(netloc=f"127.0.0.1{port}"))


class RemoteOcrClient:
    def __init__(self, config):
        self.base_url = str(getattr(config, "remote_ocr_url", "") or "").strip().rstrip("/")
        self.api_key = unprotect_secret(
            str(getattr(config, "remote_ocr_api_key", "") or "")
        ).strip()
        self.client_id = str(
            getattr(config, "remote_ocr_client_id", "") or default_client_id()
        ).strip()
        self.timeout = max(15, int(getattr(config, "remote_ocr_timeout", 180) or 180))
        self.requested_batch = max(
            1, int(getattr(config, "remote_ocr_batch", 20) or 20)
        )
        # Máy chủ cũ dùng marker căn trái có thể làm Google Docs đảo chữ. Khởi
        # động ở chế độ một ảnh an toàn; chỉ tăng lên 6-8 khi /health xác nhận
        # giao thức montage căn giữa v2.
        self.max_reliable_batch = 1
        self.checkpoint_protocol = "remote-single-panel-v1"
        self.batch_size = 1
        # Máy chủ tự quản lý pool tài khoản và hàng đợi. Client không áp trần
        # luồng cứng; chạy đúng số lượng người dùng cấu hình.
        self.parallel = max(
            1, int(getattr(config, "remote_ocr_parallel", 5) or 5)
        )
        self._session = requests.Session()
        self._capabilities_checked = False
        if not self.base_url:
            raise RemoteOcrError("Chưa nhập địa chỉ máy chủ nhận diện.")
        if not self.api_key:
            raise RemoteOcrError("Chưa nhập khóa truy cập máy chủ nhận diện.")

    def _request_with_local_fallback(
        self, method: str, path: str, **kwargs
    ) -> requests.Response:
        def send(base_url: str) -> requests.Response:
            url = f"{base_url}{path}"
            if hasattr(self._session, "request"):
                return self._session.request(method, url, **kwargs)
            if method.upper() == "GET":
                return self._session.get(url, **kwargs)
            if method.upper() == "POST":
                return self._session.post(url, **kwargs)
            raise RemoteOcrError(f"Unsupported HTTP method: {method}")

        try:
            return send(self.base_url)
        except requests.RequestException:
            fallback_base = _loopback_url(self.base_url)
            if fallback_base == self.base_url:
                raise
            response = send(fallback_base)
            self.base_url = fallback_base
            return response

    @property
    def headers(self) -> dict[str, str]:
        return {"X-API-Key": self.api_key, "X-Client-ID": self.client_id}

    def close(self) -> None:
        self._session.close()

    def apply_server_capabilities(self, health: dict | None) -> None:
        health = health if isinstance(health, dict) else {}
        protocol = str(health.get("ocr_montage_protocol", "") or "").strip()
        if protocol in {"centered-v2", "centered-v3"}:
            default_limit = 20 if protocol == "centered-v3" else 8
            hard_limit = 20 if protocol == "centered-v3" else 8
            server_limit = max(1, int(health.get("ocr_max_batch", default_limit) or default_limit))
            self.max_reliable_batch = min(hard_limit, server_limit)
            self.batch_size = min(self.requested_batch, self.max_reliable_batch)
            self.checkpoint_protocol = (
                f"remote-{protocol}-batch{self.batch_size}"
            )
        else:
            self.max_reliable_batch = 1
            self.batch_size = 1
            self.checkpoint_protocol = "remote-single-panel-v1"

    def _ensure_capabilities(self) -> None:
        """Load server montage limits before real OCR.

        The client starts in safe single-image mode for compatibility.  Real OCR
        should still pick up server-centered-v3/batch20 even if the user did not
        press the settings-page test button in this app session.
        """
        if self._capabilities_checked:
            return
        self._capabilities_checked = True
        try:
            response = self._request_with_local_fallback("GET", "/health", timeout=10)
            if response.ok:
                self.apply_server_capabilities(response.json())
        except requests.RequestException:
            # Let the following OCR request raise the detailed error.
            pass

    def _json(self, response: requests.Response) -> dict:
        try:
            payload = response.json()
        except ValueError as exc:
            raise RemoteOcrError(
                f"Máy chủ trả dữ liệu không hợp lệ (HTTP {response.status_code})."
            ) from exc
        error = str(payload.get("error") or "").strip()
        detail = payload.get("detail") or error or response.reason
        if response.status_code == 401 or error == "invalid_api_key":
            raise RemoteOcrError("Khóa truy cập máy chủ nhận diện không đúng.")
        if error == "client_disabled":
            raise RemoteOcrError("Máy này đang bị tắt hoặc không được phép dùng máy chủ nhận diện.")
        if error == "service_not_allowed":
            quota = payload.get("quota") if isinstance(payload.get("quota"), dict) else {}
            service = str(quota.get("service") or "").strip() if isinstance(quota, dict) else ""
            suffix = f" ({service})" if service else ""
            raise RemoteOcrError(f"May nay chua duoc cap quyen dung dich vu{suffix}.")
        if error == "quota_exhausted":
            quota = payload.get("quota") if isinstance(payload.get("quota"), dict) else {}
            if isinstance(quota, dict) and int(quota.get("limit", 0) or 0):
                used = int(quota.get("used", 0) or 0)
                limit = int(quota.get("limit", 0) or 0)
                raise RemoteOcrError(f"May da het quota ({used}/{limit}). Tang quota tren may chu de chay tiep.")
            raise RemoteOcrError("May da het quota. Tang quota tren may chu de chay tiep.")
        if error == "client_rate_limited":
            raise RemoteOcrError("May nay dang gui qua nhanh, cho mot luc roi thu lai.")
        if error == "client_batch_limit_exceeded":
            raise RemoteOcrError("So anh moi lo vuot gioi han may chu cap cho may nay.")
        if response.status_code == 403:
            raise RemoteOcrError("May nay dang bi tat hoac khong duoc phep dung may chu.")
        if not response.ok or not payload.get("ok", False):
            raise RemoteOcrError(f"Máy chủ nhận diện lỗi: {detail}")
        return payload

    def services(self) -> dict:
        try:
            response = self._request_with_local_fallback(
                "GET", "/v1/services", headers=self.headers, timeout=15,
            )
        except requests.RequestException as exc:
            raise RemoteOcrError(f"Khong lay duoc thong tin dich vu/quota: {exc}") from exc
        if response.status_code == 404:
            return {"ok": True, "legacy_server": True, "allowed_services": ["ocr"]}
        return self._json(response)

    def check_connection(self) -> dict:
        try:
            health = self._request_with_local_fallback("GET", "/health", timeout=15)
            if not health.ok:
                raise RemoteOcrError(f"Không kết nối được máy chủ (HTTP {health.status_code}).")
            heartbeat = self._request_with_local_fallback(
                "POST", "/v1/heartbeat", headers=self.headers, json={}, timeout=15,
            )
        except requests.RequestException as exc:
            raise RemoteOcrError(f"Không kết nối được máy chủ nhận diện: {exc}") from exc
        payload = self._json(heartbeat)
        try:
            payload["health"] = health.json()
        except ValueError:
            payload["health"] = {}
        try:
            payload["services"] = self.services()
        except RemoteOcrError as exc:
            payload["services_error"] = str(exc)
        self.apply_server_capabilities(payload["health"])
        self._capabilities_checked = True
        return payload

    @staticmethod
    def _encode(image) -> str:
        if isinstance(image, Image.Image):
            converted = image.convert("RGB")
        else:
            converted = Image.fromarray(image).convert("RGB")
        out = io.BytesIO()
        converted.save(out, format="JPEG", quality=94, optimize=True)
        return base64.b64encode(out.getvalue()).decode("ascii")

    def build_montage(self, images: list, ids: list[int]):
        """Adapter cho pipeline streaming: server nhận ảnh rời, không cần montage."""
        return list(images), list(ids)

    def read_subtitle_montage(
        self, payload, ids: list[int], lang_hint: str = ""
    ) -> dict[int, str]:
        self._ensure_capabilities()
        images, stored_ids = payload
        actual_ids = list(stored_ids or ids)
        candidates = [
            {"candidate_id": str(candidate_id), "image_base64": self._encode(image)}
            for candidate_id, image in zip(actual_ids, images)
        ]
        digest = hashlib.sha256()
        digest.update(self.client_id.encode("utf-8"))
        digest.update(self.checkpoint_protocol.encode("ascii", "ignore"))
        for candidate in candidates:
            digest.update(candidate["candidate_id"].encode("ascii"))
            digest.update(candidate["image_base64"].encode("ascii"))
        body = {
            "idempotency_key": digest.hexdigest(),
            "ocr_language": (lang_hint or "zh-Hans").strip(),
            "candidates": candidates,
        }
        try:
            # Đường này cũng có thể được gọi bởi nhiều worker OCR nền. Không
            # dùng chung requests.Session để tránh nghẽn/không thread-safe.
            response = requests.post(
                f"{self.base_url}/v1/ocr/batches",
                headers=self.headers,
                json=body,
                timeout=(12, self.timeout),
            )
        except requests.RequestException as exc:
            raise RemoteOcrError(f"Mất kết nối khi gửi ảnh nhận diện: {exc}") from exc
        results = self._json(response).get("results", [])
        parsed: dict[int, str] = {}
        for result in results:
            try:
                candidate_id = int(result.get("candidate_id", ""))
            except (TypeError, ValueError):
                continue
            parsed[candidate_id] = str(result.get("text", "") or "").strip()
        return parsed

    def read_images(
        self,
        images: list,
        lang_hint: str = "",
        report: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> tuple[list[str], list[int]]:
        self._ensure_capabilities()
        texts = [""] * len(images)
        if not images:
            return texts, []
        starts = list(range(0, len(images), self.batch_size))
        total_batches = len(starts)

        def send(start: int) -> list[dict]:
            indexes = list(range(start, min(start + self.batch_size, len(images))))
            candidates = [
                {"candidate_id": str(index), "image_base64": self._encode(images[index])}
                for index in indexes
            ]
            digest = hashlib.sha256()
            digest.update(self.client_id.encode("utf-8"))
            digest.update(self.checkpoint_protocol.encode("ascii", "ignore"))
            for candidate in candidates:
                digest.update(candidate["candidate_id"].encode("ascii"))
                digest.update(candidate["image_base64"].encode("ascii"))
            body = {
                "idempotency_key": digest.hexdigest(),
                "ocr_language": (lang_hint or "zh-Hans").strip(),
                "candidates": candidates,
            }
            try:
                # read_images có thể chạy nhiều worker. requests.Session không
                # cam kết thread-safe, nên đường song song dùng request độc lập.
                response = requests.post(
                    f"{self.base_url}/v1/ocr/batches",
                    headers=self.headers,
                    json=body,
                    timeout=(12, self.timeout),
                )
            except requests.RequestException as exc:
                raise RemoteOcrError(f"Mất kết nối khi gửi ảnh nhận diện: {exc}") from exc
            return list(self._json(response).get("results", []))

        done = 0
        lock = threading.Lock()
        with ThreadPoolExecutor(max_workers=min(self.parallel, total_batches)) as pool:
            futures = {
                pool.submit(send, start): start
                for start in starts
                if not (is_cancelled and is_cancelled())
            }
            for future in as_completed(futures):
                if is_cancelled and is_cancelled():
                    for pending in futures:
                        pending.cancel()
                    break
                results = future.result()
                for result in results:
                    try:
                        index = int(result.get("candidate_id", ""))
                    except (TypeError, ValueError):
                        continue
                    if 0 <= index < len(texts):
                        texts[index] = str(result.get("text", "") or "").strip()
                with lock:
                    done += 1
                    completed_images = min(done * self.batch_size, len(images))
                if report:
                    pct = 40 + int(55 * done / max(1, total_batches))
                    report(pct, f"Máy chủ đã đọc khoảng {completed_images}/{len(images)} ảnh...")
        return texts, [i for i, text in enumerate(texts) if not text.strip()]

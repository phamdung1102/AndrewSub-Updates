"""Client-side license/quota controller.

This does not proxy provider API keys.  The app keeps using local/provider keys,
but asks the OCR management server whether the machine may run a service and
reports usage after the task finishes.
"""

from __future__ import annotations

import socket
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator

import requests

from vicdub.utils.secret_store import unprotect_secret


class UsageControllerError(RuntimeError):
    pass


def _default_client_id() -> str:
    return socket.gethostname().strip() or "andrewsub-client"


@dataclass
class UsageController:
    base_url: str
    api_key: str
    client_id: str
    timeout: int = 15

    @classmethod
    def from_config(cls, config) -> "UsageController | None":
        if not bool(getattr(config, "managed_services_enabled", False)):
            return None
        base_url = str(getattr(config, "remote_ocr_url", "") or "").strip().rstrip("/")
        api_key = unprotect_secret(
            str(getattr(config, "remote_ocr_api_key", "") or "")
        ).strip()
        if not base_url or not api_key:
            return None
        client_id = str(
            getattr(config, "remote_ocr_client_id", "") or _default_client_id()
        ).strip()
        return cls(base_url=base_url, api_key=api_key, client_id=client_id)

    @property
    def headers(self) -> dict[str, str]:
        return {"X-API-Key": self.api_key, "X-Client-ID": self.client_id}

    def _request(self, path: str, service: str, cost: int = 0, detail: str = "") -> dict:
        try:
            response = requests.post(
                f"{self.base_url}{path}",
                headers=self.headers,
                json={"service": service, "cost": max(0, int(cost or 0)), "detail": detail},
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise UsageControllerError(f"Khong ket noi duoc may chu quan ly quota: {exc}") from exc
        try:
            payload = response.json()
        except ValueError as exc:
            raise UsageControllerError(
                f"May chu quan ly quota tra du lieu khong hop le (HTTP {response.status_code})."
            ) from exc
        if response.ok and payload.get("ok", False):
            return payload
        error = str(payload.get("error") or response.reason or "").strip()
        quota = payload.get("quota") if isinstance(payload.get("quota"), dict) else {}
        if error == "invalid_api_key":
            raise UsageControllerError("Key ket noi may chu quan ly khong dung.")
        if error == "client_disabled":
            raise UsageControllerError("May nay dang bi tat tren may chu quan ly.")
        if error == "service_not_allowed":
            raise UsageControllerError(f"May nay chua duoc cap quyen dich vu {service}.")
        if error == "quota_exhausted":
            used = int(quota.get("used", 0) or 0) if isinstance(quota, dict) else 0
            limit = int(quota.get("limit", 0) or 0) if isinstance(quota, dict) else 0
            suffix = f" ({used}/{limit})" if limit else ""
            raise UsageControllerError(f"May da het quota dich vu {service}{suffix}.")
        raise UsageControllerError(f"May chu quan ly quota bao loi: {error}")

    def check(self, service: str, cost: int = 0, detail: str = "") -> dict:
        return self._request("/v1/usage/check", service, cost, detail)

    def report(self, service: str, cost: int, detail: str = "") -> dict:
        return self._request("/v1/usage/report", service, cost, detail)


def estimate_chars(texts) -> int:
    if isinstance(texts, str):
        return len(texts.strip())
    return sum(len(str(item or "").strip()) for item in texts)


@contextmanager
def managed_usage(config, service: str, estimated_cost: int = 0, detail: str = "") -> Iterator[None]:
    controller = UsageController.from_config(config)
    if controller is None:
        yield
        return
    controller.check(service, estimated_cost, detail)
    try:
        yield
    except Exception:
        raise
    else:
        controller.report(service, estimated_cost, detail)

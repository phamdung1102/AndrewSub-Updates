const APP_ID = 'andrewsub';
const TOKEN_PREFIX = 'ASUB1';
const LICENSE_SHEET = 'Cấp phép';
const DEVICE_SHEET = 'Thiết bị';
const LOG_SHEET = 'Log';
const LICENSE_HEADERS = ['code', 'customerName', 'email', 'plan', 'days', 'used', 'machineId', 'issuedAt', 'expiresAt'];

function doPost(e) {
  const body = JSON.parse(e.postData.contents || '{}');
  const action = String(body.action || '').toLowerCase();
  if (action === 'issue') return json_(issueLicense_(body));
  if (action === 'activate' || action === 'heartbeat') return json_(track_(action, body));
  return json_({ ok: false, error: 'unknown action' });
}

function setupSheet() {
  const ss = SpreadsheetApp.getActive();
  let license = ss.getSheetByName(LICENSE_SHEET);
  if (!license) license = ss.insertSheet(LICENSE_SHEET);
  if (license.getLastRow() === 0) license.appendRow(LICENSE_HEADERS);
  let log = ss.getSheetByName(LOG_SHEET);
  if (!log) log = ss.insertSheet(LOG_SHEET);
  if (log.getLastRow() === 0) log.appendRow(['time', 'event', 'appId', 'machineId', 'appVersion', 'status']);
}

function issueLicense_(body) {
  if (body.appId && body.appId !== APP_ID) return { ok: false, error: 'wrong app' };
  const code = String(body.code || '').trim();
  const machineId = String(body.machineId || '').trim();
  if (!code || !machineId) return { ok: false, error: 'missing code or machineId' };
  const sh = SpreadsheetApp.getActive().getSheetByName(LICENSE_SHEET);
  if (!sh) return { ok: false, error: 'missing license sheet; run setupSheet first' };
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);
  const idx = Object.fromEntries(headers.map((h, i) => [h, i]));
  for (const h of LICENSE_HEADERS) {
    if (idx[h] === undefined) return { ok: false, error: `missing column ${h}` };
  }
  for (let r = 1; r < values.length; r++) {
    if (String(values[r][idx.code] || '').trim() !== code) continue;
    if (String(values[r][idx.used] || '').toLowerCase() === 'yes') {
      return { ok: false, error: 'code used' };
    }
    const days = Number(values[r][idx.days] || 365);
    const issued = new Date();
    const expires = new Date(issued.getTime() + days * 86400000);
    const payload = {
      appId: APP_ID,
      machineId,
      customerName: String(values[r][idx.customerName] || ''),
      email: String(values[r][idx.email] || ''),
      issuedAt: issued.toISOString(),
      expiresAt: expires.toISOString(),
      plan: String(values[r][idx.plan] || 'standard'),
      features: {}
    };
    const token = sign_(payload);
    sh.getRange(r + 1, idx.used + 1).setValue('yes');
    sh.getRange(r + 1, idx.machineId + 1).setValue(machineId);
    sh.getRange(r + 1, idx.issuedAt + 1).setValue(issued);
    sh.getRange(r + 1, idx.expiresAt + 1).setValue(expires);
    track_('activate', body);
    return { ok: true, license: token, expiresAt: payload.expiresAt };
  }
  return { ok: false, error: 'code not found' };
}

function track_(eventName, body) {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(LOG_SHEET);
  if (!sh) sh = ss.insertSheet(LOG_SHEET);
  sh.appendRow([new Date(), eventName, body.appId || APP_ID, body.machineId || '', body.appVersion || '', body.status || '']);
  return { ok: true };
}

function sign_(payload) {
  let privateKey = PropertiesService.getScriptProperties().getProperty('LICENSE_PRIVATE_KEY_PEM');
  if (!privateKey) throw new Error('missing LICENSE_PRIVATE_KEY_PEM');
  privateKey = privateKey.replace(/\\n/g, '\n').trim();
  if (privateKey.indexOf('\n') === -1) {
    const header = '-----BEGIN PRIVATE KEY-----';
    const footer = '-----END PRIVATE KEY-----';
    const body = privateKey.replace(header, '').replace(footer, '').replace(/\s+/g, '');
    privateKey = header + '\n' + body.match(/.{1,64}/g).join('\n') + '\n' + footer;
  }
  const encoded = b64url_(Utilities.newBlob(JSON.stringify(payload)).getBytes());
  const sig = Utilities.computeRsaSha256Signature(encoded, privateKey);
  return `${TOKEN_PREFIX}.${encoded}.${b64url_(sig)}`;
}

function b64url_(bytes) {
  return Utilities.base64EncodeWebSafe(bytes).replace(/=+$/, '');
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

"""License management page for AndrewSub."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from vicdub import APP_NAME
from vicdub.core.licensing.license_service import format_license_until


class LicensePage(QWidget):
    def __init__(self, app) -> None:
        super().__init__()
        self.app = app
        self.machine_label = QLabel()
        self.status_label = QLabel()
        self.owner_label = QLabel()
        self.expire_label = QLabel()
        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("Nhập mã kích hoạt từ License Admin/Google Sheet")
        self.token_input = QTextEdit()
        self.token_input.setPlaceholderText("Dán license thủ công nếu cấp offline")
        self.token_input.setFixedHeight(120)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)
        title = QLabel("Bản quyền AndrewSub")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)
        layout.addWidget(self.machine_label)
        layout.addWidget(self.status_label)
        layout.addWidget(self.owner_label)
        layout.addWidget(self.expire_label)

        row_machine = QHBoxLayout()
        copy_btn = QPushButton("Sao chép mã máy")
        refresh_btn = QPushButton("Làm mới")
        copy_btn.clicked.connect(self.copy_machine_id)
        refresh_btn.clicked.connect(self.refresh)
        row_machine.addWidget(copy_btn)
        row_machine.addWidget(refresh_btn)
        row_machine.addStretch(1)
        layout.addLayout(row_machine)

        layout.addWidget(QLabel("Kích hoạt online"))
        row_code = QHBoxLayout()
        activate_code_btn = QPushButton("Kích hoạt bằng mã")
        activate_code_btn.clicked.connect(self.activate_code)
        row_code.addWidget(self.code_input, 1)
        row_code.addWidget(activate_code_btn)
        layout.addLayout(row_code)

        layout.addWidget(QLabel("Kích hoạt offline"))
        layout.addWidget(self.token_input)
        row_token = QHBoxLayout()
        activate_token_btn = QPushButton("Kích hoạt license đã dán")
        clear_btn = QPushButton("Xóa license trên máy này")
        activate_token_btn.clicked.connect(self.activate_token)
        clear_btn.clicked.connect(self.clear_license)
        row_token.addWidget(activate_token_btn)
        row_token.addWidget(clear_btn)
        row_token.addStretch(1)
        layout.addLayout(row_token)
        layout.addStretch(1)
        self.refresh()

    def refresh(self) -> None:
        status = self.app.license_service.status()
        payload = status.get("license") or {}
        self.machine_label.setText(f"Mã máy: {status.get('machine_id')}")
        self.status_label.setText(f"Trạng thái: {status.get('message')}")
        owner = " / ".join(
            x for x in (payload.get("customerName"), payload.get("email"), payload.get("plan")) if x
        )
        self.owner_label.setText(f"Chủ license: {owner or '-'}")
        self.expire_label.setText(f"Hạn dùng: {format_license_until(payload) if payload else '-'}")

    def copy_machine_id(self) -> None:
        QApplication.clipboard().setText(self.app.license_service.machine_id)
        self.app.show_status("Đã sao chép mã máy")

    def activate_code(self) -> None:
        code = self.code_input.text().strip()
        if not code:
            QMessageBox.warning(self, APP_NAME, "Chưa nhập mã kích hoạt.")
            return
        try:
            self.app.license_service.activate_code(code)
            self.refresh()
            QMessageBox.information(self, APP_NAME, "Kích hoạt thành công.")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, APP_NAME, str(exc))

    def activate_token(self) -> None:
        token = self.token_input.toPlainText().strip()
        if not token:
            QMessageBox.warning(self, APP_NAME, "Chưa dán license.")
            return
        try:
            self.app.license_service.activate_token(token)
            self.refresh()
            QMessageBox.information(self, APP_NAME, "Kích hoạt thành công.")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, APP_NAME, str(exc))

    def clear_license(self) -> None:
        self.app.license_service.clear()
        self.refresh()
        QMessageBox.information(self, APP_NAME, "Đã xóa license trên máy này.")

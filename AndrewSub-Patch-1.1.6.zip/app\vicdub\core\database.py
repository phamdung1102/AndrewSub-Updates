"""Lớp truy cập SQLite - an toàn đa luồng bằng lock.

Mỗi project một file project.db. Translation Memory dùng chung ở data/tm.db.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

SCHEMA_PROJECT = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS segments (
    line INTEGER PRIMARY KEY,
    start REAL NOT NULL,
    end REAL NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    translation TEXT NOT NULL DEFAULT '',
    speaker TEXT NOT NULL DEFAULT '',
    gender TEXT NOT NULL DEFAULT 'neutral',
    voice TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS characters (
    name TEXT PRIMARY KEY,
    gender TEXT NOT NULL DEFAULT 'neutral',
    voice_id TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT DEFAULT CURRENT_TIMESTAMP,
    step TEXT,
    status TEXT,
    detail TEXT
);
CREATE TABLE IF NOT EXISTS voice_cache (
    hash TEXT PRIMARY KEY,
    wav_path TEXT NOT NULL
);
"""

SCHEMA_TM = """
CREATE TABLE IF NOT EXISTS translation_memory (
    source TEXT PRIMARY KEY,
    target TEXT NOT NULL,
    lang TEXT NOT NULL DEFAULT ''
);
"""


class Database:
    """Bao bọc sqlite3 với lock cho đa luồng."""

    def __init__(self, path: str | Path, schema: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(schema)
            self._conn.commit()

    def execute(self, sql: str, params: tuple = ()) -> None:
        with self._lock:
            self._conn.execute(sql, params)
            self._conn.commit()

    def executemany(self, sql: str, rows: list[tuple]) -> None:
        with self._lock:
            self._conn.executemany(sql, rows)
            self._conn.commit()

    def query(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    def query_one(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    def close(self) -> None:
        with self._lock:
            self._conn.close()

"""Translation Memory dùng chung giữa các project.

Câu đã dịch rồi thì không gọi Gemini nữa - tiết kiệm quota và thời gian.
"""

from __future__ import annotations

from pathlib import Path

from vicdub.core.database import Database, SCHEMA_TM


class TranslationMemory:
    """Bộ nhớ dịch key = câu gốc (đã chuẩn hóa), value = bản dịch."""

    def __init__(self, data_dir: str) -> None:
        self.db = Database(Path(data_dir) / "tm.db", SCHEMA_TM)

    @staticmethod
    def _normalize(text: str) -> str:
        return " ".join(text.split()).strip().lower()

    def get(self, source: str) -> str | None:
        row = self.db.query_one(
            "SELECT target FROM translation_memory WHERE source = ?",
            (self._normalize(source),),
        )
        return row["target"] if row else None

    def put(self, source: str, target: str, lang: str = "") -> None:
        if not source.strip() or not target.strip():
            return
        self.db.execute(
            "INSERT OR REPLACE INTO translation_memory(source, target, lang) "
            "VALUES(?, ?, ?)",
            (self._normalize(source), target, lang),
        )

    def count(self) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS n FROM translation_memory")
        return int(row["n"]) if row else 0

"""Dịch phụ đề bằng nhiều Web profile, API chỉ xử lý lô dự phòng."""

from __future__ import annotations

import threading
import logging
import hashlib
import json
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

from vicdub.api.gemini_client import GeminiClient

logger = logging.getLogger(__name__)


class WebTranslationPool:
    def __init__(self, clients: list, api_fallback=None) -> None:
        if not clients:
            raise ValueError("Cần ít nhất một profile dịch.")
        self.clients = clients
        self.api_fallback = api_fallback

    @staticmethod
    def _prompt(lines: list[dict], target: str) -> str:
        body = "\n".join(
            f'{item["line"]}. [{float(item.get("seconds", 0)):.1f}s] {item["text"]}'
            for item in lines
        )
        context = str(lines[0].get("_context_before", "")).strip() if lines else ""
        style = str(lines[0].get("_style_instruction", "")).strip() if lines else ""
        context_note = (
            "Ngữ cảnh ngay trước đoạn này (chỉ tham khảo, KHÔNG trả lại):\n"
            + context + "\n\n" if context else ""
        )
        return (
            "Bạn là chuyên gia dịch phụ đề để lồng tiếng phim. "
            f"Dịch sang {target}, tự nhiên, nhất quán xưng hô và vừa thời lượng.\n"
            + (f"PHONG CÁCH BẮT BUỘC: {style}\n" if style else "") +
            "Mỗi bản dịch phải đọc vừa số giây ghi ở đầu dòng; ưu tiên câu thoại ngắn, "
            "không thêm giải thích và không dịch dài hơn câu gốc nếu không cần thiết.\n"
            "Trả đúng JSON array, đủ mọi line, không markdown và không giải thích:\n"
            '[{"line":1,"translation":"..."}]\n\n' + context_note + body
        )

    def _translate(
        self, client, lines: list[dict], target: str, depth: int = 0
    ) -> list[dict]:
        text = client.generate_text(self._prompt(lines, target))
        parsed = GeminiClient._parse_json_objects(text)
        by_line = {
            int(item["line"]): item for item in parsed
            if str(item.get("line", "")).lstrip("-").isdigit()
            and str(item.get("translation", "")).strip()
        }
        missing = [item for item in lines if item["line"] not in by_line]
        # Web thường trả thiếu phần cuối khi lô dài. Giữ phần đã có và chỉ gửi
        # lại các dòng thiếu theo lô nhỏ, không vứt cả phản hồi.
        if missing and depth < 3:
            step = max(1, min(12, len(missing)))
            for start in range(0, len(missing), step):
                recovered = self._translate(
                    client, missing[start:start + step], target, depth + 1
                )
                by_line.update({int(item["line"]): item for item in recovered})
            missing = [item for item in lines if item["line"] not in by_line]
        if missing:
            raise RuntimeError(f"Phản hồi vẫn thiếu {len(missing)}/{len(lines)} dòng sau khi vá")
        return [by_line[item["line"]] for item in lines]

    def translate_bulk(self, lines, target_language, chunk_lines=80, progress=None):
        return self.translate_bulk_resumable(
            lines, target_language, chunk_lines=chunk_lines, progress=progress
        )

    @staticmethod
    def _chunks(lines: list[dict], max_lines: int, max_chars: int = 10000,
                max_seconds: float = 600.0) -> list[list[dict]]:
        """Chia theo số dòng, dung lượng prompt và cửa sổ tối đa 10 phút."""
        chunks: list[list[dict]] = []
        current: list[dict] = []
        chars = 0
        first_start = 0.0
        for item in lines:
            start = float(item.get("start", 0.0))
            text_size = len(str(item.get("text", ""))) + 40
            over_time = bool(current and start and first_start and start - first_start >= max_seconds)
            if current and (len(current) >= max_lines or chars + text_size > max_chars or over_time):
                chunks.append(current)
                current = []
                chars = 0
            if not current:
                first_start = start
            current.append(item)
            chars += text_size
        if current:
            chunks.append(current)
        for index in range(1, len(chunks)):
            previous = chunks[index - 1][-6:]
            chunks[index][0] = dict(chunks[index][0])
            chunks[index][0]["_context_before"] = "\n".join(
                str(item.get("text", "")) for item in previous
            )
        return chunks

    def translate_bulk_resumable(
        self, lines, target_language, chunk_lines=80, progress=None,
        checkpoint_dir: str | None = None, on_batch=None,
    ):
        chunks = self._chunks(lines, max(1, int(chunk_lines)))
        results: list[list[dict] | None] = [None] * len(chunks)
        failures: dict[int, Exception] = {}
        next_index = 0
        done = 0
        lock = threading.Lock()
        callback_lock = threading.Lock()
        checkpoint = Path(checkpoint_dir) if checkpoint_dir else None
        digest = hashlib.sha256(json.dumps(
            {"target": target_language, "lines": lines, "chunk_lines": chunk_lines},
            ensure_ascii=False, sort_keys=True,
        ).encode("utf-8")).hexdigest()
        if checkpoint:
            checkpoint.mkdir(parents=True, exist_ok=True)
            state = checkpoint / "state.json"
            old = ""
            try:
                old = json.loads(state.read_text(encoding="utf-8")).get("digest", "")
            except (OSError, ValueError, TypeError):
                pass
            if old != digest:
                for path in checkpoint.glob("batch_*.json"):
                    path.unlink(missing_ok=True)
                state.write_text(json.dumps({"digest": digest}, indent=2), encoding="utf-8")

        def save_batch(index: int, value: list[dict]) -> None:
            if checkpoint:
                path = checkpoint / f"batch_{index:05d}.json"
                temp = path.with_suffix(".tmp")
                temp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
                os.replace(temp, path)
            if on_batch:
                with callback_lock:
                    on_batch(value)

        # Resume các batch hoàn chỉnh trước khi mở trình duyệt.
        for index in range(len(chunks)):
            path = checkpoint / f"batch_{index:05d}.json" if checkpoint else None
            if path and path.exists():
                try:
                    value = json.loads(path.read_text(encoding="utf-8"))
                    expected = {int(item["line"]) for item in chunks[index]}
                    actual = {int(item["line"]) for item in value}
                    if expected == actual:
                        results[index] = value
                        done += len(value)
                        if on_batch:
                            on_batch(value)
                except (OSError, ValueError, TypeError, KeyError):
                    path.unlink(missing_ok=True)

        def worker(client):
            nonlocal next_index, done
            while True:
                with lock:
                    while next_index < len(chunks) and results[next_index] is not None:
                        next_index += 1
                    if next_index >= len(chunks):
                        return
                    index = next_index
                    next_index += 1
                try:
                    value = self._translate(client, chunks[index], target_language)
                    with lock:
                        results[index] = value
                        save_batch(index, value)
                        done += len(chunks[index])
                        if progress:
                            progress(done, len(lines))
                except Exception as exc:  # noqa: BLE001
                    with lock:
                        failures[index] = exc

        with ThreadPoolExecutor(max_workers=min(len(self.clients), len(chunks) or 1)) as pool:
            futures = [pool.submit(worker, client) for client in self.clients]
            for future in futures:
                future.result()

        # Một profile hỏng không được làm mất lô: thử lại lô đó lần lượt bằng
        # mọi profile còn lại trước khi dùng API.
        for index in sorted(failures):
            last_error = failures[index]
            for client in self.clients:
                try:
                    results[index] = self._translate(
                        client, chunks[index], target_language
                    )
                    last_error = None
                    break
                except Exception as exc:  # noqa: BLE001
                    last_error = exc
                    logger.warning("Profile dịch thử lại lô %d lỗi: %s", index + 1, exc)
            if results[index] is None:
                if self.api_fallback is None:
                    raise RuntimeError(
                        f"Tất cả profile dịch đều lỗi ở lô {index + 1}; "
                        f"API dự phòng chưa có khóa hoạt động. Chi tiết: {last_error}"
                    )
                results[index] = self.api_fallback.translate_bulk(
                    chunks[index], target_language, chunk_lines=len(chunks[index])
                )
            save_batch(index, results[index] or [])
            done += len(chunks[index])
            if progress:
                progress(done, len(lines))

        return [item for chunk in results if chunk for item in chunk]

"""Subtitle Module - sinh phụ đề gốc.

Chọn nguồn theo cấu hình:
- Đã import file phụ đề (.srt/.ass/.vtt): dùng luôn.
- Ngược lại: OCR phụ đề gắn cứng qua Gemini Web (montage vision).

Output: segments (list[Segment]), original_srt (đường dẫn)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import Segment, load_subtitle_file, write_srt


class SubtitleModule(BaseModule):
    """Tách phụ đề: import file có sẵn hoặc OCR gắn cứng qua Gemini Web."""

    name = "Tách phụ đề"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        subtitle_path = data.get("subtitle_path", "")

        if subtitle_path:
            segments = self._from_file(subtitle_path)
        else:
            # Nhận diện video chỉ dùng pool Google Drive OCR. Trình duyệt được
            # giữ riêng cho chức năng dịch, không còn là nguồn OCR dự phòng.
            segments = self._from_drive_ocr(data)

        if not segments:
            raise ModuleError("Không thu được dòng phụ đề nào.")

        # One broken OCR run must not destroy a good result already in project.
        # Importing a subtitle file is explicit, so it is exempt from this guard.
        previous = project.load_segments()
        if (not subtitle_path and len(previous) >= 10
                and len(segments) < max(3, int(len(previous) * 0.35))):
            raise ModuleError(
                f"Kết quả mới chỉ có {len(segments)} dòng, thấp bất thường so với "
                f"{len(previous)} dòng đang có. Đã giữ nguyên phụ đề cũ."
            )

        # Lưu original.srt vào project.
        original_srt = Path(project.root) / "subtitles" / "original.srt"
        write_srt(segments, original_srt)
        project.save_segments(segments)

        self.report(100, f"Có {len(segments)} dòng phụ đề")
        return {"segments": segments, "original_srt": str(original_srt)}

    # ---------- Import file ----------

    def _from_file(self, subtitle_path: str) -> list[Segment]:
        self.report(20, f"Đang đọc phụ đề: {Path(subtitle_path).name}")
        if not Path(subtitle_path).exists():
            raise ModuleError(f"File phụ đề không tồn tại: {subtitle_path}")
        try:
            return load_subtitle_file(subtitle_path)
        except ValueError as exc:
            raise ModuleError(str(exc)) from exc

    # ---------- OCR gắn cứng qua Google Drive ----------

    def _from_drive_ocr(self, data: dict[str, Any]) -> list[Segment]:
        """OCR phụ đề gắn cứng bằng Google Drive (OCR chính thức, hợp ToS)."""
        video_path = data.get("video_path", "")
        if not video_path:
            raise ModuleError("Chưa có video để nhận diện phụ đề.")
        if not Path(video_path).exists():
            raise ModuleError(f"Video không tồn tại: {video_path}")

        from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
            DriveOcrClient, DriveOcrError, classify_drive_error,
        )
        from vicdub.utils.llm_ocr_subtitles import (  # noqa: PLC0415
            DEFAULT_REGION as LLM_REGION, llm_ocr_video,
        )

        config = data["config"]
        project = data["project"]
        accounts = config.enabled_drive_accounts()
        creds = config.resolve_drive_credentials()
        if not creds and not any(a.get("credentials_path") for a in accounts):
            raise ModuleError(
                "Chưa có file kết nối cho nguồn nhận diện chính. Vào tab Cài đặt "
                "và kết nối tài khoản xử lý trước."
            )
        if not accounts:
            raise ModuleError(
                "Chưa kết nối tài khoản nhận diện. Vào tab Cài đặt và đăng nhập "
                "tài khoản xử lý trước."
            )

        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or LLM_REGION
        ))
        if len(region) != 4:
            region = LLM_REGION
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )

        self.report(3, "Đang chuẩn bị dữ liệu nhận diện phụ đề...")
        clients = []
        account_labels: list[str] = []
        for index, account in enumerate(accounts):
            label = str(account.get("email") or account.get("name") or f"Tài khoản {index + 1}")
            try:
                client = DriveOcrClient(
                    credentials_path=account.get("credentials_path") or creds,
                    token_path=account["token_path"],
                    folder_id=account.get("folder_id", ""),
                    report=None,
                )
                try:
                    # Refresh token before spending time scanning the video. Only
                    # permanent account errors remove a slot; network errors may recover.
                    email = client.account_email()
                    if email:
                        label = email
                except Exception as exc:  # noqa: BLE001
                    if classify_drive_error(exc) == "permanent_account":
                        client.close()
                        self.report(3, f"Bỏ {label}: kết nối đã hết hiệu lực.")
                        self.logger.warning("Tài khoản OCR %s bị loại khi kiểm tra: %s", label, exc)
                        continue
                    self.logger.warning("Chưa kiểm tra được tài khoản OCR %s: %s", label, exc)
                clients.append(client)
                account_labels.append(label)
            except (DriveOcrError, OSError, KeyError) as exc:
                self.report(3, f"Bỏ {label}: thiếu hoặc sai tệp kết nối.")
                self.logger.warning("Không mở được tài khoản OCR %s: %s", label, exc)
        if not clients:
            raise ModuleError(
                "Không còn tài khoản nhận diện hoạt động. Hãy thay/kết nối tài khoản; "
                "lần chạy sau sẽ tiếp tục từ checkpoint đã lưu."
            )
        self.report(3, f"Có {len(clients)}/{len(accounts)} tài khoản sẵn sàng.")

        vsf_exe = config.resolve_vsf_exe()
        try:
            if vsf_exe:
                # Đường CHÍNH XÁC (giống AIO): VideoSubFinder phát hiện + timing,
                # Drive OCR đọc chữ. Không dedup/gộp -> hết sót/lặp/lệch.
                from vicdub.utils.vsf_ocr import vsf_ocr_video  # noqa: PLC0415
                self.report(3, "Đang phân tích phụ đề trong video...")
                segments = vsf_ocr_video(
                    video_path, vsf_exe, clients[0], region=region,
                    output_dir=str(Path(project.root) / ".vsf"),
                    batch=int(getattr(config, "llm_ocr_batch", 20)),
                    lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                    num_threads=int(getattr(config, "vsf_num_threads", 4)),
                    use_cuda=bool(getattr(config, "vsf_use_cuda", False)),
                    progress=self.report,
                    cancelled=lambda: (self._cancel_event is not None
                                       and self._cancel_event.is_set()),
                )
            else:
                # Đường CHÍNH (mới): detector streaming + state machine (bám nét chữ
                # trắng, gap-tolerance) -> câu sạch, timing khít; OCR từng ảnh riêng
                # (không montage -> không dính chữ). Hết sót/lặp/lệch hơn hẳn cách cũ.
                from vicdub.utils.detect_ocr import (  # noqa: PLC0415
                    OcrQualityError, detect_ocr_video,
                )
                from vicdub.utils.sub_detector import effective_detector_fps  # noqa: PLC0415
                from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415
                self.report(3, "Đang phân tích phụ đề trong video...")
                width, height = ffmpeg.video_size(video_path)
                duration = ffmpeg.duration(video_path)
                source_fps = ffmpeg.video_fps(video_path)
                requested_fps = float(getattr(config, "llm_ocr_fps", 20.0))
                # Mức 20 là chế độ "không sót": đọc toàn bộ frame gốc của phim
                # 24/25/30 fps. Quét cố định 20 fps có thể rơi đúng vào khoảng
                # giữa và bỏ mất một hard-sub chỉ tồn tại đúng một frame.
                scan_fps = effective_detector_fps(source_fps, requested_fps)
                self.report(
                    4,
                    f"Quét {scan_fps:g} fps"
                    + (" (đủ frame gốc)" if source_fps > 0 and scan_fps >= source_fps else ""),
                )
                # Expand the selected strip vertically. A box drawn tightly on one
                # frame can clip a different font/line in subsequent frames.
                crop = region_to_crop(region, width, height, vertical_padding=0.10)
                # Có Vision API key -> đọc chữ bằng Cloud Vision (nhanh hơn nhiều và
                # ánh xạ câu bằng toạ độ pixel). Không có key -> Drive OCR như cũ.
                vision_client = None
                vision_key = str(getattr(config, "vision_api_key", "") or "").strip()
                if vision_key:
                    from vicdub.api.vision_ocr_client import (  # noqa: PLC0415
                        VisionOcrClient, VisionOcrError,
                    )
                    try:
                        vision_client = VisionOcrClient(vision_key)
                        self.report(4, "Đang dùng chế độ nhận diện nhanh.")
                    except VisionOcrError as exc:
                        self.logger.warning("Chế độ nhận diện nhanh không dùng được (%s); chuyển chế độ ổn định.", exc)
                try:
                    segments = detect_ocr_video(
                        video_path, config.ffmpeg_path, clients, crop,
                        vision_client=vision_client,
                        scan_fps=scan_fps,
                        batch=int(getattr(config, "llm_ocr_batch", 20)),
                        lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                        duration=duration,
                        # Recall-first: một frame hợp lệ vẫn là ứng viên. Chỉ OCR
                        # mới có quyền kết luận vùng đó không chứa phụ đề.
                        min_duration=0.0,
                        progress=self.report,
                        cancelled=lambda: (self._cancel_event is not None
                                           and self._cancel_event.is_set()),
                        checkpoint_dir=str(Path(project.root) / ".drive_ocr_checkpoint"),
                    )
                except OcrQualityError as exc:
                    # This is invalid OCR input, not a detector crash. The legacy
                    # path would reuse the same bad region and risk bad overwrite.
                    raise ModuleError(str(exc)) from exc
                except Exception as exc:  # noqa: BLE001 - detector lỗi -> về cách cũ
                    self.logger.warning("Bộ phân tích mới lỗi (%s); chuyển phương án dự phòng.", exc)
                    self.report(3, "Đang chuyển sang phương án nhận diện dự phòng...")
                    segments = llm_ocr_video(
                        video_path, ffmpeg,
                        clients[0] if len(clients) == 1 else clients,
                        region=region,
                        fps=float(getattr(config, "llm_ocr_fps", 8.0)),
                        batch=int(getattr(config, "llm_ocr_batch", 18)),
                        sim_threshold=max(0.95, float(getattr(config, "ocr_sim_threshold", 0.7))),
                        min_duration=float(getattr(config, "ocr_min_duration", 0.12)),
                        max_merge_gap=0.08,
                        lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                        progress=self.report,
                        cancelled=lambda: (self._cancel_event is not None
                                           and self._cancel_event.is_set()),
                        checkpoint_dir=str(Path(project.root) / ".ocr_checkpoint"),
                        engine_label="Nhận diện phụ đề",
                    )
        except RuntimeError as exc:
            raise ModuleError(str(exc)) from exc
        except FFmpegError as exc:
            raise ModuleError(f"Lỗi khi trích khung hình phụ đề:\n{exc}") from exc
        finally:
            for client in clients:
                client.close()

        if not segments:
            raise ModuleError(
                "Không đọc được dòng phụ đề nào. Kiểm tra lại vùng sub, "
                "hoặc import file phụ đề có sẵn."
            )
        return segments

    # ---------- OCR gắn cứng qua Gemini Web ----------

    def _from_gemini_web(self, data: dict[str, Any]) -> list[Segment]:
        """OCR phụ đề gắn cứng qua Gemini Web, dùng profile Chrome lâu dài."""
        video_path = data.get("video_path", "")
        if not video_path:
            raise ModuleError("Chưa có video để nhận diện phụ đề.")
        if not Path(video_path).exists():
            raise ModuleError(f"Video không tồn tại: {video_path}")

        from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415
        from vicdub.utils.llm_ocr_subtitles import (  # noqa: PLC0415
            DEFAULT_REGION as LLM_REGION, llm_ocr_video,
        )

        config = data["config"]
        project = data["project"]
        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or LLM_REGION
        ))
        if len(region) != 4:
            region = LLM_REGION
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )

        self.report(3, "Đang chuẩn bị dữ liệu nhận diện phụ đề...")
        profile_count = max(1, int(getattr(config, "gemini_web_profiles", 1)))
        profile_count = min(profile_count, 2)
        mode_note = "ổn định" if profile_count == 1 else "song song"
        self.report(4, f"Nhận diện bằng {profile_count} phiên ({mode_note}).")
        web_clients = [
            GeminiWebClient(
                config.data_dir,
                # llm_ocr_video owns the 0-100 pipeline progress. GeminiWebClient
                # logs its browser state separately so it does not reset UI progress
                # back to 4-5% while OCR is already in the Gemini batch phase.
                report=None,
                login_timeout=getattr(config, "gemini_web_login_timeout", 300),
                # Phản hồi bình thường mất 10-25 giây. Không để một request web
                # im lặng giữ cả phim ở 50% suốt 4 phút trước khi retry.
                response_timeout=min(
                    90, int(getattr(config, "gemini_web_response_timeout", 180))
                ),
                profile_name=str(idx + 1),
            )
            for idx in range(profile_count)
        ]
        gemini_arg = web_clients[0] if len(web_clients) == 1 else web_clients
        try:
            segments = llm_ocr_video(
                video_path,
                ffmpeg,
                gemini_arg,
                region=region,
                fps=float(getattr(config, "llm_ocr_fps", 2.0)),
                batch=int(getattr(config, "llm_ocr_batch", 18)),
                dedup_threshold=float(getattr(config, "ocr_dedup_threshold", 0.006)),
                # Fast-dialogue hard-sub should prefer duplicate candidates over
                # missing subtitles. Keep Web OCR merging conservative.
                sim_threshold=max(0.95, float(getattr(config, "ocr_sim_threshold", 0.7))),
                min_duration=float(getattr(config, "ocr_min_duration", 0.12)),
                max_merge_gap=0.08,
                lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                progress=self.report,
                cancelled=lambda: (self._cancel_event is not None
                                   and self._cancel_event.is_set()),
                checkpoint_dir=str(Path(project.root) / ".ocr_checkpoint"),
                engine_label="Nhận diện phụ đề",
            )
        except RuntimeError as exc:
            raise ModuleError(str(exc)) from exc
        except FFmpegError as exc:
            raise ModuleError(f"Lỗi khi trích khung hình phụ đề:\n{exc}") from exc
        finally:
            for client in web_clients:
                client.close()

        if not segments:
            raise ModuleError(
                "Không đọc được dòng phụ đề nào. Kiểm tra lại vùng "
                "sub, hoặc import file phụ đề có sẵn."
            )
        return segments

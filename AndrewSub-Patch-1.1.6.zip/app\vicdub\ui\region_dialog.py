"""Dialog chọn vùng phụ đề trên khung hình video cho OCR.

Người dùng kéo một khung chữ nhật quanh dải phụ đề; dialog trả về toạ độ theo
tỷ lệ (x0, y0, x1, y1) trong khoảng 0-1 để lưu vào cấu hình và dùng cho crop.
"""

from __future__ import annotations

from typing import Callable

from PyQt6.QtCore import QPoint, QRect, QSize, Qt
from PyQt6.QtGui import QColor, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QSlider, QVBoxLayout, QWidget,
)

# Bề rộng hiển thị tối đa của khung xem trước.
_DISPLAY_WIDTH = 760
_DISPLAY_HEIGHT_FALLBACK = 620


def _fit_width(pixmap: QPixmap) -> QPixmap:
    """Thu ảnh về bề rộng hiển thị tối đa (không phóng to ảnh nhỏ hơn)."""
    scale = min(1.0, _DISPLAY_WIDTH / max(1, pixmap.width()))
    if scale < 1.0:
        return pixmap.scaledToWidth(
            int(pixmap.width() * scale),
            Qt.TransformationMode.SmoothTransformation,
        )
    return pixmap


def _max_canvas_size() -> QSize:
    """Kích thước preview tối đa theo màn hình hiện tại."""
    screen = QApplication.primaryScreen()
    if screen is None:
        return QSize(_DISPLAY_WIDTH, _DISPLAY_HEIGHT_FALLBACK)
    area = screen.availableGeometry()
    return QSize(
        min(_DISPLAY_WIDTH, max(360, area.width() - 160)),
        max(260, area.height() - 210),
    )


def _fit_preview(pixmap: QPixmap, max_size: QSize) -> QPixmap:
    """Thu ảnh theo cả chiều rộng và cao để dialog không vượt màn hình."""
    if pixmap.isNull():
        return pixmap
    if pixmap.width() <= max_size.width() and pixmap.height() <= max_size.height():
        return pixmap
    return pixmap.scaled(
        max_size,
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )


class _Canvas(QLabel):
    """Ảnh khung hình + lớp phủ cho phép kéo chọn khung chữ nhật."""

    def __init__(self, pixmap: QPixmap, region: tuple[float, float, float, float]):
        super().__init__()
        self._max_size = _max_canvas_size()
        self._original_pix = pixmap
        self._zoom_percent = 100
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._start: QPoint | None = None
        self._rect = self._region_to_rect(region)

    def _scaled_max_size(self) -> QSize:
        factor = max(0.35, min(2.0, self._zoom_percent / 100.0))
        return QSize(
            max(1, int(self._max_size.width() * factor)),
            max(1, int(self._max_size.height() * factor)),
        )

    def set_zoom(self, percent: int) -> None:
        region = self.region()
        self._zoom_percent = max(35, min(200, int(percent)))
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._rect = self._region_to_rect(region)
        self.update()

    def set_frame(self, pixmap: QPixmap) -> None:
        """Đổi ảnh khung hình đang xem, giữ nguyên vùng đang khoanh.

        Các khung của cùng một video có cùng kích thước nên vùng (theo pixel
        hiển thị) vẫn hợp lệ sau khi đổi khung.
        """
        region = self.region()
        self._original_pix = pixmap
        self._pix = _fit_preview(self._original_pix, self._scaled_max_size())
        self.setPixmap(self._pix)
        self.setFixedSize(self._pix.size())
        self._rect = self._region_to_rect(region)
        self.update()

    # ----- Chuyển đổi tỷ lệ <-> pixel hiển thị -----

    def _region_to_rect(self, region: tuple[float, float, float, float]) -> QRect:
        w, h = self._pix.width(), self._pix.height()
        x0, y0, x1, y1 = region
        return QRect(
            QPoint(int(x0 * w), int(y0 * h)),
            QPoint(int(x1 * w), int(y1 * h)),
        ).normalized()

    def region(self) -> tuple[float, float, float, float]:
        """Trả vùng đang chọn theo tỷ lệ 0-1."""
        w, h = max(1, self._pix.width()), max(1, self._pix.height())
        r = self._rect.normalized()
        return (
            max(0.0, r.left() / w), max(0.0, r.top() / h),
            min(1.0, r.right() / w), min(1.0, r.bottom() / h),
        )

    # ----- Kéo chuột -----

    def mousePressEvent(self, event) -> None:
        self._start = event.pos()
        self._rect = QRect(self._start, self._start)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._start is not None:
            self._rect = QRect(self._start, event.pos()).normalized()
            self.update()

    def mouseReleaseEvent(self, event) -> None:
        if self._start is not None:
            self._rect = QRect(self._start, event.pos()).normalized()
            self._start = None
            self.update()

    # ----- Vẽ -----

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        if self._rect.isNull():
            return
        painter = QPainter(self)
        # Làm tối phần ngoài vùng chọn cho dễ nhìn.
        overlay = QColor(0, 0, 0, 110)
        full = self.rect()
        r = self._rect.intersected(full)
        for area in (
            QRect(full.left(), full.top(), full.width(), r.top() - full.top()),
            QRect(full.left(), r.bottom(), full.width(), full.bottom() - r.bottom()),
            QRect(full.left(), r.top(), r.left() - full.left(), r.height()),
            QRect(r.right(), r.top(), full.right() - r.right(), r.height()),
        ):
            painter.fillRect(area, overlay)
        pen = QPen(QColor(0, 200, 120), 2)
        painter.setPen(pen)
        painter.drawRect(r)


class OcrRegionDialog(QDialog):
    """Hộp thoại kéo chọn vùng phụ đề, trả tỷ lệ (x0,y0,x1,y1)."""

    def __init__(self, frame_png: str,
                 region: tuple[float, float, float, float],
                 parent: QWidget | None = None,
                 frame_provider: Callable[[], str | None] | None = None):
        super().__init__(parent)
        self.setWindowTitle("Chọn vùng phụ đề (kéo chuột quanh dòng chữ)")
        self._frame_provider = frame_provider
        layout = QVBoxLayout(self)
        hint = "Kéo chuột để chọn vùng chứa phụ đề."
        if frame_provider is not None:
            hint += (" Nếu khung này chưa hiện phụ đề, bấm 'Đổi khung hình' "
                     "để xem cảnh khác.")
        layout.addWidget(QLabel(hint))
        self._canvas = _Canvas(QPixmap(frame_png), region)

        zoom_row = QHBoxLayout()
        zoom_row.addWidget(QLabel("Kích thước preview:"))
        self._zoom_label = QLabel("100%")
        self._zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self._zoom_slider.setRange(45, 160)
        self._zoom_slider.setValue(100)
        self._zoom_slider.setSingleStep(5)
        self._zoom_slider.valueChanged.connect(self._set_zoom)
        btn_fit = QPushButton("Vừa màn hình")
        btn_fit.clicked.connect(lambda: self._zoom_slider.setValue(100))
        zoom_row.addWidget(self._zoom_slider, 1)
        zoom_row.addWidget(self._zoom_label)
        zoom_row.addWidget(btn_fit)
        layout.addLayout(zoom_row)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(False)
        self._scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._scroll.setWidget(self._canvas)
        max_size = _max_canvas_size()
        self._scroll.setMaximumSize(max_size.width() + 26, max_size.height() + 26)
        layout.addWidget(self._scroll)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        if frame_provider is not None:
            btn_other = buttons.addButton(
                "Đổi khung hình", QDialogButtonBox.ButtonRole.ActionRole
            )
            btn_other.setToolTip("Xem một khung hình khác của video")
            btn_other.clicked.connect(self._load_other_frame)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _set_zoom(self, value: int) -> None:
        self._canvas.set_zoom(value)
        self._zoom_label.setText(f"{value}%")

    def _load_other_frame(self) -> None:
        """Lấy khung hình khác từ frame_provider và nạp vào canvas."""
        if self._frame_provider is None:
            return
        try:
            path = self._frame_provider()
        except Exception:  # noqa: BLE001 - lỗi trích khung không được làm sập dialog
            path = None
        if not path:
            return
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            self._canvas.set_frame(pixmap)

    def selected_region(self) -> tuple[float, float, float, float]:
        return self._canvas.region()

"""API Manager - quản lý pool API key không giới hạn.

Chiến lược chọn key: priority | round_robin | random | fastest.
Xử lý lỗi: 429 -> đổi key, 500 -> retry, 401 -> disable key.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

DEFAULT_GEMINI_MODEL = "gemini-3.5-flash"


@dataclass
class ApiKey:
    """Một API key trong pool."""

    name: str
    key: str
    model: str = DEFAULT_GEMINI_MODEL
    rpm: int = 15            # requests/phút
    tpm: int = 1_000_000     # tokens/phút
    priority: int = 1        # nhỏ hơn = ưu tiên hơn
    enabled: bool = True
    timeout: int = 60        # giây
    retry: int = 3

    # Trạng thái runtime (không lưu file)
    last_latency: float = field(default=0.0, repr=False)
    request_times: list = field(default_factory=list, repr=False)
    cooldown_until: float = field(default=0.0, repr=False)

    def to_dict(self) -> dict:
        return {
            "name": self.name, "key": self.key, "model": self.model,
            "rpm": self.rpm, "tpm": self.tpm, "priority": self.priority,
            "enabled": self.enabled, "timeout": self.timeout, "retry": self.retry,
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "ApiKey":
        allowed = {k: v for k, v in raw.items() if k in cls.__dataclass_fields__}
        return cls(**allowed)


class NoApiKeyError(Exception):
    """Pool không còn key khả dụng."""


class ApiManager:
    """Pool API key, chọn key theo chiến lược và tôn trọng giới hạn RPM."""

    STRATEGIES = ("priority", "round_robin", "random", "fastest")

    def __init__(self, keys: list[dict] | None = None, strategy: str = "priority") -> None:
        self._lock = threading.Lock()
        self.keys: list[ApiKey] = [ApiKey.from_dict(k) for k in (keys or [])]
        self.strategy = strategy if strategy in self.STRATEGIES else "priority"
        self._rr_index = 0

    # ---------- CRUD ----------

    def add(self, key: ApiKey) -> None:
        with self._lock:
            self.keys.append(key)

    def remove(self, name: str) -> None:
        with self._lock:
            self.keys = [k for k in self.keys if k.name != name]

    def to_config(self) -> list[dict]:
        return [k.to_dict() for k in self.keys]

    # ---------- Chọn key ----------

    def _usable(self) -> list[ApiKey]:
        now = time.time()
        return [k for k in self.keys if k.enabled and k.cooldown_until <= now]

    def pick(self) -> ApiKey:
        """Chọn key theo chiến lược, chờ RPM nếu cần."""
        with self._lock:
            usable = self._usable()
            if not usable:
                raise NoApiKeyError(
                    "Không còn API key khả dụng. Thêm key ở tab Cài đặt "
                    "hoặc chờ hết cooldown."
                )
            if self.strategy == "priority":
                chosen = min(usable, key=lambda k: k.priority)
            elif self.strategy == "random":
                chosen = random.choice(usable)
            elif self.strategy == "fastest":
                chosen = min(usable, key=lambda k: k.last_latency or 0.0)
            else:  # round_robin
                self._rr_index = (self._rr_index + 1) % len(usable)
                chosen = usable[self._rr_index]
        self._wait_rpm(chosen)
        return chosen

    def _wait_rpm(self, key: ApiKey) -> None:
        """Chặn nếu key vượt giới hạn RPM trong 60 giây gần nhất."""
        while True:
            now = time.time()
            key.request_times = [t for t in key.request_times if now - t < 60]
            if len(key.request_times) < max(1, key.rpm):
                key.request_times.append(now)
                return
            time.sleep(1.0)

    # ---------- Phản hồi lỗi từ client ----------

    def report_result(self, key: ApiKey, status: int, latency: float) -> None:
        """Client báo kết quả để pool điều chỉnh.

        429 -> cooldown key 60s (đổi key khác), 401 -> disable hẳn.
        """
        key.last_latency = latency
        if status == 429:
            key.cooldown_until = time.time() + 60
            logger.warning("API '%s' bị 429, nghỉ 60 giây", key.name)
        elif status == 401:
            key.enabled = False
            logger.error("API '%s' bị 401 - đã tắt key", key.name)

    def status_rows(self) -> list[dict]:
        """Dữ liệu hiển thị bảng API Status trên UI."""
        now = time.time()
        rows = []
        for k in self.keys:
            if not k.enabled:
                state = "Tắt (401?)"
            elif k.cooldown_until > now:
                state = f"Nghỉ {int(k.cooldown_until - now)}s"
            else:
                state = "Sẵn sàng"
            rows.append({
                "name": k.name, "model": k.model, "state": state,
                "latency": f"{k.last_latency:.1f}s" if k.last_latency else "-",
            })
        return rows

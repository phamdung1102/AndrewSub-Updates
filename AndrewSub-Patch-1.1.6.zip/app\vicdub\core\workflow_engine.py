"""Workflow Engine - điều phối pipeline.

Import -> Subtitle -> Translate -> Voice -> Merge

Engine là nơi DUY NHẤT nối các module với nhau: truyền ngữ cảnh (dict),
quản lý queue/retry/pause/resume/progress/history. Module không biết nhau.
"""

from __future__ import annotations

import logging
import threading
from typing import Any

from PyQt6.QtCore import QObject, pyqtSignal

from vicdub.core.module_base import BaseModule
from vicdub.core.task_queue import Task, TaskQueue

logger = logging.getLogger(__name__)

# Thứ tự pipeline chuẩn (key -> hiển thị). Không còn bước "video" (retime clip):
# bước "merge" lồng tiếng theo timeline rồi phủ lên VIDEO GỐC, giữ nguyên hình.
PIPELINE_STEPS: list[tuple[str, str]] = [
    ("subtitle", "Tách phụ đề"),
    ("translate", "Dịch phụ đề"),
    ("voice", "Sinh giọng nói"),
    ("merge", "Lồng tiếng + Ghép"),
]


class WorkflowEngine(QObject):
    """Điều phối các module theo pipeline, phát tín hiệu cho UI."""

    step_started = pyqtSignal(str)              # key bước
    step_progress = pyqtSignal(str, int, str)   # key, %, mô tả
    step_finished = pyqtSignal(str)             # key
    step_failed = pyqtSignal(str, str)          # key, lỗi
    pipeline_finished = pyqtSignal(bool)        # True nếu trọn vẹn

    def __init__(self) -> None:
        super().__init__()
        self._modules: dict[str, BaseModule] = {}
        self._queue = TaskQueue()
        self.context: dict[str, Any] = {}
        self._name_to_key: dict[str, str] = {}

        self._queue.task_started.connect(self._on_task_started)
        self._queue.task_progress.connect(self._on_task_progress)
        self._queue.task_finished.connect(self._on_task_finished)
        self._queue.task_failed.connect(self._on_task_failed)
        self._queue.queue_finished.connect(self.pipeline_finished)

    # ---------- Đăng ký module ----------

    def register(self, key: str, module: BaseModule) -> None:
        """Đăng ký module cho một bước pipeline."""
        self._modules[key] = module
        self._name_to_key[module.name] = key

    # ---------- Chạy ----------

    def run_steps(self, keys: list[str], context: dict[str, Any]) -> None:
        """Chạy các bước theo thứ tự trên worker thread.

        Args:
            keys: danh sách key bước (theo PIPELINE_STEPS).
            context: ngữ cảnh khởi đầu (project, config, đường dẫn...).
        """
        if self._queue.is_running():
            raise RuntimeError("Pipeline đang chạy, hãy chờ hoặc hủy trước")
        self.context = dict(context)
        tasks: list[Task] = []
        for key in keys:
            module = self._modules.get(key)
            if module is None:
                raise ValueError(f"Chưa đăng ký module cho bước '{key}'")
            tasks.append(Task(
                name=module.name,
                func=self._make_runner(module),
                max_retry=2,
            ))
        self._queue.start(tasks)

    def run_all(self, context: dict[str, Any]) -> None:
        """Chạy trọn pipeline."""
        self.run_steps([k for k, _ in PIPELINE_STEPS], context)

    def _make_runner(self, module: BaseModule):
        """Đóng gói module thành hàm task: gắn callback rồi gộp output."""

        def runner(progress_cb, cancel_event: threading.Event):
            module.attach(progress_cb, cancel_event)
            output = module.run(self.context) or {}
            self.context.update(output)
            self._log_history(module.name, "done")
            return output

        return runner

    # ---------- Điều khiển ----------

    def pause(self) -> None:
        self._queue.pause()

    def resume(self) -> None:
        self._queue.resume()

    def cancel(self) -> None:
        self._queue.cancel()

    def is_running(self) -> bool:
        return self._queue.is_running()

    def is_paused(self) -> bool:
        return self._queue.is_paused()

    # ---------- History ----------

    def _log_history(self, step: str, status: str, detail: str = "") -> None:
        project = self.context.get("project")
        if project is not None:
            try:
                project.add_history(step, status, detail)
            except Exception:  # noqa: BLE001 - history không được làm gãy pipeline
                logger.exception("Không ghi được history")

    # ---------- Chuyển tiếp tín hiệu (tên task -> key bước) ----------

    def _key_of(self, task_name: str) -> str:
        return self._name_to_key.get(task_name, task_name)

    def _on_task_started(self, name: str) -> None:
        self.step_started.emit(self._key_of(name))

    def _on_task_progress(self, name: str, pct: int, msg: str) -> None:
        self.step_progress.emit(self._key_of(name), pct, msg)

    def _on_task_finished(self, name: str, _result: object) -> None:
        self.step_finished.emit(self._key_of(name))

    def _on_task_failed(self, name: str, error: str) -> None:
        self._log_history(name, "failed", error)
        self.step_failed.emit(self._key_of(name), error)

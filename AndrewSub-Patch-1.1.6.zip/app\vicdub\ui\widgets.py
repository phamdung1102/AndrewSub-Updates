"""Widget dùng chung: bảng phụ đề, tiến độ pipeline, trạng thái API."""

from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QComboBox, QHBoxLayout, QHeaderView, QLabel, QLayout, QProgressBar,
    QPushButton, QTableWidget, QTableWidgetItem, QToolButton, QVBoxLayout,
    QWidget,
)

from vicdub.core.workflow_engine import PIPELINE_STEPS
from vicdub.utils.subtitles import Segment


def title_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setProperty("role", "title")
    return label


def muted_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setProperty("role", "muted")
    label.setWordWrap(True)
    return label


class CollapsibleBox(QWidget):
    """Mục thu gọn được: bấm tiêu đề để hiện/ẩn nội dung.

    Dùng gom nhóm cấu hình cho đỡ tràn màn hình.
    """

    def __init__(self, title: str, collapsed: bool = False,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._toggle = QToolButton()
        self._toggle.setText(title)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(not collapsed)
        self._toggle.setStyleSheet(
            "QToolButton { border: none; font-weight: 700; padding: 4px 0; }"
        )
        self._toggle.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonTextBesideIcon
        )
        self._toggle.setArrowType(
            Qt.ArrowType.DownArrow if not collapsed else Qt.ArrowType.RightArrow
        )
        self._toggle.clicked.connect(self._on_toggle)

        self._content = QWidget()
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(14, 0, 0, 6)
        self._content_layout.setSpacing(6)
        self._content.setVisible(not collapsed)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._toggle)
        outer.addWidget(self._content)

    def _on_toggle(self) -> None:
        show = self._toggle.isChecked()
        self._toggle.setArrowType(
            Qt.ArrowType.DownArrow if show else Qt.ArrowType.RightArrow
        )
        self._content.setVisible(show)

    def add_layout(self, layout: QLayout) -> None:
        self._content_layout.addLayout(layout)

    def add_widget(self, widget: QWidget) -> None:
        self._content_layout.addWidget(widget)


class SubtitleTable(QTableWidget):
    """Bảng sub kiểu studio: sửa được nội dung + cột so sánh clip/voice.

    Cột 0-5 chỉnh sửa được (trừ #). Cột 6-8 (Clip/Voice/Sync) chỉ đọc,
    hiển thị so sánh thời lượng clip với voice đã sinh và tốc độ cần kéo.
    """

    #: Phát khi người dùng sửa một ô (sau khi đã ghi vào segment).
    segment_edited = pyqtSignal(object)  # Segment
    #: Phát khi bấm nút ▶ của một dòng (số dòng) - nghe voice dòng đó.
    play_requested = pyqtSignal(int)

    COLUMNS = ("#", "Bắt đầu", "Kết thúc", "Nhân vật", "Gốc", "Bản dịch",
               "Giọng", "Đoạn (s)", "Giọng (s)", "Khớp", "Nghe")
    EDITABLE_MAX = 5  # cột 1..5 sửa được

    def __init__(self) -> None:
        super().__init__(0, len(self.COLUMNS))
        self.setHorizontalHeaderLabels(self.COLUMNS)
        self.verticalHeader().setVisible(False)
        header = self.horizontalHeader()
        for col in (0, 1, 2, 3, 6, 7, 8, 9, 10):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self._segments: list[Segment] = []
        self._loading = False
        self.itemChanged.connect(self._on_item_changed)

    #: Mục đầu của combo giọng - dòng không có giọng riêng thì dùng mặc định.
    FOLLOW_SPEAKER = "(giọng mặc định)"

    def load(self, segments: list[Segment],
             sync_info: dict[int, tuple[str, str]] | None = None,
             voices: list[str] | None = None) -> None:
        """Đổ danh sách segment vào bảng.

        Args:
            sync_info: {line: (voice_giây, trạng_thái_sync)} - tùy chọn.
            voices: danh sách giọng cho combo từng dòng - tùy chọn.
        """
        self._loading = True
        old_block = self.blockSignals(True)
        self.setUpdatesEnabled(False)
        try:
            self._segments = segments
            sync_info = sync_info or {}
            voices = voices or []
            self.setRowCount(len(segments))
            for row, seg in enumerate(segments):
                voice_s, sync = sync_info.get(seg.line, ("—", "—"))
                has_voice = voice_s != "—"
                values = (
                    str(seg.line), f"{seg.start:.2f}", f"{seg.end:.2f}",
                    seg.speaker, seg.text, seg.translation,
                )
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if col == 0:
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    self.setItem(row, col, item)

                # Cột 6: combo giọng riêng của dòng.
                combo = QComboBox()
                combo.setMinimumWidth(150)
                combo.addItems([self.FOLLOW_SPEAKER, *voices])
                if seg.voice and seg.voice in voices:
                    combo.setCurrentText(seg.voice)
                combo.currentTextChanged.connect(
                    lambda value, s=seg: self._on_voice_combo(s, value)
                )
                self.setCellWidget(row, 6, combo)

                for offset, value in enumerate(
                        (f"{seg.duration:.2f}", voice_s, sync)):
                    item = QTableWidgetItem(value)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    self.setItem(row, 7 + offset, item)

                # Nút ▶ nghe voice của dòng - mờ đi khi chưa render.
                play_btn = QPushButton("▶" if has_voice else "▶ ?")
                play_btn.setFixedWidth(44)
                play_btn.setToolTip(
                    "Nghe giọng đọc" if has_voice
                    else "Chưa có giọng đọc"
                )
                play_btn.clicked.connect(
                    lambda _checked=False, line=seg.line: self.play_requested.emit(line)
                )
                self.setCellWidget(row, 10, play_btn)
        finally:
            self.setUpdatesEnabled(True)
            self.blockSignals(old_block)
            self._loading = False

    def _on_voice_combo(self, seg: Segment, value: str) -> None:
        """Đổi giọng riêng của một dòng -> lưu ngay qua segment_edited."""
        if self._loading:
            return
        seg.voice = "" if value == self.FOLLOW_SPEAKER else value
        self.segment_edited.emit(seg)

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        """Ghi thay đổi từ ô về Segment tương ứng."""
        if self._loading or item.row() >= len(self._segments):
            return
        if item.column() > self.EDITABLE_MAX:
            return
        seg = self._segments[item.row()]
        col, text = item.column(), item.text()
        try:
            if col == 1:
                seg.start = float(text)
            elif col == 2:
                seg.end = float(text)
            elif col == 3:
                seg.speaker = text.strip()
            elif col == 4:
                seg.text = text
            elif col == 5:
                seg.translation = text
        except ValueError:
            return  # nhập thời gian sai thì bỏ qua
        self.segment_edited.emit(seg)


class PipelineProgress(QWidget):
    """Panel tiến độ: danh sách bước, thanh %, nút Pause/Resume/Cancel."""

    pause_clicked = pyqtSignal()
    resume_clicked = pyqtSignal()
    cancel_clicked = pyqtSignal()

    ICON_PENDING, ICON_RUNNING, ICON_DONE, ICON_FAILED = "○", "◐", "●", "✕"

    def __init__(self) -> None:
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(title_label("Tiến độ"))

        self._step_labels: dict[str, QLabel] = {}
        for key, label in PIPELINE_STEPS:
            lbl = QLabel(f"{self.ICON_PENDING}  {label}")
            lbl.setProperty("role", "muted")
            self._step_labels[key] = lbl
            layout.addWidget(lbl)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        layout.addWidget(self.bar)

        self.message = muted_label("Sẵn sàng.")
        layout.addWidget(self.message)

        buttons = QHBoxLayout()
        self.btn_pause = QPushButton("Tạm dừng")
        self.btn_resume = QPushButton("Tiếp tục")
        self.btn_cancel = QPushButton("Hủy")
        self.btn_cancel.setProperty("variant", "danger")
        for btn in (self.btn_pause, self.btn_resume, self.btn_cancel):
            btn.setEnabled(False)
            buttons.addWidget(btn)
        layout.addLayout(buttons)

        self.btn_pause.clicked.connect(self.pause_clicked)
        self.btn_resume.clicked.connect(self.resume_clicked)
        self.btn_cancel.clicked.connect(self.cancel_clicked)

    # ---------- Cập nhật từ engine ----------

    def reset(self) -> None:
        for key, (label_key, label) in zip(self._step_labels, PIPELINE_STEPS):
            self._step_labels[key].setText(f"{self.ICON_PENDING}  {label}")
        self.bar.setValue(0)
        self.message.setText("Sẵn sàng.")

    def set_running(self, running: bool) -> None:
        self.btn_pause.setEnabled(running)
        self.btn_resume.setEnabled(running)
        self.btn_cancel.setEnabled(running)

    def _set_icon(self, key: str, icon: str) -> None:
        label = self._step_labels.get(key)
        if label:
            text = dict(PIPELINE_STEPS).get(key, key)
            label.setText(f"{icon}  {text}")

    def on_step_started(self, key: str) -> None:
        self._set_icon(key, self.ICON_RUNNING)

    def on_step_progress(self, key: str, pct: int, msg: str) -> None:
        self.bar.setValue(pct)
        self.message.setText(msg)

    def on_step_finished(self, key: str) -> None:
        self._set_icon(key, self.ICON_DONE)

    def on_step_failed(self, key: str, error: str) -> None:
        self._set_icon(key, self.ICON_FAILED)
        self.message.setText(f"Lỗi: {error}")


class ApiStatusTable(QTableWidget):
    """Bảng trạng thái API key cho panel phải."""

    COLUMNS = ("Tên", "Model", "Trạng thái", "Độ trễ")

    def __init__(self) -> None:
        super().__init__(0, len(self.COLUMNS))
        self.setHorizontalHeaderLabels(self.COLUMNS)
        self.verticalHeader().setVisible(False)
        self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.setMaximumHeight(140)

    def refresh(self, rows: list[dict]) -> None:
        self.setRowCount(len(rows))
        for row, data in enumerate(rows):
            for col, key in enumerate(("name", "model", "state", "latency")):
                self.setItem(row, col, QTableWidgetItem(str(data.get(key, ""))))

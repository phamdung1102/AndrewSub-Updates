"""Các nhà cung cấp TTS trực tuyến và catalog giọng được cache."""

from __future__ import annotations

import json
import os
import tempfile
import time
import wave
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests

from vicdub.core.module_base import ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg
from vicdub.utils.secret_store import unprotect_secret

OPENAI_VOICES = [
    "alloy", "ash", "ballad", "coral", "echo", "fable", "onyx", "nova",
    "sage", "shimmer", "verse", "marin", "cedar",
]


class VoiceApiEngine:
    """Engine tương thích TTSEngine, dùng một provider đang chọn."""

    def __init__(self, config: Any) -> None:
        self.config = config
        self.kind = str(getattr(config, "voice_api_type", "openai") or "openai")
        self.base_url = str(getattr(config, "voice_api_base_url", "") or "").rstrip("/")
        self.model = str(getattr(config, "voice_api_model", "") or "")
        self.key = unprotect_secret(getattr(config, "voice_api_key", ""))
        self.timeout = max(10, int(getattr(config, "voice_api_timeout", 90)))
        self._voice_ids: dict[str, str] = {}
        self.cache_path = Path(config.data_dir) / "voice_catalog.json"

    @property
    def provider_signature(self) -> str:
        return f"api:{self.kind}:{self.base_url}:{self.model}"

    def _headers(self) -> dict[str, str]:
        if self.kind == "elevenlabs":
            return {"xi-api-key": self.key, "Accept": "application/json"}
        header = str(getattr(self.config, "voice_api_auth_header", "Authorization") or "Authorization")
        prefix = str(getattr(self.config, "voice_api_auth_prefix", "Bearer") or "").strip()
        return {header: f"{prefix} {self.key}".strip(), "Accept": "application/json"}

    def _require(self) -> None:
        if not self.key:
            raise ModuleError("Chưa nhập khóa API giọng nói trong Cài đặt.")
        if not self.base_url:
            raise ModuleError("Chưa nhập địa chỉ API giọng nói trong Cài đặt.")

    def _load_cache(self) -> list[dict]:
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
            if data.get("signature") == self.provider_signature:
                return list(data.get("voices") or [])
        except (OSError, ValueError, TypeError):
            pass
        return []

    def catalog_stale(self) -> bool:
        """Catalog thiếu/sai provider/quá hạn thì cần đồng bộ nền."""
        if not self.cache_path.exists():
            return True
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
            hours = max(1, int(getattr(self.config, "voice_catalog_auto_sync_hours", 24)))
            return (data.get("signature") != self.provider_signature
                    or time.time() - float(data.get("updated_at", 0)) >= hours * 3600)
        except (OSError, ValueError, TypeError):
            return True

    def _save_cache(self, voices: list[dict]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps({
            "signature": self.provider_signature, "updated_at": time.time(),
            "voices": voices,
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def _label(name: str, voice_id: str) -> str:
        return name if name == voice_id else f"{name} · {voice_id}"

    def list_voices(self, force: bool = False) -> list[str]:
        voices = [] if force else self._load_cache()
        if not voices:
            if self.kind == "openai":
                voices = [{"id": v, "name": v} for v in OPENAI_VOICES]
            elif force:
                voices = self.sync_voices()
        self._voice_ids = {
            self._label(str(v.get("name") or v.get("id")), str(v.get("id"))): str(v.get("id"))
            for v in voices if v.get("id")
        }
        return list(self._voice_ids)

    def sync_voices(self) -> list[dict]:
        self._require()
        if self.kind == "openai":
            voices = [{"id": v, "name": v} for v in OPENAI_VOICES]
        elif self.kind == "elevenlabs":
            voices, token = [], None
            while True:
                params = {"page_size": 100}
                if token:
                    params["next_page_token"] = token
                response = requests.get(
                    f"{self.base_url}/v2/voices", headers=self._headers(),
                    params=params, timeout=self.timeout,
                )
                self._raise(response)
                body = response.json()
                voices.extend({"id": v.get("voice_id"), "name": v.get("name")}
                              for v in body.get("voices", []))
                token = body.get("next_page_token") if body.get("has_more") else None
                if not token:
                    break
        else:
            url = str(getattr(self.config, "voice_api_voices_url", "") or "")
            if not url:
                raise ModuleError("API REST tùy chỉnh chưa có URL danh sách giọng.")
            response = requests.get(url, headers=self._headers(), timeout=self.timeout)
            self._raise(response)
            body = response.json()
            rows = body if isinstance(body, list) else body.get("voices", body.get("data", []))
            voices = [{"id": v.get("voice_id") or v.get("id"),
                       "name": v.get("name") or v.get("display_name") or v.get("id")}
                      for v in rows]
        voices = [v for v in voices if v.get("id")]
        self._save_cache(voices)
        return voices

    @staticmethod
    def _raise(response: requests.Response) -> None:
        if response.ok:
            return
        detail = response.text[:300].strip()
        if response.status_code in (401, 403):
            raise ModuleError("API giọng nói từ chối khóa truy cập. Hãy kiểm tra lại API key.")
        if response.status_code == 429:
            raise ModuleError("API giọng nói đang giới hạn lượt gọi. Phần đã sinh được giữ lại; thử tiếp sau.")
        raise ModuleError(f"API giọng nói lỗi HTTP {response.status_code}: {detail}")

    def _voice_id(self, voice: str) -> str:
        if not self._voice_ids:
            self.list_voices()
        return self._voice_ids.get(voice, voice.rsplit(" · ", 1)[-1].strip())

    def synthesize(self, text: str, voice: str, speed: float, out_wav: str,
                   duration: float | None = None) -> None:
        self._require()
        voice_id = self._voice_id(voice)
        headers = self._headers()
        if self.kind == "openai":
            url = f"{self.base_url}/audio/speech"
            payload = {"model": self.model or "gpt-4o-mini-tts", "input": text,
                       "voice": voice_id, "response_format": "wav", "speed": speed or 1.0}
        elif self.kind == "elevenlabs":
            url = f"{self.base_url}/v1/text-to-speech/{quote(voice_id, safe='')}"
            payload = {"text": text, "model_id": self.model or "eleven_multilingual_v2"}
            headers["Accept"] = "audio/mpeg"
        else:
            template = str(getattr(self.config, "voice_api_synthesis_url", "") or "")
            if not template:
                raise ModuleError("API REST tùy chỉnh chưa có URL sinh giọng.")
            url = template.replace("{voice_id}", quote(voice_id, safe=""))
            payload = {"text": text, "voice": voice_id, "model": self.model,
                       "speed": speed or 1.0}
        headers["Content-Type"] = "application/json"
        last_error: Exception | None = None
        for attempt in range(max(1, int(getattr(self.config, "voice_api_retry", 3)))):
            try:
                response = requests.post(url, headers=headers, json=payload, timeout=self.timeout)
                self._raise(response)
                self._write_wav(response.content, out_wav)
                return
            except (requests.RequestException, ModuleError) as exc:
                last_error = exc
                if isinstance(exc, ModuleError) and ("khóa truy cập" in str(exc)):
                    break
                if attempt + 1 < max(1, int(getattr(self.config, "voice_api_retry", 3))):
                    time.sleep(1.5 * (attempt + 1))
        raise ModuleError(f"Không sinh được giọng từ API: {last_error}") from last_error

    def _write_wav(self, content: bytes, out_wav: str) -> None:
        if not content:
            raise ModuleError("API giọng nói trả file rỗng.")
        destination = Path(out_wav)
        destination.parent.mkdir(parents=True, exist_ok=True)
        suffix = ".wav" if content[:4] == b"RIFF" else ".audio"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix, dir=destination.parent) as f:
            f.write(content)
            source = f.name
        temporary = str(destination) + ".tmp.wav"
        try:
            if suffix == ".wav":
                try:
                    with wave.open(source, "rb") as audio:
                        ready = (audio.getnchannels() == 1 and audio.getsampwidth() == 2
                                 and audio.getframerate() == 24000
                                 and audio.getnframes() > 0)
                    if ready:
                        os.replace(source, destination)
                        return
                except (OSError, EOFError, wave.Error):
                    pass
            FFmpeg(self.config.ffmpeg_path, self.config.ffprobe_path).to_wav(source, temporary)
            os.replace(temporary, destination)
        finally:
            Path(source).unlink(missing_ok=True)
            Path(temporary).unlink(missing_ok=True)

    def synthesize_batch(self, texts: list[str], voice: str, speed: float,
                         out_wavs: list[str]) -> None:
        for text, out in zip(texts, out_wavs):
            self.synthesize(text, voice, speed, out)

    def default_voice(self, gender: str) -> str:
        voices = self.list_voices()
        return voices[0] if voices else ""

    def check(self) -> str:
        voices = self.sync_voices()
        return f"Kết nối API giọng nói OK — tìm thấy {len(voices)} giọng."

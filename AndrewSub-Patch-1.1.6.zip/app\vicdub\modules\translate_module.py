"""Translate Module.

Mode 1: Gemini dịch phụ đề.
Mode 2: Import translated.srt - không bắt buộc dịch bằng AI.

Có Translation Memory: câu đã dịch không gọi lại Gemini.

Output: segments (đã có translation), translated_srt
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.segmenter import estimate_speech_seconds
from vicdub.utils.subtitles import Segment, load_subtitle_file, write_srt
from vicdub.utils.translation_styles import style_instruction


class TranslateModule(BaseModule):
    """Dịch phụ đề."""

    name = "Dịch phụ đề"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        if not segments:
            raise ModuleError("Chưa có phụ đề. Chạy bước 'Tách phụ đề' trước.")

        translated_path = data.get("translated_subtitle_path", "")
        if translated_path:
            self._mode_import(segments, translated_path)
        else:
            self._mode_gemini(segments, data)

        # Tính toán khớp thời lượng: câu dịch đọc có kịp giờ của clip không?
        # Cho phép video co giãn 0.9x-1.1x nên ngưỡng cảnh báo là +15%.
        config = data["config"]
        risky = [
            seg.line for seg in segments
            if seg.translation and seg.duration > 0
            and estimate_speech_seconds(seg.translation, config.tts_chars_per_second)
            > seg.duration * 1.15
        ]
        if risky:
            preview = ", ".join(str(n) for n in risky[:10])
            more = "..." if len(risky) > 10 else ""
            message = (f"{len(risky)} câu dịch dài, có nguy cơ lệch tốc độ "
                       f"(dòng {preview}{more}) - sửa lại ở bảng bên dưới")
            self.logger.warning(message)
            project.add_history("translate", "warning", message)
            self.report(97, message)

        # Lưu kết quả.
        translated_srt = Path(project.root) / "subtitles" / "translated.srt"
        write_srt(segments, translated_srt, translated=True)
        (Path(project.root) / "subtitles" / "translated.partial.srt").unlink(missing_ok=True)
        project.save_segments(segments)

        self.report(100, f"Đã dịch {len(segments)} dòng")
        return {"segments": segments, "translated_srt": str(translated_srt)}

    # ---------- Mode 2: import bản dịch có sẵn ----------

    def _mode_import(self, segments: list[Segment], translated_path: str) -> None:
        self.report(20, f"Import bản dịch: {Path(translated_path).name}")
        if not Path(translated_path).exists():
            raise ModuleError(f"File không tồn tại: {translated_path}")
        translated = load_subtitle_file(translated_path)
        if len(translated) != len(segments):
            self.logger.warning(
                "Bản dịch %d dòng, gốc %d dòng - ghép theo thứ tự",
                len(translated), len(segments),
            )
        for seg, tr in zip(segments, translated):
            seg.translation = tr.text
            if tr.speaker:
                seg.speaker = tr.speaker
        # Dòng thiếu bản dịch thì giữ nguyên văn bản gốc.
        for seg in segments:
            if not seg.translation:
                seg.translation = seg.text
            if not seg.speaker:
                seg.speaker = "Narrator"

    # ---------- Mode 1: Gemini ----------

    def _mode_gemini(self, segments: list[Segment], data: dict[str, Any]) -> None:
        api_client = data.get("gemini")
        tm = data.get("tm")
        config = data["config"]
        project = data["project"]
        target_language = str(getattr(config, "target_language", "") or "").strip()
        if not target_language:
            raise ModuleError("Chưa chọn ngôn ngữ đích. Mở Dịch tự động và chọn ngôn ngữ cần dịch.")
        source = getattr(config, "translation_source", "web")
        web_clients = []
        translator = api_client
        if source == "web":
            from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415
            from vicdub.api.web_translation_pool import WebTranslationPool  # noqa: PLC0415
            count = max(1, min(2, int(getattr(config, "translation_web_profiles", 2))))
            web_clients = [GeminiWebClient(
                config.data_dir, report=None,
                login_timeout=getattr(config, "gemini_web_login_timeout", 300),
                response_timeout=min(120, int(getattr(config, "gemini_web_response_timeout", 240))),
                profile_name=f"translation_{index + 1}",
            ) for index in range(count)]
            fallback = api_client if getattr(config, "translation_api_fallback", True) else None
            translator = WebTranslationPool(web_clients, api_fallback=fallback)
        if translator is None:
            raise ModuleError(
                "Chưa cấu hình nguồn dịch dự phòng. Thêm khóa truy cập ở tab Cài đặt, "
                "hoặc import file translated.srt ở tab Dịch AI."
            )

        style = getattr(config, "translation_style", "conversational")
        instruction = style_instruction(
            style, getattr(config, "translation_style_custom", "")
        )
        # Phong cách là một phần của khóa cache; đổi phong cách không lấy nhầm bản cũ.
        def tm_key(text: str) -> str:
            return f"[target={target_language};style={style}:{instruction}] {text}"

        # Tra Translation Memory trước.
        pending: list[Segment] = []
        unreadable: list[Segment] = []
        for seg in segments:
            if (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được"):
                # Không gửi placeholder lên dịch vụ và không tạo voice từ một câu
                # không có nguyên văn. Người dùng vẫn thấy timing để sửa ô Gốc.
                seg.translation = ""
                unreadable.append(seg)
                continue
            cached = tm.get(tm_key(seg.text)) if tm else None
            if cached:
                seg.translation = cached
                if not seg.speaker:
                    seg.speaker = "Narrator"
            else:
                pending.append(seg)

        done = len(segments) - len(pending) - len(unreadable)
        if done:
            self.report(5, f"Translation Memory khớp {done} dòng")
        if unreadable:
            self.logger.warning(
                "Bỏ qua %d dòng nhận diện chưa đọc được khi dịch: %s",
                len(unreadable), ", ".join(str(s.line) for s in unreadable[:20]),
            )
        if not pending:
            for client in web_clients:
                client.close()
            self.report(95, "Không còn dòng hợp lệ cần dịch; các dòng nhận diện lỗi được giữ để sửa tay.")
            return

        # Dịch CẢ FILE: đẩy trọn nội dung còn lại lên Gemini theo khối lớn để
        # model thấy toàn bộ ngữ cảnh -> tên riêng, xưng hô nhất quán cả tập.
        payload = [
            {"line": s.line, "text": s.text, "seconds": round(s.duration, 1),
             "start": round(s.start, 3), "_style_instruction": instruction}
            for s in pending
        ]

        def prog(done_lines: int, total_lines: int) -> None:
            self.check_cancelled()
            pct = 10 + int(80 * done_lines / max(1, total_lines))
            self.report(pct, f"Đang dịch {done_lines}/{total_lines} dòng...")

        self.report(10, f"Đang gửi {len(pending)} dòng để dịch...")
        by_segment = {segment.line: segment for segment in segments}
        partial_srt = Path(project.root) / "subtitles" / "translated.partial.srt"

        def save_partial(batch_results: list[dict]) -> None:
            """Ghi ngay batch vừa xong để lỗi giữa phim không mất bản dịch."""
            for item in batch_results:
                line = int(item.get("line", -1))
                translation = str(item.get("translation", "")).strip()
                segment = by_segment.get(line)
                if segment is None or not translation:
                    continue
                segment.translation = translation
                if not segment.speaker:
                    segment.speaker = "Narrator"
                project.update_segment(segment)
                if tm:
                    tm.put(tm_key(segment.text), translation, target_language)
            write_srt(segments, partial_srt, translated=True)

        try:
            if source == "web":
                results = translator.translate_bulk_resumable(
                    payload, target_language,
                    chunk_lines=int(getattr(config, "translate_batch_size", 30)),
                    progress=prog,
                    checkpoint_dir=str(Path(project.root) / ".translation_checkpoint"),
                    on_batch=save_partial,
                )
            else:
                results = translator.translate_bulk(
                    payload, target_language,
                    chunk_lines=int(getattr(config, "translate_batch_size", 80)),
                    progress=prog,
                )
        except Exception as exc:  # noqa: BLE001
            raise ModuleError(f"Dịch thất bại: {exc}") from exc
        finally:
            for client in web_clients:
                client.close()

        by_line = {int(r.get("line", -1)): r for r in results}
        for seg in pending:
            r = by_line.get(seg.line)
            translation = str((r or {}).get("translation", "")).strip()
            seg.translation = translation or seg.text
            if not seg.speaker:
                seg.speaker = "Narrator"
            if tm and translation:
                tm.put(tm_key(seg.text), seg.translation, target_language)

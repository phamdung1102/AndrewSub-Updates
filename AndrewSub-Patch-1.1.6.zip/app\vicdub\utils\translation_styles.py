"""Các phong cách dịch phụ đề dùng chung cho Web và API."""

STYLES = {
    "conversational": (
        "Đối thoại tự nhiên",
        "Dịch như lời thoại đời thường: ngắn gọn, khẩu ngữ, dễ đọc thành tiếng; "
        "ưu tiên vừa thời lượng nhưng không làm mất ý chính.",
    ),
    "concise": (
        "Ngắn gọn để lồng tiếng",
        "Rút gọn mạnh câu chữ để đọc kịp thời lượng; bỏ từ đệm và cấu trúc rườm rà, "
        "giữ nguyên thông tin, cảm xúc và ý chính.",
    ),
    "cinematic": (
        "Điện ảnh",
        "Viết như thoại phim Việt tự nhiên, có nhịp điệu và cảm xúc; tránh văn dịch, "
        "vẫn phải vừa thời lượng của từng dòng.",
    ),
    "faithful": (
        "Sát nghĩa",
        "Ưu tiên sát nghĩa và đầy đủ nội dung; diễn đạt tự nhiên, chỉ rút gọn khi cần "
        "để không vượt quá thời lượng.",
    ),
    "custom": ("Tùy chỉnh", ""),
}


def style_instruction(style: str, custom: str = "") -> str:
    if style == "custom" and custom.strip():
        return custom.strip()
    return STYLES.get(style, STYLES["conversational"])[1]

﻿"""Cửa sổ chính - nav trên, vùng làm việc chính, status bar.

MainWindow là "composition root": tạo services (ProjectManager, ApiManager,
TranslationMemory, WorkflowEngine) và nối chúng với UI. Business logic nằm
trong module/engine, không nằm ở đây.
"""

from __future__ import annotations

import logging
import json
import os
import re
import threading
from pathlib import Path

from PyQt6.QtCore import QTimer, Qt, QUrl, pyqtSignal
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (
    QLabel, QListView, QListWidget, QMainWindow, QMessageBox, QProgressBar,
    QPushButton, QStackedWidget, QVBoxLayout, QWidget,
)

from vicdub import APP_NAME, __version__
from vicdub.api.api_manager import ApiManager
from vicdub.api.gemini_client import GeminiClient
from vicdub.config import APP_ROOT, AppConfig
from vicdub.core.project_manager import Project, ProjectManager
from vicdub.core.workflow_engine import PIPELINE_STEPS, WorkflowEngine
from vicdub.modules.character_module import CharacterModule
from vicdub.modules.import_module import ImportModule
from vicdub.modules.merge_module import MergeModule
from vicdub.modules.subtitle_module import SubtitleModule
from vicdub.modules.subtitle_style_module import SubtitleStyleModule
from vicdub.modules.translate_module import TranslateModule
from vicdub.modules.video_module import CutModule, VideoModule
from vicdub.modules.voice_module import VoiceModule
from vicdub.ui.pages import (
    ComponentsPage, ExportPage, ProjectPage, SeriesPage, SettingsPage, SubtitlePage,
)
from vicdub.ui.theme import DARK_QSS
from vicdub.utils.translation_memory import TranslationMemory

logger = logging.getLogger(__name__)

NAV_ITEMS = (
    "Dự án", "Phụ đề", "Ghép series",
    "Xuất video", "Cập nhật", "Cài đặt",
)


class MainWindow(QMainWindow):
    """Cửa sổ chính của AndrewSub."""

    #: Phát từ worker thread để phát audio trên GUI thread (thread-safe).
    audio_ready = pyqtSignal(str)

    def __init__(self, config: AppConfig) -> None:
        super().__init__()
        self.config = config
        self._sound = None  # giữ tham chiếu player đang phát
        self.audio_ready.connect(self._play_audio)

        # ---------- Services ----------
        self.projects = ProjectManager(config.projects_dir)
        self.tm = TranslationMemory(config.data_dir)
        self.api = ApiManager(config.api_keys, config.api_pool_strategy)
        self.engine = WorkflowEngine()
        self._register_modules()
        self._batch_queue: list[str] = []
        self._batch_results: list[tuple[str, bool, str]] = []
        self._batch_current = ""
        self._batch_total = 0
        self._batch_original_project = ""
        self._batch_last_error = ""
        self._batch_active = False
        self._batch_cancelled = False
        self._batch_steps: list[str] | str = "ALL"
        self._batch_action_label = "trọn quy trình"

        # ---------- Cửa sổ ----------
        self.setWindowTitle(f"{APP_NAME} v{__version__}")
        icon_path = APP_ROOT / "assets" / "icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.resize(1360, 800)
        self.setMinimumSize(1100, 700)
        self.setStyleSheet(DARK_QSS)
        self._build_ui()
        self._connect_engine()
        self.refresh_all()
        self.show_status("Sẵn sàng")
        if bool(getattr(self.config, "auto_check_updates", True)):
            QTimer.singleShot(2500, self._check_updates_on_startup)
        QTimer.singleShot(700, self._show_update_result)

    def _check_updates_on_startup(self) -> None:
        page = self.pages[4] if len(self.pages) > 4 else None
        checker = getattr(page, "check_app_update", None)
        if callable(checker):
            checker(True)

    def _show_update_result(self) -> None:
        status_path = APP_ROOT.parent / "update_status.json"
        if not status_path.is_file():
            return
        try:
            data = json.loads(status_path.read_text(encoding="utf-8"))
            status_path.unlink(missing_ok=True)
            message = str(data.get("message", "")).strip()
            version = str(data.get("version", "")).strip()
            if data.get("ok"):
                QMessageBox.information(
                    self, APP_NAME, f"Đã cập nhật thành công lên phiên bản {version}."
                )
            else:
                QMessageBox.warning(
                    self, APP_NAME, f"Cập nhật không thành công.\n\n{message}"
                )
        except Exception:  # noqa: BLE001
            logger.exception("Không đọc được kết quả cập nhật")

    # ================= Services =================

    def _register_modules(self) -> None:
        """Đăng ký 8 module vào engine - điểm duy nhất nối pipeline."""
        self.engine.register("import", ImportModule())
        self.engine.register("subtitle", SubtitleModule())
        self.engine.register("translate", TranslateModule())
        self.engine.register("character", CharacterModule())
        self.engine.register("voice", VoiceModule())
        self.engine.register("video", VideoModule())
        self.engine.register("cut", CutModule())
        self.engine.register("subtitle_style", SubtitleStyleModule())
        self.engine.register("merge", MergeModule())

    def reload_api_manager(self) -> None:
        """Gọi sau khi lưu cài đặt API."""
        self.api = ApiManager(self.config.api_keys, self.config.api_pool_strategy)

    # ================= UI =================

    def _build_ui(self) -> None:
        # ----- Nav trên: trả lại chiều ngang cho vùng làm việc -----
        self.nav = QListWidget()
        self.nav.setObjectName("topNav")
        self.nav.addItems(NAV_ITEMS)
        self.nav.setFlow(QListView.Flow.LeftToRight)
        self.nav.setWrapping(False)
        self.nav.setFixedHeight(48)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.nav.currentRowChanged.connect(self._on_nav_changed)

        # ----- Vùng làm việc chính -----
        self.stack = QStackedWidget()
        self.pages = [
            ProjectPage(self), SubtitlePage(self), SeriesPage(self),
            ExportPage(self), ComponentsPage(self), SettingsPage(self),
        ]
        for page in self.pages:
            self.stack.addWidget(page)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.nav)
        layout.addWidget(self.stack, 1)
        self.setCentralWidget(container)

        # ----- Status bar gọn: thông báo | thông tin project | tiến độ -----
        self.status_label = QLabel("")
        self.statusBar().addWidget(self.status_label, 1)
        self.info_compact = QLabel("")
        self.info_compact.setMaximumWidth(260)
        self.statusBar().addPermanentWidget(self.info_compact)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFixedWidth(180)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("0%")
        self.statusBar().addPermanentWidget(self.progress_bar)
        self._current_step_label = ""
        self.btn_pause = QPushButton("⏸  Tạm dừng")
        self.btn_resume = QPushButton("▶  Tiếp tục")
        self.btn_cancel = QPushButton("■  Hủy tác vụ")
        self.btn_pause.setObjectName("pipelinePause")
        self.btn_resume.setObjectName("pipelineResume")
        self.btn_cancel.setObjectName("pipelineCancel")
        for btn, width, tip in (
            (self.btn_pause, 112, "Tạm dừng pipeline"),
            (self.btn_resume, 106, "Tiếp tục"),
            (self.btn_cancel, 124, "Hủy pipeline"),
        ):
            btn.setFixedWidth(width)
            btn.setFixedHeight(30)
            btn.setToolTip(tip)
            btn.setEnabled(False)
            self.statusBar().addPermanentWidget(btn)
        self.btn_pause.clicked.connect(self._pause_clicked)
        self.btn_resume.clicked.connect(self._resume_clicked)
        self.btn_cancel.clicked.connect(self._cancel_clicked)

        self.nav.setCurrentRow(0)

    def _connect_engine(self) -> None:
        self.engine.step_started.connect(self._on_step_started)
        self.engine.step_progress.connect(self._on_step_progress)
        self.engine.step_failed.connect(self._on_step_failed)
        self.engine.pipeline_finished.connect(self._on_pipeline_finished)

    # ================= Điều phối pipeline =================

    def start_pipeline(self, steps: list[str] | str,
                       extra: dict | None = None) -> bool:
        """Chạy pipeline trên worker thread. steps="ALL" để chạy trọn bộ.

        extra: dữ liệu bổ sung (subtitle_path, translated_subtitle_path...).
        """
        project = self.projects.current
        if project is None:
            QMessageBox.warning(self, APP_NAME, "Vui lòng mở một dự án.")
            return False
        if self.engine.is_running():
            QMessageBox.warning(self, APP_NAME,
                                "Một tác vụ đang chạy. Vui lòng chờ hoặc hủy tác vụ.")
            return False

        context = {
            "project": project,
            "config": self.config,
            "tm": self.tm,
            "gemini": GeminiClient(self.api) if self.api.keys else None,
            "video_path": project.video_path,
        }
        # Giữ kết quả các bước trước (segments, voice_files, clip_files...).
        for key in ("segments", "voice_files", "clip_files",
                    "subtitle_mode", "subtitle_for_merge"):
            if key in self.engine.context:
                context[key] = self.engine.context[key]
        context.update(extra or {})

        # Các thao tác Studio có thể đã lưu sub/dịch trực tiếp xuống DB sau lần
        # pipeline trước. Khi chạy voice/translate/video, ưu tiên dữ liệu mới nhất
        # từ project để không dùng context cũ còn thiếu cột "Bản dịch".
        if not extra or "segments" not in extra:
            if any(step in (steps if steps != "ALL" else ["ALL"])
                   for step in ("translate", "voice", "video", "subtitle_style", "ALL")):
                context["segments"] = project.load_segments()

        # Studio có thể đã sinh voice/clip từng dòng ra ổ đĩa (khác phiên chạy)
        # - quét lại để pipeline dùng luôn, không bắt làm lại từ đầu.
        if "voice_files" not in context:
            found_voices = self._scan_numbered(
                Path(project.root) / "voices", ".wav"
            )
            if found_voices:
                context["voice_files"] = found_voices
        if "clip_files" not in context:
            found_clips = {
                line: path
                for line, path in self._scan_numbered(
                    Path(project.root) / "clips", ".mp4"
                ).items()
                if "_" not in Path(path).stem  # bỏ file tạm 001_raw.mp4
            }
            if found_clips:
                context["clip_files"] = found_clips

        if steps == "ALL":
            keys = ["import"] + [k for k, _ in PIPELINE_STEPS]
        else:
            keys = list(steps)
            # Các bước cần video đều phải qua import để kiểm tra file.
            if keys[0] in ("subtitle", "video") and not context.get("subtitle_path"):
                keys = ["import"] + keys

        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0%")
        self._set_pipeline_running(True)
        try:
            self.engine.run_steps(keys, context)
        except (RuntimeError, ValueError) as exc:
            self._set_pipeline_running(False)
            QMessageBox.warning(self, APP_NAME, str(exc))
            return False
        self.show_status("Đang xử lý...")
        return True

    # ================= Hàng đợi nhiều dự án =================

    def is_batch_running(self) -> bool:
        return self._batch_active

    def start_project_batch(self, names: list[str]) -> None:
        """Validate and run full pipelines sequentially for checked projects."""
        if self.engine.is_running() or self._batch_active:
            QMessageBox.warning(self, APP_NAME, "Một hàng đợi đang chạy.")
            return
        if not str(getattr(self.config, "target_language", "") or "").strip():
            QMessageBox.warning(
                self, APP_NAME,
                "Chưa chọn ngôn ngữ đích. Vào tab Phụ đề → Dịch tự động để chọn trước.",
            )
            return

        invalid_video: list[str] = []
        missing_region: list[str] = []
        valid: list[str] = []
        for name in names:
            root = self.projects.projects_dir / name
            try:
                project = Project(root)
            except Exception:  # noqa: BLE001
                invalid_video.append(name)
                continue
            try:
                if not project.video_path or not Path(project.video_path).exists():
                    invalid_video.append(name)
                elif not project.has_ocr_region:
                    missing_region.append(name)
                else:
                    valid.append(name)
            finally:
                project.close()
        if invalid_video or missing_region:
            lines = []
            if invalid_video:
                lines.append("Chưa có video hợp lệ: " + ", ".join(invalid_video))
            if missing_region:
                lines.append("Chưa khoanh vùng phụ đề: " + ", ".join(missing_region))
            QMessageBox.warning(
                self, APP_NAME,
                "Chưa thể chạy hàng loạt:\n\n" + "\n".join(lines)
                + "\n\nMở từng dự án và khoanh vùng trên preview trước.",
            )
            return
        if not valid:
            return

        self._batch_original_project = (
            self.projects.current.name if self.projects.current else ""
        )
        self._batch_queue = list(valid)
        self._batch_results = []
        self._batch_total = len(valid)
        self._batch_current = ""
        self._batch_last_error = ""
        self._batch_steps = "ALL"
        self._batch_action_label = "trọn quy trình"
        self._batch_active = True
        self._batch_cancelled = False
        self._set_project_batch_status(
            f"Đã xếp hàng {self._batch_total} dự án — đang chuẩn bị..."
        )
        self._run_next_batch_project()

    def start_export_batch(self, names: list[str]) -> None:
        """Render/export checked projects that already have video, subtitles and voices."""
        if self.engine.is_running() or self._batch_active:
            QMessageBox.warning(self, APP_NAME, "Một hàng đợi đang chạy.")
            return

        invalid: list[str] = []
        missing_sub: list[str] = []
        missing_voice: list[str] = []
        valid: list[str] = []
        for name in names:
            root = self.projects.projects_dir / name
            try:
                project = Project(root)
            except Exception:  # noqa: BLE001
                invalid.append(name)
                continue
            try:
                if not project.video_path or not Path(project.video_path).exists():
                    invalid.append(name)
                    continue
                segments = project.load_segments()
                if not segments:
                    missing_sub.append(name)
                    continue
                voices = self._scan_numbered(Path(project.root) / "voices", ".wav")
                absent = [seg.line for seg in segments if seg.line not in voices]
                if absent:
                    preview = ", ".join(map(str, absent[:8]))
                    suffix = "..." if len(absent) > 8 else ""
                    missing_voice.append(
                        f"{name} thiếu {len(absent)}/{len(segments)} voice "
                        f"(dòng {preview}{suffix})"
                    )
                    continue
                valid.append(name)
            finally:
                project.close()
        if invalid or missing_sub or missing_voice:
            lines = []
            if invalid:
                lines.append("Chưa có video hợp lệ: " + ", ".join(invalid))
            if missing_sub:
                lines.append("Chưa có phụ đề: " + ", ".join(missing_sub))
            if missing_voice:
                lines.append("Thiếu voice:\n" + "\n".join(missing_voice))
            QMessageBox.warning(
                self, APP_NAME,
                "Chưa thể xuất hàng loạt:\n\n" + "\n".join(lines),
            )
            return
        if not valid:
            return

        self._batch_original_project = (
            self.projects.current.name if self.projects.current else ""
        )
        self._batch_queue = list(valid)
        self._batch_results = []
        self._batch_total = len(valid)
        self._batch_current = ""
        self._batch_last_error = ""
        self._batch_steps = ["merge"]
        self._batch_action_label = "xuất video"
        self._batch_active = True
        self._batch_cancelled = False
        self._set_project_batch_status(
            f"Đã xếp hàng xuất video {self._batch_total} dự án — đang chuẩn bị..."
        )
        self._run_next_batch_project()

    def _run_next_batch_project(self) -> None:
        if not self._batch_active:
            return
        if self._batch_cancelled or not self._batch_queue:
            self._finish_project_batch()
            return
        name = self._batch_queue.pop(0)
        self._batch_current = name
        self._batch_last_error = ""
        index = len(self._batch_results) + 1
        try:
            self.projects.open(name)
        except ValueError as exc:
            self._batch_results.append((name, False, str(exc)))
            QTimer.singleShot(0, self._run_next_batch_project)
            return
        self.on_project_changed()
        self._set_project_batch_status(
            f"Dự án {index}/{self._batch_total}: {name} — bắt đầu {self._batch_action_label}..."
        )
        if not self.start_pipeline(self._batch_steps, {"batch_mode": True}):
            self._batch_results.append((name, False, "Không khởi động được pipeline"))
            QTimer.singleShot(0, self._run_next_batch_project)

    def _set_project_batch_status(self, message: str) -> None:
        page = self.pages[0] if getattr(self, "pages", None) else None
        if page and callable(getattr(page, "set_batch_status", None)):
            page.set_batch_status(message)
        self.show_status(message)

    def _finish_project_batch(self) -> None:
        cancelled = self._batch_cancelled
        results = list(self._batch_results)
        total = self._batch_total
        self._batch_active = False
        self._batch_queue = []
        self._batch_current = ""
        if self._batch_original_project:
            try:
                self.projects.open(self._batch_original_project)
                self.on_project_changed()
            except ValueError:
                pass
        ok_count = sum(success for _name, success, _detail in results)
        message = (
            f"Đã hủy hàng đợi — hoàn tất {len(results)}/{total} dự án."
            if cancelled else
            f"Hoàn tất hàng đợi: {ok_count}/{total} dự án thành công."
        )
        self._set_project_batch_status(message)
        failures = [f"• {name}: {detail}" for name, ok, detail in results if not ok]
        detail = message + (("\n\n" + "\n".join(failures)) if failures else "")
        if failures or cancelled:
            QMessageBox.warning(self, APP_NAME, detail)
        else:
            QMessageBox.information(self, APP_NAME, detail)

    @staticmethod
    def _scan_numbered(folder: Path, ext: str) -> dict[int, str]:
        """Quét file dạng số (0001.wav, 001.mp4) -> {line: đường dẫn}."""
        result: dict[int, str] = {}
        if folder.is_dir():
            for p in sorted(folder.glob(f"*{ext}")):
                try:
                    result[int(p.stem)] = str(p)
                except ValueError:
                    continue  # bỏ file không phải dạng số
        return result

    # ================= Slots =================

    def _on_nav_changed(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        if 0 <= index < len(self.pages):
            self.pages[index].refresh()

    def _pause_clicked(self) -> None:
        self.engine.pause()
        self.btn_pause.setEnabled(False)
        self.btn_resume.setEnabled(True)
        self.show_status("Đã yêu cầu tạm dừng - bấm 'Tiếp tục' để chạy tiếp.")

    def _resume_clicked(self) -> None:
        self.engine.resume()
        self.btn_pause.setEnabled(True)
        self.btn_resume.setEnabled(False)
        self.show_status("Đã tiếp tục tác vụ.")

    def _cancel_clicked(self) -> None:
        if self._batch_active:
            self._batch_cancelled = True
            self._batch_queue.clear()
            self._set_project_batch_status("Đang hủy toàn bộ hàng đợi dự án...")
        self.engine.cancel()

    def _set_pipeline_running(self, running: bool) -> None:
        self.btn_pause.setEnabled(running)
        self.btn_resume.setEnabled(False)
        self.btn_cancel.setEnabled(running)

    def _on_step_started(self, key: str) -> None:
        label = dict(PIPELINE_STEPS).get(key, key)
        self._current_step_label = label
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0%")
        self.show_status(f"Đang chạy: {label}...")

    def _on_step_progress(self, key: str, pct: int, msg: str) -> None:
        pct = max(0, min(100, int(pct)))
        label = self._current_step_label or dict(PIPELINE_STEPS).get(key, key)
        self.progress_bar.setValue(pct)
        self.progress_bar.setFormat(f"{pct}%")
        self.show_status(f"{label}: {pct}% - {msg}")
        if self._batch_active and self._batch_current:
            index = len(self._batch_results) + 1
            page = self.pages[0]
            if callable(getattr(page, "set_batch_status", None)):
                page.set_batch_status(
                    f"Dự án {index}/{self._batch_total}: {self._batch_current} — "
                    f"{label} {pct}%"
                )

    def _on_step_failed(self, key: str, error: str) -> None:
        # Không đổ traceback/command line trình duyệt dài hàng nghìn ký tự vào UI.
        public_error = str(error).split("Browser logs:", 1)[0].strip()
        public_error = re.sub(
            r"BrowserType\.launch_persistent_context:[^;\n]*",
            "Không thể khởi động phiên trình duyệt",
            public_error,
        )
        public_error = self._public_status(public_error)
        if self._batch_active:
            self._batch_last_error = public_error
            self._set_project_batch_status(
                f"Dự án {self._batch_current} lỗi ở {dict(PIPELINE_STEPS).get(key, key)}; "
                "sẽ chuyển dự án kế tiếp."
            )
            return
        QMessageBox.critical(
            self, APP_NAME, f"Không thể hoàn tất bước xử lý:\n\n{public_error}"
        )

    def _on_pipeline_finished(self, success: bool) -> None:
        self._set_pipeline_running(False)
        self.update_right_panel()
        current = self.stack.currentWidget()
        if hasattr(current, "refresh"):
            current.refresh()
        if self._batch_active:
            detail = self._batch_last_error or ("Hoàn tất" if success else "Đã dừng")
            self._batch_results.append((self._batch_current, success, detail))
            if self._batch_cancelled:
                self._finish_project_batch()
            else:
                QTimer.singleShot(200, self._run_next_batch_project)
            return
        if success:
            self.show_status("Hoàn tất")
            final = self.engine.context.get("final_video")
            if final:
                QMessageBox.information(
                    self, APP_NAME, f"Video hoàn chỉnh:\n{final}"
                )
        else:
            self.show_status("Tác vụ đã dừng")

    # ================= Cập nhật UI =================

    def on_project_changed(self) -> None:
        """Gọi sau khi tạo/mở project."""
        self.engine.context = {}
        self.refresh_all()
        project = self.projects.current
        if project:
            self.show_status(f"Dự án: {project.name}")

    def refresh_all(self) -> None:
        self.update_right_panel()
        current = self.stack.currentWidget()
        if hasattr(current, "refresh"):
            current.refresh()

    def update_right_panel(self) -> None:
        """Cập nhật dải thông tin gọn ở status bar (giữ tên cũ để tương thích)."""
        project = self.projects.current
        if project:
            video = (Path(project.video_path).name if project.video_path
                     else "chưa chọn video")
            self.info_compact.setText(
                f"{project.name} | {video} | "
                f"{len(project.load_segments())} phụ đề"
            )
        else:
            self.info_compact.setText("Chưa mở dự án")

    def show_status(self, message: str) -> None:
        self.status_label.setText(self._public_status(str(message)))

    @staticmethod
    def _public_status(message: str) -> str:
        """Ẩn tên nhà cung cấp/cơ chế khỏi status và popup lỗi."""
        text = str(message)
        replacements = (
            (r"Gemini(?:\s+Web)?|Google\s+Drive|Drive\s+OCR|Cloud\s+Vision|Vision\s+OCR|Vision\s+API|Vision|Google", "dịch vụ trực tuyến"),
            (r"VideoSubFinder|VSF|detector|state machine", "bộ nhận diện"),
            (r"credentials\.json|credential[s]?", "file kết nối"),
            (r"token\.json|token", "phiên đăng nhập"),
            (r"API\s*key|API", "khóa truy cập"),
            (r"montage|panel", "ảnh mẫu"),
            (r"Chrome|Playwright|browser|profile", "trình duyệt"),
            (r"FFmpeg|ffprobe", "thành phần xử lý video"),
        )
        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    # ================= Phát audio trong app =================

    def play_audio(self, path: str) -> None:
        """Gọi được từ mọi thread - phát wav ngay trong app."""
        self.audio_ready.emit(path)

    def _play_audio(self, path: str) -> None:
        try:
            from PyQt6.QtMultimedia import QSoundEffect  # noqa: PLC0415

            self._sound = QSoundEffect(self)
            self._sound.setSource(QUrl.fromLocalFile(path))
            self._sound.setVolume(1.0)
            self._sound.play()
        except Exception:  # noqa: BLE001 - thiếu QtMultimedia thì mở player ngoài
            logger.exception("Không phát được audio trong app")
            if os.name == "nt":
                os.startfile(path)  # noqa: S606

    # ================= Đóng app =================

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        engine_was_running = self.engine.is_running()
        background_pages = [
            page for page in self.pages
            if callable(getattr(page, "has_background_task", None))
            and page.has_background_task()
        ]
        if engine_was_running or background_pages:
            answer = QMessageBox.question(
                self, APP_NAME,
                "Một tác vụ đang chạy và sẽ bị hủy nếu thoát. Bạn có muốn tiếp tục?",
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.engine.cancel()
            for page in background_pages:
                page.cancel_background_tasks()
        self.config.save()
        if engine_was_running or background_pages:
            # requests/ThreadPoolExecutor có thể đang kẹt trong socket và Python
            # sẽ chờ các worker non-daemon ở lúc shutdown. Cho chúng 2 giây dọn
            # tài liệu tạm, sau đó kết thúc process để cửa sổ đóng thực sự.
            def force_exit_if_needed() -> None:
                import time  # noqa: PLC0415
                time.sleep(2.0)
                if (self.engine.is_running()
                        or any(page.has_background_task() for page in background_pages)):
                    os._exit(0)  # noqa: SLF001 - điểm thoát cuối khi worker mạng treo

            threading.Thread(
                target=force_exit_if_needed, daemon=True, name="vicdub-exit-watchdog"
            ).start()
        event.accept()

"""Tách phụ đề theo chuẩn phụ đề phim chuyên nghiệp.

Chuẩn công nghiệp (Netflix/BBC): một sub ~42 ký tự, 1-5 giây, mỗi sub là một
lượt thoại hoặc một ý trọn. Thuật toán 2 bước như phụ đề viên làm tay:

Bước 1 - Tách LƯỢT THOẠI: cắt tại dấu kết câu (. ! ? …) và tại khoảng lặng
         giữa hai từ (sóng voice ngừng = người nói đổi lượt).
Bước 2 - Lượt thoại dài quá chuẩn thì BỔ CÂN ĐỐI: chọn điểm cắt đẹp nhất
         (gần giữa, ưu tiên dấu phụ và chỗ có nhịp nghỉ nhỏ), đệ quy đến khi
         mọi sub đạt chuẩn. Không bao giờ cắt cứng giữa mệnh đề tạo đuôi mồ côi.

Fallback không có word timestamp: `split_text_segment()` tách theo câu và
chia thời gian tỷ lệ độ dài chữ.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from vicdub.utils.subtitles import Segment

#: Dấu kết thúc câu - hết lượt thoại.
SENTENCE_END = (".", "!", "?", "…", "。", "！", "？")
#: Dấu ngắt phụ - điểm cắt ưu tiên khi phải bổ câu dài.
SOFT_BREAK = (",", ";", ":", "、", "，")
#: Cho phép sub vượt chuẩn tối đa 10% trước khi bổ tiếp (tránh bổ vụn).
OVERFLOW_TOLERANCE = 1.1


@dataclass
class Word:
    """Một từ kèm timestamp từ nguồn nhận diện/align phụ đề."""

    text: str
    start: float
    end: float


def _ends_sentence(text: str) -> bool:
    return text.rstrip().endswith(SENTENCE_END)


def _ends_soft(text: str) -> bool:
    return text.rstrip().endswith(SOFT_BREAK)


def _chars_of(words: list[Word]) -> int:
    """Tổng ký tự của cụm từ (tính cả khoảng trắng nối)."""
    return sum(len(w.text.strip()) + 1 for w in words) - 1 if words else 0


# ====================================================================
# Bước 1: tách lượt thoại
# ====================================================================

def _split_utterances(words: list[Word], gap_threshold: float) -> list[list[Word]]:
    """Cắt chuỗi từ thành các lượt thoại tại dấu kết câu và khoảng lặng."""
    utterances: list[list[Word]] = []
    current: list[Word] = []
    for i, word in enumerate(words):
        current.append(word)
        next_gap = words[i + 1].start - word.end if i + 1 < len(words) else 0.0
        if _ends_sentence(word.text) or next_gap >= gap_threshold:
            utterances.append(current)
            current = []
    if current:
        utterances.append(current)
    return utterances


# ====================================================================
# Bước 2: bổ cân đối lượt thoại dài
# ====================================================================

def _best_cut(words: list[Word]) -> int:
    """Chọn chỉ số từ để cắt SAU nó - điểm cắt đẹp nhất.

    Điểm càng thấp càng đẹp: cân bằng độ dài hai nửa, thưởng lớn cho
    dấu phụ (, ; :) và cho chỗ có nhịp nghỉ nhỏ giữa hai từ.
    """
    total = _chars_of(words)
    best_index = len(words) // 2 - 1
    best_score: float | None = None
    accumulated = 0
    for i in range(len(words) - 1):
        accumulated += len(words[i].text.strip()) + 1
        balance = abs(total / 2 - accumulated)
        soft_bonus = 8.0 if _ends_soft(words[i].text) else 0.0
        gap = max(0.0, words[i + 1].start - words[i].end)
        score = balance - soft_bonus - gap * 20.0
        if best_score is None or score < best_score:
            best_index, best_score = i, score
    return best_index


def _split_balanced(
    words: list[Word], max_chars: int, max_duration: float
) -> list[list[Word]]:
    """Đệ quy bổ đôi cụm từ cho đến khi đạt chuẩn độ dài/thời lượng."""
    chars = _chars_of(words)
    duration = words[-1].end - words[0].start if words else 0.0
    if len(words) < 2 or (
        chars <= max_chars * OVERFLOW_TOLERANCE and duration <= max_duration
    ):
        return [words]
    cut = _best_cut(words)
    left, right = words[:cut + 1], words[cut + 1:]
    return (_split_balanced(left, max_chars, max_duration)
            + _split_balanced(right, max_chars, max_duration))


# ====================================================================
# API chính
# ====================================================================

def split_words(
    words: list[Word],
    max_chars: int = 42,
    max_duration: float = 5.0,
    gap_threshold: float = 0.4,
) -> list[Segment]:
    """Ghép từ thành sub chuẩn phim từ word-level timestamp.

    Xem docstring module cho mô tả thuật toán 2 bước.
    """
    segments: list[Segment] = []
    for utterance in _split_utterances(words, gap_threshold):
        for part in _split_balanced(utterance, max_chars, max_duration):
            text = " ".join(w.text.strip() for w in part if w.text.strip())
            if text:
                segments.append(Segment(
                    line=len(segments) + 1,
                    start=part[0].start,
                    end=part[-1].end,
                    text=text,
                ))
    return segments


_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?…。！？])\s+")


def split_text_segment(
    start: float,
    end: float,
    text: str,
    max_chars: int = 42,
) -> list[Segment]:
    """Fallback: tách một đoạn text dài thành câu, chia thời gian tỷ lệ.

    Dùng khi không có word timestamp chi tiết.
    """
    text = " ".join(text.split())
    if not text:
        return []
    sentences = [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]

    # Gộp câu ngắn liền nhau miễn không vượt max_chars.
    chunks: list[str] = []
    for sentence in sentences:
        if chunks and len(chunks[-1]) + len(sentence) + 1 <= max_chars:
            chunks[-1] = f"{chunks[-1]} {sentence}"
        else:
            if len(sentence) > max_chars * OVERFLOW_TOLERANCE:
                chunks.extend(_split_long_sentence(sentence, max_chars))
            else:
                chunks.append(sentence)

    total_chars = sum(len(c) for c in chunks) or 1
    duration = max(0.0, end - start)
    segments: list[Segment] = []
    cursor = start
    for i, chunk in enumerate(chunks):
        share = duration * len(chunk) / total_chars
        seg_end = end if i == len(chunks) - 1 else cursor + share
        segments.append(Segment(
            line=i + 1, start=round(cursor, 3), end=round(seg_end, 3), text=chunk,
        ))
        cursor = seg_end
    return segments


def _split_long_sentence(sentence: str, max_chars: int) -> list[str]:
    """Bổ câu quá dài tại dấu phụ hoặc khoảng trắng gần giới hạn nhất."""
    parts: list[str] = []
    rest = sentence
    while len(rest) > max_chars:
        window = rest[:max_chars]
        cut = max((window.rfind(p) for p in SOFT_BREAK), default=-1)
        if cut < max_chars // 3:  # dấu phụ quá gần đầu thì cắt tại khoảng trắng
            cut = window.rfind(" ")
        if cut <= 0:
            cut = max_chars
        parts.append(rest[:cut + 1].strip())
        rest = rest[cut + 1:].strip()
    if rest:
        parts.append(rest)
    return parts


# ====================================================================
# Hậu xử lý
# ====================================================================

def merge_short_segments(
    segments: list[Segment],
    min_chars: int = 10,
    min_duration: float = 0.8,
    max_chars: int = 42,
    max_duration: float = 5.0,
    max_join_gap: float = 0.3,
) -> list[Segment]:
    """Gộp sub quá ngắn/vụn vào sub bên cạnh.

    Lượt 1: gộp sub ngắn vào sub TRƯỚC nếu sát giờ và không vượt chuẩn.
    Lượt 2: mảnh siêu ngắn (<= 4 ký tự, ví dụ dấu câu lẻ) còn sót thì dính
            vào sub SAU bất kể giới hạn ký tự - dấu phẩy không được đứng riêng.
    """
    if not segments:
        return []

    # Lượt 1: gộp về trước.
    merged: list[Segment] = [segments[0]]
    for seg in segments[1:]:
        prev = merged[-1]
        gap = seg.start - prev.end
        prev_short = len(prev.text) < min_chars or prev.duration < min_duration
        cur_short = len(seg.text) < min_chars or seg.duration < min_duration
        tiny = len(seg.text) <= 4 or len(prev.text) <= 4
        limit = max_chars * (1.25 if tiny else 1.0)
        combined_chars = len(prev.text) + len(seg.text) + 1
        combined_duration = seg.end - prev.start
        if ((prev_short or cur_short)
                and 0 <= gap <= max_join_gap
                and combined_chars <= limit
                and combined_duration <= max_duration):
            prev.text = f"{prev.text} {seg.text}"
            prev.end = seg.end
        else:
            merged.append(seg)

    # Lượt 2: mảnh siêu ngắn còn sót dính vào sub sau.
    result: list[Segment] = []
    for seg in reversed(merged):
        if (result
                and len(seg.text) <= 4
                and 0 <= result[-1].start - seg.end <= max_join_gap):
            nxt = result[-1]
            nxt.text = f"{seg.text} {nxt.text}"
            nxt.start = seg.start
        else:
            result.append(seg)
    result.reverse()
    return renumber(result)


def pad_boundaries(segments: list[Segment], pad: float = 0.15) -> list[Segment]:
    """Nới nhẹ điểm kết thúc mỗi sub vào khoảng lặng phía sau.

    Word timestamp cắt sát âm cuối; đệm tối đa `pad` giây (không quá nửa
    khoảng lặng) để clip không chém đuôi âm.
    """
    for i, seg in enumerate(segments):
        if i + 1 < len(segments):
            gap = segments[i + 1].start - seg.end
            if gap > 0:
                seg.end += min(pad, gap / 2)
        else:
            seg.end += pad  # sub cuối: FFmpeg tự kẹp về cuối video
    return segments


def estimate_speech_seconds(text: str, chars_per_second: float = 15.0) -> float:
    """Ước tính thời gian TTS đọc đoạn text (tiếng Việt ~15 ký tự/giây)."""
    return len(" ".join(text.split())) / max(1.0, chars_per_second)


def renumber(segments: list[Segment]) -> list[Segment]:
    """Đánh lại số thứ tự sau khi tách/gộp."""
    for i, seg in enumerate(segments, start=1):
        seg.line = i
    return segments

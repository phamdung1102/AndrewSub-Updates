"""Client Gemini REST - dịch + phân vai nhân vật.

Dùng ApiManager để chọn key; tự đổi key khi 429, retry khi 5xx, tắt key khi 401.
"""

from __future__ import annotations

import json
import logging
import re
import time

import requests

from vicdub.api.api_manager import ApiKey, ApiManager, NoApiKeyError

logger = logging.getLogger(__name__)

GEMINI_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "{model}:generateContent?key={key}"
)


class GeminiError(Exception):
    """Lỗi gọi Gemini có thông điệp hiển thị được."""


class GeminiClient:
    """Gọi Gemini generateContent qua pool key."""

    def __init__(self, api_manager: ApiManager) -> None:
        self.pool = api_manager

    # ---------- Lõi ----------

    def generate(self, prompt: str, generation_config: dict | None = None) -> str:
        """Gửi prompt chữ, trả text. Tự xoay key/retry theo chính sách pool."""
        return self._generate_parts([{"text": prompt}], generation_config)

    def _generate_parts(
        self, parts: list[dict], generation_config: dict | None = None
    ) -> str:
        """Lõi gọi generateContent với danh sách parts bất kỳ (chữ và/hoặc ảnh).

        Tự xoay key khi 429, retry khi 5xx, tắt key khi 401 - dùng chung cho cả
        prompt chữ lẫn prompt kèm ảnh.
        """
        last_error = "Không rõ"
        # Thử tối đa số key x retry để không lặp vô hạn.
        max_attempts = max(1, len(self.pool.keys)) * 3
        for _ in range(max_attempts):
            try:
                key = self.pool.pick()
            except NoApiKeyError as exc:
                raise GeminiError(str(exc)) from exc

            url = GEMINI_URL.format(model=key.model, key=key.key)
            body = {"contents": [{"parts": parts}]}
            if generation_config:
                body["generationConfig"] = generation_config
            started = time.time()
            try:
                resp = requests.post(url, json=body, timeout=key.timeout)
            except requests.RequestException as exc:
                last_error = f"Lỗi mạng: {exc}"
                logger.warning("API '%s': %s", key.name, last_error)
                continue

            latency = time.time() - started
            self.pool.report_result(key, resp.status_code, latency)

            if resp.status_code == 200:
                return self._extract_text(resp.json())
            if resp.status_code == 429:
                last_error = f"'{key.name}' hết quota (429), đổi key..."
                continue
            if resp.status_code == 401:
                last_error = f"'{key.name}' key sai (401), đã tắt."
                continue
            if 500 <= resp.status_code < 600:
                last_error = f"Gemini lỗi máy chủ ({resp.status_code}), thử lại..."
                time.sleep(2)
                continue
            # Lỗi khác (400...) - không retry được.
            raise GeminiError(
                f"Gemini trả lỗi {resp.status_code}: {resp.text[:300]}"
            )
        raise GeminiError(f"Gọi Gemini thất bại sau nhiều lần thử. {last_error}")

    @staticmethod
    def _extract_text(payload: dict) -> str:
        try:
            return payload["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError) as exc:
            raise GeminiError(f"Gemini trả cấu trúc lạ: {json.dumps(payload)[:300]}") from exc

    # ---------- Nghiệp vụ: dịch phụ đề ----------

    def translate_and_detect(self, lines: list[dict], target_language: str) -> list[dict]:
        """Dịch một lô dòng phụ đề theo chuẩn lồng tiếng.

        Args:
            lines: [{"line": 1, "text": "...", "seconds": 2.3}]
                   "seconds" (tùy chọn) = thời lượng câu trên video.
            target_language: ví dụ "Tiếng Việt".

        Returns:
            [{"line": 1, "translation": "..."}]
        """
        def fmt(l: dict) -> str:
            seconds = l.get("seconds")
            tag = f" [{seconds:.1f}s]" if seconds else ""
            return f'{l["line"]}.{tag} {l["text"]}'

        numbered = "\n".join(fmt(l) for l in lines)
        style = str(lines[0].get("_style_instruction", "")).strip() if lines else ""
        prompt = (
            "Bạn là chuyên gia dịch thuật LỒNG TIẾNG phim.\n"
            f"Dịch các dòng phụ đề sau sang {target_language} để đọc lồng tiếng, "
            "giữ đúng sắc thái hội thoại và nhịp đọc tự nhiên.\n\n"
            + (f"PHONG CÁCH BẮT BUỘC: {style}\n\n" if style else "") +
            "QUY TẮC DỊCH LỒNG TIẾNG (quan trọng):\n"
            "- Số giây trong [ngoặc] là thời lượng câu trên video. Bản dịch khi "
            "đọc to với tốc độ tự nhiên (~4 âm tiết/giây) phải vừa khớp thời "
            "lượng đó, chênh tối đa 10%.\n"
            "- Ưu tiên ngắn gọn, khẩu ngữ tự nhiên như thoại phim; lược bỏ từ "
            "thừa nhưng giữ trọn ý.\n"
            "- Câu quá ngắn so với thời lượng thì diễn đạt đầy đủ hơn một chút "
            "cho khớp.\n\n"
            "CHỈ trả về JSON array, không giải thích, theo đúng mẫu:\n"
            '[{"line":1,"translation":"..."}]\n\n'
            f"Phụ đề:\n{numbered}"
        )
        text = self.generate(prompt)
        return self._parse_json_array(text, expected=len(lines))

    def translate_bulk(
        self,
        lines: list[dict],
        target_language: str,
        chunk_lines: int = 120,
        progress=None,
    ) -> list[dict]:
        """Dịch CẢ FILE: đẩy trọn nội dung lên, dịch, trả về theo dòng.

        Khác ``translate_and_detect`` (30 dòng/lô rời rạc): gửi từng khối LỚN để
        model thấy toàn bộ ngữ cảnh -> tên riêng, xưng hô nhất quán cả tập. Khối
        lớn nên đặt maxOutputTokens cao và tự vá dòng thiếu nếu output bị cắt.

        Args:
            lines: [{"line":1,"text":"...","seconds":2.3}]
            chunk_lines: số dòng tối đa mỗi lượt (an toàn giới hạn output).
            progress: callback(done, total) để báo tiến độ (tùy chọn).

        Returns:
            [{"line":1,"translation":"..."}] đủ mọi dòng đầu vào.
        """
        out: list[dict] = []
        total = len(lines)
        for i in range(0, total, chunk_lines):
            chunk = lines[i:i + chunk_lines]
            out.extend(self._translate_chunk(chunk, target_language))
            if progress:
                progress(min(i + chunk_lines, total), total)
        return out

    def _translate_chunk(
        self, chunk: list[dict], target_language: str, _depth: int = 0
    ) -> list[dict]:
        """Dịch một khối lớn; tự chia đôi & thử lại các dòng model bỏ sót."""
        def fmt(l: dict) -> str:
            seconds = l.get("seconds")
            tag = f" [{seconds:.1f}s]" if seconds else ""
            return f'{l["line"]}.{tag} {l["text"]}'

        numbered = "\n".join(fmt(l) for l in chunk)
        style = str(chunk[0].get("_style_instruction", "")).strip() if chunk else ""
        prompt = (
            "Bạn là chuyên gia dịch thuật LỒNG TIẾNG phim.\n"
            f"Dưới đây là TOÀN BỘ phụ đề một đoạn phim. Dịch sang {target_language} "
            "để đọc lồng tiếng, giữ đúng sắc thái hội thoại và nhịp đọc tự nhiên.\n\n"
            + (f"PHONG CÁCH BẮT BUỘC: {style}\n\n" if style else "") +
            "QUY TẮC (quan trọng):\n"
            "- Dịch TẤT CẢ các dòng, giữ nguyên số thứ tự dòng.\n"
            "- NHẤT QUÁN toàn đoạn: tên riêng, cách xưng hô (anh/em/ta/ngươi...), "
            "biệt danh phải giống nhau ở mọi dòng.\n"
            "- Số giây trong [ngoặc] là thời lượng câu; bản dịch đọc ~4 âm tiết/giây "
            "phải vừa khớp, chênh tối đa 10%. Ưu tiên khẩu ngữ tự nhiên, ngắn gọn.\n\n"
            "CHỈ trả về JSON array, không giải thích, đúng mẫu:\n"
            '[{"line":1,"translation":"..."}]\n\n'
            f"Phụ đề:\n{numbered}"
        )
        # Nới trần output (mặc định ~8k đủ cho ~120 dòng; mọi model Gemini đều
        # nhận giá trị này). Nếu vẫn bị cắt -> logic vá dòng thiếu bên dưới lo.
        text = self.generate(
            prompt, generation_config={"maxOutputTokens": 8192, "temperature": 0.3}
        )
        data = self._parse_json_objects(text)
        by_line = {int(d["line"]): d for d in data if str(d.get("line", "")).strip().lstrip("-").isdigit()}

        missing = [l for l in chunk if l["line"] not in by_line]
        # Output bị cắt/bỏ sót -> chia đôi phần thiếu và thử lại (tối đa vài tầng).
        if missing and _depth < 4 and len(missing) < len(chunk):
            mid = max(1, len(missing) // 2)
            for part in (missing[:mid], missing[mid:]):
                if part:
                    for d in self._translate_chunk(part, target_language, _depth + 1):
                        by_line[int(d["line"])] = d
        elif missing and _depth < 4 and len(missing) == len(chunk) and len(chunk) > 1:
            mid = len(chunk) // 2
            by_line = {}
            for part in (chunk[:mid], chunk[mid:]):
                for d in self._translate_chunk(part, target_language, _depth + 1):
                    by_line[int(d["line"])] = d

        # Dòng vẫn thiếu sau khi thử lại -> giữ nguyên gốc để không gãy pipeline.
        result = []
        for l in chunk:
            d = by_line.get(l["line"])
            result.append(d if d else {"line": l["line"], "translation": l["text"]})
        return result

    @staticmethod
    def _parse_json_objects(text: str) -> list[dict]:
        """Bóc các object {...} từ trả lời, CHỊU ĐƯỢC khi JSON bị cắt giữa chừng."""
        cleaned = re.sub(r"```(?:json)?", "", text or "").strip().strip("`")
        # Ưu tiên parse cả mảng nếu còn nguyên vẹn.
        match = re.search(r"\[.*\]", cleaned, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                if isinstance(data, list):
                    return data
            except json.JSONDecodeError:
                pass
        # Dự phòng: nhặt từng object hợp lệ (khi mảng bị cắt cụt do hết token).
        objs: list[dict] = []
        for om in re.finditer(r"\{[^{}]*\}", cleaned):
            try:
                obj = json.loads(om.group(0))
                if isinstance(obj, dict):
                    objs.append(obj)
            except json.JSONDecodeError:
                continue
        return objs

    @staticmethod
    def _parse_json_array(text: str, expected: int) -> list[dict]:
        """Bóc JSON array từ trả lời của model (kể cả khi bọc ```json)."""
        cleaned = re.sub(r"```(?:json)?", "", text).strip().strip("`")
        match = re.search(r"\[.*\]", cleaned, re.DOTALL)
        if not match:
            raise GeminiError(f"Không tìm thấy JSON trong trả lời: {text[:200]}")
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise GeminiError(f"JSON không hợp lệ từ Gemini: {exc}") from exc
        if not isinstance(data, list):
            raise GeminiError("Gemini không trả về JSON array")
        if len(data) != expected:
            logger.warning("Gemini trả %d dòng, kỳ vọng %d", len(data), expected)
        return data

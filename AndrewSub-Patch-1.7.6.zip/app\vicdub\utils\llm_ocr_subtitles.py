"""Tách phụ đề GẮN CỨNG bằng Gemini vision (LLM-OCR).

Cách này gửi ẢNH dải phụ đề cho Gemini đọc chữ - hợp khi font/kiểu chữ khó
hoặc muốn tránh cài model OCR local nặng.

Luồng xử lý (giống kỹ thuật montage của các tool lồng tiếng phổ biến):
  1. Lấy mẫu khung theo `fps`, crop vùng phụ đề, GỘP các khung liên tiếp gần y
     hệt thành "keyframe" (mỗi câu phụ đề đứng yên chỉ còn một ảnh đại diện +
     mốc bắt đầu/kết thúc). Nhờ đó số ảnh gửi đi giảm mạnh.
  2. Ghép nhiều keyframe thành một ảnh MONTAGE dọc, mỗi dải đánh số 1, 2, 3...
  3. Gửi montage cho Gemini vision, nhận lại chữ theo từng số panel.
  4. Dựng Segment từ (mốc thời gian keyframe + chữ đọc được), gộp câu trùng
     liền kề và bỏ câu quá ngắn.

Các hàm thuần Python (`plan_batches`, `events_to_segments`) tách riêng để test
được mà không cần xử lý video hay gọi mạng.
"""

from __future__ import annotations

import io
import hashlib
import json
import os
import shutil
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Callable

from vicdub.utils.video_frames import DEFAULT_REGION, region_to_crop
from vicdub.utils.segmenter import pad_boundaries, renumber
from vicdub.utils.subtitles import Segment

# Bề rộng mỗi dải trong ảnh montage (px) và bề rộng cột số ở mép trái.
MONTAGE_WIDTH = 720
LABEL_WIDTH = 70
# Chặn an toàn nền động: dedup thất bại nghĩa là gần như MỖI khung có chữ thành
# một keyframe riêng (tỷ lệ keyframe/khung-có-chữ ~1). Video dài hợp lệ có
# NHIỀU keyframe nhưng tỷ lệ vẫn thấp (mỗi câu đứng yên nhiều khung) - vì vậy
# xét TỶ LỆ sau khi đã quét đủ mẫu, không đếm tuyệt đối kẻo chặn nhầm video dài.
DEDUP_FAIL_RATIO = 0.75      # keyframe / khung có chữ vượt mức này = nền động
DEDUP_MIN_SAMPLE = 400       # chỉ kết luận sau khi đã thấy đủ khung có chữ
def effective_scan_fps(duration: float, requested_fps: float) -> float:
    """Luôn giữ đúng FPS người dùng chọn, không tự giảm với video dài."""
    del duration  # thời lượng không còn tác động tới mật độ quét
    return max(0.5, float(requested_fps))

ProgressFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]


@dataclass
class Keyframe:
    """Một câu phụ đề ứng viên: mốc thời gian + ảnh dải đại diện."""

    start: float
    end: float
    image: object = None  # np.ndarray (BGR) crop; None khi test logic thuần


# ---------- Logic thuần Python ----------

def plan_batches(count: int, batch: int) -> list[tuple[int, int]]:
    """Chia `count` keyframe thành các lô [start, end) mỗi lô tối đa `batch`.

    Trả danh sách (i0, i1) theo chỉ số 0-based để cắt danh sách keyframe.
    """
    batch = max(1, int(batch))
    return [(i, min(i + batch, count)) for i in range(0, max(0, count), batch)]


def _similar(a: str, b: str, threshold: float) -> bool:
    """Hai chữ đọc được có phải cùng một câu phụ đề không?"""
    na = "".join(a.split()).lower()
    nb = "".join(b.split()).lower()
    if not na or not nb:
        return False
    if na == nb:
        return True
    return SequenceMatcher(None, na, nb).ratio() >= threshold


def merge_adjacent_duplicate_segments(
    segments: list[Segment], max_gap: float = 0.4
) -> list[Segment]:
    """Gộp Segment LIỀN KỀ trùng chữ y hệt chỉ khi cách nhau RẤT NHỎ (<= max_gap).

    Áp dụng SAU events_to_segments cho riêng pipeline OCR. Chỉ dính lại phần
    nhấp nháy vài frame (detection rớt 1-3 khung liên tiếp) để KHÔNG phình timing;
    nếu hai bản trùng cách nhau xa (sub thật biến mất rồi hiện lại) thì GIỮ 2 dòng
    riêng với mốc chính xác - ưu tiên timing đúng hơn là gộp. Tách khỏi
    events_to_segments để không đổi hành vi hội thoại-nhanh của hàm chung.
    """
    if not segments:
        return segments

    def norm(s: str) -> str:
        return "".join((s or "").split()).lower()

    out: list[Segment] = [segments[0]]
    for seg in segments[1:]:
        prev = out[-1]
        if norm(seg.text) and norm(seg.text) == norm(prev.text) \
                and seg.start - prev.end <= max_gap:
            prev.end = seg.end  # nối dài câu trước, bỏ bản trùng
            if len(seg.text) > len(prev.text):
                prev.text = seg.text
        else:
            out.append(seg)
    return renumber(out)


def events_to_segments(
    events: list[tuple[float, float, str]],
    sim_threshold: float = 0.7,
    min_duration: float = 0.3,
    max_merge_gap: float = 0.35,
) -> list[Segment]:
    """Dựng phụ đề từ danh sách (start, end, text) đã đọc được.

    - Gộp các event liền kề có chữ giống nhau (câu hiển thị liên tục nhưng bị
      cắt thành nhiều keyframe do nền đổi).
    - Bỏ event rỗng (panel không có chữ) và câu ngắn hơn `min_duration`.
    """
    merged: list[list] = []  # [start, end, text]
    for start, end, text in events:
        text = (text or "").strip()
        if not text:
            continue
        gap = start - float(merged[-1][1]) if merged else 0.0
        if merged and gap <= max_merge_gap and _similar(merged[-1][2], text, sim_threshold):
            merged[-1][1] = end  # nối dài câu cũ
            if len(text) > len(merged[-1][2]):
                merged[-1][2] = text  # giữ bản đọc dài hơn
        else:
            merged.append([start, end, text])

    segments: list[Segment] = []
    for start, end, text in merged:
        if end - start >= min_duration:
            segments.append(Segment(
                line=len(segments) + 1,
                start=round(start, 3),
                end=round(end, 3),
                text=text,
            ))
    return renumber(segments)


# ---------- Dò chữ theo mặt nạ cạnh (mô phỏng VideoSubFinder, numpy thuần) ----------
#
# Ý tưởng như AIO/VideoSubFinder: quyết định "khung có phụ đề không" và "có phải
# câu mới không" dựa trên NÉT CHỮ (cạnh), không phải sai khác pixel của cả dải.
# Nền động tạo cạnh lộn xộn, mật độ thấp/không trải ngang nên không bị nhận nhầm
# là chữ; sub đứng yên trên nền động vẫn cho cùng một mặt nạ -> gộp làm một câu.

def _to_gray(img):
    """Ảnh BGR/gray -> mảng xám float 0..1."""
    import numpy as np  # noqa: PLC0415
    a = np.asarray(img, dtype="float32")
    if a.ndim == 3:
        a = a[..., :3].mean(axis=2)
    if a.size and a.max() > 1.5:
        a = a / 255.0
    return a


def _edge_binary(gray, k: float = 1.2):
    """Nhị phân hoá cạnh: điểm có gradient mạnh (nét chữ) = True.

    Ngưỡng tự thích nghi (mean + k*std) để chịu được độ sáng nền khác nhau.
    """
    import numpy as np  # noqa: PLC0415
    if gray.size == 0 or gray.shape[0] < 2 or gray.shape[1] < 2:
        return np.zeros_like(gray, dtype=bool)
    gy = np.abs(np.diff(gray, axis=0))
    gx = np.abs(np.diff(gray, axis=1))
    gy = np.pad(gy, ((0, 1), (0, 0)))
    gx = np.pad(gx, ((0, 0), (0, 1)))
    mag = gy + gx
    # Ảnh phẳng/gần phẳng (nền trơn) gần như không có cạnh -> trả về rỗng thay vì
    # để ngưỡng thích nghi bắt nhầm nhiễu nền thành "cạnh".
    if float(mag.max()) < 0.04:
        return np.zeros_like(mag, dtype=bool)
    thr = max(0.04, float(mag.mean() + k * mag.std()))
    return mag >= thr


def _pool(arr, gh: int, gw: int):
    """Gộp trung bình về lưới gh x gw."""
    import numpy as np  # noqa: PLC0415
    arr = np.asarray(arr, dtype="float32")
    if arr.ndim != 2 or arr.size == 0:
        return np.zeros((gh, gw), dtype="float32")
    rows = np.array_split(arr, min(gh, arr.shape[0]), axis=0)
    out = []
    for r in rows:
        cols = np.array_split(r, min(gw, r.shape[1]), axis=1)
        out.append([float(c.mean()) if c.size else 0.0 for c in cols])
    return np.asarray(out, dtype="float32")


def text_mask_signature(img, grid: tuple[int, int] = (10, 40)):
    """Chữ ký mật độ cạnh (0..1) trên lưới cố định — dùng cho cả has_text lẫn dedup.

    Bất biến với kích thước crop; làm nổi cấu trúc nét chữ, mờ nhiễu nền.
    """
    edges = _edge_binary(_to_gray(img)).astype("float32")
    return _pool(edges, grid[0], grid[1])


def mask_has_text(
    sig, min_density: float = 0.012, max_density: float = 0.72,
    min_col_cov: float = 0.08,
) -> bool:
    """Chữ ký này có giống một dòng CHỮ không?

    - density: mật độ cạnh trung bình; quá thấp = nền trơn (không chữ), quá cao
      = nhiễu đầy khung (không phải chữ).
    - col_cov: tỷ lệ cột có nét — chữ trải ngang nên nhiều cột có nét; một vật
      nền chuyển động chỉ chiếm ít cột.
    """
    import numpy as np  # noqa: PLC0415
    if sig is None or getattr(sig, "size", 0) == 0:
        return False
    density = float(sig.mean())
    if density < min_density or density > max_density:
        return False
    col_profile = sig.mean(axis=0)
    peak = float(col_profile.max())
    if peak <= 0:
        return False
    col_cov = float((col_profile > 0.3 * peak).mean())
    return col_cov >= min_col_cov


def mask_same(a, b, threshold: float = 0.05) -> bool:
    """Hai chữ ký cạnh có phải cùng một câu phụ đề (nét bố trí gần y hệt)?"""
    import numpy as np  # noqa: PLC0415
    if a is None or b is None or a.shape != b.shape:
        return False
    return float(np.mean(np.abs(a - b))) <= threshold


# ---------- Trích keyframe: FFmpeg đọc video, Pillow xử lý ảnh ----------

def extract_keyframes(
    video_path: str,
    ffmpeg,
    crop: tuple[int, int, int, int],
    duration: float,
    fps: float,
    dedup_threshold: float,
    report: ProgressFn,
    is_cancelled: CancelFn,
    mask_threshold: float = 0.05,
    min_text_density: float = 0.012,
) -> list[Keyframe]:
    """Quét video, dò dòng chữ và gộp các khung cùng một câu thành keyframe.

    Khác cách cũ (so sai khác pixel cả dải, dễ nổ keyframe khi nền động), hàm
    này quyết định theo MẶT NẠ NÉT CHỮ như VideoSubFinder:
    - Khung không có chữ (nền trơn/động, `mask_has_text` = False) bị bỏ và đóng
      câu đang mở - không tính là câu mới.
    - Hai khung có cùng bố cục nét chữ (`mask_same`) = cùng một câu -> gộp.

    `dedup_threshold` giữ lại cho tương thích chữ ký; dedup thực tế dùng
    `mask_threshold` trên mặt nạ cạnh (phân biệt tốt hơn hẳn).
    """
    from PIL import Image, ImageChops, ImageStat  # noqa: PLC0415

    with tempfile.TemporaryDirectory(prefix="vicdub_frames_") as temp_dir:
        ffmpeg.extract_frames_cropped(video_path, temp_dir, fps=fps, crop=crop)
        paths = sorted(__import__("pathlib").Path(temp_dir).glob("*.jpg"))
        times = [i / fps for i in range(len(paths))]
        frame_dur = 1.0 / fps if fps > 0 else 0.0
        keyframes: list[Keyframe] = []
        ref_sig = None
        ref_thumb = None
        cur: Keyframe | None = None
        text_frames = 0                       # số khung CÓ chữ đã quét
        panel_w = MONTAGE_WIDTH - LABEL_WIDTH

        def push(kf: Keyframe) -> None:
            keyframes.append(kf)
            # Nền động: dedup thất bại -> tỷ lệ keyframe/khung-có-chữ gần 1.
            # Video dài hợp lệ tỷ lệ vẫn thấp nên không bị chặn nhầm.
            if (text_frames >= DEDUP_MIN_SAMPLE
                    and len(keyframes) > DEDUP_FAIL_RATIO * text_frames):
                raise RuntimeError(
                    "Vùng phụ đề đổi liên tục (nền động?) nên không gộp được "
                    "khung - chế độ dự phòng không hợp video này. Hãy khoanh "
                    "HẸP đúng dải chữ hoặc giảm FPS."
                )

        for i, (t, path) in enumerate(zip(times, paths)):
            if is_cancelled():
                raise RuntimeError("Đã hủy theo yêu cầu.")
            with Image.open(path) as source:
                img = source.convert("RGB").copy()
            sig = text_mask_signature(img)
            if not mask_has_text(sig, min_density=min_text_density):
                # Không có chữ -> coi như khoảng lặng, đóng câu đang mở.
                if cur is not None:
                    push(cur)
                    cur, ref_sig, ref_thumb = None, None, None
                continue
            text_frames += 1
            thumb = img.convert("L").resize((64, 16), Image.Resampling.BILINEAR)
            diff = (ImageStat.Stat(ImageChops.difference(ref_thumb, thumb)).mean[0] / 255.0
                    if ref_thumb is not None else 1.0)
            if cur is not None and ref_sig is not None and (
                    diff <= dedup_threshold or mask_same(ref_sig, sig, mask_threshold)):
                cur.end = t + frame_dur
            else:
                if cur is not None:
                    push(cur)
                # Thu về bề rộng panel montage ngay để đỡ tốn RAM - video dài
                # có hàng nghìn keyframe, giữ crop gốc dễ tràn bộ nhớ.
                if img.width > panel_w:
                    ph = max(1, int(round(img.height * panel_w / img.width)))
                    img = img.resize((panel_w, ph), Image.Resampling.LANCZOS)
                cur = Keyframe(start=t, end=t + frame_dur, image=img)
                ref_sig = sig
                ref_thumb = thumb
            if i % 50 == 0 or i == len(times) - 1:
                report(10 + int(35 * (i + 1) / max(1, len(times))),
                       f"Quét khung {i + 1}/{len(times)} → {len(keyframes)} câu...")
        if cur is not None:
            push(cur)
        return keyframes


def build_montage(images: list, ids: list[int]) -> bytes:
    """Ghép các ảnh Pillow thành một montage dọc đánh số.

    Mỗi dải chuẩn hóa về bề rộng MONTAGE_WIDTH, có cột số ở mép trái và đường
    kẻ phân cách. Trả về PNG nhị phân.
    """
    from PIL import Image, ImageDraw  # noqa: PLC0415

    panels: list = []
    for img in images:
        source = img.convert("RGB") if hasattr(img, "convert") else Image.fromarray(img).convert("RGB")
        w, h = source.size
        new_h = max(1, int(round(h * (MONTAGE_WIDTH - LABEL_WIDTH) / max(1, w))))
        panel = source.resize((MONTAGE_WIDTH - LABEL_WIDTH, new_h), Image.Resampling.LANCZOS)
        panels.append(panel)

    sep = 3
    total_h = sum(p.height for p in panels) + sep * (len(panels) + 1)
    montage = Image.new("RGB", (MONTAGE_WIDTH, total_h), (32, 32, 32))
    draw = ImageDraw.Draw(montage)

    y = sep
    for pid, panel in zip(ids, panels):
        ph = panel.height
        montage.paste(panel, (LABEL_WIDTH, y))
        draw.text((10, y + ph // 2 - 6), str(pid), fill=(255, 230, 90))
        draw.line([(0, y + ph + sep // 2), (MONTAGE_WIDTH, y + ph + sep // 2)],
                  fill=(90, 90, 90), width=1)
        y += ph + sep

    buf = io.BytesIO()
    montage.save(buf, format="PNG")
    return buf.getvalue()


def llm_ocr_video(
    video_path: str,
    ffmpeg,
    gemini,
    region: tuple[float, float, float, float] = DEFAULT_REGION,
    fps: float = 2.0,
    batch: int = 18,
    dedup_threshold: float = 0.006,
    sim_threshold: float = 0.7,
    min_duration: float = 0.3,
    lang_hint: str = "",
    mask_threshold: float = 0.05,
    min_text_density: float = 0.012,
    max_merge_gap: float = 0.35,
    progress: ProgressFn | None = None,
    cancelled: CancelFn | None = None,
    checkpoint_dir: str | None = None,
    engine_label: str = "OCR",
) -> list[Segment]:
    """Đọc phụ đề gắn cứng bằng Gemini vision.

    Args:
        gemini: GeminiClient (đã có pool key). None -> lỗi.
        fps: khung/giây lấy mẫu (thấp là đủ vì đã gộp keyframe).
        batch: số dải mỗi ảnh montage gửi Gemini một lần.
        lang_hint: gợi ý ngôn ngữ chữ trong ảnh cho Gemini.
        mask_threshold: ngưỡng coi 2 khung là cùng một câu (mặt nạ cạnh).
        min_text_density: mật độ cạnh tối thiểu để coi khung có chữ.

    Raises:
        RuntimeError: thiếu Gemini/OpenCV, hoặc video không hợp LLM-OCR.
    """
    def report(pct: int, msg: str) -> None:
        if progress:
            progress(pct, msg)

    def is_cancelled() -> bool:
        return bool(cancelled and cancelled())

    if gemini is None:
        raise RuntimeError(
            "Chế độ dự phòng cần API key. Thêm API key ở tab Cài đặt trước."
        )

    try:
        width, height = ffmpeg.video_size(video_path)
        duration = ffmpeg.duration(video_path)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Không đọc được thông tin video: {exc}") from exc

    crop = region_to_crop(region, width, height)
    scan_fps = effective_scan_fps(duration, fps)

    checkpoint = None
    if checkpoint_dir:
        checkpoint = __import__("pathlib").Path(checkpoint_dir)
        source = __import__("pathlib").Path(video_path)
        identity = {
            "video": str(source.resolve()),
            "size": source.stat().st_size,
            "mtime_ns": source.stat().st_mtime_ns,
            "region": [round(float(v), 6) for v in region],
            "fps": scan_fps,
            "batch": int(batch),
        }
        digest = hashlib.sha256(
            json.dumps(identity, sort_keys=True).encode("utf-8")
        ).hexdigest()
        state_file = checkpoint / "state.json"
        old_digest = ""
        try:
            old_digest = json.loads(state_file.read_text(encoding="utf-8")).get(
                "digest", ""
            )
        except (OSError, ValueError, TypeError):
            pass
        if old_digest != digest:
            shutil.rmtree(checkpoint, ignore_errors=True)
            checkpoint.mkdir(parents=True, exist_ok=True)
            state_file.write_text(
                json.dumps({"digest": digest, "identity": identity},
                           ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        else:
            checkpoint.mkdir(parents=True, exist_ok=True)
    report(6, f"Vùng sub {crop[0]}x{crop[1]} px - đang quét khung ({scan_fps:g} fps)...")

    try:
        keyframes = extract_keyframes(
            video_path, ffmpeg, crop, duration, scan_fps, dedup_threshold, report, is_cancelled,
            mask_threshold=mask_threshold, min_text_density=min_text_density,
        )
    except ImportError as exc:  # pragma: no cover - phụ thuộc môi trường
        raise RuntimeError(
            "Thiếu thư viện xử lý ảnh Pillow."
        ) from exc

    if not keyframes:
        raise RuntimeError("Không tách được khung phụ đề nào từ video.")

    n_calls = len(plan_batches(len(keyframes), batch))
    report(48, f"Có {len(keyframes)} câu ứng viên ({n_calls} lượt gọi) - "
               f"đang đọc chữ...")
    batches = plan_batches(len(keyframes), batch)

    def read_batch(client, bi: int, i0: int, i1: int):
        if is_cancelled():
            raise RuntimeError("Đã hủy theo yêu cầu.")
        group = keyframes[i0:i1]
        ids = list(range(i0 + 1, i1 + 1))  # số panel 1-based, duy nhất toàn cục
        result_file = checkpoint / f"batch_{bi:05d}.json" if checkpoint else None
        if result_file and result_file.exists():
            try:
                saved = json.loads(result_file.read_text(encoding="utf-8"))
                saved_events = [tuple(event) for event in saved["events"]]
                return bi, saved_events, int(saved.get("empty", 0))
            except (OSError, ValueError, KeyError, TypeError):
                result_file.unlink(missing_ok=True)
        # Client có thể tự dựng montage phù hợp engine của nó (vd Drive OCR đọc
        # theo cột nên cần mốc full-width khác kiểu cột số của Gemini).
        build = getattr(client, "build_montage", None) or build_montage
        montage = build([kf.image for kf in group], ids)
        texts = client.read_subtitle_montage(montage, ids, lang_hint=lang_hint)
        # Vá panel montage bỏ sót bằng OCR riêng lẻ (nếu client hỗ trợ). Montage
        # nhanh nhưng hay bỏ sub NGẮN; OCR lại từng ảnh rỗng để đạt recall tối đa.
        # Chạy SONG SONG vì mỗi lần vá là một request mạng độc lập (chậm tuần tự).
        recover = getattr(client, "read_single", None)
        if recover is not None:
            empty = [offset for offset, pid in enumerate(ids)
                     if not (texts.get(pid) or "").strip()]
            if empty:
                def _one(offset: int):
                    try:
                        return offset, recover(group[offset].image, lang_hint)
                    except Exception:  # noqa: BLE001 - vá lỗi thì bỏ qua, giữ rỗng
                        return offset, ""
                workers = min(6, len(empty))
                with ThreadPoolExecutor(max_workers=workers) as ex:
                    for offset, single in ex.map(_one, empty):
                        if single and single.strip():
                            texts[ids[offset]] = single
        batch_events = []
        batch_empty = 0
        for local_id, kf in zip(ids, keyframes[i0:i1]):
            text = texts.get(local_id, "")
            if not (text or "").strip():
                batch_empty += 1
            batch_events.append((kf.start, kf.end, text))
        if result_file:
            tmp_file = result_file.with_suffix(".tmp")
            tmp_file.write_text(
                json.dumps({"events": batch_events, "empty": batch_empty},
                           ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(tmp_file, result_file)
        return bi, batch_events, batch_empty

    clients = list(gemini) if isinstance(gemini, (list, tuple)) else [gemini]
    clients = [client for client in clients if client is not None]
    if not clients:
        raise RuntimeError("LLM-OCR cần Gemini Web client.")

    events_by_batch: list[list[tuple[float, float, str]] | None] = [None] * len(batches)
    empty_panels_by_batch = [0] * len(batches)
    done_batches = 0
    progress_lock = threading.Lock()

    if len(clients) == 1 or len(batches) <= 1:
        client = clients[0]
        for bi, (i0, i1) in enumerate(batches):
            group = keyframes[i0:i1]
            montage_size = len(build_montage([kf.image for kf in group], list(range(i0 + 1, i1 + 1))))
            start_pct = 48 + int(45 * bi / max(1, len(batches)))
            report(
                start_pct,
                f"Gửi lô {bi + 1}/{len(batches)} "
                f"({len(group)} câu, {max(1, montage_size // 1024)} KB)...",
            )
            try:
                got_bi, batch_events, batch_empty = read_batch(client, bi, i0, i1)
            except Exception as exc:  # noqa: BLE001
                raise RuntimeError(
                    f"Đọc lô {bi + 1}/{len(batches)} lỗi; chưa tạo phụ đề "
                    f"để tránh mất câu âm thầm: {exc}"
                ) from exc
            events_by_batch[got_bi] = batch_events
            empty_panels_by_batch[got_bi] = batch_empty
            report(48 + int(45 * (bi + 1) / max(1, len(batches))),
                   f"Đọc lô {bi + 1}/{len(batches)}...")
    else:
        worker_count = min(len(clients), len(batches))
        report(49, f"Đang đọc song song bằng {worker_count} phiên...")

        import queue  # noqa: PLC0415
        work: queue.Queue[tuple[int, int, int]] = queue.Queue()
        for batch_index, (batch_start, batch_end) in enumerate(batches):
            work.put((batch_index, batch_start, batch_end))

        def worker(client_idx: int):
            nonlocal done_batches
            client = clients[client_idx]
            completed = 0
            error = None
            while True:
                try:
                    bi, i0, i1 = work.get_nowait()
                except queue.Empty:
                    break
                try:
                    if is_cancelled():
                        raise RuntimeError("Đã hủy theo yêu cầu.")
                    group = keyframes[i0:i1]
                    with progress_lock:
                        report(
                            48 + int(45 * done_batches / max(1, len(batches))),
                            f"Profile {client_idx + 1}: gửi lô {bi + 1}/{len(batches)} "
                            f"({len(group)} panel)...",
                        )
                    got_bi, batch_events, batch_empty = read_batch(
                        client, bi, i0, i1
                    )
                    with progress_lock:
                        events_by_batch[got_bi] = batch_events
                        empty_panels_by_batch[got_bi] = batch_empty
                        done_batches += 1
                        completed += 1
                        report(
                            48 + int(45 * done_batches / max(1, len(batches))),
                            f"Đã đọc {done_batches}/{len(batches)} lô...",
                        )
                except Exception as exc:  # noqa: BLE001
                    work.put((bi, i0, i1))
                    error = exc
                    break
            return client_idx, completed, error

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            futures = [
                executor.submit(worker, idx)
                for idx in range(worker_count)
            ]
            healthy_clients: list[int] = []
            failed_details: list[str] = []
            for future in as_completed(futures):
                client_idx, completed, error = future.result()
                if error is None or completed:
                    healthy_clients.append(client_idx)
                if error is not None:
                    failed_details.append(f"phiên {client_idx + 1}: {error}")

        # Một profile thiếu quyền tải tệp không được làm hỏng toàn bộ phim dài.
        # Chuyển những lô còn thiếu sang profile đã đọc thành công ít nhất một lô.
        missing = [bi for bi, value in enumerate(events_by_batch) if value is None]
        if missing:
            if not healthy_clients:
                detail = "; ".join(failed_details) or "không có phiên hoạt động"
                raise RuntimeError(f"Không thể tải ảnh bằng các tài khoản đã kết nối: {detail}")
            fallback_idx = healthy_clients[0]
            fallback = clients[fallback_idx]
            report(48 + int(45 * done_batches / max(1, len(batches))),
                   f"Chuyển {len(missing)} lô chưa xong sang tài khoản {fallback_idx + 1}...")
            for bi in missing:
                i0, i1 = batches[bi]
                try:
                    got_bi, batch_events, batch_empty = read_batch(
                        fallback, bi, i0, i1
                    )
                except Exception as exc:  # noqa: BLE001
                    raise RuntimeError(
                        f"Tài khoản dự phòng lỗi ở lô {bi + 1}/{len(batches)}: {exc}"
                    ) from exc
                events_by_batch[got_bi] = batch_events
                empty_panels_by_batch[got_bi] = batch_empty
                done_batches += 1
                report(48 + int(45 * done_batches / max(1, len(batches))),
                       f"Đã khôi phục {done_batches}/{len(batches)} lô...")

    events: list[tuple[float, float, str]] = []
    for bi, batch_events in enumerate(events_by_batch):
        if batch_events is None:
            raise RuntimeError(f"Thiếu kết quả đọc chữ lô {bi + 1}/{len(batches)}.")
        events.extend(batch_events)
    empty_panels = sum(empty_panels_by_batch)

    non_empty_events = len(events) - empty_panels
    report(
        95,
        f"Đang gộp phụ đề: {non_empty_events}/{len(events)} panel có chữ "
        f"({empty_panels} panel rỗng)...",
    )
    segments = events_to_segments(
        events,
        sim_threshold=sim_threshold,
        min_duration=min_duration,
        max_merge_gap=max_merge_gap,
    )
    # Chỉ dính lại phần nhấp nháy vài frame (gap <= 0.4s) để không phình timing;
    # trùng cách xa nhau thì giữ 2 dòng riêng với mốc chính xác.
    segments = merge_adjacent_duplicate_segments(segments, max_gap=0.4)
    segments = pad_boundaries(renumber(segments), pad=0.1)
    report(98, f"LLM-OCR xong: {len(segments)} dòng phụ đề từ {non_empty_events} panel có chữ")
    return renumber(segments)

"""Chuẩn bị thành phần giọng nói THEO YÊU CẦU (app-first, tải khi bấm).

Gộp một chỗ: phát hiện thiếu gì + cài torch/omnivoice (pip vào chính env đang
chạy) + tải model. Dùng cho nút "Chuẩn bị giọng nói" và lời nhắc khi bấm Tạo giọng.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from typing import Any, Callable

from vicdub.core import bootstrap
from vicdub.utils.process_utils import hidden_process_kwargs
from vicdub.utils.secret_store import unprotect_secret

ReportFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]

TORCH_VER = "2.8.0"
TORCHAUDIO_VER = "2.8.0"
CUDA_INDEX = "https://download.pytorch.org/whl/cu128"
CPU_INDEX = "https://download.pytorch.org/whl/cpu"


def has_nvidia_gpu() -> bool:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return False
    try:
        return subprocess.run(
            [exe, "-L"], capture_output=True, timeout=10,
            **hidden_process_kwargs(),
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def voice_ready(config: Any) -> bool:
    """Đủ để sinh giọng theo engine đang chọn."""
    if _api_voice_selected(config):
        return _api_voice_ready(config)
    keys_needed = {"torch", "omnivoice", "omnivoice_model", "vi_voices"}
    status = {c.key: c.ready for c in bootstrap.component_status(config)}
    return all(status.get(k, False) for k in keys_needed)


def voice_todo(config: Any) -> list[str]:
    """Danh sách việc cần làm để sinh giọng được (theo engine)."""
    if _api_voice_selected(config):
        return [] if _api_voice_ready(config) else ["voice_api"]
    status = {c.key: c.ready for c in bootstrap.component_status(config)}
    todo: list[str] = []
    if not status.get("torch", False):
        todo.append("torch")
    if not status.get("omnivoice", False):
        todo.append("omnivoice")
    if not status.get("omnivoice_model", False):
        todo.append("model")
    return todo


def _api_voice_selected(config: Any) -> bool:
    return str(getattr(config, "tts_provider", "local") or "local") == "api"


def _api_voice_ready(config: Any) -> bool:
    """API TTS không cần PyTorch/OmniVoice; chỉ cần cấu hình gọi API đủ."""
    kind = str(getattr(config, "voice_api_type", "") or "").strip().lower()
    if kind == "omnivoice_server":
        key = unprotect_secret(
            getattr(config, "voice_api_omnivoice_key", "")
            or getattr(config, "voice_api_key", "")
            or ""
        ).strip()
        base_url = str(
            getattr(config, "voice_api_omnivoice_base_url", "")
            or getattr(config, "voice_api_base_url", "")
            or ""
        ).strip()
    else:
        key = unprotect_secret(getattr(config, "voice_api_key", "") or "").strip()
        base_url = str(getattr(config, "voice_api_base_url", "") or "").strip()
    if not key or not base_url:
        return False
    if kind == "custom":
        return bool(str(getattr(config, "voice_api_synthesis_url", "") or "").strip())
    return True


def estimate_size_gb(config: Any) -> float:
    """Ước lượng dung lượng cần tải cho phần còn thiếu (để cảnh báo)."""
    todo = voice_todo(config)
    gb = 0.0
    if "torch" in todo:
        gb += 9.0 if has_nvidia_gpu() else 0.5
    if "omnivoice" in todo:
        gb += 0.2
    if "model" in todo:
        gb += 3.0
    return round(gb, 1)


def _pip(args: list[str], report: ReportFn, is_cancelled: CancelFn) -> None:
    """pip install vào CHÍNH python đang chạy; stream log ra report(-1, ...)."""
    cmd = [sys.executable, "-m", "pip", "install", "--no-input", *args]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace",
                            **hidden_process_kwargs())
    assert proc.stdout is not None
    for line in proc.stdout:
        if is_cancelled():
            proc.terminate()
            raise RuntimeError("Đã huỷ.")
        line = line.strip()
        if line:
            report(-1, line[:110])
    if proc.wait() != 0:
        raise RuntimeError("pip install thất bại (xem log/mạng).")


def prepare_voice(
    config: Any,
    report: ReportFn | None = None,
    is_cancelled: CancelFn | None = None,
    prefer_cuda: bool | None = None,
) -> None:
    """Cài mọi thứ còn thiếu để sinh giọng: torch -> omnivoice -> model.

    prefer_cuda: None = tự quyết theo GPU; True/False = ép.
    """
    def say(pct: int, msg: str) -> None:
        if report:
            report(pct, msg)

    def cancelled() -> bool:
        return bool(is_cancelled and is_cancelled())

    todo = voice_todo(config)
    if not todo:
        say(100, "Giọng nói đã sẵn sàng.")
        return

    cuda = has_nvidia_gpu() if prefer_cuda is None else prefer_cuda
    total = len(todo)
    for i, step in enumerate(todo):
        if cancelled():
            raise RuntimeError("Đã huỷ.")
        base = int(100 * i / total)
        if step == "torch":
            say(base, f"Cài PyTorch {'GPU' if cuda else 'CPU'} (vài phút)...")
            index = CUDA_INDEX if cuda else CPU_INDEX
            _pip([f"torch=={TORCH_VER}", f"torchaudio=={TORCHAUDIO_VER}",
                  "--index-url", index], say, cancelled)
        elif step == "omnivoice":
            say(base, "Cài OmniVoice...")
            _pip(["omnivoice>=0.1.5"], say, cancelled)
        elif step == "model":
            say(base, "Tải model giọng (~3GB)...")
            bootstrap.ensure_omnivoice_model(
                config, progress=lambda p, m: say(base + int((100 - base) * p / 100), m))
    say(100, "Đã chuẩn bị xong giọng nói.")

"""Tiện ích: phụ đề, FFmpeg, translation memory."""

"""Import Module - nhập video, phụ đề, batch folder.

Input:  video_path hoặc subtitle_path hoặc folder_path
Output: video_path (đã kiểm tra), video_info tối thiểu
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.subtitles import SUPPORTED_SUBTITLE_EXTS

SUPPORTED_VIDEO_EXTS = (".mp4", ".mov", ".mkv", ".avi", ".webm")


class ImportModule(BaseModule):
    """Kiểm tra và nạp file đầu vào."""

    name = "Nhập video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        video_path = data.get("video_path", "")
        if not video_path:
            raise ModuleError("Chưa chọn video. Vào tab Video để chọn file.")

        path = Path(video_path)
        if not path.exists():
            raise ModuleError(f"File không tồn tại: {video_path}")
        if path.suffix.lower() not in SUPPORTED_VIDEO_EXTS:
            raise ModuleError(
                f"Định dạng {path.suffix} không hỗ trợ. "
                f"Chỉ nhận: {', '.join(SUPPORTED_VIDEO_EXTS)}"
            )

        self.report(80, f"Đã nhận file: {path.name}")
        info = {
            "path": str(path),
            "name": path.name,
            "suffix": path.suffix.lower(),
            "size": path.stat().st_size,
        }

        self.report(100, f"Đã nhập: {path.name}")
        return {"video_path": str(path), "video_info": info}

    # ---------- Tiện ích cho UI (không thuộc pipeline) ----------

    @staticmethod
    def scan_folder(folder: str) -> list[str]:
        """Batch import: liệt kê mọi video trong thư mục."""
        root = Path(folder)
        if not root.is_dir():
            raise ModuleError(f"Không phải thư mục: {folder}")
        return sorted(
            str(p) for p in root.iterdir()
            if p.suffix.lower() in SUPPORTED_VIDEO_EXTS
        )

    @staticmethod
    def is_subtitle(path: str) -> bool:
        return Path(path).suffix.lower() in SUPPORTED_SUBTITLE_EXTS

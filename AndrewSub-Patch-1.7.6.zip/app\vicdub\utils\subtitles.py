"""Đọc/ghi phụ đề SRT, ASS, VTT.

Mọi định dạng được quy về danh sách Segment thống nhất cho toàn pipeline.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Segment:
    """Một dòng phụ đề trong pipeline."""

    line: int                 # số thứ tự, bắt đầu từ 1
    start: float              # giây
    end: float                # giây
    text: str = ""            # văn bản gốc
    translation: str = ""     # bản dịch
    speaker: str = ""         # nhân vật
    gender: str = "neutral"   # male | female | neutral
    voice: str = ""           # voice riêng của dòng (rỗng = theo nhân vật)
    ocr_warning: str = ""     # cần người dùng kiểm tra lại nhận diện

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


MALE_GENDERS = {"male", "nam", "man", "m", "boy", "男", "男声"}
FEMALE_GENDERS = {"female", "nữ", "nu", "woman", "f", "girl", "女", "女声"}


def normalize_gender(value: str) -> str:
    """Chuẩn hóa giới tính nhân vật để voice/export dùng chung một khóa."""
    raw = str(value or "").strip().casefold()
    if raw in {item.casefold() for item in MALE_GENDERS}:
        return "male"
    if raw in {item.casefold() for item in FEMALE_GENDERS}:
        return "female"
    return "neutral"


def gender_label(value: str) -> str:
    gender = normalize_gender(value)
    if gender == "male":
        return "Nam"
    if gender == "female":
        return "Nữ"
    return "Chưa rõ"


# ---------- Thời gian ----------

def _parse_time(value: str) -> float:
    """'00:01:02,500' hoặc '00:01:02.500' hoặc '0:01:02.50' -> giây."""
    value = value.strip().replace(",", ".")
    parts = value.split(":")
    if len(parts) == 3:
        h, m, s = parts
    elif len(parts) == 2:
        h, (m, s) = "0", parts
    else:
        raise ValueError(f"Thời gian không hợp lệ: {value}")
    return int(h) * 3600 + int(m) * 60 + float(s)


def format_srt_time(seconds: float) -> str:
    """Giây -> '00:01:02,500'."""
    seconds = max(0.0, seconds)
    ms = round((seconds - int(seconds)) * 1000)
    if ms == 1000:  # tránh lỗi làm tròn 0.9995
        ms = 0
        seconds += 1
    total = int(seconds)
    return f"{total // 3600:02d}:{(total % 3600) // 60:02d}:{total % 60:02d},{ms:03d}"


# ---------- SRT ----------

_SRT_TIME_RE = re.compile(
    r"(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})"
)


def clean_subtitle_text(text: str) -> str:
    """Bỏ tag định dạng SRT/VTT/ASS, giữ lại chữ thật."""
    text = str(text or "")
    text = re.sub(r"\{[^}]*\}", "", text)
    text = text.replace("\\N", "\n").replace("\\n", "\n")
    text = re.sub(r"</?[^>\n]+>", "", text)
    text = (
        text.replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&#39;", "'")
    )
    lines = [" ".join(line.split()) for line in text.splitlines()]
    cleaned_lines: list[str] = []
    for line in lines:
        line = line.strip().strip("|｜¦").strip()
        # Một số API dịch/OCR chèn bullet/marker đầu dòng. Đây là ký tự điều
        # hướng, không phải thoại thật; bỏ trước khi hiển thị, ghi SRT và TTS.
        for _ in range(3):
            new_line = re.sub(
                r"^[\s\uFEFF]*(?:[●•◦▪■□◆◇★☆·・]+|[|｜¦丨]+)\s*",
                "",
                line,
            ).strip()
            if new_line == line:
                break
            line = new_line
        cleaned_lines.append(line)
    lines = cleaned_lines
    return "\n".join(line for line in lines if line).strip()


def parse_srt(content: str) -> list[Segment]:
    """Parse nội dung SRT thành danh sách Segment."""
    segments: list[Segment] = []
    blocks = re.split(r"\n\s*\n", content.replace("\r\n", "\n").strip())
    for block in blocks:
        lines = [l for l in block.split("\n") if l.strip()]
        if not lines:
            continue
        # Tìm dòng thời gian (dòng đầu có thể là số thứ tự).
        time_idx = next(
            (i for i, l in enumerate(lines) if _SRT_TIME_RE.search(l)), None
        )
        if time_idx is None:
            continue
        match = _SRT_TIME_RE.search(lines[time_idx])
        text = clean_subtitle_text("\n".join(lines[time_idx + 1:]).strip())
        segments.append(Segment(
            line=len(segments) + 1,
            start=_parse_time(match.group(1)),
            end=_parse_time(match.group(2)),
            text=text,
        ))
    return segments


def wrap_two_lines(text: str, width: int = 42) -> str:
    """Bẻ text dài thành tối đa 2 dòng tại khoảng trắng gần giữa nhất.

    Chuẩn hiển thị phụ đề phim: tối đa 2 dòng, ~42 ký tự/dòng.
    """
    text = " ".join(text.split())
    if len(text) <= width or " " not in text:
        return text
    middle = len(text) // 2
    left = text.rfind(" ", 0, middle + 1)
    right = text.find(" ", middle)
    cut = left if (left != -1 and (right == -1 or middle - left <= right - middle)) else right
    if cut <= 0:
        return text
    return f"{text[:cut]}\n{text[cut + 1:]}"


def write_srt(segments: list[Segment], path: str | Path, translated: bool = False) -> None:
    """Ghi danh sách Segment ra file .srt chuẩn.

    Args:
        translated: True thì ghi bản dịch, False ghi văn bản gốc.
    """
    blocks = []
    for i, seg in enumerate(segments, start=1):
        text = clean_subtitle_text(seg.translation if translated else seg.text)
        text = wrap_two_lines(text)
        blocks.append(
            f"{i}\n{format_srt_time(seg.start)} --> {format_srt_time(seg.end)}\n{text}"
        )
    # utf-8-sig (BOM): file thô mở chuẩn trên mọi player/editor Windows.
    Path(path).write_text("\n\n".join(blocks) + "\n", encoding="utf-8-sig")


def _format_ass_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    total_cs = round(seconds * 100)
    hours, rest = divmod(total_cs, 360000)
    minutes, rest = divmod(rest, 6000)
    secs, centis = divmod(rest, 100)
    return f"{hours}:{minutes:02d}:{secs:02d}.{centis:02d}"


def _ass_colour(hex_colour: str, alpha: int = 0) -> str:
    """Convert #RRGGBB to ASS &HAABBGGRR."""
    value = (hex_colour or "").strip()
    if value.startswith("#"):
        value = value[1:]
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", value):
        value = "FFFFFF"
    red = int(value[0:2], 16)
    green = int(value[2:4], 16)
    blue = int(value[4:6], 16)
    alpha = max(0, min(255, int(alpha)))
    return f"&H{alpha:02X}{blue:02X}{green:02X}{red:02X}"


def _clean_ass_font_name(font_name: str) -> str:
    value = " ".join((font_name or "Arial").split()).strip()
    value = value.replace(",", " ").replace("\n", " ")
    return value or "Arial"


def write_positioned_ass(
    segments: list[Segment], path: str | Path, *, x: float = 0.5, y: float = 0.9,
    font_size: int = 24, background: bool = False, translated: bool = True,
    font_name: str = "Arial", text_color: str = "#FFFFFF",
    bg_color: str = "#000000", play_res: tuple[int, int] | None = None,
) -> None:
    """Write ASS with one normalized free-position shared by every subtitle."""
    x = max(0.03, min(0.97, float(x)))
    y = max(0.03, min(0.97, float(y)))
    # Preview stores normalized coordinates on the real video frame. Render must
    # use the same aspect/resolution, otherwise vertical videos drift when ASS is
    # authored at fixed 640x360 and libass stretches it non-uniformly.
    if play_res:
        play_w, play_h = int(play_res[0]), int(play_res[1])
    else:
        play_w, play_h = 640, 360
    play_w = max(160, play_w)
    play_h = max(120, play_h)
    px, py = round(x * play_w), round(y * play_h)
    # UI font size was calibrated on a 360px-tall script resolution. Keep that
    # visual scale when PlayRes switches to the real video height.
    ass_font_size = max(8, round(max(8, int(font_size)) * play_h / 360))
    border_style = 3 if background else 1
    outline = 0 if background else 2
    primary_colour = _ass_colour(text_color, 0)
    outline_colour = _ass_colour("#000000", 0)
    back_colour = _ass_colour(bg_color, 128) if background else _ass_colour("#000000", 255)
    font_name = _clean_ass_font_name(font_name)
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_w}
PlayResY: {play_h}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font_name},{ass_font_size},{primary_colour},&H000000FF,{outline_colour},{back_colour},-1,0,0,0,100,100,0,0,{border_style},{outline},1,5,20,20,20,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    rows = []
    usable_w = max(80, play_w - 40)
    usable_h = max(60, play_h - 30)
    for seg in segments:
        text = (seg.translation if translated else seg.text) or seg.text
        # \pos bỏ qua MarginL/MarginR của ASS. Vì vậy phải bẻ dòng rõ ràng và
        # kẹp tâm theo kích thước hộp ước tính, nếu không kéo sát mép sẽ làm chữ
        # và nền hộp tràn ra ngoài video.
        max_chars = max(8, min(42, int(usable_w / max(8, ass_font_size) / 0.56)))
        text = wrap_for_box(text, max_chars=max_chars)
        longest = max((len(line) for line in text.splitlines()), default=1)
        box_w = min(usable_w, round(longest * max(8, ass_font_size) * 0.56 + 28))
        box_h = min(usable_h, round(len(text.splitlines()) * max(8, ass_font_size) * 1.30 + 16))
        safe_x = max(box_w // 2 + 8, min(play_w - box_w // 2 - 8, px))
        safe_y = max(box_h // 2 + 6, min(play_h - box_h // 2 - 6, py))
        text = text.replace("\\", r"\\").replace("{", "(").replace("}", ")")
        text = text.replace("\n", r"\N")
        rows.append(
            f"Dialogue: 0,{_format_ass_time(seg.start)},{_format_ass_time(seg.end)},"
            f"Default,,0,0,0,,{{\\pos({safe_x},{safe_y})}}{text}"
        )
    Path(path).write_text(header + "\n".join(rows) + "\n", encoding="utf-8-sig")


def wrap_for_box(text: str, max_chars: int = 42) -> str:
    """Bẻ đủ số dòng cần thiết để không dòng nào vượt hộp hiển thị."""
    clean = " ".join((text or "").split())
    if not clean:
        return ""
    width = max(8, int(max_chars))
    words = clean.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        # Chuỗi không có khoảng trắng (CJK/mã dài) vẫn phải được cắt an toàn.
        while len(word) > width:
            if current:
                lines.append(current)
                current = ""
            lines.append(word[:width])
            word = word[width:]
        candidate = word if not current else f"{current} {word}"
        if len(candidate) <= width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return "\n".join(lines)


def write_blur_mask_ass(
    segments: list[Segment], path: str | Path,
    *, region: tuple[float, float, float, float], translated: bool = False,
    scale_percent: int = 140, play_res: tuple[int, int] | None = None,
) -> None:
    """Write a white-on-black ASS mask whose boxes follow each subtitle timing/text."""
    x0, y0, x1, y1 = (max(0.0, min(1.0, float(v))) for v in region)
    x0, x1 = sorted((x0, x1)); y0, y1 = sorted((y0, y1))
    scale = max(80, min(250, int(scale_percent))) / 100.0
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    half_w = (x1 - x0) * scale / 2.0
    half_h = (y1 - y0) * scale / 2.0
    rx0, rx1 = max(0.0, cx - half_w), min(1.0, cx + half_w)
    ry0, ry1 = max(0.0, cy - half_h), min(1.0, cy + half_h)
    if play_res:
        play_w, play_h = int(play_res[0]), int(play_res[1])
    else:
        play_w, play_h = 640, 360
    play_w = max(160, play_w)
    play_h = max(120, play_h)
    px, py = round(rx0 * play_w), round(ry0 * play_h)
    box_w = max(1, round((rx1 - rx0) * play_w))
    box_h = max(1, round((ry1 - ry0) * play_h))
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_w}
PlayResY: {play_h}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Mask,Arial,20,&H00FFFFFF,&H00FFFFFF,&H00FFFFFF,&H00FFFFFF,-1,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    rows = []
    for seg in segments:
        text = ((seg.translation if translated else seg.text) or seg.text).strip()
        if not text:
            continue
        drawing = f"m 0 0 l {box_w} 0 l {box_w} {box_h} l 0 {box_h}"
        rows.append(
            f"Dialogue: 0,{_format_ass_time(seg.start)},{_format_ass_time(seg.end)},"
            f"Mask,,0,0,0,,{{\\an7\\pos({px},{py})\\p1}}{drawing}{{\\p0}}"
        )
    Path(path).write_text(header + "\n".join(rows) + "\n", encoding="utf-8-sig")


def match_translations(base: list[Segment], other: list[Segment]) -> int:
    """Ghép bản dịch từ danh sách sub khác vào base, ưu tiên khớp theo thời gian.

    Dùng khi tải file translated.srt lên: số dòng có thể lệch so với sub gốc
    nên khớp theo trùng khung thời gian; bằng số dòng thì ghép theo thứ tự.

    Returns:
        Số dòng ghép được.
    """
    if not base or not other:
        return 0
    if len(base) == len(other):
        for b, o in zip(base, other):
            b.translation = o.text
        return len(base)

    matched = 0
    for b in base:
        mid = (b.start + b.end) / 2
        best = None
        for o in other:
            if o.start <= mid <= o.end:
                best = o
                break
        if best is None:
            best = min(
                other,
                key=lambda o: abs((o.start + o.end) / 2 - mid),
            )
            if abs((best.start + best.end) / 2 - mid) > 3.0:
                best = None  # lệch quá 3 giây coi như không khớp
        if best is not None:
            b.translation = best.text
            matched += 1
    return matched


# ---------- VTT ----------

def parse_vtt(content: str) -> list[Segment]:
    """WEBVTT: bỏ header rồi parse như SRT (thời gian dùng dấu chấm)."""
    lines = content.replace("\r\n", "\n").split("\n")
    # Bỏ header WEBVTT và các khối NOTE/STYLE ở đầu.
    body_start = 0
    for i, line in enumerate(lines):
        if _SRT_TIME_RE.search(line):
            body_start = i
            break
        body_start = i + 1
    return parse_srt("\n".join(lines[max(0, body_start - 1):]))


# ---------- ASS ----------

def parse_ass(content: str) -> list[Segment]:
    """Parse phần [Events] của file ASS/SSA."""
    segments: list[Segment] = []
    fmt: list[str] = []
    for raw in content.replace("\r\n", "\n").split("\n"):
        line = raw.strip()
        if line.lower().startswith("format:"):
            fmt = [f.strip().lower() for f in line.split(":", 1)[1].split(",")]
        elif line.lower().startswith("dialogue:") and fmt:
            values = line.split(":", 1)[1].split(",", len(fmt) - 1)
            row = dict(zip(fmt, values))
            text = row.get("text", "")
            # Bỏ tag ASS kiểu {\an8}
            text = clean_subtitle_text(text)
            if not text:
                continue
            segments.append(Segment(
                line=len(segments) + 1,
                start=_parse_time(row.get("start", "0:00:00.00")),
                end=_parse_time(row.get("end", "0:00:00.00")),
                text=text,
                speaker=row.get("name", "").strip(),
            ))
    return segments


# ---------- API chung ----------

SUPPORTED_SUBTITLE_EXTS = (".srt", ".ass", ".vtt")


def load_subtitle_file(path: str | Path) -> list[Segment]:
    """Đọc file phụ đề bất kỳ (.srt/.ass/.vtt) thành Segment."""
    path = Path(path)
    content = path.read_text(encoding="utf-8-sig", errors="replace")
    ext = path.suffix.lower()
    if ext == ".srt":
        return parse_srt(content)
    if ext == ".vtt":
        return parse_vtt(content)
    if ext == ".ass":
        return parse_ass(content)
    raise ValueError(f"Định dạng phụ đề không hỗ trợ: {ext}")


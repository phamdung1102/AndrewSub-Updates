"""Theme tối cho toàn app - QSS tập trung một chỗ, không rải rác."""

DARK_QSS = """
QWidget {
    background-color: #0b0f14;
    color: #e6edf3;
    font-family: "Segoe UI", "Arial";
    font-size: 13px;
}
QMainWindow, QDialog { background-color: #0b0f14; }

/* Sidebar */
QListWidget#nav {
    background-color: #111827;
    border: none;
    border-right: 1px solid #223044;
    padding-top: 6px;
    outline: none;
}
QListWidget#nav::item {
    padding: 10px 14px;
    margin: 2px 8px;
    border-radius: 6px;
    color: #c7d2df;
}
QListWidget#nav::item:hover { background-color: #1b2940; }
QListWidget#nav::item:selected {
    background-color: #1f6feb;
    color: #ffffff;
}

/* Top nav */
QListWidget#topNav {
    background-color: #111827;
    border: none;
    border-bottom: 1px solid #223044;
    padding: 6px 10px;
    outline: none;
}
QListWidget#topNav::item {
    padding: 8px 16px;
    margin: 0 4px;
    border-radius: 6px;
    color: #c7d2df;
}
QListWidget#topNav::item:hover { background-color: #1b2940; }
QListWidget#topNav::item:selected {
    background-color: #1f6feb;
    color: #ffffff;
}

/* Panel phải */
QFrame#rightPanel {
    background-color: #0f1724;
    border-left: 1px solid #223044;
}
QFrame#voicePanel {
    background-color: #101923;
    border: 1px solid #2b3b51;
    border-radius: 10px;
}
QFrame#voicePanel QLabel#voiceServiceStatus {
    background-color: #0d211b;
    border: 1px solid #1f6f55;
    border-radius: 7px;
    color: #72e6ad;
    font-weight: 600;
    padding: 8px 10px;
}
QFrame#voicePanel QLabel#voiceServiceStatus[state="offline"] {
    background-color: #251b12;
    border-color: #72501e;
    color: #f5c76b;
}
QFrame#studioToolbar {
    background-color: #0f1724;
    border: 1px solid #223044;
    border-radius: 6px;
}
QFrame#projectWorkspaceCard {
    background-color: #0f1724;
    border: 1px solid #26364b;
    border-radius: 10px;
}
QFrame#projectWorkspaceCard QLabel {
    background-color: transparent;
}
QFrame#subtitleSourceCard {
    background-color: #111c2b;
    border: 1px solid #2b3b51;
    border-radius: 9px;
}
QFrame#subtitleSourceCard QLabel {
    background-color: transparent;
}
QRadioButton#subtitleSourceChoice {
    background-color: #162235;
    border: 1px solid #33465f;
    border-radius: 7px;
    padding: 10px 12px;
    font-weight: 600;
}
QRadioButton#subtitleSourceChoice:hover {
    background-color: #1b2c44;
    border-color: #5d789a;
}
QRadioButton#subtitleSourceChoice:checked {
    color: #ffffff;
    background-color: #164e83;
    border: 2px solid #38bdf8;
    padding: 9px 11px;
}
QRadioButton#subtitleSourceChoice[sourceMode="audio"]:checked {
    background-color: #115e59;
    border-color: #2dd4bf;
}
QWidget#settingsContent {
    background-color: #0f1724;
    border: 1px solid #26364b;
    border-radius: 10px;
}
QWidget#settingsContent QLabel {
    background-color: transparent;
}
QWidget#settingsShell {
    background-color: transparent;
}
QListWidget#settingsCategoryNav {
    background-color: #0f1724;
    border: 1px solid #26364b;
    border-radius: 10px;
    padding: 8px;
    outline: none;
}
QListWidget#settingsCategoryNav::item {
    color: #c7d2df;
    border-radius: 7px;
    padding: 11px 12px;
    margin: 2px 0;
}
QListWidget#settingsCategoryNav::item:hover {
    background-color: #17243a;
}
QListWidget#settingsCategoryNav::item:selected {
    background-color: #173d70;
    color: #ffffff;
    font-weight: 600;
}
QTabWidget#settingsTabs::pane {
    border: none;
    border-top: 1px solid #223044;
    background-color: #0b0f14;
}
QTabWidget#settingsTabs QTabBar::tab {
    background-color: transparent;
    color: #9fb0c2;
    border: none;
    padding: 10px 18px;
    margin-right: 4px;
}
QTabWidget#settingsTabs QTabBar::tab:hover {
    color: #e6edf3;
    background-color: #111827;
}
QTabWidget#settingsTabs QTabBar::tab:selected {
    color: #ffffff;
    border-bottom: 2px solid #3b82f6;
    font-weight: 600;
}
QFrame#exportPanelShell {
    background-color: #101923;
    border-left: 1px solid #2d3b50;
}
QScrollArea#exportPanelScroll,
QScrollArea#exportPanelScroll > QWidget > QWidget,
QWidget#exportPanel {
    background-color: #101923;
    border: none;
}
QWidget#exportPanel QLabel {
    background-color: transparent;
}
QFrame#exportSection {
    background-color: #111c2b;
    border: 1px solid #2b3b51;
    border-radius: 9px;
}
QWidget#exportPanel QLabel[role="title"] {
    color: #f8fafc;
    font-size: 15px;
    padding: 0 0 5px 0;
}
QWidget#exportPanel QLabel[role="muted"] {
    color: #c7d2df;
    line-height: 1.35;
}
QWidget#exportPanel QRadioButton {
    color: #f1f5f9;
    padding: 2px 0;
}
QWidget#exportPanel QRadioButton#subtitleMode {
    background-color: #162235;
    border: 1px solid #33465f;
    border-radius: 7px;
    padding: 10px 12px;
    font-weight: 600;
    min-height: 20px;
}
QWidget#exportPanel QRadioButton#subtitleMode:hover {
    background-color: #1b2c44;
    border-color: #5d789a;
}
QWidget#exportPanel QRadioButton#subtitleMode:checked {
    color: #ffffff;
    background-color: #164e83;
    border: 2px solid #38bdf8;
    padding: 9px 11px;
}
QWidget#exportPanel QRadioButton#subtitleMode[mode="none"]:checked {
    background-color: #374151;
    border-color: #94a3b8;
}
QWidget#exportPanel QRadioButton#subtitleMode[mode="soft"]:checked {
    background-color: #115e59;
    border-color: #2dd4bf;
}
QWidget#exportPanel QComboBox,
QWidget#exportPanel QPushButton {
    min-height: 24px;
}
QWidget#exportPanel QSlider::groove:horizontal {
    background: #0b1118;
    height: 5px;
    border-radius: 3px;
}
QWidget#exportPanel QSlider::sub-page:horizontal {
    background: #38bdf8;
    height: 5px;
    border-radius: 3px;
}
QWidget#exportPanel QSlider::handle:horizontal {
    background: #ffffff;
    border: 2px solid #38bdf8;
    width: 12px;
    height: 12px;
    margin: -5px 0;
    border-radius: 7px;
}

/* Card tiêu đề nhóm */
QLabel[role="title"] {
    font-size: 16px;
    font-weight: 700;
    padding: 4px 0;
}
QLabel[role="muted"] { color: #9fb0c2; }

/* Nút */
QPushButton {
    background-color: #111827;
    border: 1px solid #2d3b50;
    border-radius: 6px;
    padding: 7px 14px;
}
QPushButton:hover { background-color: #1b2940; border-color: #1f6feb; }
QPushButton:pressed { background-color: #16233a; }
QPushButton:disabled { color: #5b6b7d; border-color: #223044; }
QPushButton[variant="primary"] {
    background-color: #1f6feb;
    border-color: #1f6feb;
    color: #ffffff;
    font-weight: 600;
}
QPushButton[variant="primary"]:hover { background-color: #3b82f6; }
QPushButton[variant="danger"] { border-color: #7f1d1d; color: #fca5a5; }

/* Điều khiển tác vụ ở status bar: nút chữ lớn, phân biệt bằng màu. */
QPushButton#pipelinePause {
    background-color: #713f12;
    border: 1px solid #f59e0b;
    color: #fef3c7;
    font-weight: 700;
    padding: 4px 10px;
}
QPushButton#pipelinePause:hover { background-color: #92400e; }
QPushButton#pipelineResume {
    background-color: #14532d;
    border: 1px solid #22c55e;
    color: #dcfce7;
    font-weight: 700;
    padding: 4px 10px;
}
QPushButton#pipelineResume:hover { background-color: #166534; }
QPushButton#pipelineCancel {
    background-color: #7f1d1d;
    border: 1px solid #ef4444;
    color: #fee2e2;
    font-weight: 700;
    padding: 4px 10px;
}
QPushButton#pipelineCancel:hover { background-color: #991b1b; }
QPushButton#pipelinePause:disabled,
QPushButton#pipelineResume:disabled,
QPushButton#pipelineCancel:disabled {
    background-color: #172033;
    border-color: #334155;
    color: #64748b;
}

/* Input */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit {
    background-color: #111827;
    border: 1px solid #223044;
    border-radius: 6px;
    padding: 6px 8px;
    selection-background-color: #1f6feb;
}
QLineEdit:focus, QComboBox:focus { border-color: #1f6feb; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView {
    background-color: #111827;
    border: 1px solid #223044;
    selection-background-color: #1f6feb;
}

/* Bảng */
QTableWidget {
    background-color: #0f1724;
    border: 1px solid #223044;
    border-radius: 6px;
    gridline-color: #1b2940;
}
QTableWidget::item:selected { background-color: #1f6feb; }
QHeaderView::section {
    background-color: #111827;
    border: none;
    border-bottom: 1px solid #223044;
    padding: 6px;
    font-weight: 600;
}
QTableCornerButton::section { background-color: #111827; border: none; }

/* Progress */
QProgressBar {
    background-color: #223044;
    border: none;
    border-radius: 4px;
    height: 8px;
    text-align: center;
    color: transparent;
}
QProgressBar::chunk { background-color: #38bdf8; border-radius: 4px; }

/* Tab & list phụ */
QListWidget {
    background-color: #0f1724;
    border: 1px solid #223044;
    border-radius: 6px;
}
QListWidget::item { padding: 6px 8px; }
QListWidget::item:selected { background-color: #1f6feb; }

/* Radio / checkbox */
QRadioButton, QCheckBox { spacing: 8px; }

/* Scrollbar */
QScrollBar:vertical {
    background: #0b0f14; width: 10px; border-radius: 5px;
}
QScrollBar::handle:vertical {
    background: #2d3b50; border-radius: 5px; min-height: 30px;
}
QScrollBar::handle:vertical:hover { background: #3b4d68; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; }

/* Status bar */
QStatusBar {
    background-color: #111827;
    border-top: 1px solid #223044;
    color: #9fb0c2;
}
QSplitter::handle { background-color: #223044; width: 1px; }
"""

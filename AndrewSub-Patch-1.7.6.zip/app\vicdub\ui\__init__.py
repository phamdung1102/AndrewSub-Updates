"""Giao diện PyQt6 - tách hoàn toàn khỏi business logic và engine."""

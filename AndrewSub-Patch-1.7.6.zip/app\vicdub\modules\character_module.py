"""Character Module - hoàn thiện danh sách nhân vật.

Phân vai chính do Gemini làm trong bước dịch. Bước này đảm bảo:
- Mọi segment đều có speaker.
- Bảng characters đầy đủ, thống kê số dòng mỗi nhân vật.
Người dùng chỉnh sửa (đổi tên/thêm/xóa) qua UI -> ProjectManager.

Output: characters (list[dict] có đếm số dòng)
"""

from __future__ import annotations

from collections import Counter
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.subtitles import Segment
from vicdub.utils.voice_registry import assign_missing


class CharacterModule(BaseModule):
    """Chuẩn hóa nhân vật sau khi dịch."""

    name = "Phân vai nhân vật"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        if not segments:
            raise ModuleError("Chưa có phụ đề để phân vai.")

        self.report(30, "Chuẩn hóa nhân vật...")
        for seg in segments:
            if not seg.speaker.strip():
                seg.speaker = "Narrator"
        project.save_segments(segments)

        # Đồng bộ bảng characters, giữ voice_id đã gán trước đó.
        existing = {c["name"]: c for c in project.load_characters()}
        counts = Counter(seg.speaker for seg in segments)
        genders: dict[str, str] = {}
        for seg in segments:
            genders.setdefault(seg.speaker, seg.gender)

        # Tự gán giọng: giữ voice_id đã gán, gán giọng KHÁC NHAU cho nhân vật
        # còn trống (nhân vật nhiều dòng ưu tiên trước). Chỉ CHỌN giọng, không
        # đụng cách sinh giọng.
        order = [name for name, _ in counts.most_common()]
        existing_voice = {n: existing.get(n, {}).get("voice_id", "") for n in order}
        voice_map = assign_missing(order, existing_voice)

        characters = []
        for name, count in counts.most_common():
            old = existing.get(name, {})
            gender = old.get("gender") or genders.get(name, "neutral")
            voice_id = voice_map.get(name, old.get("voice_id", ""))
            project.save_character(name, gender, voice_id)
            characters.append({
                "name": name, "gender": gender,
                "voice_id": voice_id, "lines": count,
            })

        self.report(100, f"Có {len(characters)} nhân vật")
        return {"segments": segments, "characters": characters}

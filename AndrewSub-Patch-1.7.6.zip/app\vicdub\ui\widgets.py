"""Widget dùng chung: bảng phụ đề, tiến độ pipeline, trạng thái API."""

from __future__ import annotations

from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QComboBox, QHBoxLayout, QHeaderView, QLabel, QLayout, QProgressBar,
    QPushButton, QStyledItemDelegate, QTableWidget, QTableWidgetItem,
    QToolButton, QVBoxLayout, QWidget,
)

from vicdub.core.workflow_engine import PIPELINE_STEPS
from vicdub.utils.subtitles import Segment, gender_label, normalize_gender


def subtitle_cps(text: str, duration: float) -> float:
    """Visible characters per second; whitespace is not spoken."""
    compact = "".join(str(text or "").split())
    return len(compact) / max(0.08, float(duration or 0.0))


def title_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setProperty("role", "title")
    return label


def muted_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setProperty("role", "muted")
    label.setWordWrap(True)
    return label


class CollapsibleBox(QWidget):
    """Mục thu gọn được: bấm tiêu đề để hiện/ẩn nội dung.

    Dùng gom nhóm cấu hình cho đỡ tràn màn hình.
    """

    def __init__(self, title: str, collapsed: bool = False,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._toggle = QToolButton()
        self._toggle.setText(title)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(not collapsed)
        self._toggle.setStyleSheet(
            "QToolButton { border: none; font-weight: 700; padding: 4px 0; }"
        )
        self._toggle.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonTextBesideIcon
        )
        self._toggle.setArrowType(
            Qt.ArrowType.DownArrow if not collapsed else Qt.ArrowType.RightArrow
        )
        self._toggle.clicked.connect(self._on_toggle)

        self._content = QWidget()
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(14, 0, 0, 6)
        self._content_layout.setSpacing(6)
        self._content.setVisible(not collapsed)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._toggle)
        outer.addWidget(self._content)

    def _on_toggle(self) -> None:
        show = self._toggle.isChecked()
        self._toggle.setArrowType(
            Qt.ArrowType.DownArrow if show else Qt.ArrowType.RightArrow
        )
        self._content.setVisible(show)

    def add_layout(self, layout: QLayout) -> None:
        self._content_layout.addLayout(layout)

    def add_widget(self, widget: QWidget) -> None:
        self._content_layout.addWidget(widget)


class _VoiceComboDelegate(QStyledItemDelegate):
    """Chỉ tạo combo lúc sửa ô, không giữ hàng nghìn widget trong bảng."""

    def createEditor(self, parent, _option, _index):  # noqa: N802 - Qt API
        combo = QComboBox(parent)
        table = self.parent()
        combo.addItems([table.FOLLOW_SPEAKER, *table._voices])
        return combo

    def setEditorData(self, editor, index) -> None:  # noqa: N802 - Qt API
        value = str(index.data() or "")
        editor.setCurrentText(
            value if editor.findText(value) >= 0 else editor.itemText(0)
        )

    def setModelData(self, editor, model, index) -> None:  # noqa: N802 - Qt API
        model.setData(index, editor.currentText())


class SubtitleTable(QTableWidget):
    """Bảng sub kiểu studio: sửa được nội dung + cột so sánh clip/voice.

    Cột 1-6 chỉnh sửa được; cột Giọng dùng combo mở khi cần. Các cột thời
    lượng/khớp/nghe chỉ đọc để bảng vẫn nhẹ với dự án dài.
    """

    #: Phát khi người dùng sửa một ô (sau khi đã ghi vào segment).
    segment_edited = pyqtSignal(object)  # Segment
    #: Phát khi bấm nút ▶ của một dòng (số dòng) - nghe voice dòng đó.
    play_requested = pyqtSignal(int)

    COLUMNS = ("#", "Bắt đầu", "Kết thúc", "Nhân vật", "Giới tính",
               "Gốc", "Bản dịch", "Giọng", "Đoạn (s)", "Giọng (s)",
               "Khớp", "Nghe")
    EDITABLE_MAX = 7  # cột 1..7 sửa được

    def __init__(self) -> None:
        super().__init__(0, len(self.COLUMNS))
        self.setHorizontalHeaderLabels(self.COLUMNS)
        self.verticalHeader().setVisible(False)
        header = self.horizontalHeader()
        for col in (0, 1, 2, 3, 4, 7, 8, 9, 10, 11):
            # ResizeToContents quét lại toàn bộ ô mỗi khi nạp thêm một lô. Với
            # vài nghìn dòng, việc đo chữ này khóa event loop lâu hơn cả đọc DB.
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
        for col, width in {
            0: 46, 1: 72, 2: 72, 3: 110, 4: 72, 7: 150,
            8: 72, 9: 72, 10: 110, 11: 54,
        }.items():
            self.setColumnWidth(col, width)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self._segments: list[Segment] = []
        self._voices: list[str] = []
        self._loading = False
        self._cps_target = 15.0
        self._load_generation = 0
        self.setItemDelegateForColumn(7, _VoiceComboDelegate(self))
        self.itemChanged.connect(self._on_item_changed)
        self.cellClicked.connect(self._on_cell_clicked)

    #: Mục đầu của combo giọng - dòng không có giọng riêng thì dùng mặc định.
    FOLLOW_SPEAKER = "(giọng mặc định)"

    def set_cps_target(self, value: float) -> None:
        self._cps_target = max(8.0, float(value or 15.0))

    def _fit_value(self, seg: Segment, sync: str = "—") -> tuple[str, QColor, str]:
        if not (seg.translation or "").strip():
            return sync, QColor("#94a3b8"), "Chưa có bản dịch để tính tốc độ đọc."
        cps = subtitle_cps(seg.translation, seg.duration)
        if cps <= self._cps_target:
            marker, color = "✓", QColor("#86efac")
        elif cps <= self._cps_target * 1.2:
            marker, color = "⚠", QColor("#fde68a")
        else:
            marker, color = "!", QColor("#fca5a5")
        label = f"CPS {cps:.1f} {marker}"
        if sync and sync != "—":
            label = f"{sync} · {label}"
        tip = (
            f"Tốc độ bản dịch: {cps:.1f} ký tự/giây; "
            f"mục tiêu ≤ {self._cps_target:.1f}."
        )
        return label, color, tip

    def refresh_fit_cell(self, row: int, seg: Segment, sync: str | None = None) -> None:
        item = self.item(row, 10)
        if item is None:
            return
        raw_sync = sync if sync is not None else "—"
        value, color, tip = self._fit_value(seg, raw_sync)
        item.setText(value)
        item.setForeground(color)
        item.setToolTip(tip)

    def load(self, segments: list[Segment],
             sync_info: dict[int, tuple[str, str]] | None = None,
             voices: list[str] | None = None) -> None:
        """Đổ danh sách segment vào bảng.

        Args:
            sync_info: {line: (voice_giây, trạng_thái_sync)} - tùy chọn.
            voices: danh sách giọng cho combo từng dòng - tùy chọn.
        """
        self._load_generation += 1  # hủy lô nạp cũ nếu người dùng đổi dự án
        self._loading = True
        old_block = self.blockSignals(True)
        self.setUpdatesEnabled(False)
        try:
            self._segments = segments
            sync_info = sync_info or {}
            self._voices = list(voices or [])
            self.setRowCount(len(segments))
            for row, seg in enumerate(segments):
                voice_s, sync = sync_info.get(seg.line, ("—", "—"))
                has_voice = voice_s != "—"
                values = (
                    str(seg.line), f"{seg.start:.2f}", f"{seg.end:.2f}",
                    seg.speaker, gender_label(seg.gender), seg.text,
                    seg.translation,
                )
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if col == 0:
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    if seg.ocr_warning:
                        item.setForeground(QColor("#fecaca"))
                        item.setBackground(QColor("#4c1118"))
                        item.setToolTip(
                            "Cần kiểm tra nhận diện thủ công: " + seg.ocr_warning
                        )
                    self.setItem(row, col, item)

                # Combo giọng chỉ được tạo khi người dùng sửa ô.
                voice_value = (
                    seg.voice if seg.voice and seg.voice in self._voices
                    else self.FOLLOW_SPEAKER
                )
                voice_item = QTableWidgetItem(voice_value)
                voice_item.setToolTip("Bấm đúp để chọn giọng riêng cho dòng.")
                self.setItem(row, 7, voice_item)

                for offset, value in enumerate(
                        (f"{seg.duration:.2f}", voice_s, sync)):
                    item = QTableWidgetItem(value)
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    self.setItem(row, 8 + offset, item)
                self.refresh_fit_cell(row, seg, sync)

                # Ô nghe nhẹ hơn một QPushButton thường trực cho mỗi hàng.
                play_item = QTableWidgetItem("▶" if has_voice else "▶ ?")
                play_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                play_item.setFlags(
                    play_item.flags() & ~Qt.ItemFlag.ItemIsEditable
                )
                play_item.setToolTip(
                    "Nghe giọng đọc" if has_voice
                    else "Chưa có giọng đọc"
                )
                self.setItem(row, 11, play_item)
        finally:
            self.setUpdatesEnabled(True)
            self.blockSignals(old_block)
            self._loading = False

    def load_deferred(
        self, segments: list[Segment],
        sync_info: dict[int, tuple[str, str]] | None = None,
        voices: list[str] | None = None,
        batch_size: int = 50,
    ) -> None:
        """Nạp bảng lớn theo lô để giao diện không bị Windows báo treo."""
        self._load_generation += 1
        generation = self._load_generation
        self._segments = segments
        self._voices = list(voices or [])
        info = sync_info or {}
        self._loading = True
        old_block = self.blockSignals(True)
        self.clearContents()
        self.setRowCount(len(segments))
        self.blockSignals(old_block)

        def add_batch(start: int = 0) -> None:
            if generation != self._load_generation:
                return
            stop = min(len(segments), start + max(25, int(batch_size)))
            old = self.blockSignals(True)
            self.setUpdatesEnabled(False)
            try:
                for row in range(start, stop):
                    self._populate_deferred_row(row, segments[row], info)
            finally:
                self.setUpdatesEnabled(True)
                self.blockSignals(old)
                self.viewport().update()
            if stop < len(segments):
                # Nhường một nhịp thật cho Windows xử lý repaint/input. Timer 0
                # vẫn có thể chiếm kín event queue khi bảng có 30-40 nghìn ô.
                QTimer.singleShot(12, lambda: add_batch(stop))
            else:
                self._loading = False

        QTimer.singleShot(0, add_batch)

    def update_sync_info_deferred(
        self, sync_info: dict[int, tuple[str, str]], batch_size: int = 100,
    ) -> None:
        """Cập nhật metadata voice theo lô để dự án dài không khóa giao diện."""
        generation = self._load_generation

        def update_batch(start: int = 0) -> None:
            if generation != self._load_generation:
                return
            stop = min(len(self._segments), start + max(25, int(batch_size)))
            old = self.blockSignals(True)
            self.setUpdatesEnabled(False)
            try:
                for row in range(start, stop):
                    seg = self._segments[row]
                    voice_s, sync = sync_info.get(seg.line, ("—", "—"))
                    for column, value in ((9, voice_s), (10, sync)):
                        item = self.item(row, column)
                        if item is not None:
                            item.setText(value)
                    self.refresh_fit_cell(row, seg, sync)
                    play = self.item(row, 11)
                    if play is not None:
                        has_voice = voice_s != "—"
                        play.setText("▶" if has_voice else "▶ ?")
                        play.setToolTip(
                            "Nghe giọng đọc" if has_voice else "Chưa có giọng đọc"
                        )
            finally:
                self.setUpdatesEnabled(True)
                self.blockSignals(old)
                self.viewport().update()
            if stop < len(self._segments):
                QTimer.singleShot(12, lambda: update_batch(stop))

        QTimer.singleShot(0, update_batch)

    def _populate_deferred_row(
        self, row: int, seg: Segment,
        sync_info: dict[int, tuple[str, str]],
    ) -> None:
        voice_s, sync = sync_info.get(seg.line, ("—", "—"))
        has_voice = voice_s != "—"
        values = (
            str(seg.line), f"{seg.start:.2f}", f"{seg.end:.2f}",
            seg.speaker, gender_label(seg.gender), seg.text, seg.translation,
        )
        for col, value in enumerate(values):
            item = QTableWidgetItem(value)
            if col == 0:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if seg.ocr_warning:
                item.setForeground(QColor("#fecaca"))
                item.setBackground(QColor("#4c1118"))
                item.setToolTip("Cần kiểm tra nhận diện thủ công: " + seg.ocr_warning)
            self.setItem(row, col, item)
        voice_value = (
            seg.voice if seg.voice and seg.voice in self._voices
            else self.FOLLOW_SPEAKER
        )
        voice_item = QTableWidgetItem(voice_value)
        voice_item.setToolTip("Bấm đúp để chọn giọng riêng cho dòng.")
        self.setItem(row, 7, voice_item)
        for offset, value in enumerate((f"{seg.duration:.2f}", voice_s, sync)):
            item = QTableWidgetItem(value)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.setItem(row, 8 + offset, item)
        self.refresh_fit_cell(row, seg, sync)
        play_item = QTableWidgetItem("▶" if has_voice else "▶ ?")
        play_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        play_item.setFlags(play_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        play_item.setToolTip("Nghe giọng đọc" if has_voice else "Chưa có giọng đọc")
        self.setItem(row, 11, play_item)

    def update_sync_info(
        self, sync_info: dict[int, tuple[str, str]]
    ) -> None:
        """Chỉ cập nhật cột voice/sync, không dựng lại hàng nghìn ô phụ đề."""
        self._loading = True
        old_block = self.blockSignals(True)
        self.setUpdatesEnabled(False)
        try:
            for row, seg in enumerate(self._segments):
                voice_s, sync = sync_info.get(seg.line, ("—", "—"))
                values = (voice_s, sync)
                for column, value in ((9, values[0]), (10, values[1])):
                    item = self.item(row, column)
                    if item is None:
                        item = QTableWidgetItem()
                        item.setFlags(
                            item.flags() & ~Qt.ItemFlag.ItemIsEditable
                        )
                        self.setItem(row, column, item)
                    item.setText(value)
                self.refresh_fit_cell(row, seg, sync)
                play = self.item(row, 11)
                if play is None:
                    play = QTableWidgetItem()
                    play.setFlags(
                        play.flags() & ~Qt.ItemFlag.ItemIsEditable
                    )
                    play.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    self.setItem(row, 11, play)
                has_voice = voice_s != "—"
                play.setText("▶" if has_voice else "▶ ?")
                play.setToolTip(
                    "Nghe giọng đọc" if has_voice
                    else "Chưa có giọng đọc"
                )
        finally:
            self.setUpdatesEnabled(True)
            self.blockSignals(old_block)
            self._loading = False
        self.viewport().update()

    def _on_cell_clicked(self, row: int, column: int) -> None:
        if column == 11 and 0 <= row < len(self._segments):
            self.play_requested.emit(self._segments[row].line)

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        """Ghi thay đổi từ ô về Segment tương ứng."""
        if self._loading or item.row() >= len(self._segments):
            return
        if item.column() > self.EDITABLE_MAX:
            return
        seg = self._segments[item.row()]
        col, text = item.column(), item.text()
        try:
            if col == 1:
                seg.start = float(text)
            elif col == 2:
                seg.end = float(text)
            elif col == 3:
                seg.speaker = text.strip()
            elif col == 4:
                seg.gender = normalize_gender(text)
                label = gender_label(seg.gender)
                if item.text() != label:
                    item.setText(label)
            elif col == 5:
                seg.text = text
                # Người dùng đã kiểm tra/sửa trực tiếp nội dung nguồn.
                seg.ocr_warning = ""
            elif col == 6:
                seg.translation = text
            elif col == 7:
                seg.voice = "" if text == self.FOLLOW_SPEAKER else text
        except ValueError:
            return  # nhập thời gian sai thì bỏ qua
        self.segment_edited.emit(seg)


class PipelineProgress(QWidget):
    """Panel tiến độ: danh sách bước, thanh %, nút Pause/Resume/Cancel."""

    pause_clicked = pyqtSignal()
    resume_clicked = pyqtSignal()
    cancel_clicked = pyqtSignal()

    ICON_PENDING, ICON_RUNNING, ICON_DONE, ICON_FAILED = "○", "◐", "●", "✕"

    def __init__(self) -> None:
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(title_label("Tiến độ"))

        self._step_labels: dict[str, QLabel] = {}
        for key, label in PIPELINE_STEPS:
            lbl = QLabel(f"{self.ICON_PENDING}  {label}")
            lbl.setProperty("role", "muted")
            self._step_labels[key] = lbl
            layout.addWidget(lbl)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        layout.addWidget(self.bar)

        self.message = muted_label("Sẵn sàng.")
        layout.addWidget(self.message)

        buttons = QHBoxLayout()
        self.btn_pause = QPushButton("Tạm dừng")
        self.btn_resume = QPushButton("Tiếp tục")
        self.btn_cancel = QPushButton("Hủy")
        self.btn_cancel.setProperty("variant", "danger")
        for btn in (self.btn_pause, self.btn_resume, self.btn_cancel):
            btn.setEnabled(False)
            buttons.addWidget(btn)
        layout.addLayout(buttons)

        self.btn_pause.clicked.connect(self.pause_clicked)
        self.btn_resume.clicked.connect(self.resume_clicked)
        self.btn_cancel.clicked.connect(self.cancel_clicked)

    # ---------- Cập nhật từ engine ----------

    def reset(self) -> None:
        for key, (label_key, label) in zip(self._step_labels, PIPELINE_STEPS):
            self._step_labels[key].setText(f"{self.ICON_PENDING}  {label}")
        self.bar.setValue(0)
        self.message.setText("Sẵn sàng.")

    def set_running(self, running: bool) -> None:
        self.btn_pause.setEnabled(running)
        self.btn_resume.setEnabled(running)
        self.btn_cancel.setEnabled(running)

    def _set_icon(self, key: str, icon: str) -> None:
        label = self._step_labels.get(key)
        if label:
            text = dict(PIPELINE_STEPS).get(key, key)
            label.setText(f"{icon}  {text}")

    def on_step_started(self, key: str) -> None:
        self._set_icon(key, self.ICON_RUNNING)

    def on_step_progress(self, key: str, pct: int, msg: str) -> None:
        self.bar.setValue(pct)
        self.message.setText(msg)

    def on_step_finished(self, key: str) -> None:
        self._set_icon(key, self.ICON_DONE)

    def on_step_failed(self, key: str, error: str) -> None:
        self._set_icon(key, self.ICON_FAILED)
        self.message.setText(f"Lỗi: {error}")


class ApiStatusTable(QTableWidget):
    """Bảng trạng thái API key cho panel phải."""

    COLUMNS = ("Tên", "Model", "Trạng thái", "Độ trễ")

    def __init__(self) -> None:
        super().__init__(0, len(self.COLUMNS))
        self.setHorizontalHeaderLabels(self.COLUMNS)
        self.verticalHeader().setVisible(False)
        self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.setMaximumHeight(140)

    def refresh(self, rows: list[dict]) -> None:
        self.setRowCount(len(rows))
        for row, data in enumerate(rows):
            for col, key in enumerate(("name", "model", "state", "latency")):
                self.setItem(row, col, QTableWidgetItem(str(data.get(key, ""))))

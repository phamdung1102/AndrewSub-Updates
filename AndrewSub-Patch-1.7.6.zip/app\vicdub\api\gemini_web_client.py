﻿"""Gemini Web vision client dùng Chromium profile lâu dài.

Client cung cấp ``read_subtitle_montage`` để pipeline OCR Web dùng lại nguyên
phần crop, montage và dựng Segment.
Không đọc/ghi token thủ công; phiên Google nằm trong persistent browser profile.
"""

from __future__ import annotations

import logging
import re
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)


class GeminiWebError(RuntimeError):
    """Lỗi Gemini Web có thông điệp phù hợp để hiển thị lên UI."""


class GeminiWebClient:
    """Gửi montage lên Gemini Web qua một Chromium persistent context."""

    RESPONSE_SELECTOR = (
        "message-content, model-response, .model-response-text, "
        ".markdown-main-panel, [data-message-author-role='model']"
    )
    PROMPT_SELECTORS = (
        "div[contenteditable='true'][role='textbox']",
        "rich-textarea div[contenteditable='true']",
        "textarea",
    )

    def __init__(
        self,
        data_dir: str,
        report: Callable[[int, str], None] | None = None,
        login_timeout: int = 300,
        response_timeout: int = 180,
        profile_name: str = "1",
        allow_interactive_login: bool = True,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.profile_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", profile_name or "1").strip("_") or "1"
        suffix = "" if self.profile_name in ("1", "main", "default") else f"_{self.profile_name}"
        self.profile_dir = self.data_dir / f"gemini_web_profile{suffix}"
        self.login_marker = self.data_dir / f"gemini_web_login{suffix}.ok"
        self.report = report
        self.login_timeout = max(30, int(login_timeout))
        self.response_timeout = max(30, int(response_timeout))
        self.allow_interactive_login = bool(allow_interactive_login)
        self._playwright = None
        self._context = None
        self._page = None
        self._translation_ready = False

    def _log(self, percent: int, message: str) -> None:
        logger.info(message)
        if self.report:
            self.report(percent, message)

    def __enter__(self) -> "GeminiWebClient":
        try:
            from playwright.sync_api import sync_playwright  # noqa: PLC0415
        except ImportError as exc:
            raise GeminiWebError(
                "OCR Web cần Playwright. Chạy: pip install playwright"
            ) from exc

        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self._playwright = sync_playwright().start()
        try:
            # Đã đăng nhập trước đó: chạy ngầm ngay. Marker chỉ là tối ưu UX;
            # cookie thật vẫn được kiểm tra để phát hiện phiên hết hạn.
            if self.login_marker.exists():
                self._launch_context(headless=True)
                if self._is_signed_in():
                    self._wait_until_ready()
                    return self
                self._close_context()
                self.login_marker.unlink(missing_ok=True)

            if not self.allow_interactive_login:
                raise GeminiWebError(
                    f"Profile {self.profile_name} chưa đăng nhập hoặc phiên đã hết hạn. "
                    "Vào Cài đặt → Dịch & Đồng bộ để kiểm tra/đăng nhập lại."
                )

            # Chỉ hiện Chrome khi cần người dùng đăng nhập.
            self._launch_context(headless=False)
            self._wait_until_ready()
            self.login_marker.touch()

            # Giữ nguyên context vừa đăng nhập. Đóng rồi mở persistent profile
            # ngay lập tức khiến Chrome chưa nhả khóa và thoát exit code 21.
            # Lần chạy kế tiếp (đã có marker) vẫn tự mở headless bình thường.
            self._log(5, f"Profile {self.profile_name}: đăng nhập thành công và sẵn sàng.")
            return self
        except Exception:
            self.close()
            raise

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()

    def _launch_context(self, headless: bool) -> None:
        """Mở persistent Chrome và điều hướng tới Gemini."""
        assert self._playwright is not None
        args = [] if headless else [
            "--start-maximized",
            "--disable-blink-features=AutomationControlled",
        ]
        last_error = None
        for attempt in range(3):
            if attempt:
                # Chrome cần thời gian nhả singleton/profile sau khi context
                # crash. Mở lại tức thì thường thoát với exit code 21.
                time.sleep(2.0 * attempt)
            try:
                self._context = self._playwright.chromium.launch_persistent_context(
                    str(self.profile_dir),
                    channel="chrome",
                    headless=headless,
                    viewport={"width": 1380, "height": 860},
                    args=args,
                    chromium_sandbox=True,
                    ignore_default_args=["--enable-automation"],
                )
                break
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                self._context = None
        if self._context is None:
            raise GeminiWebError(
                f"Không thể mở phiên trình duyệt {self.profile_name} sau 3 lần thử. "
                "Hãy đóng các cửa sổ nhận diện cũ rồi chạy lại."
            ) from last_error
        self._page = (
            self._context.pages[0]
            if self._context.pages else self._context.new_page()
        )
        self._page.goto(
            "https://gemini.google.com/app",
            wait_until="domcontentloaded",
            timeout=60_000,
        )

    def _close_context(self) -> None:
        if self._context is not None:
            try:
                self._context.close()
            except Exception:  # noqa: BLE001
                pass
            self._context = None
            time.sleep(0.5)
        self._page = None
        self._translation_ready = False

    def close(self) -> None:
        self._close_context()
        if self._playwright is not None:
            try:
                self._playwright.stop()
            except Exception:  # noqa: BLE001
                pass
            self._playwright = None

    def _ensure_open(self) -> None:
        """Chỉ mở Chrome khi montage đầu tiên thực sự chuẩn bị được gửi."""
        page_alive = False
        if self._page is not None:
            try:
                page_alive = not self._page.is_closed()
            except Exception:  # noqa: BLE001
                page_alive = False
        if page_alive and self._context is not None:
            return
        # Giữ Playwright sống và chỉ tái tạo browser context. Việc stop/start
        # ngay lập tức dễ khiến Chrome chưa nhả persistent profile (exit 21).
        self._close_context()
        if self._playwright is None:
            self.__enter__()
        else:
            self._launch_context(headless=True)
            self._wait_until_ready()

    def _prompt_box(self):
        if self._page is None or self._page.is_closed():
            return None
        for selector in self.PROMPT_SELECTORS:
            locator = self._page.locator(selector).last
            try:
                if locator.count() and locator.is_visible():
                    return locator
            except Exception:  # noqa: BLE001
                continue
        return None

    @staticmethod
    def _first_visible(locator):
        try:
            count = locator.count()
        except Exception:  # noqa: BLE001
            return None
        for idx in range(count):
            item = locator.nth(idx)
            try:
                if item.is_visible():
                    return item
            except Exception:  # noqa: BLE001
                continue
        return None

    def _is_signed_in(self) -> bool:
        if self._context is None:
            return False
        try:
            cookie_names = {item["name"] for item in self._context.cookies()}
        except Exception:  # noqa: BLE001
            return False
        return any(
            name in cookie_names
            for name in ("__Secure-1PSID", "__Secure-3PSID", "SID")
        )

    def account_email(self) -> str:
        """Đọc email hiển thị trong UI tài khoản; không truy cập token/cookie thô."""
        self._ensure_open()
        assert self._page is not None
        email_pattern = re.compile(
            r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}",
            re.IGNORECASE,
        )
        selectors = (
            "[aria-label*='Google Account']",
            "[aria-label*='Tài khoản Google']",
            "button[aria-label]",
            "[title]",
        )
        def scan_attributes() -> str:
            for selector in selectors:
                locator = self._page.locator(selector)
                try:
                    count = min(locator.count(), 80)
                except Exception:  # noqa: BLE001
                    continue
                for index in range(count):
                    item = locator.nth(index)
                    for attribute in ("aria-label", "title"):
                        try:
                            value = item.get_attribute(attribute) or ""
                        except Exception:  # noqa: BLE001
                            value = ""
                        match = email_pattern.search(value)
                        if match:
                            return match.group(0).lower()
            return ""

        found = scan_attributes()
        if found:
            return found
        # Một số bản Gemini chỉ đưa email vào menu sau khi bấm avatar.
        for selector in (
            "[aria-label*='Google Account']",
            "[aria-label*='Tài khoản Google']",
            "a[href*='accounts.google.com']",
        ):
            button = self._first_visible(self._page.locator(selector))
            if button is None:
                continue
            try:
                button.click()
                self._page.wait_for_timeout(350)
                found = scan_attributes()
                if found:
                    self._page.keyboard.press("Escape")
                    return found
                body = self._page.locator("body").inner_text(timeout=2_000)
                match = email_pattern.search(body)
                self._page.keyboard.press("Escape")
                if match:
                    return match.group(0).lower()
            except Exception:  # noqa: BLE001
                continue
        return ""

    def _wait_until_ready(self) -> None:
        self._log(4, "Đang kiểm tra phiên Gemini Web...")
        deadline = time.monotonic() + self.login_timeout
        announced = False
        while time.monotonic() < deadline:
            if self._page is None or self._page.is_closed():
                raise GeminiWebError("Cửa sổ Gemini Web đã bị đóng.")
            # Gemini vẫn hiện ô prompt ở chế độ khách nên chỉ kiểm tra textbox
            # sẽ báo đăng nhập giả. Cookie SID là tín hiệu phiên Google thật.
            if self._is_signed_in() and self._prompt_box() is not None:
                self._log(5, "Gemini Web đã sẵn sàng.")
                return
            if not announced:
                self._log(
                    4,
                    "Nếu Gemini yêu cầu, hãy đăng nhập Google trong cửa sổ "
                    "Chrome; AndrewSub sẽ tự tiếp tục sau khi đăng nhập xong.",
                )
                announced = True
            self._page.wait_for_timeout(1_000)
        raise GeminiWebError(
            "Hết thời gian chờ đăng nhập Gemini Web. Hãy thử lại và hoàn tất "
            "đăng nhập trong cửa sổ Chrome."
        )

    def _prefer_translation_model(self) -> None:
        """Best-effort chọn 3.1 Pro cho tác vụ chữ; UI đổi thì vẫn tiếp tục an toàn."""
        if self._page is None or self._page.is_closed():
            return
        try:
            visible_pro = self._first_visible(
                self._page.get_by_role(
                    "button", name=re.compile(r"3[.]1\s*Pro", re.IGNORECASE)
                )
            )
            if visible_pro is not None:
                return

            switcher = None
            selectors = (
                "button[aria-label*='model' i]",
                "button[aria-label*='mô hình' i]",
                "button[aria-label*='mode' i]",
                "button:has-text('Flash')",
                "button:has-text('Pro')",
            )
            for selector in selectors:
                switcher = self._first_visible(self._page.locator(selector))
                if switcher is not None:
                    break
            if switcher is None:
                self._log(5, "Không thấy bộ chọn model; giữ model hiện tại của profile.")
                return
            switcher.click()
            self._page.wait_for_timeout(350)
            option = self._first_visible(
                self._page.get_by_text(
                    re.compile(r"3[.]1\s*Pro", re.IGNORECASE), exact=False
                )
            )
            if option is None:
                self._page.keyboard.press("Escape")
                self._log(5, "Profile chưa có lựa chọn 3.1 Pro; giữ model hiện tại.")
                return
            option.click()
            self._page.wait_for_timeout(500)
            self._log(5, "Đã ưu tiên Gemini 3.1 Pro cho phiên dịch.")
        except Exception as exc:  # noqa: BLE001
            self._log(5, f"Không đổi được model; giữ model hiện tại: {exc}")

    def _prepare_translation_chat(self) -> None:
        """Giữ nguyên phiên/model; mỗi lô chỉ mở chat mới, không tải lại trang."""
        assert self._page is not None
        if not self._translation_ready:
            self._wait_until_ready()
            self._prefer_translation_model()
            self._translation_ready = True
            return

        selectors = (
            "[data-test-id='new-chat-button']",
            "button[aria-label*='New chat' i]",
            "button[aria-label*='Cuộc trò chuyện mới' i]",
            "a[aria-label*='New chat' i]",
            "a[aria-label*='Cuộc trò chuyện mới' i]",
            "a[href='/app']",
        )
        for selector in selectors:
            button = self._first_visible(self._page.locator(selector))
            if button is None:
                continue
            try:
                button.click()
                self._page.wait_for_timeout(250)
                if self._prompt_box() is not None:
                    return
            except Exception:  # noqa: BLE001
                continue

        # UI Gemini đổi hoặc nút chat mới bị ẩn: tải lại là đường dự phòng an toàn.
        self._page.goto(
            "https://gemini.google.com/app",
            wait_until="domcontentloaded",
            timeout=60_000,
        )
        self._wait_until_ready()

    @staticmethod
    def _parse_numbered_lines(text: str) -> dict[int, str]:
        cleaned = re.sub(r"```(?:\w+)?", "", text or "").strip().strip("`")
        result: dict[int, str] = {}
        for raw in cleaned.splitlines():
            match = re.match(r"\s*\[?(\d+)\]?\s*[:.\)\-]?\s*(.*)$", raw)
            if match:
                result[int(match.group(1))] = match.group(2).strip()
        return result

    @staticmethod
    def _missing_ids(ids: list[int], parsed: dict[int, str]) -> list[int]:
        """Return panel IDs that Gemini did not include."""
        return sorted(set(ids) - parsed.keys())

    @staticmethod
    def _build_prompt(ids: list[int], lang_hint: str = "", retry: bool = False) -> str:
        """Build a strict montage OCR prompt that is easier to parse."""
        language = f" The subtitle language is mainly {lang_hint}." if lang_hint else ""
        retry_note = (
            " Previous answer missed some IDs. Be strict this time."
            if retry else ""
        )
        return (
            "The image is a vertical montage of subtitle panels. Each panel has "
            f"an ID number on the left.{language}{retry_note}\n"
            "Read the subtitle text exactly as written. Do not translate. Do not "
            "treat the ID number as subtitle text.\n"
            "Return exactly one line for every required ID, using this format:\n"
            "<ID>: <subtitle text>\n"
            "If a panel has no subtitle text, still return '<ID>:'.\n"
            "No markdown, no explanation, no bullet list.\n"
            "Required IDs: " + ", ".join(str(value) for value in ids)
        )

    def _upload(self, image_path: str) -> None:
        assert self._page is not None
        self._log(5, "Đang tải montage lên Gemini Web...")
        inputs = self._page.locator("input[type='file']")
        if inputs.count():
            inputs.last.set_input_files(image_path)
            self._wait_upload_ready()
            self._log(5, "Đã gắn montage vào Gemini Web.")
            return

        # UI hiện tại: nút “Upload & tools” -> menuitem “Upload files” ->
        # file chooser. Hỗ trợ thêm nhãn Việt/Anh cũ để ít phụ thuộc locale.
        menu_button = None
        for label in (
            "Upload & tools", "Open upload file menu",
            "Nội dung tải lên và công cụ", "Tải lên và công cụ",
            "Tải tệp và công cụ",
        ):
            candidate = self._page.get_by_role("button", name=label, exact=False)
            menu_button = self._first_visible(candidate)
            if menu_button is not None:
                break
        if menu_button is None:
            raise GeminiWebError("Không tìm thấy nút 'Upload & tools' của Gemini Web.")
        menu_button.click()
        self._page.wait_for_timeout(300)

        upload_item = None
        for label in ("Upload files", "Tải tệp lên", "Tải tệp"):
            # Accessible name còn có mô tả loại tệp ở phía sau, ví dụ
            # “Tải tệp lên. Tài liệu, dữ liệu, tệp mã nguồn”.
            candidate = self._page.get_by_role("menuitem", name=label, exact=False)
            upload_item = self._first_visible(candidate)
            if upload_item is not None:
                break
        if upload_item is None:
            raise GeminiWebError(
                "Không thấy mục 'Upload files'. Phiên có thể chưa đăng nhập "
                "hoặc tài khoản chưa được phép tải tệp."
            )
        try:
            with self._page.expect_file_chooser(timeout=10_000) as chooser_info:
                upload_item.click()
            chooser_info.value.set_files(image_path)
        except Exception as exc:  # noqa: BLE001
            raise GeminiWebError(f"Không mở được hộp chọn ảnh Gemini Web: {exc}") from exc
        self._wait_upload_ready()
        self._log(5, "Đã gắn montage vào Gemini Web.")

    def _wait_upload_ready(self) -> None:
        """Wait for Gemini Web to attach the image instead of using a fixed sleep."""
        assert self._page is not None
        selectors = (
            "img[src^='blob:']",
            "img[src^='data:']",
            "[aria-label*='Remove']",
            "[aria-label*='Xóa']",
            "[aria-label*='Tệp']",
            "[aria-label*='file']",
        )
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            for selector in selectors:
                try:
                    locator = self._page.locator(selector)
                    if locator.count():
                        self._page.wait_for_timeout(800)
                        return
                except Exception:  # noqa: BLE001
                    continue
            self._page.wait_for_timeout(500)
        self._page.wait_for_timeout(3_000)

    def _wait_response(self, previous_count: int) -> str:
        assert self._page is not None
        deadline = time.monotonic() + self.response_timeout
        last_text = ""
        stable = 0
        first_text_at = None
        while time.monotonic() < deadline:
            responses = self._page.locator(self.RESPONSE_SELECTOR)
            count = responses.count()
            if count > previous_count:
                try:
                    current = responses.last.inner_text().strip()
                except Exception:  # noqa: BLE001
                    current = ""
                if current and first_text_at is None:
                    first_text_at = time.monotonic()
                if current and current == last_text:
                    stable += 1
                    if stable >= 5 and time.monotonic() - (first_text_at or 0) >= 5:
                        return current
                else:
                    last_text = current
                    stable = 0
            self._page.wait_for_timeout(1_000)
        if last_text:
            return last_text
        self._dump_debug_page("no_response")
        raise GeminiWebError("Gemini Web không trả lời trong thời gian chờ.")

    def _dump_debug_page(self, reason: str) -> None:
        """Save a local snapshot of the hidden Gemini page for diagnosis."""
        if self._page is None or self._page.is_closed():
            return
        debug_dir = self.data_dir / "debug"
        debug_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base = debug_dir / f"gemini_web_{reason}_{stamp}"
        try:
            self._page.screenshot(path=str(base.with_suffix(".png")), full_page=True)
        except Exception:  # noqa: BLE001
            pass
        try:
            summary = self._page.evaluate(
                """() => ({
                    url: location.href,
                    title: document.title,
                    bodyText: document.body ? document.body.innerText.slice(0, 12000) : "",
                    buttons: Array.from(document.querySelectorAll("button"))
                        .map((b, i) => ({
                            i,
                            text: (b.innerText || "").trim(),
                            aria: b.getAttribute("aria-label") || "",
                            disabled: b.disabled || b.getAttribute("aria-disabled") === "true",
                            visible: !!(b.offsetWidth || b.offsetHeight || b.getClientRects().length)
                        }))
                        .filter(b => b.visible)
                        .slice(-80),
                    textboxes: Array.from(document.querySelectorAll("[contenteditable='true'], textarea"))
                        .map((b, i) => ({
                            i,
                            text: (b.innerText || b.value || "").slice(0, 2000),
                            aria: b.getAttribute("aria-label") || "",
                            role: b.getAttribute("role") || ""
                        }))
                })"""
            )
            base.with_suffix(".txt").write_text(str(summary), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        self._log(5, f"Đã lưu debug Gemini Web: {base}.png/.txt")

    def _fill_prompt(self, prompt: str) -> None:
        assert self._page is not None
        box = self._prompt_box()
        if box is None:
            raise GeminiWebError("Không tìm thấy ô nhập prompt Gemini Web.")
        box.click(timeout=15_000)
        try:
            box.fill(prompt, timeout=15_000)
        except Exception:  # noqa: BLE001
            # Gemini đổi rich textarea khá thường xuyên; keyboard insert bền hơn
            # khi Locator.fill không nhận contenteditable hiện tại.
            self._page.keyboard.press("Control+A")
            self._page.keyboard.insert_text(prompt)
        self._page.wait_for_timeout(500)

    def _send_prompt(self) -> None:
        assert self._page is not None
        selectors = (
            "button[aria-label*='Send']",
            "button[aria-label*='send']",
            "button[aria-label*='Submit']",
            "button[aria-label*='submit']",
            "button[aria-label*='Gửi']",
            "button[data-testid*='send']",
            "button[type='submit']",
        )
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            for selector in selectors:
                try:
                    button = self._page.locator(selector).last
                    if button.count() and button.is_visible() and button.is_enabled():
                        button.click(timeout=10_000)
                        self._page.wait_for_timeout(1_500)
                        return
                except Exception:  # noqa: BLE001
                    continue
            for label in ("Send message", "Send", "Submit", "Gửi tin nhắn", "Gửi"):
                try:
                    button = self._page.get_by_role("button", name=label, exact=False).last
                    if button.count() and button.is_visible() and button.is_enabled():
                        button.click(timeout=10_000)
                        self._page.wait_for_timeout(1_500)
                        return
                except Exception:  # noqa: BLE001
                    continue
            self._page.wait_for_timeout(500)

        self._page.keyboard.press("Enter")
        self._page.wait_for_timeout(1_500)

    def read_subtitle_montage(
        self, montage_png: bytes, ids: list[int], lang_hint: str = ""
    ) -> dict[int, str]:
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                suffix=".png", prefix="vicdub_montage_", delete=False,
                dir=str(self.data_dir),
            ) as temp:
                temp.write(montage_png)
                temp_path = temp.name

            last_error = ""
            for attempt in range(1, 3):
                try:
                    self._ensure_open()
                    assert self._page is not None

                    # New chat per attempt so old responses do not affect parsing.
                    self._page.goto(
                        "https://gemini.google.com/app",
                        wait_until="domcontentloaded",
                        timeout=60_000,
                    )
                    self._wait_until_ready()
                    self._upload(temp_path)

                    previous_count = self._page.locator(self.RESPONSE_SELECTOR).count()
                    self._log(5, "Đã tải ảnh, đang gửi prompt Gemini Web...")
                    self._fill_prompt(self._build_prompt(ids, lang_hint, retry=attempt > 1))
                    self._send_prompt()
                    self._log(5, "Đang chờ Gemini Web trả lời...")
                    parsed = self._parse_numbered_lines(self._wait_response(previous_count))
                    self._log(5, "Đã nhận phản hồi Gemini Web, đang kiểm tra đủ panel...")
                    missing = self._missing_ids(ids, parsed)
                    if not missing:
                        return {panel_id: parsed[panel_id] for panel_id in ids}
                    last_error = (
                        "Gemini Web trả thiếu panel: "
                        + ", ".join(str(value) for value in missing)
                    )
                    if attempt < 2:
                        self._log(50, f"{last_error}; thử lại montage...")
                        continue
                except Exception as exc:  # noqa: BLE001
                    last_error = str(exc)
                    if attempt < 2:
                        self._log(50, f"Gemini Web lỗi lần {attempt}/2: {exc}; thử lại...")
                        self._close_context()
                        continue
                raise GeminiWebError(last_error or "Gemini Web không đọc được montage.")
            raise GeminiWebError(last_error or "Gemini Web không đọc được montage.")
        finally:
            if temp_path:
                try:
                    Path(temp_path).unlink(missing_ok=True)
                except OSError:
                    pass

    def generate_text(self, prompt: str) -> str:
        """Gửi prompt chỉ có văn bản bằng profile này và trả phản hồi cuối."""
        last_error = ""
        for attempt in range(2):
            try:
                self._ensure_open()
                assert self._page is not None
                self._prepare_translation_chat()
                previous_count = self._page.locator(self.RESPONSE_SELECTOR).count()
                self._fill_prompt(prompt)
                self._send_prompt()
                return self._wait_response(previous_count)
            except Exception as exc:  # noqa: BLE001
                last_error = str(exc)
                self._close_context()
                if attempt == 0:
                    continue
        raise GeminiWebError(last_error or "Phiên dịch trực tuyến không phản hồi.")

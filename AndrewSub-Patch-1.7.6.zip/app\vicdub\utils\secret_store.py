"""Lưu bí mật theo tài khoản Windows bằng DPAPI."""

from __future__ import annotations

import base64
import ctypes
import os
from ctypes import wintypes


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes) -> tuple[_Blob, object]:
    buf = ctypes.create_string_buffer(data)
    return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf


def protect_secret(value: str) -> str:
    """Mã hóa secret cho đúng user Windows; không mã hóa lại giá trị DPAPI."""
    value = str(value or "")
    if not value or value.startswith("dpapi:"):
        return value
    if os.name != "nt":
        return "base64:" + base64.b64encode(value.encode()).decode()
    source, keepalive = _blob(value.encode("utf-8"))
    target = _Blob()
    if not ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(source), "AndrewSub Voice API", None, None, None, 0,
        ctypes.byref(target),
    ):
        raise ctypes.WinError()
    try:
        raw = ctypes.string_at(target.pbData, target.cbData)
        return "dpapi:" + base64.b64encode(raw).decode("ascii")
    finally:
        ctypes.windll.kernel32.LocalFree(target.pbData)


def unprotect_secret(value: str) -> str:
    """Giải mã secret; vẫn đọc chuỗi rõ cũ để migrate tương thích."""
    value = str(value or "")
    if value.startswith("base64:"):
        return base64.b64decode(value[7:]).decode("utf-8")
    if not value.startswith("dpapi:"):
        return value
    raw = base64.b64decode(value[6:])
    source, keepalive = _blob(raw)
    target = _Blob()
    if not ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(source), None, None, None, None, 0, ctypes.byref(target),
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(target.pbData, target.cbData).decode("utf-8")
    finally:
        ctypes.windll.kernel32.LocalFree(target.pbData)

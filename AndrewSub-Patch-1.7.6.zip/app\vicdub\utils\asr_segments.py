"""Gom Word (từ ASR) thành Segment phụ đề - CJK-aware + glossary.

Segmenter chuẩn của app (`utils/segmenter.py`) nối từ bằng dấu cách, hợp
tiếng Việt/Anh. Nguồn ASR ở đây là tiếng Trung (char-based) nên dùng bộ gom
riêng: cắt tại dấu câu/khoảng lặng/độ dài, không chèn dấu cách giữa chữ Hán,
lùi về dấu câu gần nhất khi tràn (không cắt giữa từ), lọc cue rác (nhạc/nhiễu).

Glossary sửa tên riêng đồng âm TRƯỚC khi dịch (ASR không phân biệt được
江/姜 cùng âm; chỉ bảng thay cố định mới sửa được).
"""

from __future__ import annotations

import re
from dataclasses import replace
from difflib import SequenceMatcher

from vicdub.utils.segmenter import Word
from vicdub.utils.subtitles import Segment

SENT_END = "。！？!?…"
SOFT_BREAK = "，,、；;：:"


def _join(ws: list[Word]) -> str:
    """CJK -> không dấu cách; latin -> dấu cách."""
    cjk = sum(1 for w in ws if w.text and ord(w.text[0]) > 0x2E80)
    sep = "" if cjk > len(ws) / 2 else " "
    parts = [w.text for w in ws]
    return (sep.join(parts) if sep else "".join(parts)).strip()


def _expand_coarse_cjk_words(words: list[Word]) -> list[Word]:
    """Tách response dạng cả cụm thành đơn vị có time để bộ chia câu làm việc.

    Một số máy chủ nhận diện vẫn trả ``word_timestamps`` theo cả câu. Nếu giữ
    nguyên, một ``Word`` 15-30 chữ không thể được cắt tại dấu câu/max_chars.
    Với cụm chủ yếu là CJK, phân bố đều từng ký tự trong chính khoảng thời gian
    của cụm. Timestamp thật từng từ vẫn được giữ nguyên vì các phần tử một ký
    tự không đi qua nhánh này.
    """
    expanded: list[Word] = []
    for word in words:
        text = str(word.text or "").strip()
        chars = [char for char in text if not char.isspace()]
        cjk = sum("\u3400" <= char <= "\u9fff" for char in chars)
        if len(chars) <= 1 or cjk < max(1, len(chars) // 2):
            expanded.append(word)
            continue
        base_start = float(word.start)
        base_end = max(float(word.end), base_start + 0.01 * len(chars))
        duration = base_end - base_start
        step = duration / len(chars)
        for index, char in enumerate(chars):
            start = base_start + index * step
            end = base_start + (index + 1) * step
            expanded.append(Word(
                text=char,
                start=start,
                end=max(start + 0.01, end),
                confidence=float(getattr(word, "confidence", 0.0) or 0.0),
                source=str(getattr(word, "source", "") or ""),
                warning=str(getattr(word, "warning", "") or ""),
            ))
    return expanded


def group_words(
    words: list[Word],
    max_chars: int = 16,
    soft_chars: int = 6,
    max_duration: float = 6.0,
    gap_split: float = 0.5,
    junk_duration: float = 3.5,
    junk_chars: int = 2,
) -> list[Segment]:
    """Word timestamp -> cue phim, ưu tiên giữ trọn câu thay vì cắt theo ngưỡng cứng.

    ``gap_split`` là khoảng nghỉ mềm. Chỉ khoảng nghỉ lớn hơn ngưỡng cứng thích
    nghi mới luôn tách; khoảng nghỉ mềm còn xét dấu câu và độ dài cụm hiện tại.
    """
    words = _expand_coarse_cjk_words(sorted(words, key=lambda w: w.start))
    if not words:
        return []
    # Bản cũ cho phép soft_chars=2 và cắt cứng ở gap=0.35s, làm tiếng Trung bị
    # vụn thành 那 / 个 / 我. Clamp an toàn ngay cả với settings cũ chưa migrate.
    cjk_count = sum(
        1 for word in words for char in str(word.text or "")
        if "\u3400" <= char <= "\u9fff"
    )
    total_letters = sum(len(str(word.text or "").strip()) for word in words)
    cjk_timeline = cjk_count >= max(2, total_letters // 3)
    effective_soft_chars = max(7 if cjk_timeline else 5, int(soft_chars))
    soft_gap = max(0.30, float(gap_split))
    observed_gaps = sorted(
        max(0.0, words[i].start - words[i - 1].end)
        for i in range(1, len(words))
        if words[i].start >= words[i - 1].end
    )
    if observed_gaps:
        # P75 phản ánh nhịp nghỉ của chính video; giới hạn để không nuốt lượt thoại.
        p75 = observed_gaps[min(len(observed_gaps) - 1, int(len(observed_gaps) * 0.75))]
    else:
        p75 = soft_gap
    hard_gap = max(0.72, min(0.95, max(soft_gap * 1.55, p75 * 1.35)))
    cues: list[tuple[float, float, str, str]] = []
    cur: list[Word] = []
    prev_end: float | None = None

    def emit(chunk: list[Word]) -> None:
        if chunk:
            warnings = list(dict.fromkeys(
                str(getattr(word, "warning", "") or "").strip()
                for word in chunk
                if str(getattr(word, "warning", "") or "").strip()
            ))
            cues.append((
                chunk[0].start, chunk[-1].end, _join(chunk), "; ".join(warnings)
            ))

    def last_punct_idx(buf: list[Word]) -> int:
        for i in range(len(buf) - 1, -1, -1):
            t = buf[i].text
            if t and t[-1] in (SENT_END + SOFT_BREAK):
                return i
        return -1

    for w in words:
        if cur and prev_end is not None:
            gap = max(0.0, w.start - prev_end)
            current_text = _join(cur)
            strong_end = bool(current_text and current_text[-1] in SENT_END)
            enough_text = len(current_text) >= max(4, effective_soft_chars // 2)
            if gap >= hard_gap or (gap >= soft_gap and (strong_end or enough_text)):
                emit(cur); cur = []
        cur.append(w)
        prev_end = w.end
        text_len = len(_join(cur))
        dur = w.end - cur[0].start
        last = w.text[-1] if w.text else ""
        end_p = last in SENT_END
        soft_p = last in SOFT_BREAK
        if end_p or (soft_p and text_len >= effective_soft_chars) or (
            dur >= max_duration and text_len >= max(4, effective_soft_chars // 2)
        ):
            emit(cur); cur = []
        elif text_len >= max_chars:
            idx = last_punct_idx(cur[:-1])
            if idx >= 0:
                emit(cur[:idx + 1]); cur = cur[idx + 1:]
            else:
                emit(cur); cur = []
    emit(cur)

    # Ghép mảnh 1-2 chữ không có dấu kết câu với câu kế bên nếu chúng gần nhau.
    # Không vượt hard_gap, không gộp qua dấu mạnh, không vượt giới hạn độ dài.
    repaired: list[tuple[float, float, str, str]] = []
    index = 0
    while index < len(cues):
        start, end, text, warning = cues[index]
        compact = _norm_text(text)
        if (
            len(compact) <= 2
            and text
            and text[-1] not in SENT_END
            and index + 1 < len(cues)
        ):
            n_start, n_end, n_text, n_warning = cues[index + 1]
            gap = n_start - end
            combined = _join_text(text, n_text)
            if -0.05 <= gap <= min(hard_gap, 0.70) and len(combined) <= max_chars:
                warnings = "; ".join(filter(None, (warning, n_warning)))
                repaired.append((start, n_end, combined, warnings))
                index += 2
                continue
        repaired.append((start, end, text, warning))
        index += 1
    cues = repaired

    # Không xóa cue chỉ vì ngắn chữ/dài thời gian. Với thoại nói nhỏ, đây có
    # thể là câu thật; lớp kiểm tra cuối sẽ đánh dấu để người dùng xem lại.
    cues.sort(key=lambda c: c[0])
    return [
        Segment(
            line=i + 1, start=round(b, 3), end=round(e, 3), text=t,
            ocr_warning=warning,
        )
        for i, (b, e, t, warning) in enumerate(cues)
    ]


def group_words_by_spans(
    words: list[Word],
    speech_spans: list[tuple[float, float]],
    **kwargs,
) -> list[Segment]:
    """Group ASR words inside hard VAD spans so subtitle cues never merge across voice cuts."""
    # Phải bung response dạng cả cụm TRƯỚC khi phân vào VAD span. Nếu làm sau,
    # một cụm 4 giây giao với ba lượt nói vẫn bị giữ nguyên trong span đầu tiên.
    words = _expand_coarse_cjk_words(sorted(words, key=lambda w: w.start))
    if not words:
        return []
    if not speech_spans:
        return group_words(words, **kwargs)

    out: list[Segment] = []
    used = [False] * len(words)
    spans = sorted((float(a), float(b)) for a, b in speech_spans if b > a)
    for span_start, span_end in spans:
        chunk: list[Word] = []
        for i, word in enumerate(words):
            if used[i]:
                continue
            mid = (word.start + word.end) / 2.0
            if span_start <= mid <= span_end or (word.start < span_end and word.end > span_start):
                chunk.append(word)
                used[i] = True
        if chunk:
            out.extend(group_words(chunk, **kwargs))

    leftovers = [word for i, word in enumerate(words) if not used[i]]
    if leftovers:
        out.extend(group_words(leftovers, **kwargs))

    out.sort(key=lambda seg: seg.start)
    for i, seg in enumerate(out, start=1):
        seg.line = i
    return out


def scored_boundary_spans(
    words: list[Word],
    vad_spans: list[tuple[float, float]],
    segment_spans: list[tuple[float, float]] | None = None,
    *,
    min_score: int = 5,
) -> list[tuple[float, float]]:
    """Fuse Silero, Whisper segments and word timestamps into safe cue spans.

    VAD boundaries are hints, not knives: every accepted cut is snapped between
    two ASR tokens, so a server boundary can never split the middle of a token.
    """
    ordered = sorted(words, key=lambda word: (word.start, word.end))
    vad = sorted((float(a), float(b)) for a, b in vad_spans if b > a)
    whisper = sorted(
        (float(a), float(b)) for a, b in (segment_spans or []) if b > a
    )
    if len(ordered) < 2 or not vad:
        return vad

    def between(spans: list[tuple[float, float]]) -> list[float]:
        return [
            (left[1] + right[0]) / 2.0
            for left, right in zip(spans, spans[1:])
        ]

    token_rows: list[tuple[float, float, Word]] = []
    scores: list[int] = []
    for left, right in zip(ordered, ordered[1:]):
        gap = float(right.start) - float(left.end)
        cut = (float(left.end) + float(right.start)) / 2.0
        score = 0
        if gap >= 0.45:
            score += 4
        elif gap >= 0.25:
            score += 2
        if str(left.text or "").rstrip().endswith(tuple(SENT_END)):
            score += 3
        if gap < -0.05:
            score -= 5
        token_rows.append((cut, gap, left))
        scores.append(score)

    def award_nearest(boundaries: list[float], points: int, tolerance: float) -> None:
        for boundary in boundaries:
            candidates = [
                (abs(cut - boundary), index)
                for index, (cut, gap, _left) in enumerate(token_rows)
                if gap >= -0.05
            ]
            if not candidates:
                continue
            distance, index = min(candidates)
            if distance <= tolerance:
                scores[index] += points

    # One Silero boundary selects exactly one nearest token gap. A wider snap
    # window tolerates coarse Whisper timestamps without creating many cuts
    # around the same VAD boundary.
    award_nearest(between(vad), points=5, tolerance=1.20)
    award_nearest(between(whisper), points=3, tolerance=0.75)

    cuts: list[float] = []
    for (cut, _gap, _left), score in zip(token_rows, scores):
        if score >= min_score and (not cuts or cut - cuts[-1] >= 0.05):
            cuts.append(cut)

    if not cuts:
        return []
    start = min(float(ordered[0].start), vad[0][0])
    end = max(float(ordered[-1].end), vad[-1][1])
    points = [start, *cuts, end]
    return [
        (left, right) for left, right in zip(points, points[1:])
        if right - left >= 0.05
    ]


def _norm_text(text: str) -> str:
    """Normalize only for comparison; keep displayed subtitle text untouched."""
    return re.sub(r"[^\w\u3400-\u9fff]+", "", text or "").casefold()


def _join_text(left: str, right: str) -> str:
    left, right = left.strip(), right.strip()
    if not left:
        return right
    if not right:
        return left
    cjk_left = ord(left[-1]) >= 0x2E80
    cjk_right = ord(right[0]) >= 0x2E80
    return left + ("" if cjk_left and cjk_right else " ") + right


def validate_and_repair_segments(
    segments: list[Segment],
    min_duration: float = 0.35,
    tiny_duration: float = 0.12,
    merge_gap: float = 0.08,
    max_chars: int = 24,
    junk_duration: float = 3.5,
    junk_chars: int = 2,
) -> tuple[list[Segment], dict[str, int]]:
    """Repair mechanical ASR errors without rewriting valid dialogue.

    Duplicates are removed only when their time ranges overlap or touch. Tiny
    cues are merged only across a near-zero gap, preserving intentional short
    and repeated dialogue.
    """
    stats = {
        "empty_removed": 0,
        "credit_noise_removed": 0,
        "duplicates_removed": 0,
        "tiny_merged": 0,
        "timing_repaired": 0,
        "overlaps_repaired": 0,
        "suspicious": 0,
    }
    ordered = sorted(segments, key=lambda s: (float(s.start), float(s.end), s.line))
    timeline_end = max((float(segment.end) for segment in ordered), default=0.0)
    credit_zone_start = timeline_end * 0.88
    clean: list[Segment] = []
    for source in ordered:
        text = (source.text or "").strip()
        if not text:
            stats["empty_removed"] += 1
            continue
        # Chỉ lọc marker credit rất chắc chắn ở 12% cuối timeline. Không xóa
        # Latin chung trên toàn phim vì tên nhân vật, OK/CEO... có thể là thoại.
        in_credit_zone = float(source.start) >= credit_zone_start
        chinese_credit = bool(re.search(
            r"(?:中文字幕|字幕组|字幕.{0,8}志愿者|翻译.{0,8}字幕)", text
        ))
        latin_credit = bool(re.fullmatch(
            r"(?i)\s*(?:by|sub(?:title)?s?)\b[\s:._-]*[a-z0-9\s._-]*", text
        ))
        if in_credit_zone and (chinese_credit or latin_credit):
            stats["credit_noise_removed"] += 1
            continue
        seg = replace(
            source,
            start=max(0.0, float(source.start)),
            end=max(0.0, float(source.end)),
            text=text,
        )
        if clean:
            prev = clean[-1]
            a, b = _norm_text(prev.text), _norm_text(seg.text)
            overlap = max(0.0, min(prev.end, seg.end) - max(prev.start, seg.start))
            min_span = max(0.05, min(prev.end - prev.start, seg.end - seg.start))
            overlap_ratio = overlap / min_span
            similar = bool(a and b and (a == b or SequenceMatcher(None, a, b).ratio() >= 0.92))
            if similar and overlap_ratio >= 0.65:
                prev.start = min(prev.start, seg.start)
                prev.end = max(prev.end, seg.end)
                if len(seg.text) > len(prev.text):
                    prev.text = seg.text
                stats["duplicates_removed"] += 1
                continue
        clean.append(seg)

    # Sửa mẫu động từ lặp A一A bị VAD/API cắt thành ``A一`` + ``A``.
    # Đây là cấu trúc tiếng Trung chắc chắn, nên có thể ghép qua một khoảng
    # nghỉ dài hơn ngưỡng thông thường mà không nuốt hai lượt thoại độc lập.
    stitched: list[Segment] = []
    i = 0
    while i < len(clean):
        cur = clean[i]
        if i + 1 < len(clean):
            nxt = clean[i + 1]
            left = _norm_text(cur.text)
            right = _norm_text(nxt.text)
            gap = nxt.start - cur.end
            repeat_pattern = (
                len(left) >= 2
                and bool(right)
                and left[-1] in {"一", "了"}
                and left[-2] == right[0]
            )
            if repeat_pattern and -0.30 <= gap <= 1.60:
                cur.end = max(cur.end, nxt.end)
                cur.text = _join_text(cur.text, nxt.text)
                cur.ocr_warning = "; ".join(filter(None, (
                    cur.ocr_warning, nxt.ocr_warning,
                )))
                stitched.append(cur)
                stats["tiny_merged"] += 1
                i += 2
                continue
        stitched.append(cur)
        i += 1
    clean = stitched

    merged: list[Segment] = []
    i = 0
    while i < len(clean):
        cur = clean[i]
        duration = cur.end - cur.start
        # Chỉ tự gộp timestamp cơ học gần như bằng 0. Câu nói nhanh 50-120 ms
        # vẫn được giữ và đánh dấu, không biến mất khỏi kết quả.
        mechanical_tiny = duration <= 0.02
        if mechanical_tiny and i + 1 < len(clean):
            nxt = clean[i + 1]
            gap = nxt.start - cur.end
            combined = _join_text(cur.text, nxt.text)
            if -0.05 <= gap <= merge_gap and len(combined) <= max_chars:
                nxt.start = min(cur.start, nxt.start)
                nxt.text = combined
                stats["tiny_merged"] += 1
                i += 1
                continue
        if mechanical_tiny and merged:
            prev = merged[-1]
            gap = cur.start - prev.end
            combined = _join_text(prev.text, cur.text)
            if -0.05 <= gap <= merge_gap and len(combined) <= max_chars:
                prev.end = max(prev.end, cur.end)
                prev.text = combined
                stats["tiny_merged"] += 1
                i += 1
                continue
        merged.append(cur)
        i += 1

    original_tiny = {
        i for i, seg in enumerate(merged)
        if seg.end - seg.start <= tiny_duration
    }
    minimum = max(0.10, float(min_duration))
    for i, seg in enumerate(merged):
        if seg.end - seg.start < minimum:
            target_end = seg.start + minimum
            if i + 1 < len(merged):
                room_end = merged[i + 1].start - 0.02
                if room_end > seg.start + 0.10:
                    target_end = min(target_end, room_end)
            if target_end > seg.end:
                seg.end = target_end
                stats["timing_repaired"] += 1

    warned: set[int] = set()

    def warn(index: int, message: str) -> None:
        seg = merged[index]
        if seg.ocr_warning:
            if message not in seg.ocr_warning:
                seg.ocr_warning += "; " + message
        else:
            seg.ocr_warning = message
        if index not in warned:
            warned.add(index)
            stats["suspicious"] += 1

    for i in range(1, len(merged)):
        prev, cur = merged[i - 1], merged[i]
        overlap = prev.end - cur.start
        if 0 < overlap <= 0.50 and cur.start - prev.start >= 0.12:
            prev.end = max(prev.start + 0.10, cur.start - 0.01)
            stats["overlaps_repaired"] += 1
        elif overlap > 0.25:
            warn(i, "ASR: chồng thời gian, cần kiểm tra")

    for i, seg in enumerate(merged):
        duration = max(0.001, seg.end - seg.start)
        compact_len = len(_norm_text(seg.text))
        if i in original_tiny:
            warn(i, "ASR: câu rất nhanh, cần nghe lại")
        if duration > junk_duration and compact_len <= junk_chars:
            warn(i, "ASR: câu ngắn kéo dài, cần nghe lại")
        if compact_len / duration > 18.0:
            warn(i, "ASR: mật độ chữ cao, có thể lệch thời gian")

    for line, seg in enumerate(merged, start=1):
        seg.line = line
        seg.start = round(seg.start, 3)
        seg.end = round(max(seg.end, seg.start + 0.10), 3)
    return merged, stats


def load_glossary(path: str) -> list[tuple[str, str]]:
    """File mỗi dòng 'sai=đúng' (# là ghi chú). Key dài thay trước."""
    pairs: list[tuple[str, str]] = []
    try:
        for line in open(path, encoding="utf-8-sig"):
            line = line.rstrip("\n")
            if not line.strip() or line.lstrip().startswith("#") or "=" not in line:
                continue
            a, b = line.split("=", 1)
            if a:
                pairs.append((a, b))
    except OSError:
        return []
    pairs.sort(key=lambda p: len(p[0]), reverse=True)
    return pairs


def apply_glossary(segments: list[Segment], pairs: list[tuple[str, str]]) -> list[Segment]:
    if not pairs:
        return segments
    for seg in segments:
        for a, b in pairs:
            if a in seg.text:
                seg.text = seg.text.replace(a, b)
    return segments

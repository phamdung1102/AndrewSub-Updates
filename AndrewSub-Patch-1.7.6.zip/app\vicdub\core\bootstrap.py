"""Bootstrap 'app nhẹ, tải sau'.

Bản phát hành đóng gói nhẹ (code + FFmpeg + 6 giọng preset). Các thứ NẶNG được
xử lý ngoài gói:
- Gói pip nặng (torch, omnivoice, playwright, opencv...) do `setup.bat` cài vào
  .venv lúc cài đặt.
- Model giọng OmniVoice (~3GB) được APP tự tải LẦN ĐẦU về data/hf_cache.
- OCR web dùng Google Chrome đã cài sẵn trên máy (không tải Chromium).

Phần kiểm tra ở đây thuần Python (không nạp model), test được và không gọi mạng.
"""

from __future__ import annotations

import importlib.util
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

ProgressFn = Callable[[int, str], None]

# File bắt buộc trong snapshot OmniVoice để coi là "đã tải đủ" (khớp voice_module).
_OMNI_REQUIRED = (
    "config.json",
    "model.safetensors",
    "tokenizer.json",
    "audio_tokenizer/config.json",
    "audio_tokenizer/model.safetensors",
    "audio_tokenizer/preprocessor_config.json",
)


@dataclass
class Component:
    """Một thành phần cần có để app chạy đầy đủ."""

    key: str
    label: str
    ready: bool
    downloadable: bool = False  # app tự tải được (data), hay phải chạy setup (pip)
    detail: str = ""


# ---------- Kiểm tra (thuần Python) ----------

def _pkg_installed(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def hf_home(config: Any) -> Path:
    """Thư mục cache model (ưu tiên HF_HOME, mặc định data/hf_cache)."""
    env = os.environ.get("HF_HOME")
    if env:
        return Path(env)
    return Path(getattr(config, "data_dir", "data")) / "hf_cache"


def omnivoice_model_ready(hf_home_dir: str | Path) -> bool:
    """Model OmniVoice đã tải đủ trong cache HuggingFace chưa?"""
    repo = Path(hf_home_dir) / "hub" / "models--k2-fsa--OmniVoice"
    ref = repo / "refs" / "main"
    if not ref.exists():
        return False
    try:
        revision = ref.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    snap = repo / "snapshots" / revision
    return snap.is_dir() and all((snap / rel).exists() for rel in _OMNI_REQUIRED)


def vi_voices_ready(data_dir: str | Path) -> bool:
    """Có ít nhất một giọng preset .pt trong data/vi_voices không?"""
    d = Path(data_dir) / "vi_voices"
    return d.is_dir() and any(d.glob("*.pt"))


def chrome_ready() -> bool:
    """Google Chrome có trên máy chưa (OCR/dịch web chạy channel='chrome')."""
    import shutil  # noqa: PLC0415
    if shutil.which("chrome"):
        return True
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(env, "")
        if base and (Path(base) / "Google" / "Chrome" / "Application"
                     / "chrome.exe").exists():
            return True
    return False


def ffmpeg_ready(config: Any) -> bool:
    """FFmpeg dùng được (đường dẫn khai báo tồn tại, hoặc lệnh 'ffmpeg' hệ thống)."""
    path = str(getattr(config, "ffmpeg_path", "ffmpeg") or "ffmpeg")
    if path in ("ffmpeg", ""):
        return True  # dựa PATH hệ thống - coi như có, kiểm thật lúc chạy
    return Path(path).exists()


def component_status(config: Any) -> list[Component]:
    """Trạng thái mọi thành phần. downloadable=True nghĩa là app tự tải được."""
    cache = hf_home(config)
    return [
        Component("torch", "PyTorch (engine sinh giọng)", _pkg_installed("torch")),
        Component("omnivoice", "Gói OmniVoice", _pkg_installed("omnivoice")),
        Component("playwright", "Playwright (OCR web)", _pkg_installed("playwright")),
        Component("numpy", "NumPy (phân tích khung phụ đề)", _pkg_installed("numpy")),
        Component("omnivoice_model", "Model giọng OmniVoice (~3GB)",
                  omnivoice_model_ready(cache), downloadable=True,
                  detail=str(cache)),
        Component("vi_voices", "6 giọng Việt preset", vi_voices_ready(
            getattr(config, "data_dir", "data"))),
        Component("ffmpeg", "FFmpeg", ffmpeg_ready(config), downloadable=True),
        Component("chrome", "Google Chrome (OCR/dịch web)", chrome_ready(),
                  detail="Cài từ google.com/chrome nếu thiếu"),
    ]


def missing(config: Any) -> list[Component]:
    """Thành phần còn thiếu."""
    return [c for c in component_status(config) if not c.ready]


def needs_setup(config: Any) -> list[Component]:
    """Thiếu gói pip (phải chạy setup.bat, app không tự cài được)."""
    return [c for c in missing(config) if not c.downloadable]


def needs_download(config: Any) -> list[Component]:
    """Thiếu dữ liệu app TỰ TẢI được (model giọng)."""
    return [c for c in missing(config) if c.downloadable]


# ---------- Tải (gọi mạng - không chạy trong test) ----------

def ensure_omnivoice_model(config: Any, progress: ProgressFn | None = None) -> None:
    """Tải model giọng OmniVoice về data/hf_cache nếu chưa có.

    Dùng chính OmniVoice.from_pretrained (tự tải từ HuggingFace). Không nạp lên
    thiết bị lâu - chỉ cần kéo file về cache. Raise RuntimeError nếu thiếu gói.
    """
    def report(pct: int, msg: str) -> None:
        if progress:
            progress(pct, msg)

    cache = hf_home(config)
    cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(cache))

    if omnivoice_model_ready(cache):
        report(100, "Model giọng đã có sẵn.")
        return

    report(2, "Chuẩn bị tải model giọng OmniVoice (~3GB, lần đầu)...")
    try:
        import torch  # noqa: PLC0415
        from omnivoice import OmniVoice  # noqa: PLC0415
    except ImportError as exc:
        raise RuntimeError(
            "Thiếu torch/omnivoice - chạy setup.bat trước để cài môi trường."
        ) from exc

    report(5, "Đang tải model giọng (giữ cửa sổ, có thể mất vài phút)...")
    # device_map='cpu' để chỉ kéo file về, không chiếm VRAM lúc bootstrap.
    OmniVoice.from_pretrained(
        "k2-fsa/OmniVoice", device_map="cpu", dtype=torch.float32,
    )
    report(100, "Tải model giọng xong.")

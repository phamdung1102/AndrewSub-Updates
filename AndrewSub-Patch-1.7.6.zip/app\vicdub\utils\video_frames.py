"""Lightweight video frame helpers shared by OCR Web and region preview."""

from __future__ import annotations


DEFAULT_REGION = (0.05, 0.78, 0.95, 1.0)  # x0, y0, x1, y1 ratio


def region_to_crop(
    region: tuple[float, float, float, float], width: int, height: int,
    *, vertical_padding: float = 0.0,
) -> tuple[int, int, int, int]:
    """Convert ratio region (x0, y0, x1, y1) to pixel crop (w, h, x, y).

    ``vertical_padding`` expands both the top and bottom by a fraction of the
    selected height. OCR uses it because a tight box from one frame may cut
    glyphs in later frames.
    """
    x0, y0, x1, y1 = region
    x0, x1 = sorted((max(0.0, min(1.0, x0)), max(0.0, min(1.0, x1))))
    y0, y1 = sorted((max(0.0, min(1.0, y0)), max(0.0, min(1.0, y1))))
    if vertical_padding > 0:
        pad = max(0.0, y1 - y0) * vertical_padding
        y0 = max(0.0, y0 - pad)
        y1 = min(1.0, y1 + pad)
    x = int(round(x0 * width))
    y = int(round(y0 * height))
    w = max(2, int(round((x1 - x0) * width)))
    h = max(2, int(round((y1 - y0) * height)))
    w = min(w, width - x)
    h = min(h, height - y)
    return w, h, x, y


def sample_times(start: float, end: float, fps: float) -> list[float]:
    """Return frame sample timestamps from start to end, inclusive-ish."""
    if fps <= 0 or end <= start:
        return []
    step = 1.0 / fps
    count = max(1, int((end - start) * fps) + 1)
    return [start + i * step for i in range(count) if start + i * step <= end]

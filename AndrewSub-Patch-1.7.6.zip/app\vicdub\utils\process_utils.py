"""Tùy chọn chạy tiến trình nền mà không bật cửa sổ console trên Windows."""

from __future__ import annotations

import os
import subprocess


CREATE_NO_WINDOW = (
    getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    if os.name == "nt"
    else 0
)


def hidden_process_kwargs() -> dict[str, int]:
    """Các keyword dùng an toàn cho subprocess.run/Popen trên mọi nền tảng."""
    return {"creationflags": CREATE_NO_WINDOW} if CREATE_NO_WINDOW else {}

"""Timeline kiểu editor chuyên nghiệp: 3 track Video / Phụ đề / Voice.

Vẽ các block trên trục thời gian như CapCut:
- Track VIDEO: các clip băm theo khung giờ sub - tím = đã cắt sẵn trên đĩa,
  xám viền = chưa cắt.
- Track PHỤ ĐỀ: block theo khung giờ sub (start -> end), hiện chữ.
- Track VOICE: block từ start theo thời lượng voice THẬT đã render.
  Xanh = khớp (ngắn/bằng clip, phần thiếu đệm lặng), cam = dài hơn clip
  (video sẽ kéo chậm theo), xám = chưa render.

Click block chọn dòng, double-click nghe voice dòng đó.
"""

from __future__ import annotations

import wave
from pathlib import Path

from PyQt6.QtCore import QRectF, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import QWidget

from vicdub.utils.subtitles import Segment

# Bảng màu đồng bộ theme tối của app.
COLOR_BG = QColor("#0b0f14")
COLOR_RULER_BG = QColor("#111827")
COLOR_GRID = QColor("#223044")
COLOR_TEXT = QColor("#e6edf3")
COLOR_MUTED = QColor("#9fb0c2")
COLOR_VIDEO_CUT = QColor("#7c3aed")
COLOR_VIDEO_RAW = QColor("#1b2536")
COLOR_SUB = QColor("#1f6feb")
COLOR_VOICE_OK = QColor("#16a34a")
COLOR_VOICE_STRETCH = QColor("#d97706")
COLOR_VOICE_MISSING = QColor("#374151")
COLOR_SELECTED = QColor("#38bdf8")


def wav_seconds(path: str | Path) -> float:
    """Thời lượng wav (giây) - đọc header, tức thời."""
    try:
        with wave.open(str(path), "rb") as f:
            rate = f.getframerate()
            return f.getnframes() / rate if rate else 0.0
    except (wave.Error, OSError):
        return 0.0


def project_voice_path(project_root: str | Path, line: int) -> Path:
    """Đường dẫn voice đã render của một dòng."""
    return Path(project_root) / "voices" / f"{line:04d}.wav"


def project_clip_path(project_root: str | Path, line: int) -> Path:
    """Đường dẫn clip đã cắt của một dòng."""
    return Path(project_root) / "clips" / f"{line:03d}.mp4"


class TimelineWidget(QWidget):
    """Canvas timeline 3 track, đặt trong QScrollArea ngang."""

    #: Click một block (số dòng).
    line_clicked = pyqtSignal(int)
    #: Double-click một block (số dòng) - nghe voice.
    line_played = pyqtSignal(int)
    #: Kéo playhead trên thước thời gian (giây) - preview theo vị trí.
    time_scrubbed = pyqtSignal(float)

    RULER_H = 26
    TRACK_H = 40
    GAP = 6
    TRACKS = 3  # Video, Phụ đề, Voice

    def __init__(self) -> None:
        super().__init__()
        self._segments: list[Segment] = []
        #: {line: (voice_dur, fits)} - fits=True nếu voice <= clip.
        self._voices: dict[int, tuple[float, bool]] = {}
        #: {line: True nếu clip đã cắt sẵn trên đĩa}
        self._clips: dict[int, bool] = {}
        self._pps = 40.0  # pixel mỗi giây (zoom)
        self._duration = 0.0
        self._selected: int | None = None
        self._playhead = 0.0
        self._scrubbing = False
        self.setMinimumHeight(
            self.RULER_H + self.TRACKS * (self.TRACK_H + self.GAP) + 12
        )

    # ---------- Dữ liệu ----------

    def set_data(self, segments: list[Segment],
                 voices: dict[int, tuple[float, bool]],
                 clips: dict[int, bool] | None = None) -> None:
        self._segments = segments
        self._voices = voices
        self._clips = clips or {}
        end_times = [s.end for s in segments]
        end_times += [s.start + voices[s.line][0]
                      for s in segments if s.line in voices]
        self._duration = max(end_times, default=0.0)
        self._resize_to_fit()
        self.update()

    def set_zoom(self, pixels_per_second: float) -> None:
        self._pps = max(5.0, min(300.0, pixels_per_second))
        self._resize_to_fit()
        self.update()

    def select_line(self, line: int | None) -> None:
        self._selected = line
        self.update()

    def _resize_to_fit(self) -> None:
        self.setFixedWidth(int(self._duration * self._pps) + 120)

    # ---------- Hình học ----------

    def _track_y(self, track: int) -> float:
        return self.RULER_H + self.GAP + track * (self.TRACK_H + self.GAP)

    def _video_rect(self, seg: Segment) -> QRectF:
        return QRectF(seg.start * self._pps, self._track_y(0),
                      max(2.0, seg.duration * self._pps - 1), self.TRACK_H)

    def _sub_rect(self, seg: Segment) -> QRectF:
        return QRectF(seg.start * self._pps, self._track_y(1),
                      max(2.0, seg.duration * self._pps - 1), self.TRACK_H)

    def _voice_rect(self, seg: Segment) -> QRectF:
        info = self._voices.get(seg.line)
        width = (info[0] if info else seg.duration) * self._pps
        return QRectF(seg.start * self._pps, self._track_y(2),
                      max(2.0, width - 1), self.TRACK_H)

    def _line_at(self, x: float, y: float) -> int | None:
        """Tìm dòng theo tọa độ click trên cả 3 track."""
        for seg in self._segments:
            for rect in (self._video_rect(seg), self._sub_rect(seg),
                         self._voice_rect(seg)):
                if rect.contains(x, y):
                    return seg.line
        return None

    # ---------- Vẽ ----------

    def paintEvent(self, _event) -> None:  # noqa: N802 - Qt API
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), COLOR_BG)

        self._paint_ruler(painter)
        font = painter.font()
        font.setPixelSize(11)
        painter.setFont(font)

        for seg in self._segments:
            selected = seg.line == self._selected

            # Track 0: video clip băm theo sub.
            cut = self._clips.get(seg.line, False)
            self._paint_block(
                painter, self._video_rect(seg),
                COLOR_VIDEO_CUT if cut else COLOR_VIDEO_RAW,
                f"clip {seg.duration:.1f}s" if cut else "chưa cắt",
                selected,
            )

            # Track 1: phụ đề (chữ).
            self._paint_block(
                painter, self._sub_rect(seg), COLOR_SUB,
                seg.translation or seg.text, selected,
            )

            # Track 2: voice.
            info = self._voices.get(seg.line)
            if info is not None:
                voice_dur, fits = info
                color = COLOR_VOICE_OK if fits else COLOR_VOICE_STRETCH
                text = f"{voice_dur:.1f}s"
            else:
                color, text = COLOR_VOICE_MISSING, "chưa render"
            self._paint_block(painter, self._voice_rect(seg), color, text,
                              selected)

        self._paint_playhead(painter)
        painter.end()

    def _paint_playhead(self, painter: QPainter) -> None:
        """Vạch playhead dọc + tay cầm tam giác trên thước."""
        x = int(self._playhead * self._pps)
        painter.setPen(QPen(COLOR_SELECTED, 2))
        painter.drawLine(x, 0, x, self.height())
        painter.setBrush(COLOR_SELECTED)
        painter.setPen(Qt.PenStyle.NoPen)
        from PyQt6.QtGui import QPolygonF  # noqa: PLC0415
        from PyQt6.QtCore import QPointF  # noqa: PLC0415
        painter.drawPolygon(QPolygonF([
            QPointF(x - 6, 0), QPointF(x + 6, 0), QPointF(x, self.RULER_H - 8),
        ]))

    def _paint_ruler(self, painter: QPainter) -> None:
        painter.fillRect(0, 0, self.width(), self.RULER_H, COLOR_RULER_BG)
        painter.setPen(QPen(COLOR_GRID))
        painter.drawLine(0, self.RULER_H, self.width(), self.RULER_H)

        # Bước vạch theo mức zoom: dày thì mỗi giây, thưa thì 5/10 giây.
        step = 1 if self._pps >= 40 else (5 if self._pps >= 12 else 10)
        total = int(self._duration) + step * 2
        for second in range(0, total, step):
            x = second * self._pps
            painter.setPen(QPen(COLOR_GRID))
            painter.drawLine(int(x), self.RULER_H - 7, int(x), self.RULER_H)
            painter.drawLine(int(x), self.RULER_H, int(x), self.height())
            painter.setPen(QPen(COLOR_MUTED))
            minutes, secs = divmod(second, 60)
            painter.drawText(int(x) + 3, self.RULER_H - 10,
                             f"{minutes:02d}:{secs:02d}")

    def _paint_block(self, painter: QPainter, rect: QRectF, color: QColor,
                     text: str, selected: bool) -> None:
        fill = QColor(color)
        fill.setAlpha(215)
        painter.setPen(QPen(COLOR_SELECTED, 2) if selected
                       else QPen(color.darker(130), 1))
        painter.setBrush(fill)
        painter.drawRoundedRect(rect, 4, 4)

        painter.setPen(QPen(COLOR_TEXT))
        metrics = painter.fontMetrics()
        elided = metrics.elidedText(
            text, Qt.TextElideMode.ElideRight, int(rect.width()) - 8
        )
        painter.drawText(rect.adjusted(4, 0, -4, 0),
                         Qt.AlignmentFlag.AlignVCenter, elided)

    # ---------- Chuột ----------

    def _scrub_to(self, x: float) -> None:
        self._playhead = max(0.0, min(self._duration, x / self._pps))
        self.update()
        self.time_scrubbed.emit(self._playhead)

    def mousePressEvent(self, event) -> None:  # noqa: N802 - Qt API
        pos = event.position()
        if pos.y() <= self.RULER_H:
            # Bấm/kéo trên thước -> scrub playhead.
            self._scrubbing = True
            self._scrub_to(pos.x())
            return
        line = self._line_at(pos.x(), pos.y())
        if line is not None:
            self._selected = line
            self.update()
            self.line_clicked.emit(line)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802 - Qt API
        if self._scrubbing:
            self._scrub_to(event.position().x())

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802 - Qt API
        self._scrubbing = False

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802 - Qt API
        line = self._line_at(event.position().x(), event.position().y())
        if line is not None:
            self.line_played.emit(line)

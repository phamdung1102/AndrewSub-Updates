"""Registry giọng + CHỌN giọng theo nhân vật.

Chỉ lo việc CHỌN giọng nào cho mỗi dòng/nhân vật - KHÔNG đụng tham số sinh
giọng (num_step, seed, tốc độ...). Cách sinh giọng vẫn do voice_module lo.

Nguồn giọng: 6 preset nữ tiếng Việt của OmniVoice-vi (data/vi_voices/<stem>.pt).
Đây là nguồn sự thật duy nhất về danh sách giọng; voice_module import lại từ đây.
"""

from __future__ import annotations

from pathlib import Path

# (nhãn hiển thị, stem file .pt, giới tính). Thứ tự = thứ tự xoay vòng khi tự
# gán giọng cho nhân vật, nên nhân vật khác nhau nhận giọng khác nhau.
VOICES: list[tuple[str, str, str]] = [
    ("Nữ 1 - Ban Mai", "ban_mai", "female"),
    ("Nữ 2 - Lan Trinh", "lan_trinh", "female"),
    ("Nữ 3 - Ngân Hà", "ngan_ha", "female"),
    ("Nữ 4 - Ngọc Huyền", "ngoc_huyen", "female"),
    ("Nữ 5 - Thảo Trinh", "thao_trinh", "female"),
    ("Nữ 6 - Tường Vy", "tuong_vy", "female"),
]

VI_VOICES: dict[str, str] = {label: stem for label, stem, _ in VOICES}
VOICE_GENDER: dict[str, str] = {label: g for label, _, g in VOICES}
VOICE_LABELS: list[str] = [label for label, _, _ in VOICES]
DEFAULT_VOICE: str = VOICE_LABELS[0]


def available_labels(vi_voices_dir) -> list[str]:
    """Danh sách nhãn giọng thực sự có file .pt trong thư mục (giữ thứ tự)."""
    if not vi_voices_dir:
        return list(VOICE_LABELS)
    d = Path(vi_voices_dir)
    return [label for label, stem, _ in VOICES if (d / f"{stem}.pt").exists()]


def _clean(voice: str) -> str:
    return (voice or "").strip()


def is_valid(voice: str, available: list[str] | None = None) -> bool:
    """Nhãn giọng có hợp lệ (thuộc registry và có mặt nếu giới hạn available)?"""
    v = _clean(voice)
    # Engine API có catalog động, không thuộc registry local. Khi engine đã
    # cung cấp `available`, chính catalog đó là nguồn xác thực.
    if available is not None:
        return v in available
    return v in VI_VOICES


def resolve_voice(
    seg_voice: str,
    speaker: str,
    char_voice: dict[str, str] | None,
    default: str = "",
    available: list[str] | None = None,
) -> str:
    """Chọn giọng cho MỘT dòng theo thứ tự ưu tiên.

    dòng gán riêng (seg_voice) > giọng của nhân vật (char_voice[speaker]) >
    giọng mặc định chung (default) > giọng đầu tiên khả dụng. Chỉ trả nhãn hợp
    lệ; nhãn cũ/không tồn tại bị bỏ qua để không rơi vào giọng lạ.
    """
    pool = available if available else VOICE_LABELS
    cands = [
        seg_voice,
        (char_voice or {}).get(speaker, ""),
        default,
    ]
    for c in cands:
        if is_valid(c, available):
            return _clean(c)
    return pool[0] if pool else DEFAULT_VOICE


def assign_missing(
    speakers: list[str],
    existing: dict[str, str] | None = None,
    available: list[str] | None = None,
) -> dict[str, str]:
    """Gán giọng cho danh sách nhân vật: giữ giọng hợp lệ đã có, gán giọng CHƯA
    DÙNG cho nhân vật còn trống (xoay vòng khi hết giọng riêng).

    Args:
        speakers: tên nhân vật theo thứ tự ưu tiên (thường số dòng giảm dần).
        existing: map nhân vật -> giọng đã gán trước đó (giữ nếu còn hợp lệ).
        available: giới hạn danh sách giọng dùng được (mặc định toàn bộ).

    Returns:
        map nhân vật -> nhãn giọng, mỗi nhân vật một giá trị.
    """
    existing = existing or {}
    pool = list(available) if available else list(VOICE_LABELS)
    result: dict[str, str] = {}
    used: list[str] = []

    # Giữ giọng đã gán còn hợp lệ.
    for sp in speakers:
        v = _clean(existing.get(sp, ""))
        if is_valid(v, available):
            result[sp] = v
            used.append(v)

    if not pool:
        return result

    # Gán cho nhân vật còn trống: ưu tiên giọng chưa ai dùng để đa dạng.
    cycle = 0
    for sp in speakers:
        if sp in result:
            continue
        choice = next((v for v in pool if v not in used), None)
        if choice is None:  # đã dùng hết giọng riêng -> xoay vòng lại
            choice = pool[cycle % len(pool)]
            cycle += 1
        result[sp] = choice
        used.append(choice)
    return result

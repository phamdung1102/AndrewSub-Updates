"""Core engine: workflow, task queue, project manager, database."""

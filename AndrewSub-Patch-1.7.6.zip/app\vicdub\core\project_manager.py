"""Project Manager - mỗi video là một project.

Cấu trúc thư mục project:
projects/<tên>/
    project.db      - segments, characters, history, voice cache
    subtitles/      - original.srt, translated.srt
    voices/         - wav sinh từ TTS
    clips/          - clip cắt theo dòng
    output/         - Final.mp4
"""

from __future__ import annotations

import logging
import json
import re
from pathlib import Path

from vicdub.core.database import Database, SCHEMA_PROJECT
from vicdub.utils.subtitles import Segment

logger = logging.getLogger(__name__)


class Project:
    """Một project lồng tiếng, gắn với một video."""

    SUBDIRS = ("subtitles", "voices", "clips", "output")

    def __init__(self, root: Path) -> None:
        self.root = root
        self.name = root.name
        for sub in self.SUBDIRS:
            (root / sub).mkdir(parents=True, exist_ok=True)
        self.db = Database(root / "project.db", SCHEMA_PROJECT)
        self._migrate()

    def _migrate(self) -> None:
        """Nâng schema project cũ (thêm cột voice cho segments)."""
        import sqlite3  # noqa: PLC0415
        try:
            self.db.execute(
                "ALTER TABLE segments ADD COLUMN voice TEXT NOT NULL DEFAULT ''"
            )
        except sqlite3.OperationalError:
            pass  # cột đã có
        try:
            self.db.execute(
                "ALTER TABLE segments ADD COLUMN ocr_warning TEXT NOT NULL DEFAULT ''"
            )
        except sqlite3.OperationalError:
            pass

    # ---------- Meta ----------

    def set_meta(self, key: str, value: str) -> None:
        self.db.execute(
            "INSERT INTO meta(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )

    def get_meta(self, key: str, default: str = "") -> str:
        row = self.db.query_one("SELECT value FROM meta WHERE key = ?", (key,))
        return row["value"] if row else default

    @property
    def video_path(self) -> str:
        return self.get_meta("video_path")

    def set_ocr_region(self, region) -> None:
        values = [max(0.0, min(1.0, float(value))) for value in region]
        if len(values) != 4:
            raise ValueError("Vùng phụ đề phải có đủ 4 tọa độ")
        self.set_meta("ocr_region", json.dumps(values))

    def get_ocr_region(self, fallback=None) -> list[float]:
        """Return this project's OCR rectangle; old projects use app fallback."""
        default = list(fallback or [0.05, 0.78, 0.95, 1.0])
        try:
            values = json.loads(self.get_meta("ocr_region", ""))
            if isinstance(values, list) and len(values) == 4:
                return [max(0.0, min(1.0, float(value))) for value in values]
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
        return default

    @property
    def has_ocr_region(self) -> bool:
        return bool(self.get_meta("ocr_region", "").strip())

    def set_blur_region(self, region) -> None:
        """Lưu riêng vùng che phụ đề gốc của từng video/dự án."""
        values = [max(0.0, min(1.0, float(value))) for value in region]
        if len(values) != 4:
            raise ValueError("Vùng làm mờ phải có đủ 4 tọa độ")
        x0, x1 = sorted((values[0], values[2]))
        y0, y1 = sorted((values[1], values[3]))
        self.set_meta("subtitle_blur_region", json.dumps([x0, y0, x1, y1]))

    def get_blur_region(self, fallback=None) -> list[float]:
        """Vùng làm mờ tùy chỉnh; dự án cũ dùng vùng nhận diện làm mặc định."""
        default = list(fallback or self.get_ocr_region())
        try:
            values = json.loads(self.get_meta("subtitle_blur_region", ""))
            if isinstance(values, list) and len(values) == 4:
                return [max(0.0, min(1.0, float(value))) for value in values]
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
        return default

    # ---------- Segments ----------

    def save_segments(self, segments: list[Segment]) -> None:
        self.db.execute("DELETE FROM segments")
        self.db.executemany(
            "INSERT INTO segments(line, start, end, text, translation, speaker, "
            "gender, voice, ocr_warning) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [(s.line, s.start, s.end, s.text, s.translation, s.speaker,
              s.gender, s.voice, s.ocr_warning) for s in segments],
        )

    def load_segments(self) -> list[Segment]:
        rows = self.db.query("SELECT * FROM segments ORDER BY line")
        return [
            Segment(line=r["line"], start=r["start"], end=r["end"], text=r["text"],
                    translation=r["translation"], speaker=r["speaker"],
                    gender=r["gender"], voice=r["voice"],
                    ocr_warning=r["ocr_warning"])
            for r in rows
        ]

    def update_segment(self, segment: Segment) -> None:
        self.db.execute(
            "UPDATE segments SET start=?, end=?, text=?, translation=?, "
            "speaker=?, gender=?, voice=?, ocr_warning=? WHERE line=?",
            (segment.start, segment.end, segment.text, segment.translation,
             segment.speaker, segment.gender, segment.voice,
             segment.ocr_warning, segment.line),
        )

    def update_segments(self, segments: list[Segment]) -> None:
        """Cập nhật cả lô trong một transaction thay vì commit từng dòng."""
        if not segments:
            return
        self.db.executemany(
            "UPDATE segments SET start=?, end=?, text=?, translation=?, "
            "speaker=?, gender=?, voice=?, ocr_warning=? WHERE line=?",
            [(s.start, s.end, s.text, s.translation, s.speaker, s.gender,
              s.voice, s.ocr_warning, s.line) for s in segments],
        )

    # ---------- Nhân vật ----------

    def save_character(self, name: str, gender: str, voice_id: str) -> None:
        self.db.execute(
            "INSERT INTO characters(name, gender, voice_id) VALUES(?, ?, ?) "
            "ON CONFLICT(name) DO UPDATE SET gender=excluded.gender, "
            "voice_id=excluded.voice_id",
            (name, gender, voice_id),
        )

    def delete_character(self, name: str) -> None:
        self.db.execute("DELETE FROM characters WHERE name = ?", (name,))

    def rename_character(self, old: str, new: str) -> None:
        """Đổi tên nhân vật, cập nhật cả segments."""
        self.db.execute("UPDATE OR REPLACE characters SET name=? WHERE name=?", (new, old))
        self.db.execute("UPDATE segments SET speaker=? WHERE speaker=?", (new, old))

    def load_characters(self) -> list[dict]:
        rows = self.db.query("SELECT * FROM characters ORDER BY name")
        return [dict(r) for r in rows]

    # ---------- Lịch sử & cache ----------

    def add_history(self, step: str, status: str, detail: str = "") -> None:
        self.db.execute(
            "INSERT INTO history(step, status, detail) VALUES(?, ?, ?)",
            (step, status, detail),
        )

    def load_history(self, limit: int = 100) -> list[dict]:
        rows = self.db.query(
            "SELECT ts, step, status, detail FROM history ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in rows]

    def cache_get(self, key: str) -> str | None:
        row = self.db.query_one("SELECT wav_path FROM voice_cache WHERE hash = ?", (key,))
        return row["wav_path"] if row else None

    def cache_put(self, key: str, wav_path: str) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO voice_cache(hash, wav_path) VALUES(?, ?)",
            (key, wav_path),
        )

    def close(self) -> None:
        self.db.close()


class ProjectManager:
    """Tạo/mở/liệt kê project."""

    def __init__(self, projects_dir: str) -> None:
        self.projects_dir = Path(projects_dir)
        self.projects_dir.mkdir(parents=True, exist_ok=True)
        self.current: Project | None = None

    @staticmethod
    def _safe_name(name: str) -> str:
        """Chuẩn hóa tên project thành tên thư mục hợp lệ."""
        name = re.sub(r'[\\/:*?"<>|]+', "_", name).strip()
        return name or "project"

    def create(self, name: str, video_path: str = "") -> Project:
        root = self.projects_dir / self._safe_name(name)
        if root.exists():
            raise ValueError(f"Project '{name}' đã tồn tại")
        # Đóng project đang mở (như open) để không giữ nhiều kết nối DB - trên
        # Windows kết nối còn mở sẽ khóa file, không xóa/di chuyển được.
        if self.current:
            self.current.close()
        project = Project(root)
        if video_path:
            project.set_meta("video_path", video_path)
        project.add_history("project", "created", name)
        self.current = project
        logger.info("Tạo project: %s", root)
        return project

    def open(self, name: str) -> Project:
        root = self.projects_dir / name
        if not (root / "project.db").exists():
            raise ValueError(f"Không tìm thấy project '{name}'")
        if self.current:
            self.current.close()
        self.current = Project(root)
        logger.info("Mở project: %s", root)
        return self.current

    def list_projects(self) -> list[str]:
        return sorted(
            p.name for p in self.projects_dir.iterdir()
            if (p / "project.db").exists()
        )

    def delete(self, name: str) -> None:
        """Xóa hẳn thư mục project khỏi ổ đĩa (không hoàn tác)."""
        import shutil  # noqa: PLC0415
        root = self.projects_dir / name
        if not (root / "project.db").exists():
            raise ValueError(f"Không tìm thấy project '{name}'")
        # Đóng DB nếu đang mở, nếu không Windows khóa file không xóa được.
        if self.current and self.current.root == root:
            self.current.close()
            self.current = None
        shutil.rmtree(root, ignore_errors=True)
        if root.exists():
            raise ValueError(
                f"Không xóa được '{name}' - có thể file đang được mở ở nơi khác. "
                f"Đóng ứng dụng đang dùng thư mục rồi thử lại."
            )
        logger.info("Xóa project: %s", root)

    def set_projects_dir(self, path: str) -> None:
        """Đổi thư mục lưu các project (đóng project đang mở)."""
        if self.current:
            self.current.close()
            self.current = None
        self.projects_dir = Path(path)
        self.projects_dir.mkdir(parents=True, exist_ok=True)

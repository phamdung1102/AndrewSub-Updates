"""Cài thành phần còn thiếu NGAY TRONG APP (app-first: mở app trước, tải sau).

Dùng cho tab "Cập nhật": liệt kê từ bootstrap.component_status, cài từng cái
theo yêu cầu — pip vào chính Python đang chạy, model tải về data/hf_cache,
FFmpeg tải bản essentials về data/ffmpeg. Google Chrome và 6 giọng preset không
tự cài được (một cái là trình cài riêng của Google, một cái đóng kèm app).
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any, Callable

from vicdub.core import bootstrap
from vicdub.utils.process_utils import hidden_process_kwargs

logger = logging.getLogger(__name__)

ReportFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]

TORCH_VER = "2.8.0"
TORCHAUDIO_VER = "2.8.0"
CUDA_INDEX = "https://download.pytorch.org/whl/cu128"
CPU_INDEX = "https://download.pytorch.org/whl/cpu"
FFMPEG_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"

# Thứ tự cài an toàn (phụ thuộc trước, nặng sau) + ước lượng dung lượng tải.
INSTALL_ORDER = ("numpy", "ffmpeg", "playwright", "torch",
                 "omnivoice", "omnivoice_model")
_SIZE_GB = {"numpy": 0.03, "ffmpeg": 0.09, "playwright": 0.04,
            "torch_cpu": 0.5, "torch_cuda": 9.0,
            "omnivoice": 0.2, "omnivoice_model": 3.0}


def has_nvidia_gpu() -> bool:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return False
    try:
        return subprocess.run(
            [exe, "-L"], capture_output=True, timeout=10,
            **hidden_process_kwargs(),
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def installable(key: str) -> bool:
    """App tự cài được thành phần này không?"""
    return key in INSTALL_ORDER


def estimate_size_gb(keys, cuda: bool | None = None) -> float:
    """Ước lượng GB phải tải cho danh sách thành phần (để cảnh báo trước)."""
    if cuda is None:
        cuda = has_nvidia_gpu()
    total = 0.0
    for key in keys:
        if key == "torch":
            total += _SIZE_GB["torch_cuda" if cuda else "torch_cpu"]
        else:
            total += _SIZE_GB.get(key, 0.0)
    return round(total, 1)


def sort_for_install(keys) -> list[str]:
    """Sắp các key theo thứ tự cài an toàn; key lạ bị loại."""
    wanted = {str(k) for k in keys}
    return [k for k in INSTALL_ORDER if k in wanted]


def _pip(args: list[str], report: ReportFn, is_cancelled: CancelFn) -> None:
    """pip install vào CHÍNH python đang chạy; stream log ra report(-1, ...)."""
    cmd = [sys.executable, "-m", "pip", "install", "--no-input", *args]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace",
                            **hidden_process_kwargs())
    assert proc.stdout is not None
    for line in proc.stdout:
        if is_cancelled():
            proc.terminate()
            raise RuntimeError("Đã huỷ.")
        line = line.strip()
        if line:
            report(-1, line[:110])
    if proc.wait() != 0:
        raise RuntimeError("pip install thất bại (xem log/mạng).")


def _install_ffmpeg(config: Any, report: ReportFn, is_cancelled: CancelFn) -> None:
    """Tải FFmpeg essentials (~85MB) về data/ffmpeg và trỏ config vào đó."""
    import requests  # noqa: PLC0415

    dest_dir = Path(getattr(config, "data_dir", "data")) / "ffmpeg"
    dest_dir.mkdir(parents=True, exist_ok=True)
    zip_path = dest_dir / "_ffmpeg_download.zip"

    report(1, "Tải FFmpeg (~85MB)...")
    with requests.get(FFMPEG_URL, stream=True, timeout=(15, 300)) as resp:
        resp.raise_for_status()
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        with open(zip_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                if is_cancelled():
                    raise RuntimeError("Đã huỷ.")
                f.write(chunk)
                done += len(chunk)
                if total:
                    report(int(80 * done / total),
                           f"Tải FFmpeg {done // (1 << 20)}/{total // (1 << 20)}MB...")

    report(85, "Giải nén FFmpeg...")
    wanted = {"ffmpeg.exe", "ffprobe.exe"}
    found: dict[str, str] = {}
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = Path(info.filename).name.lower()
            if name in wanted and "/bin/" in info.filename.replace("\\", "/"):
                with zf.open(info) as src, open(dest_dir / name, "wb") as out:
                    shutil.copyfileobj(src, out)
                found[name] = str(dest_dir / name)
    zip_path.unlink(missing_ok=True)
    if set(found) != wanted:
        raise RuntimeError("Gói FFmpeg tải về không có đủ ffmpeg.exe/ffprobe.exe.")

    config.ffmpeg_path = found["ffmpeg.exe"]
    config.ffprobe_path = found["ffprobe.exe"]
    if callable(getattr(config, "save", None)):
        config.save()
    report(100, f"FFmpeg sẵn sàng: {dest_dir}")


def install_component(key: str, config: Any, report: ReportFn,
                      is_cancelled: CancelFn, cuda: bool | None = None) -> None:
    """Cài MỘT thành phần theo key của bootstrap.component_status."""
    if key == "torch":
        use_cuda = has_nvidia_gpu() if cuda is None else cuda
        report(0, f"Cài PyTorch {'GPU (NVIDIA)' if use_cuda else 'CPU'} — vài phút...")
        index = CUDA_INDEX if use_cuda else CPU_INDEX
        _pip([f"torch=={TORCH_VER}", f"torchaudio=={TORCHAUDIO_VER}",
              "--index-url", index], report, is_cancelled)
    elif key == "omnivoice":
        report(0, "Cài OmniVoice...")
        _pip(["omnivoice>=0.1.5"], report, is_cancelled)
    elif key == "numpy":
        report(0, "Cài NumPy...")
        _pip(["numpy"], report, is_cancelled)
    elif key == "playwright":
        report(0, "Cài Playwright (OCR web dùng Chrome sẵn có, không tải Chromium)...")
        _pip(["playwright"], report, is_cancelled)
    elif key == "omnivoice_model":
        bootstrap.ensure_omnivoice_model(config, progress=report)
    elif key == "ffmpeg":
        _install_ffmpeg(config, report, is_cancelled)
    else:
        raise RuntimeError(f"Thành phần '{key}' không tự cài được từ app.")


def install_missing(config: Any, report: ReportFn | None = None,
                    is_cancelled: CancelFn | None = None,
                    keys=None, cuda: bool | None = None) -> list[str]:
    """Cài các thành phần còn thiếu (mặc định: mọi thứ app tự cài được).

    Trả danh sách key đã cài xong. Tiến trình chia đều theo số việc.
    """
    def say(pct: int, msg: str) -> None:
        if report:
            report(pct, msg)

    def cancelled() -> bool:
        return bool(is_cancelled and is_cancelled())

    missing_keys = [c.key for c in bootstrap.missing(config)]
    todo = sort_for_install(missing_keys if keys is None else
                            [k for k in keys if k in missing_keys])
    if not todo:
        say(100, "Mọi thành phần đã sẵn sàng.")
        return []

    done: list[str] = []
    total = len(todo)
    for index, key in enumerate(todo):
        if cancelled():
            raise RuntimeError("Đã huỷ.")
        base = int(100 * index / total)
        span = max(1, int(100 / total))

        def scaled(pct: int, msg: str, _base=base, _span=span) -> None:
            if pct < 0:
                say(-1, msg)
            else:
                say(min(99, _base + int(_span * min(100, pct) / 100)), msg)

        install_component(key, config, scaled, cancelled, cuda=cuda)
        done.append(key)
    say(100, f"Đã cài xong {len(done)} thành phần.")
    return done

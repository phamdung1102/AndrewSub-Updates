"""Khoá voice NHẬP TAY theo dòng — chống TTS đè mất khi 'Sinh giọng' chạy lại.

Voice người dùng tự chọn (nhập thư mục hoặc chọn file cho từng dòng) nằm ở
``voices/NNNN.wav`` y hệt voice TTS sinh ra. Không đánh dấu thì lần Sinh giọng
kế tiếp sẽ sinh lại và ghi đè (file nhập không có trong cache theo hash text).
Danh sách dòng khoá lưu ``voices/custom_lines.json`` — đi cùng project, không
cần đổi schema database.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_FILE = "custom_lines.json"


def _store(project_root: str | Path) -> Path:
    return Path(project_root) / "voices" / _FILE


def load_custom_lines(project_root: str | Path) -> set[int]:
    """Các dòng đang dùng voice nhập tay (TTS phải bỏ qua)."""
    try:
        raw = json.loads(_store(project_root).read_text(encoding="utf-8"))
        return {int(v) for v in raw.get("lines", [])}
    except (OSError, ValueError, TypeError):
        return set()


def _save(project_root: str | Path, lines: set[int]) -> None:
    store = _store(project_root)
    store.parent.mkdir(parents=True, exist_ok=True)
    store.write_text(
        json.dumps({"lines": sorted(lines)}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def mark_custom_lines(project_root: str | Path, lines) -> set[int]:
    """Khoá thêm các dòng (giữ khoá cũ). Trả về tập sau khi cập nhật."""
    merged = load_custom_lines(project_root) | {int(v) for v in lines}
    _save(project_root, merged)
    return merged


def unmark_custom_lines(project_root: str | Path, lines) -> set[int]:
    """Gỡ khoá các dòng (TTS được phép sinh lại). Trả về tập sau khi cập nhật."""
    remaining = load_custom_lines(project_root) - {int(v) for v in lines}
    _save(project_root, remaining)
    return remaining

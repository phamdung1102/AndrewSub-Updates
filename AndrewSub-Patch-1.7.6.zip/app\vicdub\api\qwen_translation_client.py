"""Qwen/DashScope translation client using the OpenAI-compatible chat API."""

from __future__ import annotations

import json
import logging
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable

import requests

from vicdub.utils.secret_store import unprotect_secret

logger = logging.getLogger(__name__)


class QwenTranslationError(RuntimeError):
    """Qwen translation error safe to show in the UI."""


class QwenTranslationClient:
    """Translate subtitle batches with Qwen through DashScope compatible mode."""

    def __init__(self, config) -> None:
        self.base_url = str(
            getattr(config, "translation_qwen_base_url", "")
            or "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
        ).rstrip("/")
        self.model = str(getattr(config, "translation_qwen_model", "") or "qwen-plus")
        self.key = unprotect_secret(getattr(config, "translation_qwen_api_key", ""))
        self.timeout = max(20, int(getattr(config, "translation_qwen_timeout", 90)))
        self.retry = max(1, int(getattr(config, "translation_qwen_retry", 3)))
        self.parallel = max(1, min(4, int(getattr(config, "translation_parallel", 4))))
        self.chunk_chars = max(1200, int(getattr(config, "translation_chunk_chars", 3500)))
        self.chunk_lines = max(50, int(getattr(config, "translation_chunk_lines", 450)))
        self.character_sheet_enabled = bool(
            getattr(config, "translation_character_sheet", True)
        )
        self.mode = str(getattr(config, "translation_mode", "balanced") or "balanced")
        if self.mode == "fast":
            self.parallel = max(self.parallel, 4)
            self.chunk_chars = max(self.chunk_chars, 5200)
            self.chunk_lines = max(self.chunk_lines, 600)
            self.character_sheet_enabled = False
        elif self.mode == "quality":
            self.parallel = min(self.parallel, 2)
            self.chunk_chars = min(self.chunk_chars, 2600)
            self.chunk_lines = min(self.chunk_lines, 220)
            self.character_sheet_enabled = True
        self.tts_chars_per_second = max(
            8.0, float(getattr(config, "tts_chars_per_second", 15.0))
        )
        if not self.key:
            raise QwenTranslationError("Chưa có khóa Qwen API cho nguồn dịch này.")

    def _chat(self, prompt: str) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You translate subtitles for dubbing. Follow the requested "
                        "output format exactly."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,
            "max_tokens": 8192,
        }
        last_error = ""
        for attempt in range(self.retry):
            try:
                response = requests.post(
                    url, headers=headers, json=payload, timeout=self.timeout
                )
            except requests.RequestException as exc:
                last_error = f"Lỗi mạng: {exc}"
                time.sleep(min(6, 1 + attempt * 2))
                continue
            if response.status_code == 200:
                try:
                    return response.json()["choices"][0]["message"]["content"]
                except (KeyError, IndexError, TypeError, ValueError) as exc:
                    raise QwenTranslationError(
                        f"Qwen trả cấu trúc lạ: {response.text[:300]}"
                    ) from exc
            if response.status_code in {429, 500, 502, 503, 504}:
                last_error = f"Qwen trả {response.status_code}: {response.text[:240]}"
                time.sleep(min(12, 2 + attempt * 3))
                continue
            if response.status_code in {401, 403}:
                raise QwenTranslationError(
                    "Qwen API key không hợp lệ hoặc chưa có quyền gọi model."
                )
            raise QwenTranslationError(
                f"Qwen trả {response.status_code}: {response.text[:300]}"
            )
        raise QwenTranslationError(f"Gọi Qwen thất bại sau nhiều lần thử. {last_error}")

    @staticmethod
    def _chunks(lines: list[dict], max_lines: int, max_chars: int) -> list[list[dict]]:
        chunks: list[list[dict]] = []
        current: list[dict] = []
        chars = 0
        for item in lines:
            text_size = len(str(item.get("text", ""))) + 12
            if current and (len(current) >= max_lines or chars + text_size > max_chars):
                chunks.append(current)
                current = []
                chars = 0
            current.append(item)
            chars += text_size
        if current:
            chunks.append(current)

        for index in range(1, len(chunks)):
            previous = chunks[index - 1][-8:]
            chunks[index][0] = dict(chunks[index][0])
            chunks[index][0]["_context_before"] = "\n".join(
                f'{item.get("line")}|{item.get("speaker") or ""}|{item.get("text", "")}'
                for item in previous
            )
        for index in range(0, len(chunks) - 1):
            following = chunks[index + 1][:8]
            chunks[index][-1] = dict(chunks[index][-1])
            chunks[index][-1]["_context_after"] = "\n".join(
                f'{item.get("line")}|{item.get("speaker") or ""}|{item.get("text", "")}'
                for item in following
            )
        return chunks

    @staticmethod
    def _parse_json_objects(text: str) -> list[dict]:
        cleaned = re.sub(r"```(?:json)?", "", text or "").strip().strip("`")
        match = re.search(r"\[.*\]", cleaned, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                if isinstance(data, list):
                    return [item for item in data if isinstance(item, dict)]
            except json.JSONDecodeError:
                pass
        objects: list[dict] = []
        for match in re.finditer(r"\{[^{}]*\}", cleaned):
            try:
                item = json.loads(match.group(0))
                if isinstance(item, dict):
                    objects.append(item)
            except json.JSONDecodeError:
                continue
        return objects

    @staticmethod
    def _parse_pipe_lines(text: str) -> list[dict]:
        """Parse compact Qwen output: line|speaker|translation."""
        rows: list[dict] = []
        cleaned = re.sub(r"```(?:text|json)?", "", text or "").strip().strip("`")
        for raw in cleaned.splitlines():
            line = raw.strip()
            if not line or "|" not in line:
                continue
            parts = [part.strip() for part in line.split("|")]
            if not parts or not parts[0].lstrip("-").isdigit():
                continue
            number = int(parts[0])
            speaker = ""
            body_parts = parts[1:]
            for idx, part in enumerate(body_parts):
                if re.fullmatch(r"S\d+", part, flags=re.IGNORECASE):
                    speaker = part.upper()
                    body_parts = body_parts[:idx] + body_parts[idx + 1 :]
                    break
            body_parts = [
                part
                for part in body_parts
                if part
                and part.casefold()
                not in {
                    "so",
                    "sodong",
                    "line",
                    "speaker",
                    "ban dich",
                    "bản dịch",
                    "translation",
                }
            ]
            translation = "|".join(body_parts).strip()
            if translation:
                rows.append(
                    {"line": number, "speaker": speaker, "translation": translation}
                )
        return rows

    @classmethod
    def _parse_numbered_lines(cls, text: str, valid_lines: set[int]) -> list[dict]:
        """Accept harmless format drift such as ``12: text`` or ``12) text``.

        Only IDs present in the request are accepted, so a natural sentence that
        starts with a year/quantity cannot silently attach to another subtitle.
        """
        rows = cls._parse_pipe_lines(text)
        found = {int(row["line"]) for row in rows}
        cleaned = re.sub(r"```(?:text|json)?", "", text or "").strip().strip("`")
        pattern = re.compile(r"^\s*[\[（(【]?\s*(\d{1,7})\s*[\]）)】]?\s*(?:[:：.．、)）\-_—])\s*(.+?)\s*$")
        for raw in cleaned.splitlines():
            match = pattern.match(raw)
            if not match:
                continue
            number = int(match.group(1))
            body = match.group(2).strip().strip("|｜¦")
            if number not in valid_lines or number in found or not body:
                continue
            rows.append({"line": number, "speaker": "", "translation": body})
            found.add(number)
        return rows

    def _character_sheet(self, lines: list[dict]) -> str:
        if not self.character_sheet_enabled or not lines:
            return ""
        sample = "\n".join(
            f'{item["line"]}|{item.get("text", "")}' for item in lines[:3500]
        )
        prompt = (
            "Analyze the full source subtitle dialogue and return a compact character sheet.\n"
            "Infer gender from names and honorifics only; Chinese speech recognition may confuse he/she, "
            "so do not rely on pronouns.\n"
            "Return JSON array only. Max 20 characters. Fields: id, name, gender, role, addressing.\n"
            "Use id S1, S2, ...; gender is male/female/unknown.\n\n"
            f"Dialogue:\n{sample}"
        )
        try:
            parsed = self._parse_json_objects(self._chat(prompt))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Không tạo được hồ sơ nhân vật Qwen: %s", exc)
            return ""

        safe: list[dict] = []
        for index, item in enumerate(parsed[:20], start=1):
            name = str(item.get("name", "")).strip()
            if not name:
                continue
            gender = str(item.get("gender", "unknown")).strip().lower()
            if gender not in {"male", "female", "unknown"}:
                gender = "unknown"
            safe.append(
                {
                    "id": str(item.get("id", "") or f"S{index}").strip(),
                    "name": name[:40],
                    "gender": gender,
                    "role": str(item.get("role", item.get("vai", ""))).strip()[:80],
                    "addressing": str(
                        item.get("addressing", item.get("xung_ho", ""))
                    ).strip()[:120],
                }
            )
        return json.dumps(safe, ensure_ascii=False) if safe else ""

    def _prompt(
        self, lines: list[dict], target_language: str, character_sheet: str = ""
    ) -> str:
        body = "\n".join(
            f'{item["line"]}|'
            f'{int(item.get("max_chars") or max(4, round(float(item.get("seconds", 0)) * self.tts_chars_per_second)))}|'
            f'{item["text"]}'
            for item in lines
        )
        context_before = str(lines[0].get("_context_before", "")).strip() if lines else ""
        context_after = str(lines[-1].get("_context_after", "")).strip() if lines else ""
        style = str(lines[0].get("_style_instruction", "")).strip() if lines else ""
        addressing = str(lines[0].get("_addressing_guide", "")).strip() if lines else ""
        return (
            f"Translate these movie subtitle lines into {target_language}.\n"
            "Rules:\n"
            "- Keep every input line number exactly once. Do not add, remove or reorder line numbers.\n"
            "- Natural dubbing dialogue, concise, easy to speak aloud.\n"
            "- Keep names, relationships and pronouns consistent across context.\n"
            "- The second input column is max Vietnamese characters; try to stay within it. "
            "If impossible, keep meaning and stay concise.\n"
            "- Do not translate context lines; use them only for story continuity.\n"
            "- Output plain lines only, no markdown, no JSON, no explanation.\n"
            "- Output format with placeholders: <line>|<speaker>|<Vietnamese translation>\n"
            "- Speaker may be blank to mean same speaker as previous line. Use S1, S2... only when useful.\n"
            "Example output:\n"
            "1|S1|Dạ, tiểu thư.\n"
            "2||Con đến đây.\n\n"
            + (f"Style requirement: {style}\n" if style else "")
            + (f"Addressing guide: {addressing}\n" if addressing else "")
            + (f"Character sheet:\n{character_sheet}\n\n" if character_sheet else "")
            + (
                f"Context before, do not translate:\n{context_before}\n\n"
                if context_before
                else ""
            )
            + (
                f"Context after, do not translate:\n{context_after}\n\n"
                if context_after
                else ""
            )
            + "Input format: <line>|<max_chars>|<source subtitle>\n"
            + f"Subtitles to translate:\n{body}"
        )

    def _translate_chunk(
        self,
        chunk: list[dict],
        target_language: str,
        character_sheet: str = "",
        depth: int = 0,
    ) -> list[dict]:
        text = self._chat(self._prompt(chunk, target_language, character_sheet))
        valid_lines = {int(item["line"]) for item in chunk}
        parsed = self._parse_numbered_lines(text, valid_lines)
        if not parsed:
            parsed = self._parse_json_objects(text)
        by_line = {
            int(item["line"]): item
            for item in parsed
            if str(item.get("line", "")).strip().lstrip("-").isdigit()
            and int(item["line"]) in valid_lines
            and str(item.get("translation", "")).strip()
        }
        missing = [item for item in chunk if item["line"] not in by_line]
        if missing and depth < 4 and len(chunk) > 1:
            source = missing if len(missing) < len(chunk) else chunk
            mid = max(1, len(source) // 2)
            for part in (source[:mid], source[mid:]):
                if part:
                    for item in self._translate_chunk(
                        part, target_language, character_sheet, depth + 1
                    ):
                        by_line[int(item["line"])] = item

        result = []
        for item in chunk:
            found = by_line.get(item["line"])
            if found:
                result.append(found)
            else:
                result.append(
                    {
                        "line": item["line"],
                        "speaker": item.get("speaker") or "",
                        "translation": "",
                        "failed": True,
                    }
                )
        return result

    def translate_bulk(
        self,
        lines: list[dict],
        target_language: str,
        chunk_lines: int = 120,
        progress: Callable[[int, int], None] | None = None,
        on_batch: Callable[[list[dict]], None] | None = None,
    ) -> list[dict]:
        max_lines = min(max(1, int(chunk_lines)), self.chunk_lines)
        chunks = self._chunks(lines, max_lines, self.chunk_chars)
        character_sheet = self._character_sheet(lines)
        output_by_line: dict[int, dict] = {}
        done = 0
        total = len(lines)

        def run_chunk(chunk: list[dict]) -> list[dict]:
            return self._translate_chunk(chunk, target_language, character_sheet)

        workers = min(self.parallel, max(1, len(chunks)))
        if workers <= 1:
            for chunk in chunks:
                translated = run_chunk(chunk)
                output_by_line.update({int(item["line"]): item for item in translated})
                done += len(chunk)
                if on_batch:
                    on_batch(translated)
                if progress:
                    progress(min(done, total), total)
        else:
            with ThreadPoolExecutor(max_workers=workers) as executor:
                future_to_size = {
                    executor.submit(run_chunk, chunk): len(chunk) for chunk in chunks
                }
                for future in as_completed(future_to_size):
                    translated = future.result()
                    output_by_line.update(
                        {int(item["line"]): item for item in translated}
                    )
                    done += future_to_size[future]
                    if on_batch:
                        on_batch(translated)
                    if progress:
                        progress(min(done, total), total)

        return [
            output_by_line.get(
                int(item["line"]),
                {
                    "line": item["line"],
                    "speaker": item.get("speaker") or "",
                    "translation": "",
                    "failed": True,
                },
            )
            for item in lines
        ]


def qwen_translation_configured(config) -> bool:
    return bool(unprotect_secret(getattr(config, "translation_qwen_api_key", "")))

"""Translate Module.

Mode 1: Gemini dịch phụ đề.
Mode 2: Import translated.srt - không bắt buộc dịch bằng AI.

Có Translation Memory: câu đã dịch không gọi lại Gemini.

Output: segments (đã có translation), translated_srt
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.subtitles import (
    Segment, clean_subtitle_text, load_subtitle_file, normalize_gender, write_srt,
)
from vicdub.utils.translation_styles import genre_instruction, style_instruction


class TranslateModule(BaseModule):
    """Dịch phụ đề."""

    name = "Dịch phụ đề"

    @staticmethod
    def _clean_translation(value: str) -> str:
        """Clean transport/parser artifacts from translated subtitle text."""
        text = clean_subtitle_text(value)
        # Qwen pipe output may return "1||text"; after parsing this used to leave
        # a leading "|" in the translation. Strip only edge delimiters/noise.
        text = text.strip().strip("|｜¦")
        # Một số model vẫn nhét marker dòng vào chính field translation:
        # "6|Giả người ngoài hành tinh?", "18] Chị còn cứng miệng",
        # "23. Còn tưởng..." -> bỏ marker, giữ câu dịch thật.
        # Chỉ xử lý khi số đứng đầu kèm dấu phân cách rõ ràng, không đụng số
        # nội dung như "300 tỷ", "1 người".
        for _ in range(3):
            text = re.sub(r"^\s*[\[【]\s*\d{1,6}\s*[\]】]\s*", "", text).strip()
            cleaned = re.sub(
                r"^\s*(?:[#\[\(【]?\s*\d{1,6}\s*[\]\)】]?\s*(?:[|｜¦:：.．、,，;-]|-\s+)\s*)+",
                "",
                text,
            ).strip()
            if cleaned == text:
                break
            text = cleaned.strip().strip("|｜¦")
        # Target Vietnamese should not contain raw CJK fragments. If a mostly
        # Latin/Vietnamese translation still contains Chinese/Japanese/Han text,
        # drop those fragments instead of letting TTS read them.
        has_latin = bool(re.search(r"[A-Za-zÀ-ỹĐđ]", text))
        if has_latin and re.search(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]", text):
            text = re.sub(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]+", "", text)
            text = re.sub(r"\s+([,.!?;:])", r"\1", text)
            text = re.sub(r"\s{2,}", " ", text)
        # Model sometimes leaves a dangling dash after names, e.g. "Giang Nhất Yến—".
        text = re.sub(r"\s*[—–-]+\s*$", "", text)
        text = text.strip()
        return text

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        if not segments:
            raise ModuleError("Chưa có phụ đề. Chạy bước 'Tách phụ đề' trước.")

        translated_path = data.get("translated_subtitle_path", "")
        if translated_path:
            self._mode_import(segments, translated_path)
        else:
            self._mode_gemini(segments, data)

        # Lưu kết quả. Không xoá/insert lại toàn bảng ở cuối bước dịch: với file dài
        # vài nghìn dòng, thao tác đó làm app đứng ở 97% dù phần dịch đã xong.
        translated_srt = Path(project.root) / "subtitles" / "translated.srt"
        write_srt(segments, translated_srt, translated=True)
        (Path(project.root) / "subtitles" / "translated.partial.srt").unlink(missing_ok=True)
        if hasattr(project, "update_segments"):
            project.update_segments(segments)
        else:
            project.save_segments(segments)

        self.report(100, f"Đã dịch {len(segments)} dòng")
        return {"segments": segments, "translated_srt": str(translated_srt)}

    # ---------- Mode 2: import bản dịch có sẵn ----------

    def _mode_import(self, segments: list[Segment], translated_path: str) -> None:
        self.report(20, f"Import bản dịch: {Path(translated_path).name}")
        if not Path(translated_path).exists():
            raise ModuleError(f"File không tồn tại: {translated_path}")
        translated = load_subtitle_file(translated_path)
        if len(translated) != len(segments):
            self.logger.warning(
                "Bản dịch %d dòng, gốc %d dòng - ghép theo thứ tự",
                len(translated), len(segments),
            )
        for seg, tr in zip(segments, translated):
            seg.translation = self._clean_translation(tr.text)
            if tr.speaker:
                seg.speaker = tr.speaker
            seg.gender = normalize_gender(tr.gender or seg.gender)
        # Dòng thiếu bản dịch thì để trống để người dùng thấy rõ và dịch bù;
        # không fallback sang text gốc vì TTS sẽ đọc tiếng nguồn.
        for seg in segments:
            if not seg.speaker:
                seg.speaker = "Narrator"

    # ---------- Mode 1: Gemini ----------

    def _mode_gemini(self, segments: list[Segment], data: dict[str, Any]) -> None:
        api_client = data.get("gemini")
        tm = data.get("tm")
        config = data["config"]
        project = data["project"]
        target_language = str(getattr(config, "target_language", "") or "").strip()
        if not target_language:
            raise ModuleError("Chưa chọn ngôn ngữ đích. Mở Dịch tự động và chọn ngôn ngữ cần dịch.")
        source = getattr(config, "translation_source", "web")
        progress_state = {"done": 0, "total": max(1, len(segments))}

        def worker_status(message: str) -> None:
            pct = 10 + int(
                80 * progress_state["done"] / max(1, progress_state["total"])
            )
            self.report(pct, message)

        web_clients = []
        qwen_client = None
        if source == "qwen":
            try:
                from vicdub.api.qwen_translation_client import QwenTranslationClient  # noqa: PLC0415
                qwen_client = QwenTranslationClient(config)
            except Exception as exc:  # noqa: BLE001
                raise ModuleError(f"Chưa dùng được Qwen API: {exc}") from exc
        translator = qwen_client or api_client
        if source == "web":
            from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415
            from vicdub.api.web_translation_pool import WebTranslationPool  # noqa: PLC0415
            count = max(1, min(4, int(getattr(config, "translation_web_profiles", 2))))
            account_by_slot = {
                int(item.get("slot", 0)): item
                for item in (getattr(config, "translation_accounts", []) or [])
                if str(item.get("slot", "")).isdigit()
            }
            for index in range(count):
                slot = index + 1
                account = account_by_slot.get(slot, {})
                marker = (
                    Path(config.data_dir)
                    / f"gemini_web_login_translation_{slot}.ok"
                )
                if (
                    not marker.exists()
                    or str(account.get("status", "")) in {"error", "duplicate"}
                ):
                    self.logger.warning(
                        "Bỏ qua phiên dịch %d vì chưa đăng nhập hoặc kiểm tra lỗi.",
                        slot,
                    )
                    continue
                client = GeminiWebClient(
                    config.data_dir, report=None,
                    login_timeout=getattr(config, "gemini_web_login_timeout", 300),
                    response_timeout=min(
                        120, int(getattr(config, "gemini_web_response_timeout", 240))
                    ),
                    profile_name=f"translation_{slot}",
                    # Tác vụ nền không được bật bốn cửa sổ đăng nhập cùng lúc.
                    allow_interactive_login=False,
                )
                email = str(account.get("email", "")).strip()
                client.display_name = (
                    f"Phiên {slot} · {email}" if email else f"Phiên {slot}"
                )
                web_clients.append(client)
            if not web_clients:
                raise ModuleError(
                    "Không có phiên dịch nào sẵn sàng. Vào Cài đặt → "
                    "Dịch & Đồng bộ, đăng nhập rồi bấm 'Kiểm tra tất cả tuần tự'."
                )
            self.report(
                4,
                "Phiên dịch đang dùng: "
                + ", ".join(client.display_name for client in web_clients),
            )
            fallback = None
            if getattr(config, "translation_api_fallback", True):
                try:
                    from vicdub.api.qwen_translation_client import (  # noqa: PLC0415
                        QwenTranslationClient,
                        qwen_translation_configured,
                    )
                    if qwen_translation_configured(config):
                        fallback = QwenTranslationClient(config)
                except Exception as exc:  # noqa: BLE001
                    self.logger.warning("Không khởi tạo được Qwen fallback: %s", exc)
                if fallback is None:
                    fallback = api_client
            translator = WebTranslationPool(
                web_clients, api_fallback=fallback, status=worker_status
            )
        if translator is None:
            raise ModuleError(
                "Chưa cấu hình nguồn dịch dự phòng. Thêm khóa truy cập ở tab Cài đặt, "
                "hoặc import file translated.srt ở tab Dịch AI."
            )

        style = getattr(config, "translation_style", "conversational")
        instruction = style_instruction(
            style, getattr(config, "translation_style_custom", "")
        )
        genre = getattr(config, "translation_genre", "neutral")
        custom_overrides = style == "custom" and bool(
            str(getattr(config, "translation_style_custom", "")).strip()
        )
        genre_note = genre_instruction(genre, custom_overrides=custom_overrides)
        if genre_note:
            instruction = f"{instruction} Thể loại: {genre_note}".strip()
        translation_mode = getattr(config, "translation_mode", "balanced")
        addressing_enabled = bool(
            getattr(config, "translation_addressing_enabled", True)
        )
        speaker_profiles: dict[str, str] = {}
        if addressing_enabled:
            for segment in segments:
                speaker = (segment.speaker or "").strip()
                gender = (segment.gender or "neutral").strip().lower()
                if speaker and speaker.casefold() not in {"narrator", "unknown", "—"}:
                    speaker_profiles.setdefault(speaker, gender)
        profile_text = ", ".join(
            f"{name} ({gender})"
            for name, gender in list(speaker_profiles.items())[:30]
        )
        addressing_guide = ""
        if addressing_enabled:
            addressing_guide = (
                "Giữ nhất quán vai nói và chiều xưng hô trong toàn tập. Không được "
                "đảo anh/em giữa hai người. Dựa vào trường người nói, giới tính và "
                "các câu trước/sau; nếu chưa đủ chắc chắn thì ưu tiên tôi/bạn hoặc "
                "cách gọi trung tính, không tự đoán quan hệ."
            )
            if profile_text:
                addressing_guide += f" Danh sách người nói đã biết: {profile_text}."
        # Phong cách là một phần của khóa cache; đổi phong cách không lấy nhầm bản cũ.
        def tm_key(text: str, speaker: str = "", gender: str = "neutral") -> str:
            return (
                f"[target={target_language};style={style}:{instruction};genre={genre};"
                f"mode={translation_mode};"
                f"addressing={int(addressing_enabled)};speaker={speaker or 'unknown'};"
                f"gender={gender or 'neutral'}] {text}"
            )

        # Tra Translation Memory trước.
        pending: list[Segment] = []
        unreadable: list[Segment] = []
        for seg in segments:
            if (seg.text or "").strip().casefold().startswith("[ocr chưa đọc được"):
                # Không gửi placeholder lên dịch vụ và không tạo voice từ một câu
                # không có nguyên văn. Người dùng vẫn thấy timing để sửa ô Gốc.
                seg.translation = ""
                unreadable.append(seg)
                continue
            cached = tm.get(
                tm_key(seg.text, seg.speaker, seg.gender)
            ) if tm else None
            if cached:
                seg.translation = self._clean_translation(cached)
                if not seg.speaker:
                    seg.speaker = "Narrator"
            else:
                pending.append(seg)

        done = len(segments) - len(pending) - len(unreadable)
        if done:
            self.report(5, f"Translation Memory khớp {done} dòng")
        if unreadable:
            self.logger.warning(
                "Bỏ qua %d dòng nhận diện chưa đọc được khi dịch: %s",
                len(unreadable), ", ".join(str(s.line) for s in unreadable[:20]),
            )
        if not pending:
            for client in web_clients:
                client.close()
            self.report(95, "Không còn dòng hợp lệ cần dịch; các dòng nhận diện lỗi được giữ để sửa tay.")
            return

        # Dịch CẢ FILE: đẩy trọn nội dung còn lại lên Gemini theo khối lớn để
        # model thấy toàn bộ ngữ cảnh -> tên riêng, xưng hô nhất quán cả tập.
        payload = [
            {"line": s.line, "text": s.text, "seconds": round(s.duration, 1),
             "max_chars": max(
                 4,
                 int(round(
                     s.duration
                     * float(getattr(config, "tts_chars_per_second", 15.0))
                 )),
             ),
             "start": round(s.start, 3), "speaker": s.speaker or "",
             "gender": s.gender or "neutral",
             "_style_instruction": instruction,
             "_addressing_guide": addressing_guide}
            for s in pending
        ]

        def prog(done_lines: int, total_lines: int) -> None:
            self.check_cancelled()
            progress_state["done"] = done_lines
            progress_state["total"] = total_lines
            pct = 10 + int(80 * done_lines / max(1, total_lines))
            self.report(pct, f"Đang dịch {done_lines}/{total_lines} dòng...")

        self.report(10, f"Đang gửi {len(pending)} dòng để dịch...")
        progress_state["total"] = len(pending)
        by_segment = {segment.line: segment for segment in segments}
        partial_srt = Path(project.root) / "subtitles" / "translated.partial.srt"
        partial_state = {"batches": 0}

        def save_partial(batch_results: list[dict]) -> None:
            """Ghi ngay batch vừa xong để lỗi giữa phim không mất bản dịch."""
            changed = []
            memory_rows = []
            for item in batch_results:
                line = int(item.get("line", -1))
                translation = self._clean_translation(str(item.get("translation", "")))
                segment = by_segment.get(line)
                if segment is None or not translation:
                    continue
                segment.translation = translation
                speaker = str(item.get("speaker", "")).strip()
                if speaker:
                    segment.speaker = speaker
                gender = normalize_gender(str(item.get("gender", "")))
                if gender != "neutral":
                    segment.gender = gender
                if not segment.speaker:
                    segment.speaker = "Narrator"
                changed.append(segment)
                if tm:
                    memory_rows.append(
                        (tm_key(segment.text, segment.speaker, segment.gender),
                         translation, target_language)
                    )
            if hasattr(project, "update_segments"):
                project.update_segments(changed)
            else:
                for segment in changed:
                    project.update_segment(segment)
            if tm and memory_rows:
                if hasattr(tm, "put_many"):
                    tm.put_many(memory_rows)
                else:
                    for source_text, target_text, lang in memory_rows:
                        tm.put(source_text, target_text, lang)
            partial_state["batches"] += 1
            if partial_state["batches"] % 3 == 0:
                write_srt(segments, partial_srt, translated=True)

        try:
            if source == "web":
                configured_batch = max(
                    1, int(getattr(config, "translate_batch_size", 30))
                )
                if translation_mode == "fast":
                    configured_batch = max(configured_batch, 48)
                elif translation_mode == "quality":
                    configured_batch = min(configured_batch, 20)
                if len(pending) >= 1000:
                    configured_batch = max(configured_batch, 42)
                elif len(pending) >= 400:
                    configured_batch = max(configured_batch, 36)
                results = translator.translate_bulk_resumable(
                    payload, target_language,
                    chunk_lines=configured_batch,
                    progress=prog,
                    checkpoint_dir=str(Path(project.root) / ".translation_checkpoint"),
                    on_batch=save_partial,
                )
            elif source == "qwen":
                configured_batch = max(
                    40,
                    int(
                        getattr(
                            config,
                            "translation_chunk_lines",
                            getattr(config, "translate_batch_size", 120),
                        )
                    ),
                )
                if translation_mode == "fast":
                    configured_batch = max(configured_batch, 300)
                elif translation_mode == "quality":
                    configured_batch = min(configured_batch, 120)
                results = translator.translate_bulk(
                    payload, target_language,
                    chunk_lines=configured_batch,
                    progress=prog,
                    on_batch=save_partial,
                )
            else:
                results = translator.translate_bulk(
                    payload, target_language,
                    chunk_lines=int(getattr(config, "translate_batch_size", 80)),
                    progress=prog,
                )
        except Exception as exc:  # noqa: BLE001
            raise ModuleError(f"Dịch thất bại: {exc}") from exc
        finally:
            for client in web_clients:
                client.close()

        by_line = {int(r.get("line", -1)): r for r in results}
        final_memory_rows = []
        failed_lines = []
        for seg in pending:
            r = by_line.get(seg.line)
            translation = self._clean_translation(str((r or {}).get("translation", "")))
            seg.translation = translation
            if not translation:
                failed_lines.append(seg.line)
            speaker = str((r or {}).get("speaker", "")).strip()
            if speaker:
                seg.speaker = speaker
            gender = normalize_gender(str((r or {}).get("gender", "")))
            if gender != "neutral":
                seg.gender = gender
            if not seg.speaker:
                seg.speaker = "Narrator"
            if tm and translation:
                final_memory_rows.append(
                    (tm_key(seg.text, seg.speaker, seg.gender),
                     seg.translation, target_language)
                )
        if failed_lines:
            preview = ", ".join(str(n) for n in failed_lines[:20])
            more = "..." if len(failed_lines) > 20 else ""
            message = (
                f"{len(failed_lines)} dòng dịch lỗi/thiếu, đã để trống để sửa hoặc dịch bù "
                f"(dòng {preview}{more})"
            )
            self.logger.warning(message)
            project.add_history("translate", "warning", message)
            self.report(96, message)

        if (
            source == "qwen"
            and bool(getattr(config, "asr_gender_from_audio", True))
            and getattr(project, "video_path", "")
        ):
            try:
                from vicdub.utils.voice_gender import apply_audio_gender  # noqa: PLC0415

                genders = apply_audio_gender(
                    project.video_path,
                    segments,
                    getattr(config, "ffmpeg_path", "ffmpeg"),
                    work_dir=Path(project.root) / ".voice_gender",
                )
                if genders:
                    summary = ", ".join(
                        f"{speaker}:{gender}"
                        for speaker, gender in list(genders.items())[:12]
                    )
                    self.logger.info("Đã gán giới tính theo audio: %s", summary)
                    project.add_history(
                        "translate", "done",
                        f"Gán giới tính theo audio cho {len(genders)} nhân vật",
                    )
            except Exception as exc:  # noqa: BLE001
                self.logger.warning("Bỏ qua gán giới tính theo audio: %s", exc)
        if tm and final_memory_rows:
            if hasattr(tm, "put_many"):
                tm.put_many(final_memory_rows)
            else:
                for source_text, target_text, lang in final_memory_rows:
                    tm.put(source_text, target_text, lang)

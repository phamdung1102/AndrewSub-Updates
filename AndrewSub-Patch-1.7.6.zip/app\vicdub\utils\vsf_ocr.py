"""Tách phụ đề = VideoSubFinder (phát hiện + timing) → Drive OCR (đọc chữ).

Thay cho luồng extract_keyframes tự chế: VSF cho mốc thời gian chính xác và một
ảnh sạch mỗi câu, nên KHÔNG cần dedup/gộp/căn lại (nguồn lỗi sót-lặp-lệch cũ).
Ở đây chỉ việc OCR từng ảnh VSF rồi gán chữ vào đúng mốc VSF.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

from vicdub.utils.llm_ocr_subtitles import plan_batches
from vicdub.utils.subtitles import Segment
from vicdub.utils.vsf_scanner import (
    VsfSegment, clear_vsf_output, run_vsf,
)

logger = logging.getLogger(__name__)

ProgressFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]


def _ocr_images(
    client, images: list, batch: int, lang_hint: str,
    report: ProgressFn, is_cancelled: CancelFn,
) -> list[str]:
    """OCR danh sách ảnh sub qua Drive: montage theo lô + vá ảnh rỗng song song."""
    results = [""] * len(images)
    batches = plan_batches(len(images), max(1, batch))
    recover = getattr(client, "read_single", None)
    for bi, (i0, i1) in enumerate(batches):
        if is_cancelled():
            raise RuntimeError("Đã hủy theo yêu cầu.")
        group = images[i0:i1]
        ids = list(range(1, len(group) + 1))
        montage = client.build_montage(group, ids)
        texts = client.read_subtitle_montage(montage, ids, lang_hint=lang_hint)
        if recover is not None:
            empty = [o for o, pid in enumerate(ids)
                     if not (texts.get(pid) or "").strip()]
            if empty:
                def _one(o: int):
                    try:
                        return o, recover(group[o], lang_hint)
                    except Exception:  # noqa: BLE001
                        return o, ""
                with ThreadPoolExecutor(max_workers=min(6, len(empty))) as ex:
                    for o, single in ex.map(_one, empty):
                        if single and single.strip():
                            texts[ids[o]] = single
        for o, pid in enumerate(ids):
            results[i0 + o] = texts.get(pid, "") or ""
        report(40 + int(58 * (bi + 1) / max(1, len(batches))),
               f"Đang đọc {min(i1, len(images))}/{len(images)} câu...")
    return results


def vsf_ocr_video(
    video_path: str,
    vsf_exe: str,
    client,
    region: tuple[float, float, float, float],
    output_dir: str,
    batch: int = 20,
    lang_hint: str = "",
    num_threads: int = 4,
    use_cuda: bool = False,
    progress: ProgressFn | None = None,
    cancelled: CancelFn | None = None,
) -> list[Segment]:
    """VideoSubFinder phát hiện + Drive OCR đọc chữ. Trả segments đã có timing chuẩn."""
    def report(pct: int, msg: str) -> None:
        if progress:
            progress(pct, msg)

    def is_cancelled() -> bool:
        return bool(cancelled and cancelled())

    from PIL import Image  # noqa: PLC0415

    vsf_segs: list[VsfSegment] = run_vsf(
        video_path, output_dir, region, vsf_exe,
        num_threads=num_threads, use_cuda=use_cuda,
        report=report, is_cancelled=is_cancelled,
    )

    # Nạp ảnh (bỏ ảnh hỏng), giữ song song với mốc thời gian.
    images: list = []
    metas: list[VsfSegment] = []
    for seg in vsf_segs:
        try:
            with Image.open(seg.image_path) as im:
                images.append(im.convert("RGB").copy())
            metas.append(seg)
        except Exception:  # noqa: BLE001
            logger.warning("Bỏ ảnh VSF hỏng: %s", seg.image_path)

    if not images:
        raise RuntimeError("Không thu được ảnh phụ đề hợp lệ nào từ video.")

    report(40, f"Đang đọc chữ {len(images)} câu phụ đề...")
    texts = _ocr_images(client, images, batch, lang_hint, report, is_cancelled)

    # Dựng segment: timing lấy TỪ VSF (chính xác), chữ từ OCR. Không dedup/gộp.
    segments: list[Segment] = []
    for meta, text in zip(metas, texts):
        text = (text or "").strip()
        if not text:
            continue
        segments.append(Segment(
            line=len(segments) + 1,
            start=round(meta.start_ms / 1000.0, 3),
            end=round(meta.end_ms / 1000.0, 3),
            text=text,
        ))

    clear_vsf_output(output_dir)
    report(98, f"Xong: {len(segments)} dòng phụ đề")
    if not segments:
        raise RuntimeError("Không đọc được chữ từ ảnh phụ đề.")
    return segments

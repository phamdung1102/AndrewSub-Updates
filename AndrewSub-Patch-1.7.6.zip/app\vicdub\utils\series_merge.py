"""Helper cho Ghép series: sort tự nhiên, kiểm khớp sub↔video, tách SRT tổng.

Ba việc nhỏ nhưng là nơi "lẫn" hay xảy ra nhất khi ghép 50 tập:
  1. Sort thường xếp ``tap10`` trước ``tap2`` -> ghép sai thứ tự ngay từ đầu vào.
  2. Sub ghép nhầm cặp (dài hơn video của nó) bị cộng offset im lặng -> đè tập sau.
  3. Dịch xong chỉ có bản tổng, muốn đăng lẻ từng tập phải tách lại bằng tay.
"""

from __future__ import annotations

import re
from pathlib import Path

from vicdub.utils.subtitles import Segment

_NUM_RE = re.compile(r"(\d+)")


def natural_key(text: str):
    """Khóa sort tự nhiên: ``tap2`` đứng trước ``tap10`` (số so theo giá trị)."""
    parts = _NUM_RE.split(str(text).casefold())
    return [int(p) if p.isdigit() else p for p in parts]


def sort_paths_natural(paths):
    """Sort đường dẫn theo TÊN FILE tự nhiên (rồi theo thư mục cho ổn định)."""
    return sorted(paths, key=lambda p: (natural_key(Path(p).name), str(p).casefold()))


def sub_overrun(segments: list[Segment], duration: float,
                tolerance: float = 2.0) -> int:
    """Đếm số dòng sub BẮT ĐẦU sau khi video đã hết (dấu hiệu ghép nhầm cặp).

    Cho phép dòng cuối kết thúc trễ vài giây (nguồn hay để dư) nhưng một dòng
    *bắt đầu* sau ``duration`` thì gần như chắc chắn sub không thuộc video này.
    """
    if duration <= 0:
        return 0
    return sum(1 for seg in segments if seg.start > duration + tolerance)


def split_by_episodes(
    master: list[Segment],
    episodes: list[tuple[str, float, float]],
) -> list[tuple[str, list[Segment]]]:
    """Tách SRT tổng về từng tập theo bảng offset (name, offset, duration).

    Dòng thuộc tập nào quyết định bằng thời điểm BẮT ĐẦU của nó nằm trong
    [offset, offset + duration); timestamp được trả về gốc tập (trừ offset).
    Đảo ngược chính xác của phép ghép cộng dồn — không đoán, không heuristic.
    """
    out: list[tuple[str, list[Segment]]] = []
    for index, (name, offset, duration) in enumerate(episodes):
        last = index == len(episodes) - 1
        end_bound = float("inf") if last else offset + duration
        rows: list[Segment] = []
        for seg in master:
            if seg.start < offset or seg.start >= end_bound:
                continue
            rows.append(Segment(
                line=len(rows) + 1,
                start=max(0.0, seg.start - offset),
                end=max(0.0, seg.end - offset),
                text=seg.text,
                translation=seg.translation,
                speaker=seg.speaker,
                gender=seg.gender,
                voice=seg.voice,
            ))
        out.append((name, rows))
    return out

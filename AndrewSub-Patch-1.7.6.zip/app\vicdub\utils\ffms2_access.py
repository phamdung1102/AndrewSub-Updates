"""Optional FFMS2 backend for repeated, frame-accurate random access.

The sequential subtitle scan intentionally remains an FFmpeg raw-video pipe.
FFMS2 is used only by scrubbing, region selection and targeted OCR repair,
where repeatedly starting FFmpeg and decoding from a keyframe is wasteful.

No FFMS2 binary is required: callers must always keep their FFmpeg fallback.
"""

from __future__ import annotations

import ctypes
import hashlib
import logging
import os
import subprocess
import sys
import threading
from collections import OrderedDict
from pathlib import Path

from PIL import Image

from vicdub.utils.process_utils import hidden_process_kwargs

logger = logging.getLogger(__name__)
_SOURCE_CACHE: "OrderedDict[tuple[str, str, str], FFMS2FrameSource]" = OrderedDict()
_SOURCE_CACHE_LOCK = threading.RLock()


class FFMS2Unavailable(RuntimeError):
    pass


class _ErrorInfo(ctypes.Structure):
    _fields_ = [
        ("ErrorType", ctypes.c_int),
        ("SubType", ctypes.c_int),
        ("BufferSize", ctypes.c_int),
        ("Buffer", ctypes.c_char_p),
    ]


class _Frame(ctypes.Structure):
    # Only the stable leading fields are consumed, but the complete public
    # structure keeps ctypes aligned with FFMS2 5.x.
    _fields_ = [
        ("Data", ctypes.POINTER(ctypes.c_uint8) * 4),
        ("Linesize", ctypes.c_int * 4),
        ("EncodedWidth", ctypes.c_int),
        ("EncodedHeight", ctypes.c_int),
        ("EncodedPixelFormat", ctypes.c_int),
        ("ScaledWidth", ctypes.c_int),
        ("ScaledHeight", ctypes.c_int),
        ("ConvertedPixelFormat", ctypes.c_int),
        ("KeyFrame", ctypes.c_int),
        ("RepeatPict", ctypes.c_int),
        ("InterlacedFrame", ctypes.c_int),
        ("TopFieldFirst", ctypes.c_int),
        ("PictType", ctypes.c_char),
        ("ColorSpace", ctypes.c_int),
        ("ColorRange", ctypes.c_int),
        ("ColorPrimaries", ctypes.c_int),
        ("TransferCharateristics", ctypes.c_int),
        ("ChromaLocation", ctypes.c_int),
        ("HasMasteringDisplayPrimaries", ctypes.c_int),
        ("MasteringDisplayPrimariesX", ctypes.c_double * 3),
        ("MasteringDisplayPrimariesY", ctypes.c_double * 3),
        ("MasteringDisplayWhitePointX", ctypes.c_double),
        ("MasteringDisplayWhitePointY", ctypes.c_double),
        ("HasMasteringDisplayLuminance", ctypes.c_int),
        ("MasteringDisplayMinLuminance", ctypes.c_double),
        ("MasteringDisplayMaxLuminance", ctypes.c_double),
        ("HasContentLightLevel", ctypes.c_int),
        ("ContentLightLevelMax", ctypes.c_uint),
        ("ContentLightLevelAverage", ctypes.c_uint),
    ]


def _roots() -> list[Path]:
    source_root = Path(__file__).resolve().parents[2]
    exe_root = Path(sys.executable).resolve().parent
    roots = [
        source_root / "ffms2",
        # Patch updates cannot replace the protected app-level ``ffms2``
        # directory used by the installer.  Runtime binaries delivered by a
        # verified patch therefore live here; both locations use the same
        # discovery and API path.
        source_root / "runtime" / "ffms2",
        source_root / "data" / "ffms2",
        exe_root / "ffms2",
        exe_root / "runtime" / "ffms2",
        exe_root / "data" / "ffms2",
        source_root,
        exe_root,
    ]
    configured = os.environ.get("ANDREWSUB_FFMS2_DIR", "").strip()
    return ([Path(configured)] if configured else []) + roots


def find_ffms2_tools() -> tuple[Path | None, Path | None]:
    """Return matching DLL/indexer locations without modifying PATH."""
    dll = indexer = None
    for root in _roots():
        if dll is None and (root / "ffms2.dll").is_file():
            dll = root / "ffms2.dll"
        if indexer is None and (root / "ffmsindex.exe").is_file():
            indexer = root / "ffmsindex.exe"
    return dll, indexer


def ffms2_available() -> bool:
    dll, indexer = find_ffms2_tools()
    return bool(dll and indexer)


def _cache_key(video: str) -> str:
    source = Path(video).resolve()
    stat = source.stat()
    value = f"{source}|{stat.st_size}|{stat.st_mtime_ns}"
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


class FFMS2FrameSource:
    """One non-thread-safe FFMS video source protected by a Python lock."""

    def __init__(self, video: str, cache_dir: str | Path) -> None:
        self.video = str(Path(video).resolve())
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.source = None
        self.index = None
        self.lib = None
        self._error_buffer = ctypes.create_string_buffer(2048)
        self.error = _ErrorInfo(
            0, 0, len(self._error_buffer),
            ctypes.cast(self._error_buffer, ctypes.c_char_p),
        )
        dll, indexer = find_ffms2_tools()
        if not dll or not indexer:
            raise FFMS2Unavailable("FFMS2 chưa được cài kèm ứng dụng.")
        self.dll_path = dll
        self.indexer_path = indexer
        self.index_path = self.cache_dir / f"{_cache_key(self.video)}.ffindex"
        self._open()

    def _message(self) -> str:
        return self._error_buffer.value.decode("utf-8", "replace").strip()

    def _raise(self, action: str) -> None:
        raise FFMS2Unavailable(f"{action}: {self._message() or 'FFMS2 error'}")

    def _bind(self) -> None:
        lib = self.lib
        lib.FFMS_Init.argtypes = [ctypes.c_int, ctypes.c_int]
        lib.FFMS_ReadIndex.argtypes = [ctypes.c_char_p, ctypes.POINTER(_ErrorInfo)]
        lib.FFMS_ReadIndex.restype = ctypes.c_void_p
        lib.FFMS_IndexBelongsToFile.argtypes = [
            ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_IndexBelongsToFile.restype = ctypes.c_int
        lib.FFMS_GetFirstTrackOfType.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_GetFirstTrackOfType.restype = ctypes.c_int
        lib.FFMS_CreateVideoSource.argtypes = [
            ctypes.c_char_p, ctypes.c_int, ctypes.c_void_p,
            ctypes.c_int, ctypes.c_int, ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_CreateVideoSource.restype = ctypes.c_void_p
        lib.FFMS_DestroyIndex.argtypes = [ctypes.c_void_p]
        lib.FFMS_DestroyVideoSource.argtypes = [ctypes.c_void_p]
        lib.FFMS_GetFrame.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_GetFrame.restype = ctypes.POINTER(_Frame)
        lib.FFMS_GetFrameByTime.argtypes = [
            ctypes.c_void_p, ctypes.c_double, ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_GetFrameByTime.restype = ctypes.POINTER(_Frame)
        lib.FFMS_GetPixFmt.argtypes = [ctypes.c_char_p]
        lib.FFMS_GetPixFmt.restype = ctypes.c_int
        lib.FFMS_SetOutputFormatV2.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_int),
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(_ErrorInfo),
        ]
        lib.FFMS_SetOutputFormatV2.restype = ctypes.c_int

    def _build_index(self) -> None:
        command = [
            str(self.indexer_path), "-f", self.video, str(self.index_path),
        ]
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=21600,
            **hidden_process_kwargs(),
        )
        if result.returncode != 0 or not self.index_path.is_file():
            raise FFMS2Unavailable(
                "Không tạo được FFMS2 index: "
                + (result.stderr.strip() or f"exit {result.returncode}")
            )

    def _read_index(self):
        return self.lib.FFMS_ReadIndex(
            os.fsencode(self.index_path), ctypes.byref(self.error),
        )

    def _open(self) -> None:
        try:
            self.lib = ctypes.CDLL(str(self.dll_path))
            self._bind()
            self.lib.FFMS_Init(0, 0)
            if not self.index_path.is_file():
                self._build_index()
            self.index = self._read_index()
            if not self.index or self.lib.FFMS_IndexBelongsToFile(
                self.index, os.fsencode(self.video), ctypes.byref(self.error),
            ):
                if self.index:
                    self.lib.FFMS_DestroyIndex(self.index)
                self.index_path.unlink(missing_ok=True)
                self._build_index()
                self.index = self._read_index()
            if not self.index:
                self._raise("Không đọc được FFMS2 index")
            track = self.lib.FFMS_GetFirstTrackOfType(
                self.index, 0, ctypes.byref(self.error),  # FFMS_TYPE_VIDEO
            )
            if track < 0:
                self._raise("Không tìm thấy video track")
            self.source = self.lib.FFMS_CreateVideoSource(
                os.fsencode(self.video), track, self.index,
                0, 1, ctypes.byref(self.error),  # auto threads, SEEK_NORMAL
            )
            if not self.source:
                self._raise("Không mở được FFMS2 video source")
            first = self.lib.FFMS_GetFrame(
                self.source, 0, ctypes.byref(self.error),
            )
            if not first:
                self._raise("Không đọc được frame đầu")
            width = int(first.contents.EncodedWidth)
            height = int(first.contents.EncodedHeight)
            formats = (ctypes.c_int * 2)(
                self.lib.FFMS_GetPixFmt(b"rgb24"), -1,
            )
            if self.lib.FFMS_SetOutputFormatV2(
                self.source, formats, width, height, 4, ctypes.byref(self.error),
            ):
                self._raise("Không đặt được định dạng RGB24")
        except FFMS2Unavailable:
            self.close()
            raise
        except (OSError, ValueError) as exc:
            self.close()
            raise FFMS2Unavailable(str(exc)) from exc
        finally:
            if self.index and self.lib:
                self.lib.FFMS_DestroyIndex(self.index)
                self.index = None

    def get_frame(self, at_second: float, crop=None) -> Image.Image:
        with self.lock:
            if not self.source:
                raise FFMS2Unavailable("FFMS2 source đã đóng.")
            frame_ptr = self.lib.FFMS_GetFrameByTime(
                self.source, max(0.0, float(at_second)), ctypes.byref(self.error),
            )
            if not frame_ptr:
                self._raise("Không lấy được frame theo thời gian")
            frame = frame_ptr.contents
            width = int(frame.ScaledWidth if frame.ScaledWidth > 0 else frame.EncodedWidth)
            height = int(frame.ScaledHeight if frame.ScaledHeight > 0 else frame.EncodedHeight)
            stride = int(frame.Linesize[0])
            if not frame.Data[0] or not stride or width <= 0 or height <= 0:
                self._raise("Frame FFMS2 không có dữ liệu RGB")
            row_bytes = width * 3
            rows = []
            base = ctypes.cast(frame.Data[0], ctypes.c_void_p).value
            if base is None:
                self._raise("Frame FFMS2 có con trỏ rỗng")
            for row in range(height):
                offset = row * stride
                rows.append(ctypes.string_at(base + offset, row_bytes))
            image = Image.frombytes("RGB", (width, height), b"".join(rows))
            if crop is not None:
                image = image.crop(tuple(crop))
            return image

    def close(self) -> None:
        with self.lock:
            if self.source and self.lib:
                self.lib.FFMS_DestroyVideoSource(self.source)
            self.source = None
            if self.index and self.lib:
                self.lib.FFMS_DestroyIndex(self.index)
            self.index = None

    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc, _tb):
        self.close()


def extract_frame_exact(
    video: str,
    at_second: float,
    out_png: str,
    cache_dir: str | Path,
    crop=None,
) -> None:
    """Reuse at most three indexed sources for UI scrubbing/targeted repair."""
    key = (
        str(Path(video).resolve()),
        str(Path(cache_dir).resolve()),
        _cache_key(video),
    )
    with _SOURCE_CACHE_LOCK:
        source = _SOURCE_CACHE.get(key)
        if source is None:
            source = FFMS2FrameSource(video, cache_dir)
            _SOURCE_CACHE[key] = source
        _SOURCE_CACHE.move_to_end(key)
        while len(_SOURCE_CACHE) > 3:
            _old_key, old_source = _SOURCE_CACHE.popitem(last=False)
            old_source.close()
    image = source.get_frame(at_second, crop=crop)
    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    image.save(out_png, "PNG")

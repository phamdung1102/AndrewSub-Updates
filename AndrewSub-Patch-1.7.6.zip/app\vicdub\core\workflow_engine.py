"""Workflow Engine - điều phối pipeline.

Import -> Subtitle -> Translate -> Voice -> Merge

Engine là nơi DUY NHẤT nối các module với nhau: truyền ngữ cảnh (dict),
quản lý queue/retry/pause/resume/progress/history. Module không biết nhau.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from PyQt6.QtCore import QObject, pyqtSignal

from vicdub.core.module_base import BaseModule
from vicdub.core.task_queue import Task, TaskQueue

logger = logging.getLogger(__name__)

# Thứ tự pipeline chuẩn (key -> hiển thị). Không còn bước "video" (retime clip):
# bước "merge" lồng tiếng theo timeline rồi phủ lên VIDEO GỐC, giữ nguyên hình.
PIPELINE_STEPS: list[tuple[str, str]] = [
    ("subtitle", "Tách phụ đề"),
    ("translate", "Dịch phụ đề"),
    ("voice", "Sinh giọng nói"),
    ("merge", "Lồng tiếng + Ghép"),
]


def format_elapsed(seconds: float, *, compact: bool = False) -> str:
    """Format wall-clock processing time consistently for UI and history."""
    total = max(0, int(round(float(seconds))))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if compact:
        if hours:
            return f"{hours}:{minutes:02d}:{secs:02d}"
        return f"{minutes}:{secs:02d}"
    if hours:
        return f"{hours} giờ {minutes:02d} phút {secs:02d} giây"
    if minutes:
        return f"{minutes} phút {secs:02d} giây"
    return f"{secs} giây"


class WorkflowEngine(QObject):
    """Điều phối các module theo pipeline, phát tín hiệu cho UI."""

    step_started = pyqtSignal(str)              # key bước
    step_progress = pyqtSignal(str, int, str)   # key, %, mô tả
    step_finished = pyqtSignal(str)             # key
    step_failed = pyqtSignal(str, str)          # key, lỗi
    pipeline_finished = pyqtSignal(bool)        # True nếu trọn vẹn

    def __init__(self) -> None:
        super().__init__()
        self._modules: dict[str, BaseModule] = {}
        self._queue = TaskQueue()
        self.context: dict[str, Any] = {}
        self._name_to_key: dict[str, str] = {}
        self.step_timings: dict[str, float] = {}
        self.pipeline_elapsed = 0.0
        self._pipeline_started_at = 0.0
        self._step_started_at: dict[str, float] = {}
        self._active_task_name = ""
        self._failed_task_name = ""

        self._queue.task_started.connect(self._on_task_started)
        self._queue.task_progress.connect(self._on_task_progress)
        self._queue.task_finished.connect(self._on_task_finished)
        self._queue.task_failed.connect(self._on_task_failed)
        self._queue.queue_finished.connect(self._on_queue_finished)

    # ---------- Đăng ký module ----------

    def register(self, key: str, module: BaseModule) -> None:
        """Đăng ký module cho một bước pipeline."""
        self._modules[key] = module
        self._name_to_key[module.name] = key

    # ---------- Chạy ----------

    def run_steps(self, keys: list[str], context: dict[str, Any]) -> None:
        """Chạy các bước theo thứ tự trên worker thread.

        Args:
            keys: danh sách key bước (theo PIPELINE_STEPS).
            context: ngữ cảnh khởi đầu (project, config, đường dẫn...).
        """
        if self._queue.is_running():
            raise RuntimeError("Pipeline đang chạy, hãy chờ hoặc hủy trước")
        self.context = dict(context)
        self.step_timings = {}
        self.pipeline_elapsed = 0.0
        self._pipeline_started_at = time.monotonic()
        self._step_started_at = {}
        self._active_task_name = ""
        self._failed_task_name = ""
        tasks: list[Task] = []
        for key in keys:
            module = self._modules.get(key)
            if module is None:
                raise ValueError(f"Chưa đăng ký module cho bước '{key}'")
            tasks.append(Task(
                name=module.name,
                func=self._make_runner(module),
                max_retry=2,
            ))
        self._queue.start(tasks)

    def run_all(self, context: dict[str, Any]) -> None:
        """Chạy trọn pipeline."""
        self.run_steps([k for k, _ in PIPELINE_STEPS], context)

    def _make_runner(self, module: BaseModule):
        """Đóng gói module thành hàm task: gắn callback rồi gộp output."""

        def runner(progress_cb, cancel_event: threading.Event):
            module.attach(progress_cb, cancel_event)
            output = module.run(self.context) or {}
            self.context.update(output)
            return output

        return runner

    # ---------- Điều khiển ----------

    def pause(self) -> None:
        self._queue.pause()

    def resume(self) -> None:
        self._queue.resume()

    def cancel(self) -> None:
        self._queue.cancel()

    def is_running(self) -> bool:
        return self._queue.is_running()

    def is_paused(self) -> bool:
        return self._queue.is_paused()

    # ---------- History ----------

    def _log_history(self, step: str, status: str, detail: str = "") -> None:
        project = self.context.get("project")
        if project is not None:
            try:
                project.add_history(step, status, detail)
            except Exception:  # noqa: BLE001 - history không được làm gãy pipeline
                logger.exception("Không ghi được history")

    # ---------- Chuyển tiếp tín hiệu (tên task -> key bước) ----------

    def _key_of(self, task_name: str) -> str:
        return self._name_to_key.get(task_name, task_name)

    def _on_task_started(self, name: str) -> None:
        self._active_task_name = name
        self._step_started_at[name] = time.monotonic()
        self.step_started.emit(self._key_of(name))

    def _on_task_progress(self, name: str, pct: int, msg: str) -> None:
        self.step_progress.emit(self._key_of(name), pct, msg)

    def _on_task_finished(self, name: str, _result: object) -> None:
        key = self._key_of(name)
        started = self._step_started_at.get(name)
        elapsed = max(0.0, time.monotonic() - started) if started is not None else 0.0
        self.step_timings[key] = elapsed
        self.context["step_timings"] = dict(self.step_timings)
        self._log_history(name, "done", f"Thời gian thực: {format_elapsed(elapsed)}")
        self._active_task_name = ""
        self.step_finished.emit(key)

    def _on_task_failed(self, name: str, error: str) -> None:
        key = self._key_of(name)
        started = self._step_started_at.get(name)
        elapsed = max(0.0, time.monotonic() - started) if started is not None else 0.0
        self.step_timings[key] = elapsed
        self.context["step_timings"] = dict(self.step_timings)
        self._log_history(
            name, "failed",
            f"Thời gian thực: {format_elapsed(elapsed)} | {error}",
        )
        self._failed_task_name = name
        self._active_task_name = ""
        self.step_failed.emit(key, error)

    def _on_queue_finished(self, success: bool) -> None:
        # Cancellation does not emit task_failed. Preserve the time already
        # spent so a stopped run is still useful for machine comparisons.
        if self._active_task_name and not self._failed_task_name:
            name = self._active_task_name
            key = self._key_of(name)
            started = self._step_started_at.get(name)
            elapsed = (
                max(0.0, time.monotonic() - started)
                if started is not None else 0.0
            )
            self.step_timings[key] = elapsed
            self._log_history(
                name, "cancelled",
                f"Thời gian thực trước khi dừng: {format_elapsed(elapsed)}",
            )
        self.pipeline_elapsed = (
            max(0.0, time.monotonic() - self._pipeline_started_at)
            if self._pipeline_started_at else 0.0
        )
        self.context["step_timings"] = dict(self.step_timings)
        self.context["pipeline_elapsed"] = self.pipeline_elapsed
        self._active_task_name = ""
        self.pipeline_finished.emit(success)

"""OCR phụ đề bằng Google Cloud Vision API (backend thay cho Drive OCR).

Điểm khác cốt lõi so với DriveOcrClient
---------------------------------------
Drive trả về TEXT PHẲNG, không nói chữ nằm ở đâu -> buộc phải in marker
``@@@ N @@@`` vào ảnh montage rồi đoán ngược, mà Drive lại hay đọc theo CỘT nên
marker vỡ, phải chống chế bằng parser + lọc theo script (bỏ dòng không có CJK).

Vision trả về TOẠ ĐỘ PIXEL + CONFIDENCE cho từng từ. Vì montage do MÌNH ghép nên
mình biết chắc câu thứ ``i`` chiếm dải ``y ∈ [i*PANEL_H, (i+1)*PANEL_H)``. Chỉ cần
``idx = y_center // PANEL_H`` là ra câu -> ánh xạ XÁC ĐỊNH, không cần marker, không
phụ thuộc engine đọc theo hàng hay cột. Nhiễu (logo/watermark) lọc bằng confidence
thay vì heuristic script.

Auth: API KEY (Vision là một trong số ít API Google cho phép) -> không OAuth
loopback, không refresh_token, không service-account. Không thêm dependency nào.
"""

from __future__ import annotations

import base64
import io
import logging
import time
from typing import Callable

import requests

logger = logging.getLogger(__name__)

ENDPOINT = "https://vision.googleapis.com/v1/images:annotate"

# Crop phụ đề gốc chỉ ~440px ngang -> phóng ~2x cho Vision đọc chắc tay hơn.
PANEL_W = 880
# Chiều cao CỐ ĐỊNH mỗi ô: đây là mấu chốt để y//PANEL_H ra đúng index.
PANEL_H = 168
PANEL_MARGIN = 12                 # đệm quanh ô -> chữ không dính sang ô kế bên
PANELS_PER_MONTAGE = 40           # 1 ảnh = 1 unit tính tiền, nhồi càng nhiều càng rẻ
IMAGES_PER_REQUEST = 16           # trần cứng của images:annotate
MIN_CONFIDENCE = 0.55

_LANG_HINTS = {
    "": [],
    "zh": ["zh"], "zh-cn": ["zh"], "zh-hans": ["zh"], "chinese": ["zh"],
    "zh-tw": ["zh-Hant"], "zh-hant": ["zh-Hant"],
    "ja": ["ja"], "ko": ["ko"], "en": ["en"], "vi": ["vi"],
}


class VisionOcrError(RuntimeError):
    """Vision API trả lỗi (key sai, chưa bật API, hết quota...)."""


def _is_latin(ch: str) -> bool:
    return ch.isascii() and ch.isalnum()


def build_montage(images: list) -> bytes:
    """Ghép các crop thành 1 ảnh dọc, MỖI Ô CAO ĐÚNG PANEL_H px.

    Ô đều nhau là điều kiện để ánh xạ y -> index chính xác tuyệt đối. Ảnh được
    scale vừa khung (giữ tỉ lệ) rồi dán giữa ô, nền đen.
    """
    from PIL import Image  # noqa: PLC0415

    canvas = Image.new("RGB", (PANEL_W, PANEL_H * len(images)), (0, 0, 0))
    inner_w = PANEL_W - 2 * PANEL_MARGIN
    inner_h = PANEL_H - 2 * PANEL_MARGIN
    for index, image in enumerate(images):
        panel = image.convert("RGB") if image.mode != "RGB" else image
        scale = min(inner_w / max(1, panel.width), inner_h / max(1, panel.height))
        new_size = (max(1, int(panel.width * scale)), max(1, int(panel.height * scale)))
        panel = panel.resize(new_size, Image.Resampling.LANCZOS)
        x = (PANEL_W - panel.width) // 2
        y = index * PANEL_H + (PANEL_H - panel.height) // 2
        canvas.paste(panel, (x, y))
    buffer = io.BytesIO()
    canvas.save(buffer, format="PNG")
    return buffer.getvalue()


def _word_text(word: dict) -> str:
    parts = []
    for symbol in word.get("symbols", []):
        parts.append(symbol.get("text", ""))
        brk = (symbol.get("property", {}).get("detectedBreak", {}) or {}).get("type", "")
        if brk in ("SPACE", "SURE_SPACE", "EOL_SURE_SPACE", "LINE_BREAK"):
            parts.append(" ")
    return "".join(parts).strip()


def _center_y(box: dict) -> float:
    vertices = box.get("vertices") or []
    ys = [float(v.get("y", 0)) for v in vertices]
    return sum(ys) / len(ys) if ys else 0.0


def _min_x(box: dict) -> float:
    vertices = box.get("vertices") or []
    xs = [float(v.get("x", 0)) for v in vertices]
    return min(xs) if xs else 0.0


def parse_response(annotation: dict, panel_count: int,
                   min_confidence: float = MIN_CONFIDENCE) -> list[str]:
    """Trả text cho từng ô, ánh xạ THUẦN HÌNH HỌC (y//PANEL_H).

    Gom ở mức TỪ (không phải đoạn): box của từ luôn nhỏ, chắc chắn nằm gọn trong
    một ô, nên không sợ Vision gộp hai ô thành một đoạn.
    """
    buckets: dict[int, list[tuple[float, float, str]]] = {}
    full = (annotation or {}).get("fullTextAnnotation") or {}
    for page in full.get("pages", []):
        for block in page.get("blocks", []):
            for paragraph in block.get("paragraphs", []):
                for word in paragraph.get("words", []):
                    text = _word_text(word)
                    if not text:
                        continue
                    confidence = float(word.get("confidence", 1.0))
                    if confidence < min_confidence:
                        continue          # nhiễu: watermark mờ, logo, viền
                    box = word.get("boundingBox") or {}
                    y = _center_y(box)
                    index = int(y // PANEL_H)
                    if not 0 <= index < panel_count:
                        continue
                    buckets.setdefault(index, []).append((y, _min_x(box), text))

    results = [""] * panel_count
    for index, words in buckets.items():
        # Trong một ô có thể có 2 dòng -> gom theo hàng (y) trước, rồi trái->phải (x).
        words.sort(key=lambda item: (round(item[0] / 40.0), item[1]))
        line = ""
        for _y, _x, text in words:
            if line and (_is_latin(line[-1]) or _is_latin(text[0])):
                line += " "
            line += text
        results[index] = line.strip()
    return results


class VisionOcrClient:
    """Đọc phụ đề qua Vision API. Cùng contract với pool Drive: (texts, failed)."""

    def __init__(self, api_key: str, timeout: float = 180.0, max_attempts: int = 3):
        key = (api_key or "").strip()
        if not key:
            raise VisionOcrError("Thiếu Vision API key.")
        self._key = key
        self._timeout = timeout
        self._max_attempts = max_attempts
        self._session = requests.Session()

    def _annotate(self, montages: list[bytes], lang_hint: str) -> list[dict]:
        hints = _LANG_HINTS.get((lang_hint or "").strip().lower(), [])
        payload = {
            "requests": [
                {
                    "image": {"content": base64.b64encode(data).decode("ascii")},
                    "features": [{"type": "DOCUMENT_TEXT_DETECTION"}],
                    "imageContext": {"languageHints": hints} if hints else {},
                }
                for data in montages
            ]
        }
        last_error = ""
        for attempt in range(1, self._max_attempts + 1):
            try:
                response = self._session.post(
                    ENDPOINT, params={"key": self._key}, json=payload,
                    timeout=self._timeout,
                )
            except requests.RequestException as exc:
                last_error = str(exc)
            else:
                if response.status_code == 200:
                    return response.json().get("responses", [])
                last_error = f"HTTP {response.status_code}: {response.text[:200]}"
                # 4xx (trừ 429) là lỗi cấu hình -> retry vô ích, báo ngay.
                if 400 <= response.status_code < 500 and response.status_code != 429:
                    raise VisionOcrError(_explain(response.status_code, response.text))
            if attempt < self._max_attempts:
                time.sleep(2.0 * attempt)
        raise VisionOcrError(f"Vision API thất bại sau {self._max_attempts} lần: {last_error}")

    def read_images(
        self,
        images: list,
        lang_hint: str = "",
        report: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> tuple[list[str], list[int]]:
        """OCR toàn bộ ảnh. Trả (texts theo đúng thứ tự, index các ảnh đọc rỗng)."""
        texts = [""] * len(images)
        if not images:
            return texts, []

        # Gom thành montage (40 ảnh/montage), rồi gom montage thành request (16/req).
        groups = [
            list(range(start, min(start + PANELS_PER_MONTAGE, len(images))))
            for start in range(0, len(images), PANELS_PER_MONTAGE)
        ]
        batches = [
            groups[start:start + IMAGES_PER_REQUEST]
            for start in range(0, len(groups), IMAGES_PER_REQUEST)
        ]
        total_units = len(groups)
        done_units = 0
        for batch in batches:
            if is_cancelled and is_cancelled():
                break
            montages = [build_montage([images[i] for i in group]) for group in batch]
            responses = self._annotate(montages, lang_hint)
            for group, annotation in zip(batch, responses):
                error = (annotation or {}).get("error")
                if error:
                    raise VisionOcrError(f"Vision lỗi ảnh: {error.get('message', error)}")
                for offset, text in enumerate(parse_response(annotation, len(group))):
                    texts[group[offset]] = text
            done_units += len(batch)
            if report:
                percent = 40 + int(55 * done_units / max(1, total_units))
                report(percent, f"Đang đọc ảnh {done_units}/{total_units} "
                                f"({len(images)} câu)...")

        failed = [index for index, text in enumerate(texts) if not text.strip()]
        return texts, failed


def self_test(api_key: str, report: Callable[[str], None] | None = None
              ) -> tuple[int, int, list[str]]:
    """Gửi 1 montage chữ mẫu qua Vision. Trả (số ô đọc đúng, tổng, text đọc được).

    Kiểm luôn cả ánh xạ hình học: mỗi ô phải trả về ĐÚNG câu của nó, không lẫn.
    """
    from PIL import Image, ImageDraw, ImageFont  # noqa: PLC0415

    def say(message: str) -> None:
        if report:
            report(message)

    def font(size: int):
        for name in ("msyh.ttc", "simsun.ttc", "arial.ttf"):
            try:
                return ImageFont.truetype(f"C:/Windows/Fonts/{name}", size)
            except OSError:
                continue
        return ImageFont.load_default()

    samples = ["你好世界", "这是测试", "第三行字"]
    images = []
    typeface = font(48)
    for text in samples:
        # Giả lập phụ đề thật: chữ trắng trên nền tối, cỡ gần đúng crop thực tế.
        panel = Image.new("RGB", (442, 77), (18, 18, 22))
        draw = ImageDraw.Draw(panel)
        draw.text((20, 8), text, fill=(255, 255, 255), font=typeface)
        images.append(panel)

    say(f"Test Vision OCR: gửi {len(samples)} câu mẫu (1 request)...")
    texts, _failed = VisionOcrClient(api_key).read_images(images, lang_hint="zh")
    good = sum(
        1 for want, got in zip(samples, texts)
        if want in (got or "").replace(" ", "")
    )
    say(f"Vision đọc đúng {good}/{len(samples)} ô.")
    return good, len(samples), texts


def _explain(status: int, body: str) -> str:
    body = (body or "")[:300]
    if status == 403:
        return ("Vision API từ chối (403). Thường do CHƯA BẬT Cloud Vision API cho "
                "project, hoặc API key bị giới hạn sai. Vào Google Cloud Console → "
                "APIs & Services → bật 'Cloud Vision API'.\n" + body)
    if status == 400:
        return f"Vision API báo request sai (400). Kiểm tra API key.\n{body}"
    if status == 429:
        return f"Vision API hết quota (429).\n{body}"
    return f"Vision API lỗi {status}.\n{body}"

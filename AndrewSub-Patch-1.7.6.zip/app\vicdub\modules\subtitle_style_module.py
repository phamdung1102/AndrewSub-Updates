"""Subtitle Style Module - lựa chọn cách chèn phụ đề vào video cuối.

Ba chế độ (cấu hình config.subtitle_mode):
- none: không chèn phụ đề.
- hard: vẽ phụ đề lên khung hình (burn-in).
- soft: nhúng track phụ đề bật/tắt được.

Module này chỉ chuẩn bị file translated.srt khớp timeline mới và cờ chế độ;
việc áp vào video do Merge Module thực hiện theo cờ.

Output: subtitle_mode, subtitle_for_merge (đường dẫn srt hoặc rỗng)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import Segment, write_srt


class SubtitleStyleModule(BaseModule):
    """Chuẩn bị phụ đề cho bước ghép cuối."""

    name = "Chèn phụ đề"

    VALID_MODES = ("none", "hard", "soft")

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        config = data["config"]
        mode = config.subtitle_mode if config.subtitle_mode in self.VALID_MODES else "none"

        if mode == "none":
            self.report(100, "Bỏ qua chèn phụ đề (chế độ: không chèn)")
            return {"subtitle_mode": "none", "subtitle_for_merge": ""}

        project = data["project"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        clip_files: dict[int, str] = data.get("clip_files") or {}
        if not segments:
            raise ModuleError("Chưa có phụ đề đã dịch.")

        # Timeline sau retime đã đổi: tính lại start/end theo thời lượng clip thật.
        self.report(30, "Tính lại timeline phụ đề theo clip...")
        remapped = self._remap_timeline(segments, clip_files, data)

        srt_path = Path(project.root) / "subtitles" / "merge.srt"
        write_srt(remapped, srt_path, translated=True)

        label = "hard (vẽ lên hình)" if mode == "hard" else "soft (bật/tắt được)"
        self.report(100, f"Phụ đề sẵn sàng - chế độ {label}")
        return {"subtitle_mode": mode, "subtitle_for_merge": str(srt_path)}

    def _remap_timeline(self, segments: list[Segment],
                        clip_files: dict[int, str],
                        data: dict[str, Any]) -> list[Segment]:
        """Xếp phụ đề nối tiếp nhau theo thời lượng clip thực tế."""
        config = data["config"]
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        remapped: list[Segment] = []
        cursor = 0.0
        for seg in segments:
            clip = clip_files.get(seg.line)
            if not clip:
                continue
            try:
                dur = ffmpeg.duration(clip)
            except FFmpegError:
                dur = seg.duration  # fallback thời lượng gốc
            remapped.append(Segment(
                line=seg.line, start=cursor, end=cursor + dur,
                text=seg.text, translation=seg.translation,
                speaker=seg.speaker, gender=seg.gender,
            ))
            cursor += dur
        return remapped or segments

"""API Manager và client Gemini."""

"""Bọc VideoSubFinder (VSF) làm bộ phát hiện phụ đề gắn cứng - giống AIO.

VideoSubFinder quét TỪNG frame vùng phụ đề, dò lúc chữ xuất hiện/biến mất theo
độ ổn định pixel -> cho timing chính xác tới ms + một ảnh sạch cho mỗi câu. Chính
xác hơn hẳn cách lấy mẫu fps + edge-mask tự chế (hay sót/lặp/lệch).

Luồng: chạy VideoSubFinderWXW.exe ở chế độ CLI -> nó xuất thư mục RGBImages/ với
tên file mã hoá timing (start__end) -> ta parse ra danh sách câu (start_ms,
end_ms, ảnh). Sau đó OCR từng ảnh (Drive) để lấy chữ.

LƯU Ý: cờ CLI & quy ước vùng của VSF cần xác minh với binary thật (chưa có sẵn
trên máy). Mọi tham số để ở đây cho dễ chỉnh.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from vicdub.utils.process_utils import hidden_process_kwargs

logger = logging.getLogger(__name__)

# Tên file RGBImages của VSF: "<start>__<end>_<...>.jpeg" với thời gian dạng
# H_MM_SS_MSS, ví dụ "0_00_05_120__0_00_06_940_0.jpeg".
_TS = r"(\d+)_(\d+)_(\d+)_(\d+)"
_NAME_RE = re.compile(_TS + r"__" + _TS)


@dataclass
class VsfSegment:
    """Một câu phụ đề VSF phát hiện: mốc thời gian (ms) + ảnh vùng chữ."""
    start_ms: int
    end_ms: int
    image_path: str


class VsfError(RuntimeError):
    """Lỗi chạy VideoSubFinder, thông điệp hiển thị được."""


def find_vsf_exe(explicit: str = "", app_root: Path | None = None) -> str:
    """Tìm VideoSubFinderWXW.exe: cấu hình -> vài vị trí mặc định. '' nếu không có."""
    candidates = [explicit.strip()]
    roots = [app_root] if app_root else []
    for root in roots:
        candidates += [
            str(root / "tools" / "VideoSubFinder" / "VideoSubFinderWXW.exe"),
            str(root / "VideoSubFinder" / "VideoSubFinderWXW.exe"),
            str(root / "vsf" / "VideoSubFinderWXW.exe"),
        ]
    for path in candidates:
        if path and Path(path).exists():
            return path
    return ""


def _ms_from_match(m: re.Match, base: int) -> int:
    h, mm, ss, mss = (int(m.group(base + i)) for i in range(4))
    return ((h * 60 + mm) * 60 + ss) * 1000 + mss


def parse_rgb_images(rgb_dir: str) -> list[VsfSegment]:
    """Đọc thư mục RGBImages -> danh sách câu theo thời gian (đã sort tăng dần)."""
    out: list[VsfSegment] = []
    folder = Path(rgb_dir)
    if not folder.is_dir():
        return out
    for img in folder.iterdir():
        if img.suffix.lower() not in (".jpeg", ".jpg", ".png", ".bmp"):
            continue
        m = _NAME_RE.search(img.name)
        if not m:
            continue
        start_ms = _ms_from_match(m, 1)
        end_ms = _ms_from_match(m, 5)
        if end_ms > start_ms:
            out.append(VsfSegment(start_ms, end_ms, str(img)))
    out.sort(key=lambda s: s.start_ms)
    return out


def _fmt_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:06.3f}"


def run_vsf(
    video_path: str,
    output_dir: str,
    region: tuple[float, float, float, float],
    vsf_exe: str,
    start: float | None = None,
    end: float | None = None,
    num_threads: int = 4,
    use_cuda: bool = False,
    report: Callable[[int, str], None] | None = None,
    is_cancelled: Callable[[], bool] | None = None,
    timeout: int = 21600,
) -> list[VsfSegment]:
    """Chạy VideoSubFinder CLI, trả danh sách câu (timing + ảnh).

    region: (x0, y0, x1, y1) chuẩn hoá, y tính từ TRÊN (0=đỉnh, 1=đáy).
    """
    if not vsf_exe or not Path(vsf_exe).exists():
        raise VsfError(
            "Không tìm thấy VideoSubFinderWXW.exe. Tải VideoSubFinder và đặt vào "
            "thư mục tools/VideoSubFinder/ của app, hoặc khai báo đường dẫn ở Cài đặt."
        )
    if not Path(video_path).exists():
        raise VsfError(f"Video không tồn tại: {video_path}")

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    x0, y0, x1, y1 = region
    # VSF đo vùng dọc TỪ ĐÁY (0=đáy, 1=đỉnh) -> đổi từ y-tính-từ-trên.
    top_end = round(1.0 - float(y0), 4)      # -te: cạnh trên (từ đáy)
    bottom_end = round(1.0 - float(y1), 4)   # -be: cạnh dưới (từ đáy)
    left_end = round(float(x0), 4)           # -le
    right_end = round(float(x1), 4)          # -re

    cmd = [
        vsf_exe,
        "-c",                      # clear folders trước khi quét
        "-r",                      # run search
        "-i", str(video_path),
        "-o", str(out),
        "-nthr", str(max(1, int(num_threads))),
        "-te", str(top_end), "-be", str(bottom_end),
        "-le", str(left_end), "-re", str(right_end),
    ]
    if start is not None:
        cmd += ["-s", _fmt_time(start)]
    if end is not None:
        cmd += ["-e", _fmt_time(end)]
    if use_cuda:
        cmd += ["-uc"]

    if report:
        report(5, "VideoSubFinder đang quét từng frame để dò phụ đề...")
    logger.info("VSF cmd: %s", " ".join(cmd))
    try:
        proc = subprocess.Popen(
            cmd, cwd=str(Path(vsf_exe).parent),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            **hidden_process_kwargs(),
        )
    except OSError as exc:
        raise VsfError(f"Không chạy được VideoSubFinder: {exc}") from exc

    try:
        while True:
            if is_cancelled and is_cancelled():
                proc.terminate()
                raise VsfError("Đã hủy theo yêu cầu.")
            try:
                line = proc.stdout.readline() if proc.stdout else ""
            except Exception:  # noqa: BLE001
                line = ""
            if not line and proc.poll() is not None:
                break
            if line:
                logger.debug("VSF: %s", line.rstrip())
        code = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        proc.kill()
        raise VsfError("VideoSubFinder chạy quá lâu (timeout).") from exc

    # VSF đặt ảnh vào <out>/RGBImages (hoặc TXTImages cho ảnh đã làm sạch).
    rgb = out / "RGBImages"
    txt = out / "TXTImages"
    segments = parse_rgb_images(str(rgb))
    if not segments and txt.is_dir():
        segments = parse_rgb_images(str(txt))
    if not segments:
        raise VsfError(
            f"VideoSubFinder không tạo ảnh phụ đề nào (exit={code}). Kiểm tra lại "
            "vùng khoanh, hoặc video có phụ đề gắn cứng không."
        )
    if report:
        report(40, f"VideoSubFinder tìm được {len(segments)} câu phụ đề.")
    return segments


def clear_vsf_output(output_dir: str) -> None:
    """Xoá thư mục ảnh VSF sau khi OCR xong (đỡ rác đĩa)."""
    for sub in ("RGBImages", "TXTImages", "ISAImages", "ILAImages"):
        shutil.rmtree(Path(output_dir) / sub, ignore_errors=True)

"""Online TTS providers and cached voice catalog."""

from __future__ import annotations

import base64
import json
import os
import tempfile
import threading
import time
import wave
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests

from vicdub.core.module_base import ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg
from vicdub.utils.secret_store import unprotect_secret
from vicdub.utils.voice_registry import VOICES as LOCAL_OMNIVOICE_VOICES

OPENAI_VOICES = [
    "alloy", "ash", "ballad", "coral", "echo", "fable", "onyx", "nova",
    "sage", "shimmer", "verse", "marin", "cedar",
]

OMNIVOICE_SERVER_VOICES = [
    {"id": stem, "name": label}
    for label, stem, _gender in LOCAL_OMNIVOICE_VOICES
]
OMNIVOICE_SERVER_VOICE_VERSION = "six-presets-v1"

VIETAUTO_DEFAULT_VOICES = [
    {"id": "foH7s9fX31wFFH2yqrFa", "name": "Huyen - Calm, Friendly and Clear"},
    {"id": "a3AkyqGG4v8Pg7SWQ0Y3", "name": "Ngan - Cute, Bubbly and Authentic"},
    {"id": "6adFm46eyy74snVn6YrT", "name": "Nhật - Narrative & Compelling"},
    {"id": "558B1EcdabtcSdleer40", "name": "Thảo - Soft, Calm and Gentle"},
    {"id": "5vqV9IG7sDpzgzKOIZAv", "name": "Kenh"},
    {"id": "FTYCiQT21H9XQvhRu0ch", "name": "Trung - Soft, Smooth and Narrative"},
    {"id": "HG0MlJIknmaXREpTckfK", "name": "Tuan Anh - Deep & Narrative"},
    {"id": "iSFxP4Z6YNcx9OXl62Ic", "name": "Viên - Narrative, Warm and Clear"},
]

VIETAUTO_DEFAULT_VOICE_VERSION = "2026-07-21-named"

VOICE_LABEL_SEP = " · "


class VoiceApiEngine:
    """Engine compatible with TTSEngine, using the selected online provider."""

    _wake_lock = threading.Lock()
    _ready_until: dict[str, float] = {}

    def __init__(self, config: Any) -> None:
        self.config = config
        self.kind = str(getattr(config, "voice_api_type", "openai") or "openai")
        self.base_url = str(getattr(config, "voice_api_base_url", "") or "").rstrip("/")
        self.model = str(getattr(config, "voice_api_model", "") or "")
        if self.model == "eleven_multilingual_v3":
            self.model = "eleven_v3"
        self.key = unprotect_secret(getattr(config, "voice_api_key", ""))
        if self.kind == "omnivoice_server":
            self.base_url = str(
                getattr(config, "voice_api_omnivoice_base_url", "")
                or self.base_url
                or "http://47.84.113.154:8000"
            ).rstrip("/")
            self.key = unprotect_secret(
                getattr(config, "voice_api_omnivoice_key", "")
                or getattr(config, "voice_api_key", "")
            )
        self.timeout = max(10, int(getattr(config, "voice_api_timeout", 90)))
        self.last_latency_ms = ""
        self.last_rtf = ""
        self.last_audio_duration_sec = ""
        self._omnivoice_ref_audio_b64: str | None = None
        self._voice_ids: dict[str, str] = {}
        self.cache_path = Path(config.data_dir) / "voice_catalog.json"

    @property
    def provider_signature(self) -> str:
        signature = f"api:{self.kind}:{self.base_url}:{self.model}"
        if self.kind == "vietauto":
            signature = f"{signature}:{VIETAUTO_DEFAULT_VOICE_VERSION}"
        elif self.kind == "omnivoice_server":
            signature = (
                f"{signature}:{getattr(self.config, 'voice_api_omnivoice_mode', 'auto')}:"
                f"{getattr(self.config, 'voice_api_omnivoice_instruct', '')}:"
                f"{getattr(self.config, 'voice_api_omnivoice_ref_audio', '')}:"
                f"{OMNIVOICE_SERVER_VOICE_VERSION}"
            )
        return signature

    def _headers(self) -> dict[str, str]:
        if self.kind == "elevenlabs":
            return {"xi-api-key": self.key, "Accept": "application/json"}
        if self.kind == "omnivoice_server":
            return {"X-API-Key": self.key, "Accept": "audio/wav"}
        header = str(
            getattr(self.config, "voice_api_auth_header", "Authorization")
            or "Authorization"
        )
        prefix = str(
            getattr(self.config, "voice_api_auth_prefix", "Bearer") or ""
        ).strip()
        return {header: f"{prefix} {self.key}".strip(), "Accept": "application/json"}

    def _require(self) -> None:
        if not self.key:
            raise ModuleError("Chưa nhập khóa API giọng nói trong Cài đặt.")
        if not self.base_url:
            raise ModuleError("Chưa nhập địa chỉ API giọng nói trong Cài đặt.")

    def _omnivoice_health_ready(self, timeout: float = 3.0) -> bool:
        try:
            response = requests.get(
                f"{self.base_url}/health", timeout=max(1.0, float(timeout))
            )
            if not response.ok:
                return False
            try:
                body = response.json()
            except ValueError:
                return True
            return str(body.get("status", "ok")).lower() in {
                "ok", "ready", "running", "healthy"
            }
        except requests.RequestException:
            return False

    def _ensure_omnivoice_server_ready(self) -> None:
        if self.kind != "omnivoice_server":
            return
        if not bool(getattr(self.config, "voice_api_wake_enabled", False)):
            return
        if time.monotonic() < self._ready_until.get(self.base_url, 0.0):
            return
        with self._wake_lock:
            if time.monotonic() < self._ready_until.get(self.base_url, 0.0):
                return
            if self._omnivoice_health_ready():
                self._ready_until[self.base_url] = time.monotonic() + 30.0
                return
            wake_url = str(
                getattr(self.config, "voice_api_wake_url", "") or ""
            ).strip()
            if not wake_url:
                raise ModuleError("Đã bật tự khởi động nhưng chưa nhập Wake URL.")
            wake_token = unprotect_secret(
                getattr(self.config, "voice_api_wake_token", "") or ""
            ).strip()
            headers = {"Accept": "application/json"}
            if wake_token:
                headers["Authorization"] = f"Bearer {wake_token}"
            try:
                response = requests.post(
                    wake_url,
                    headers=headers,
                    json={"service": "omnivoice"},
                    timeout=15,
                )
            except requests.RequestException as exc:
                raise ModuleError(f"Không gọi được dịch vụ khởi động máy chủ: {exc}") from exc
            if not response.ok:
                raise ModuleError(
                    f"Dịch vụ khởi động máy chủ từ chối yêu cầu (HTTP {response.status_code})."
                )
            timeout = max(
                30, int(getattr(self.config, "voice_api_wake_timeout", 180) or 180)
            )
            poll = max(
                1.0,
                float(getattr(self.config, "voice_api_wake_poll_seconds", 2.0) or 2.0),
            )
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if self._omnivoice_health_ready():
                    self._ready_until[self.base_url] = time.monotonic() + 30.0
                    return
                time.sleep(poll)
            raise ModuleError(
                f"Máy chủ giọng nói chưa sẵn sàng sau {timeout} giây."
            )

    def _load_cache(self) -> list[dict]:
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
            if data.get("signature") == self.provider_signature:
                return list(data.get("voices") or [])
        except (OSError, ValueError, TypeError):
            pass
        return []

    def catalog_stale(self) -> bool:
        if not self.cache_path.exists():
            return True
        try:
            data = json.loads(self.cache_path.read_text(encoding="utf-8"))
            hours = max(
                1, int(getattr(self.config, "voice_catalog_auto_sync_hours", 24))
            )
            return (
                data.get("signature") != self.provider_signature
                or time.time() - float(data.get("updated_at", 0)) >= hours * 3600
            )
        except (OSError, ValueError, TypeError):
            return True

    def _save_cache(self, voices: list[dict]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(
            json.dumps(
                {
                    "signature": self.provider_signature,
                    "updated_at": time.time(),
                    "voices": voices,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    @staticmethod
    def _label(name: str, voice_id: str) -> str:
        return name if name == voice_id else f"{name}{VOICE_LABEL_SEP}{voice_id}"

    def list_voices(self, force: bool = False) -> list[str]:
        voices = [] if force else self._load_cache()
        if not voices:
            if force:
                voices = self.sync_voices()
            elif self.kind == "openai":
                voices = [{"id": v, "name": v} for v in OPENAI_VOICES]
            elif self.kind == "omnivoice_server":
                voices = self._omnivoice_server_voices()
            elif self.kind == "vietauto":
                voices = self._vietauto_default_voices()
        self._voice_ids = self._build_voice_label_map(voices)
        return list(self._voice_ids)

    def sync_voices(self) -> list[dict]:
        self._require()
        if self.kind == "openai":
            voices = [{"id": v, "name": v} for v in OPENAI_VOICES]
        elif self.kind == "omnivoice_server":
            url = str(
                getattr(self.config, "voice_api_omnivoice_voices_url", "")
                or getattr(self.config, "voice_api_voices_url", "")
                or ""
            ).strip() or f"{self.base_url}/voices"
            try:
                response = requests.get(
                    url, headers=self._headers(), timeout=self.timeout
                )
                if response.status_code in (404, 405):
                    voices = self._omnivoice_server_voices()
                else:
                    self._raise(response)
                    voices = self._voice_rows_from_json(response.json())
                    if not voices:
                        voices = self._omnivoice_server_voices()
            except (requests.RequestException, ValueError):
                voices = self._omnivoice_server_voices()
        elif self.kind == "elevenlabs":
            voices, token = [], None
            while True:
                params = {"page_size": 100}
                if token:
                    params["next_page_token"] = token
                response = requests.get(
                    f"{self.base_url}/v2/voices",
                    headers=self._headers(),
                    params=params,
                    timeout=self.timeout,
                )
                self._raise(response)
                body = response.json()
                voices.extend(
                    {"id": v.get("voice_id"), "name": v.get("name")}
                    for v in body.get("voices", [])
                )
                token = body.get("next_page_token") if body.get("has_more") else None
                if not token:
                    break
        elif self.kind == "vietauto":
            url = str(getattr(self.config, "voice_api_voices_url", "") or "").strip()
            if not url:
                # VietAuto docs có thể không có endpoint catalog công khai.
                # Cho phép nhập voice_id thủ công để sinh giọng.
                voices = self._vietauto_default_voices()
            else:
                response = requests.get(url, headers=self._headers(), timeout=self.timeout)
                self._raise(response)
                voices = self._voice_rows_from_json(response.json())
        else:
            url = str(getattr(self.config, "voice_api_voices_url", "") or "")
            if not url:
                raise ModuleError("API REST tùy chỉnh chưa có URL danh sách giọng.")
            response = requests.get(url, headers=self._headers(), timeout=self.timeout)
            self._raise(response)
            voices = self._voice_rows_from_json(response.json())
        voices = [v for v in voices if v.get("id")]
        self._save_cache(voices)
        return voices

    @staticmethod
    def _vietauto_default_voices() -> list[dict]:
        return [dict(voice) for voice in VIETAUTO_DEFAULT_VOICES]

    def _omnivoice_server_voices(self) -> list[dict]:
        return [dict(voice) for voice in OMNIVOICE_SERVER_VOICES]

    def _omnivoice_server_payload(
        self, text: str, voice_id: str = ""
    ) -> dict[str, Any]:
        mode = str(
            getattr(self.config, "voice_api_omnivoice_mode", "auto") or "auto"
        ).strip().lower()
        if mode not in {"auto", "design", "clone"}:
            mode = "auto"
        payload: dict[str, Any] = {
            "text": text,
            "mode": mode,
            "format": "wav",
            "return": "audio",
        }
        if voice_id:
            payload["voice_id"] = voice_id
        if mode == "design":
            instruct = str(
                getattr(self.config, "voice_api_omnivoice_instruct", "") or ""
            ).strip()
            if not instruct:
                raise ModuleError("Chế độ thiết kế giọng chưa có mô tả giọng.")
            payload["instruct"] = instruct
        elif mode == "clone":
            ref_path = Path(str(
                getattr(self.config, "voice_api_omnivoice_ref_audio", "") or ""
            ).strip())
            ref_text = str(
                getattr(self.config, "voice_api_omnivoice_ref_text", "") or ""
            ).strip()
            if not ref_path.is_file() or not ref_text:
                raise ModuleError("Chế độ clone cần file audio mẫu và lời thoại mẫu.")
            if self._omnivoice_ref_audio_b64 is None:
                self._omnivoice_ref_audio_b64 = base64.b64encode(ref_path.read_bytes()).decode("ascii")
            payload["ref_audio_b64"] = self._omnivoice_ref_audio_b64
            payload["ref_text"] = ref_text
        return payload

    def _build_voice_label_map(self, voices: list[dict]) -> dict[str, str]:
        """Tạo nhãn công khai, giữ mã kỹ thuật hoàn toàn ở lớp kết nối.

        UI chỉ cần tên giọng dễ đọc. Khi hai giọng trùng tên, thêm số thứ tự
        trung tính thay vì để lộ voice_id của nhà cung cấp.
        """
        labels: dict[str, str] = {}
        name_counts: dict[str, int] = {}
        for voice in voices:
            voice_id = str(voice.get("id") or "").strip()
            if not voice_id:
                continue
            name = str(voice.get("name") or voice_id).strip() or voice_id
            count = name_counts.get(name, 0) + 1
            name_counts[name] = count
            label = name if count == 1 else f"{name} ({count})"
            labels[label] = voice_id
        return labels

    @staticmethod
    def _voice_rows_from_json(body: Any) -> list[dict]:
        if isinstance(body, list):
            rows = body
        elif isinstance(body, dict):
            rows = (
                body.get("voices")
                or body.get("data")
                or body.get("items")
                or body.get("results")
                or []
            )
            if isinstance(rows, dict):
                rows = (
                    rows.get("voices")
                    or rows.get("data")
                    or rows.get("items")
                    or rows.get("results")
                    or []
                )
        else:
            rows = []
        out: list[dict] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            voice_id = (
                row.get("voice_id")
                or row.get("voiceId")
                or row.get("id")
                or row.get("value")
            )
            if voice_id:
                out.append(
                    {
                        "id": str(voice_id),
                        "name": str(
                            row.get("name")
                            or row.get("display_name")
                            or row.get("displayName")
                            or row.get("label")
                            or voice_id
                        ),
                    }
                )
        return out

    @staticmethod
    def _raise(response: requests.Response) -> None:
        if response.ok:
            return
        detail = response.text[:300].strip()
        if response.status_code in (401, 403):
            raise ModuleError(
                "API giọng nói từ chối khóa truy cập. Hãy kiểm tra lại API key."
            )
        if response.status_code == 429:
            raise ModuleError(
                "API giọng nói đang giới hạn lượt gọi. Phần đã sinh được giữ lại; thử tiếp sau."
            )
        raise ModuleError(f"API giọng nói lỗi HTTP {response.status_code}: {detail}")

    def _vietauto_project_id(self) -> str:
        project_id = str(getattr(self.config, "voice_api_project_id", "") or "").strip()
        if project_id:
            return project_id
        response = requests.get(
            f"{self.base_url}/api/elevenlabs/projects",
            headers=self._headers(),
            params={"page": 1, "limit": 1},
            timeout=self.timeout,
        )
        self._raise(response)
        body = response.json()
        rows = body.get("list") if isinstance(body, dict) else body
        if isinstance(rows, list) and rows:
            project_id = str(rows[0].get("id", "")).strip()
        if not project_id:
            response = requests.post(
                f"{self.base_url}/api/elevenlabs/project",
                headers={**self._headers(), "Content-Type": "application/json"},
                json={"name": "AndrewSub"},
                timeout=self.timeout,
            )
            self._raise(response)
            body = response.json()
            project_id = str(body.get("project_id") or body.get("id") or "").strip()
        if not project_id:
            raise ModuleError("VietAuto API không trả project_id.")
        try:
            self.config.voice_api_project_id = project_id
            save = getattr(self.config, "save", None)
            if callable(save):
                save()
        except Exception:
            pass
        return project_id

    def _vietauto_wait_audio(self, job_id: str) -> requests.Response:
        deadline = time.time() + max(self.timeout, 30)
        last_message = ""
        while time.time() < deadline:
            response = requests.get(
                f"{self.base_url}/api/elevenlabs",
                headers=self._headers(),
                params={"id": job_id},
                timeout=self.timeout,
            )
            self._raise(response)
            body = response.json()
            status = str(body.get("status", "")).upper()
            last_message = str(body.get("message", "") or "")
            if status == "SUCCESS" and (
                body.get("audio")
                or body.get("audio_base64")
                or body.get("audioBase64")
                or body.get("file_url")
                or body.get("url")
            ):
                proxy = requests.Response()
                proxy.status_code = 200
                proxy._content = json.dumps(body, ensure_ascii=False).encode("utf-8")
                proxy.headers["Content-Type"] = "application/json"
                return proxy
            if status in {"FAILED", "ERROR", "CANCELLED"}:
                raise ModuleError(f"VietAuto tạo giọng lỗi: {last_message or status}")
            time.sleep(2.0)
        raise ModuleError(f"VietAuto tạo giọng quá lâu: {last_message or job_id}")

    def _voice_id(self, voice: str) -> str:
        if not self._voice_ids:
            self.list_voices()
        return self._voice_ids.get(
            voice, str(voice or "").rsplit(VOICE_LABEL_SEP, 1)[-1].strip()
        )

    def synthesize(
        self,
        text: str,
        voice: str,
        speed: float,
        out_wav: str,
        duration: float | None = None,
    ) -> None:
        self._require()
        voice_id = self._voice_id(voice)
        headers = self._headers()
        if self.kind == "openai":
            url = f"{self.base_url}/audio/speech"
            payload = {
                "model": self.model or "gpt-4o-mini-tts",
                "input": text,
                "voice": voice_id,
                "response_format": "wav",
                "speed": speed or 1.0,
            }
        elif self.kind == "elevenlabs":
            url = f"{self.base_url}/v1/text-to-speech/{quote(voice_id, safe='')}"
            payload = {"text": text, "model_id": self.model or "eleven_v3"}
            headers["Accept"] = "audio/mpeg"
        elif self.kind == "vietauto":
            template = str(getattr(self.config, "voice_api_synthesis_url", "") or "").strip()
            if not template:
                template = f"{self.base_url}/api/elevenlabs"
            url = template.replace("{voice_id}", quote(voice_id, safe=""))
            model_id = self.model or "eleven_v3"
            voice_settings: dict[str, Any] = {"stability": 0.5}
            if model_id != "eleven_v3":
                voice_settings.update(
                    {
                        "useSpeakerBoost": False,
                        "similarityBoost": 0.75,
                        "style": 0.5,
                        "speed": max(0.7, min(1.2, float(speed or 1.0))),
                    }
                )
            payload = {
                "name": f"AndrewSub-{int(time.time() * 1000)}",
                "project_id": self._vietauto_project_id(),
                "text": text,
                "is_create_srt": False,
                "voice_config": json.dumps(
                    {
                        "model_id": model_id,
                        "voice_id": voice_id,
                        "applyTextNormalization": "auto",
                        "voice_settings": voice_settings,
                    },
                    ensure_ascii=False,
                ),
            }
        elif self.kind == "omnivoice_server":
            self._ensure_omnivoice_server_ready()
            template = str(
                getattr(self.config, "voice_api_omnivoice_synthesis_url", "")
                or getattr(self.config, "voice_api_synthesis_url", "")
                or ""
            ).strip()
            url = template or f"{self.base_url}/tts"
            payload = self._omnivoice_server_payload(text, voice_id)
        else:
            template = str(getattr(self.config, "voice_api_synthesis_url", "") or "")
            if not template:
                raise ModuleError("API REST tùy chỉnh chưa có URL sinh giọng.")
            url = template.replace("{voice_id}", quote(voice_id, safe=""))
            payload = {
                "text": text,
                "voice": voice_id,
                "model": self.model,
                "speed": speed or 1.0,
            }
        headers["Content-Type"] = "application/json"
        retry = max(1, int(getattr(self.config, "voice_api_retry", 3)))
        last_error: Exception | None = None
        for attempt in range(retry):
            try:
                response = requests.post(
                    url, headers=headers, json=payload, timeout=self.timeout
                )
                self._raise(response)
                if self.kind == "vietauto":
                    body = response.json()
                    job_id = str(body.get("id") or body.get("job_id") or "").strip()
                    if not job_id:
                        raise ModuleError("VietAuto API không trả job id.")
                    response = self._vietauto_wait_audio(job_id)
                if self.kind == "omnivoice_server":
                    self.last_latency_ms = str(response.headers.get("X-Latency-Ms", "") or "")
                    self.last_rtf = str(response.headers.get("X-RTF", "") or "")
                    self.last_audio_duration_sec = str(
                        response.headers.get("X-Audio-Duration-Sec", "") or ""
                    )
                self._write_wav(self._extract_audio_content(response), out_wav)
                return
            except (requests.RequestException, ModuleError) as exc:
                last_error = exc
                if isinstance(exc, ModuleError) and "khóa truy cập" in str(exc):
                    break
                if attempt + 1 < retry:
                    time.sleep(1.5 * (attempt + 1))
        raise ModuleError(f"Không sinh được giọng từ API: {last_error}") from last_error

    def _extract_audio_content(self, response: requests.Response) -> bytes:
        """Accept direct audio bytes or JSON containing audio/url/base64."""
        content = response.content or b""
        headers = response.headers if isinstance(response.headers, dict) else {}
        content_type = str(headers.get("Content-Type", "")).lower()
        if "application/json" not in content_type and not content.lstrip().startswith(
            (b"{", b"[")
        ):
            return content
        try:
            body = response.json()
        except ValueError:
            return content
        audio = self._find_audio_value(body)
        if not audio:
            raise ModuleError("API giọng nói trả JSON nhưng không thấy audio/url.")
        if isinstance(audio, str) and audio.startswith(("http://", "https://")):
            downloaded = requests.get(audio, headers=self._headers(), timeout=self.timeout)
            self._raise(downloaded)
            return downloaded.content
        if isinstance(audio, str):
            data = audio.split(",", 1)[-1] if audio.startswith("data:") else audio
            try:
                return base64.b64decode(data, validate=False)
            except (ValueError, TypeError) as exc:
                raise ModuleError("API giọng nói trả base64 audio không hợp lệ.") from exc
        raise ModuleError("API giọng nói trả audio không hợp lệ.")

    @staticmethod
    def _find_audio_value(body: Any) -> Any:
        if isinstance(body, dict):
            for key in (
                "audio",
                "audio_base64",
                "audioBase64",
                "base64",
                "url",
                "audio_url",
                "audioUrl",
                "file_url",
                "fileUrl",
                "download_url",
                "downloadUrl",
            ):
                if body.get(key):
                    return body.get(key)
            for key in ("data", "result", "output"):
                found = VoiceApiEngine._find_audio_value(body.get(key))
                if found:
                    return found
        elif isinstance(body, list):
            for item in body:
                found = VoiceApiEngine._find_audio_value(item)
                if found:
                    return found
        return None

    def _write_wav(self, content: bytes, out_wav: str) -> None:
        if not content:
            raise ModuleError("API giọng nói trả file rỗng.")
        destination = Path(out_wav)
        destination.parent.mkdir(parents=True, exist_ok=True)
        suffix = ".wav" if content[:4] == b"RIFF" else ".audio"
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=suffix, dir=destination.parent
        ) as f:
            f.write(content)
            source = f.name
        temporary = str(destination) + ".tmp.wav"
        try:
            if suffix == ".wav":
                try:
                    with wave.open(source, "rb") as audio:
                        ready = (
                            audio.getnchannels() == 1
                            and audio.getsampwidth() == 2
                            and audio.getframerate() == 24000
                            and audio.getnframes() > 0
                        )
                    if ready:
                        os.replace(source, destination)
                        return
                except (OSError, EOFError, wave.Error):
                    pass
            FFmpeg(self.config.ffmpeg_path, self.config.ffprobe_path).to_wav(
                source, temporary
            )
            os.replace(temporary, destination)
        finally:
            Path(source).unlink(missing_ok=True)
            Path(temporary).unlink(missing_ok=True)

    def synthesize_batch(
        self, texts: list[str], voice: str, speed: float, out_wavs: list[str]
    ) -> None:
        for text, out in zip(texts, out_wavs):
            self.synthesize(text, voice, speed, out)

    def default_voice(self, gender: str) -> str:
        voices = self.list_voices()
        return voices[0] if voices else ""

    def check(self) -> str:
        if self.kind == "omnivoice_server":
            self._require()
            self._ensure_omnivoice_server_ready()
            health = requests.get(f"{self.base_url}/health", timeout=self.timeout)
            self._raise(health)
            try:
                health_info = health.json()
            except ValueError:
                health_info = {}
            url = str(
                getattr(self.config, "voice_api_omnivoice_synthesis_url", "")
                or getattr(self.config, "voice_api_synthesis_url", "")
                or ""
            ).strip()
            url = url or f"{self.base_url}/tts"
            response = requests.post(
                url,
                headers={**self._headers(), "Content-Type": "application/json"},
                json={"text": "Xin chào.", "mode": "auto"},
                timeout=self.timeout,
            )
            self._raise(response)
            content = self._extract_audio_content(response)
            if not content.startswith(b"RIFF"):
                raise ModuleError("OmniVoice Server không trả về WAV hợp lệ.")
            voices = self.sync_voices()
            latency = str(response.headers.get("X-Latency-Ms", "") or "—")
            rtf = str(response.headers.get("X-RTF", "") or "—")
            gpu = str(health_info.get("gpu") or health_info.get("device") or "server")
            return (
                f"Kết nối OmniVoice Server OK — {gpu}, latency {latency} ms, "
                f"RTF {rtf}, {len(voices)} giọng."
            )
        if self.kind == "vietauto":
            self._require()
            response = requests.get(
                f"{self.base_url}/api/me",
                headers=self._headers(),
                timeout=self.timeout,
            )
            self._raise(response)
            project_id = self._vietauto_project_id()
            return f"Kết nối VietAuto API OK — project {project_id[:8]}..."
        voices = self.sync_voices()
        return f"Kết nối API giọng nói OK — tìm thấy {len(voices)} giọng."

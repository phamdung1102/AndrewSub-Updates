"""Estimate speaker gender from source audio F0.

This is a lightweight helper for dubbing voice defaults. It never guesses when
the signal is weak or near the adaptive threshold.
"""

from __future__ import annotations

import logging
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np

from vicdub.utils.process_utils import hidden_process_kwargs
from vicdub.utils.subtitles import Segment, normalize_gender

logger = logging.getLogger(__name__)

SR = 16000


def _read_wav_mono(path: str | Path) -> np.ndarray:
    with wave.open(str(path), "rb") as audio:
        channels = audio.getnchannels()
        width = audio.getsampwidth()
        rate = audio.getframerate()
        frames = audio.readframes(audio.getnframes())
    if width != 2:
        raise ValueError("F0 chỉ hỗ trợ WAV PCM 16-bit.")
    data = np.frombuffer(frames, dtype="<i2").astype(np.float32) / 32768.0
    if channels > 1:
        data = data.reshape(-1, channels).mean(axis=1)
    if rate != SR:
        raise ValueError(f"WAV phải là {SR}Hz.")
    return data


def extract_audio_for_f0(video_path: str, ffmpeg_path: str, out_wav: str) -> None:
    """Extract source audio to 16k mono PCM for F0 analysis."""
    cmd = [
        ffmpeg_path,
        "-y",
        "-i",
        str(video_path),
        "-vn",
        "-ac",
        "1",
        "-ar",
        str(SR),
        "-sample_fmt",
        "s16",
        str(out_wav),
    ]
    subprocess.run(
        cmd,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        **hidden_process_kwargs(),
    )


def estimate_f0_median(
    audio: np.ndarray,
    start_s: float,
    end_s: float,
    *,
    sr: int = SR,
) -> float | None:
    """Return median F0 for a cue using FFT autocorrelation, or None if weak."""
    start = max(0, int(start_s * sr))
    end = min(len(audio), int(end_s * sr))
    if end - start < int(0.5 * sr):
        return None
    segment = audio[start:end].astype(np.float32, copy=False)
    if segment.size < int(0.5 * sr):
        return None

    frame_len = int(0.040 * sr)
    hop = int(0.010 * sr)
    if len(segment) < frame_len:
        return None

    min_f0, max_f0 = 80.0, 300.0
    min_lag = int(sr / max_f0)
    max_lag = int(sr / min_f0)
    window = np.hanning(frame_len).astype(np.float32)
    values: list[float] = []

    for pos in range(0, len(segment) - frame_len + 1, hop):
        frame = segment[pos:pos + frame_len]
        frame = frame - float(np.mean(frame))
        rms = float(np.sqrt(np.mean(frame * frame)))
        if rms < 0.008:
            continue
        frame = frame * window
        nfft = 1 << int(np.ceil(np.log2(frame_len * 2 - 1)))
        spectrum = np.fft.rfft(frame, n=nfft)
        corr = np.fft.irfft(spectrum * np.conj(spectrum), n=nfft)[:frame_len]
        if corr[0] <= 1e-8:
            continue
        corr = corr / corr[0]
        search = corr[min_lag:max_lag + 1]
        if search.size == 0:
            continue
        lag = int(np.argmax(search)) + min_lag
        confidence = float(corr[lag])
        if confidence < 0.35:
            continue
        values.append(sr / lag)

    if len(values) < 8:
        return None
    return float(np.median(values))


def _adaptive_threshold(f0_values: list[float]) -> float | None:
    """Two-means threshold between lower/higher F0 clusters."""
    if len(f0_values) < 2:
        return None
    values = np.asarray(f0_values, dtype=np.float32)
    low = float(np.percentile(values, 25))
    high = float(np.percentile(values, 75))
    if abs(high - low) < 18:
        return None
    for _ in range(20):
        distances_low = np.abs(values - low)
        distances_high = np.abs(values - high)
        low_group = values[distances_low <= distances_high]
        high_group = values[distances_low > distances_high]
        if low_group.size == 0 or high_group.size == 0:
            return None
        new_low = float(np.mean(low_group))
        new_high = float(np.mean(high_group))
        if abs(new_low - low) < 0.1 and abs(new_high - high) < 0.1:
            break
        low, high = new_low, new_high
    if high - low < 18:
        return None
    return (low + high) / 2.0


def infer_gender_by_speaker(
    audio: np.ndarray,
    segments: list[Segment],
    *,
    sr: int = SR,
    margin_hz: float = 12.0,
) -> dict[str, str]:
    """Infer gender per speaker id/name from cue F0 medians."""
    by_speaker: dict[str, list[float]] = {}
    for seg in segments:
        speaker = (seg.speaker or "").strip()
        if not speaker or speaker.casefold() in {"unknown", "narrator", "—"}:
            continue
        f0 = estimate_f0_median(audio, seg.start, seg.end, sr=sr)
        if f0 is not None:
            by_speaker.setdefault(speaker, []).append(f0)

    speaker_f0 = {
        speaker: float(np.median(values))
        for speaker, values in by_speaker.items()
        if len(values) >= 2
    }
    threshold = _adaptive_threshold(list(speaker_f0.values()))
    if threshold is None:
        return {}

    genders: dict[str, str] = {}
    for speaker, f0 in speaker_f0.items():
        if abs(f0 - threshold) <= margin_hz:
            genders[speaker] = "neutral"
        elif f0 < threshold:
            genders[speaker] = "male"
        else:
            genders[speaker] = "female"
    return genders


def apply_audio_gender(
    video_path: str,
    segments: list[Segment],
    ffmpeg_path: str = "ffmpeg",
    *,
    work_dir: str | Path | None = None,
) -> dict[str, str]:
    """Extract audio, infer speaker genders, and apply them to segments."""
    if not video_path or not Path(video_path).exists():
        return {}
    if not any((seg.speaker or "").strip() for seg in segments):
        return {}

    temp_context = None
    if work_dir is None:
        temp_context = tempfile.TemporaryDirectory(prefix="andrewsub_f0_")
        folder = Path(temp_context.name)
    else:
        folder = Path(work_dir)
        folder.mkdir(parents=True, exist_ok=True)
    wav = folder / "source_f0.wav"
    try:
        extract_audio_for_f0(video_path, ffmpeg_path, str(wav))
        audio = _read_wav_mono(wav)
        genders = infer_gender_by_speaker(audio, segments)
        for seg in segments:
            speaker = (seg.speaker or "").strip()
            gender = normalize_gender(genders.get(speaker, ""))
            if gender != "neutral":
                seg.gender = gender
        return genders
    except Exception as exc:  # noqa: BLE001
        logger.warning("Không đo được giới tính từ audio: %s", exc)
        return {}
    finally:
        if temp_context is not None:
            temp_context.cleanup()

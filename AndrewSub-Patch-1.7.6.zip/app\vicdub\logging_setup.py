"""Thiết lập logging: ghi file theo ngày + console."""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path


def setup_logging(log_dir: str, level: int = logging.INFO) -> logging.Logger:
    """Cấu hình root logger: xoay vòng file 5MB x 5 bản + console."""
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    log_file = Path(log_dir) / "vicdub.log"

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )

    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(level)
    # Tránh gắn trùng handler khi gọi lại (ví dụ trong test).
    root.handlers.clear()
    root.addHandler(file_handler)
    root.addHandler(console_handler)
    return logging.getLogger("vicdub")

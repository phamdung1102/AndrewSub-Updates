"""Các phong cách dịch phụ đề dùng chung cho Web và API."""

STYLES = {
    "conversational": (
        "Đối thoại tự nhiên",
        "Dịch như lời thoại đời thường: ngắn gọn, khẩu ngữ, dễ đọc thành tiếng; "
        "ưu tiên vừa thời lượng nhưng không làm mất ý chính.",
    ),
    "concise": (
        "Ngắn gọn để lồng tiếng",
        "Rút gọn mạnh câu chữ để đọc kịp thời lượng; bỏ từ đệm và cấu trúc rườm rà, "
        "giữ nguyên thông tin, cảm xúc và ý chính.",
    ),
    "cinematic": (
        "Điện ảnh",
        "Viết như thoại phim Việt tự nhiên, có nhịp điệu và cảm xúc; tránh văn dịch, "
        "vẫn phải vừa thời lượng của từng dòng.",
    ),
    "faithful": (
        "Sát nghĩa",
        "Ưu tiên sát nghĩa và đầy đủ nội dung; diễn đạt tự nhiên, chỉ rút gọn khi cần "
        "để không vượt quá thời lượng.",
    ),
    "custom": ("Tùy chỉnh", ""),
}

GENRES = {
    "neutral": ("Trung tính", "Giữ giọng điệu trung tính, không tự thêm màu sắc thể loại."),
    "romance": (
        "Ngôn tình",
        "Ưu tiên cảm xúc và quan hệ nhân vật; xưng hô thân mật tự nhiên nhưng không tự suy diễn quan hệ.",
    ),
    "fantasy": (
        "Huyền huyễn",
        "Giữ thuật ngữ thế giới giả tưởng, cấp bậc, pháp thuật và danh xưng nhất quán xuyên suốt.",
    ),
    "costume": (
        "Tiên hiệp / cổ trang",
        "Dùng sắc thái cổ trang vừa phải; giữ tông vai vế, môn phái, cảnh giới và kính ngữ nhất quán.",
    ),
    "modern": (
        "Đô thị hiện đại",
        "Dùng lời thoại hiện đại, tự nhiên; tránh từ cổ hoặc văn phong dịch máy.",
    ),
    "action": (
        "Hành động",
        "Câu gọn, dứt khoát, nhịp nhanh; giữ rõ mệnh lệnh, đe doạ và thông tin hành động.",
    ),
}

TRANSLATION_MODES = {
    "fast": ("Nhanh", "Lô lớn, bỏ bước hồ sơ nhân vật; phù hợp nội dung đơn giản."),
    "balanced": ("Cân bằng", "Giữ ngữ cảnh và tốc độ ổn định; khuyên dùng."),
    "quality": ("Chất lượng", "Lô nhỏ hơn, nhiều ngữ cảnh và kiểm tra nhân vật kỹ hơn."),
}


def style_instruction(style: str, custom: str = "") -> str:
    if style == "custom" and custom.strip():
        return custom.strip()
    return STYLES.get(style, STYLES["conversational"])[1]


def genre_instruction(genre: str, *, custom_overrides: bool = False) -> str:
    if custom_overrides:
        return ""
    return GENRES.get(genre, GENRES["neutral"])[1]

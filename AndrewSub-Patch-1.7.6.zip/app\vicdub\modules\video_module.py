"""Đồng bộ voice nhưng giữ nguyên tuyệt đối timeline và hình của video.

Voice dài được tăng tốc giữ cao độ. Voice ngắn giữ nguyên, khoảng còn lại là
im lặng tự nhiên. Bước xuất cuối tự mượn khoảng trống và mix overlap nên module
này tuyệt đối không cắt, kéo chậm hay tạo hàng trăm clip video trung gian.
"""

from __future__ import annotations

import wave
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import Segment


class VideoModule(BaseModule):
    """Chuẩn hóa voice dài mà không xử lý lại hình."""

    name = "Đồng bộ voice"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        video_path = data.get("video_path") or project.video_path
        segments: list[Segment] = data.get("segments") or project.load_segments()
        voice_files: dict[int, str] = data.get("voice_files") or {}

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video nguồn.")
        if not segments:
            raise ModuleError("Chưa có phụ đề.")
        if not voice_files:
            raise ModuleError("Chưa có voice. Chạy bước 'Sinh giọng nói' trước.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        out_voice_files: dict[int, str] = dict(voice_files)
        warnings: list[str] = []

        ordered = sorted(segments, key=lambda item: (item.start, item.end, item.line))
        total = len(ordered)
        for i, seg in enumerate(ordered):
            self.check_cancelled()
            voice_wav = voice_files.get(seg.line)
            if not voice_wav or not Path(voice_wav).exists():
                continue

            self.report(
                int(100 * i / total),
                f"Voice {i + 1}/{total}: kiểm tra thời lượng dòng {seg.line}",
            )
            try:
                if Path(voice_wav).suffix.lower() == ".wav":
                    with wave.open(str(voice_wav), "rb") as handle:
                        rate = handle.getframerate()
                        voice_dur = handle.getnframes() / rate if rate else 0.0
                else:
                    voice_dur = ffmpeg.duration(voice_wav)
            except FFmpegError as exc:
                raise ModuleError(f"Dòng {seg.line}: {exc}") from exc
            except (OSError, wave.Error) as exc:
                raise ModuleError(f"Dòng {seg.line}: không đọc được voice: {exc}") from exc

            next_start = (
                ordered[i + 1].start if i + 1 < total else max(seg.end, seg.start)
            )
            available = max(seg.duration, next_start - seg.start)
            _video_speed, voice_speed, _pad = self._plan_sync(
                available, voice_dur, 1.0, config.speed_max,
                seg.line, warnings,
            )
            # Chỉ kiểm tra/kế hoạch ở đây. MergeModule sẽ co đúng một lần từ
            # file gốc sau khi đã xét cả cụm hội thoại, tránh tăng tốc chồng.

        for warning in warnings:
            self.logger.warning(warning)
        message = (
            f"Đã lập lịch {len(out_voice_files)} voice; "
            "sẽ co/mix một lần lúc xuất, hình giữ nguyên"
        )
        if warnings:
            message += f" ({len(warnings)} cảnh báo tốc độ)"
        self.report(100, message)
        return {"voice_files": out_voice_files, "speed_warnings": warnings}

    @staticmethod
    def _plan_sync(clip_dur: float, voice_dur: float, min_video_speed: float,
                   max_voice_speed: float, line: int,
                   warnings: list[str]) -> tuple[float, float, float]:
        """Lên kế hoạch chỉ thay đổi voice; video_speed luôn bằng 1.0."""
        if voice_dur <= 0 or clip_dur <= 0:
            return 1.0, 1.0, 0.0
        if voice_dur <= clip_dur:
            pad = clip_dur - voice_dur
            return 1.0, 1.0, (pad if pad > 0.05 else 0.0)

        needed = voice_dur / clip_dur
        voice_speed = min(max(1.0, max_voice_speed), needed)
        if needed > max_voice_speed + 0.005:
            warnings.append(
                f"Dòng {line}: cần {needed:.2f}x nhưng giới hạn voice là "
                f"{max_voice_speed:.2f}x; phần dư sẽ được dời/mix khi xuất."
            )
        return 1.0, voice_speed, 0.0


class CutModule(BaseModule):
    """Băm video thành clip theo khung giờ sub - chạy ngay sau Tách sub.

    Cắt TOÀN BỘ (ghi đè clip cũ vì ranh giới sub có thể đã đổi) để track
    Video trên Video Studio có sẵn clip xem demo. Bước Đồng bộ video sau
    này sẽ retime lại theo voice.
    """

    name = "Băm video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        video_path = data.get("video_path") or project.video_path
        segments: list[Segment] = data.get("segments") or project.load_segments()

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video nguồn để băm.")
        if not segments:
            raise ModuleError("Chưa có sub để băm theo.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        clips_dir = Path(project.root) / "clips"
        keep_bg = getattr(config, "bg_volume", 0) > 0

        clip_files: dict[int, str] = {}
        total = len(segments)
        for i, seg in enumerate(segments):
            self.check_cancelled()
            clip = clips_dir / f"{seg.line:03d}.mp4"
            self.report(
                int(100 * i / total),
                f"Băm clip {seg.line}/{total} "
                f"({seg.start:.1f}s - {seg.end:.1f}s)...",
            )
            try:
                ffmpeg.cut_clip(video_path, seg.start, seg.end, str(clip),
                                keep_audio=keep_bg)
            except FFmpegError as exc:
                raise ModuleError(f"Dòng {seg.line}: {exc}") from exc
            clip_files[seg.line] = str(clip)

        self.report(100, f"Băm xong {len(clip_files)} clip - xem ở Video Studio")
        return {"clip_files": clip_files}

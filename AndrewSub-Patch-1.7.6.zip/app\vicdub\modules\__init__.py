"""8 module pipeline - mỗi module độc lập, chỉ nhận input trả output."""

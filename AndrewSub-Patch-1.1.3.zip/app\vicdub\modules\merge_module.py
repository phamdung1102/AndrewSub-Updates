"""Merge Module - lồng tiếng theo timeline SRT rồi phủ lên VIDEO GỐC.

Cách làm (theo omnivoice-vi): KHÔNG cắt/kéo video. Dựng một track audio lồng
tiếng dài bằng video: im lặng ở mọi chỗ, đặt voice của từng dòng đúng mốc thời
gian gốc của phụ đề. Voice dài hơn khoảng tới câu kế thì giữ nguyên, tràn nhẹ
sang sau; câu sau mix đè lên tail câu trước và tail cũ bị hạ âm lượng.

Nhờ vậy giữ nguyên hình + thời lượng + mọi khoảng lặng của video gốc.

Output: final_video (đường dẫn Final.mp4)
"""

from __future__ import annotations

import wave
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import (
    Segment, write_blur_mask_ass, write_positioned_ass, write_srt,
)

DUB_SR = 24000  # OmniVoice xuất 24 kHz


class MergeModule(BaseModule):
    """Lồng tiếng theo timeline + phủ lên video gốc + chèn phụ đề."""

    name = "Ghép video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        segments: list[Segment] = data.get("segments") or project.load_segments()
        voice_files: dict[int, str] = data.get("voice_files") or {}
        video_path = data.get("video_path") or project.video_path

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video gốc để lồng tiếng.")
        if not segments:
            raise ModuleError("Chưa có phụ đề.")

        # Ưu tiên voice trong context (có thể đã được đồng bộ/tăng tốc), rồi mới
        # rơi về voice gốc trong project.
        voices_dir = Path(project.root) / "voices"
        resolved: dict[int, str] = {}
        for seg in segments:
            p = voices_dir / f"{seg.line:04d}.wav"
            cand = voice_files.get(seg.line)
            if cand and Path(cand).exists():
                resolved[seg.line] = cand
            elif p.exists():
                resolved[seg.line] = str(p)
        voice_files = resolved
        if not voice_files:
            raise ModuleError("Chưa có voice. Chạy bước 'Sinh giọng nói' trước.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        output_dir = Path(project.root) / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            video_dur = ffmpeg.duration(video_path)
        except FFmpegError as exc:
            raise ModuleError(f"Không đọc được video: {exc}") from exc

        # Lập timeline co giãn chỉ cho các câu voice thật sự không thể khớp bằng
        # khoảng trống + tăng tốc nhẹ. Không sửa/cắt khoảng lặng trong voice.
        timeline_video: Path | None = None
        timing_warnings: list[str] = []
        if bool(getattr(config, "merge_video_stretch_enabled", True)):
            intervals, adjusted_segments, timing_warnings = self._plan_local_video_stretch(
                segments, voice_files, video_dur, config,
            )
            if intervals:
                self.check_cancelled()
                added = sum(
                    (end - start) / speed + hold - (end - start)
                    for start, end, speed, hold in intervals
                )
                self.report(
                    5,
                    f"Đồng bộ hình cho {len(intervals)} vùng voice dài "
                    f"(+{added:.1f}s, không cắt voice)...",
                )
                timeline_video = output_dir / "_timeline.mp4"
                try:
                    ffmpeg.retime_timeline(video_path, intervals, str(timeline_video))
                except FFmpegError as exc:
                    raise ModuleError(f"Co giãn timeline video lỗi: {exc}") from exc
                video_path = str(timeline_video)
                video_dur += added
                segments = adjusted_segments

        # 1. Dựng track lồng tiếng theo timeline SRT (im lặng ở khoảng trống).
        self.report(10, "Dựng track lồng tiếng theo timeline...")
        dub_wav = output_dir / "_dub.wav"
        warnings = timing_warnings + self._build_dub_audio(
            segments, voice_files, video_dur, dub_wav, ffmpeg, config, output_dir,
        )
        for w in warnings:
            self.logger.warning(w)

        # 2. Phủ track lồng tiếng lên VIDEO GỐC (giữ nguyên hình + thời lượng).
        self.check_cancelled()
        self.report(55, "Ghép tiếng vào video gốc...")
        bg_volume = getattr(config, "bg_volume", 0) / 100.0
        voice_volume = getattr(config, "voice_volume", 100) / 100.0
        dubbed = output_dir / "_dubbed.mp4"
        try:
            if bg_volume > 0:
                try:
                    ffmpeg.replace_audio(video_path, str(dub_wav), str(dubbed),
                                         bg_volume, voice_volume)
                except FFmpegError:
                    # Video gốc không có audio -> chỉ dùng voice.
                    ffmpeg.replace_audio(video_path, str(dub_wav), str(dubbed),
                                         0.0, voice_volume)
            else:
                ffmpeg.replace_audio(video_path, str(dub_wav), str(dubbed),
                                     0.0, voice_volume)
        except FFmpegError as exc:
            raise ModuleError(f"Ghép tiếng vào video lỗi: {exc}") from exc
        finally:
            dub_wav.unlink(missing_ok=True)
            if timeline_video is not None:
                timeline_video.unlink(missing_ok=True)

        # 3. Phụ đề (giữ TIMING GỐC vì video không đổi).
        self.check_cancelled()
        final_path = output_dir / "Final.mp4"
        mode = getattr(config, "subtitle_mode", "none")
        blur_original = bool(getattr(config, "subtitle_blur_original", False))
        blur_region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or (0.05, 0.78, 0.95, 1.0)
        ))
        # Blur chỉ xuất hiện đúng lúc hard-sub gốc hiện trên hình. Không phủ một
        # dải mờ cố định xuyên suốt các khoảng không có thoại.
        blur_intervals = [
            (segment.start, segment.end) for segment in segments
            if (segment.text or "").strip()
        ]
        blur_mask = output_dir / "_blur_mask.ass"
        if blur_original:
            write_blur_mask_ass(
                segments, blur_mask, region=blur_region,
                scale_percent=int(getattr(config, "subtitle_blur_scale", 140)),
            )
        has_text = any((s.translation or s.text).strip() for s in segments)
        try:
            if mode in ("hard", "soft") and has_text:
                srt = output_dir / "_sub.srt"
                write_srt(segments, srt, translated=True)
                if mode == "hard":
                    self.report(80, "Đang vẽ phụ đề lên video (hard sub)...")
                    ass = output_dir / "_sub_positioned.ass"
                    write_positioned_ass(
                        segments, ass,
                        x=float(getattr(config, "subtitle_x", 0.5)),
                        y=float(getattr(config, "subtitle_y", 0.90)),
                        font_size=int(getattr(config, "subtitle_font_size", 24)),
                        background=bool(getattr(config, "subtitle_bg", False)),
                        translated=True,
                    )
                    ffmpeg.burn_subtitle(
                        str(dubbed), str(ass), str(final_path),
                        position=getattr(config, "subtitle_position", "bottom"),
                        font_size=getattr(config, "subtitle_font_size", 24),
                        background=getattr(config, "subtitle_bg", False),
                        blur_region=blur_region if blur_original else None,
                        blur_intervals=blur_intervals if blur_original else None,
                        blur_mask_ass=str(blur_mask) if blur_original else None,
                    )
                    dubbed.unlink(missing_ok=True)
                else:
                    self.report(80, "Đang nhúng track phụ đề (soft sub)...")
                    source_for_soft = dubbed
                    blurred = output_dir / "_blurred.mp4"
                    if blur_original:
                        self.report(75, "Đang làm mờ phụ đề gốc...")
                        ffmpeg.blur_video_region(
                            str(dubbed), str(blurred), blur_region, blur_intervals,
                            blur_mask_ass=str(blur_mask),
                        )
                        source_for_soft = blurred
                    ffmpeg.soft_subtitle(str(source_for_soft), str(srt), str(final_path))
                    dubbed.unlink(missing_ok=True)
                    blurred.unlink(missing_ok=True)
            elif blur_original:
                self.report(80, "Đang làm mờ phụ đề gốc...")
                ffmpeg.blur_video_region(
                    str(dubbed), str(final_path), blur_region, blur_intervals,
                    blur_mask_ass=str(blur_mask),
                )
                dubbed.unlink(missing_ok=True)
            else:
                dubbed.replace(final_path)
        except FFmpegError as exc:
            raise ModuleError(f"Chèn phụ đề thất bại: {exc}") from exc

        # Người dùng chọn thư mục xuất riêng -> copy Final ra đó theo tên project.
        export_dir = getattr(config, "export_dir", "")
        if export_dir:
            import shutil  # noqa: PLC0415
            dest_dir = Path(export_dir)
            try:
                dest_dir.mkdir(parents=True, exist_ok=True)
                dest = dest_dir / f"{project.name}.mp4"
                shutil.copy2(final_path, dest)
                self.report(100, f"Hoàn tất: {dest}")
                return {"final_video": str(dest)}
            except OSError as exc:
                self.logger.warning("Không copy được ra %s: %s", export_dir, exc)

        note = f" ({len(warnings)} câu tràn nhẹ)" if warnings else ""
        self.report(100, f"Hoàn tất: {final_path}{note}")
        return {"final_video": str(final_path)}

    # ---------- Timeline video co giãn cục bộ ----------

    @staticmethod
    def _wav_duration(path: str) -> float:
        """Đọc duration WAV trực tiếp, không trim khoảng lặng đầu/cuối."""
        try:
            with wave.open(str(path), "rb") as handle:
                rate = handle.getframerate()
                return handle.getnframes() / rate if rate else 0.0
        except (OSError, wave.Error):
            return 0.0

    @staticmethod
    def _map_timeline_time(
        value: float, intervals: list[tuple[float, float, float, float]],
    ) -> float:
        """Ánh xạ timestamp gốc sang timeline sau co giãn/giữ khung."""
        value = max(0.0, float(value))
        offset = 0.0
        for start, end, speed, hold in intervals:
            if value < start:
                break
            if value <= end:
                mapped = start + offset + (value - start) / speed
                if value >= end - 1e-6:
                    mapped += hold
                return mapped
            offset += (end - start) / speed + hold - (end - start)
        return value + offset

    def _plan_local_video_stretch(
        self, segments: list[Segment], voice_files: dict[int, str],
        video_dur: float, config: Any,
    ) -> tuple[
        list[tuple[float, float, float, float]], list[Segment], list[str]
    ]:
        """Chỉ kéo vùng hình không đủ chỗ cho voice sau các biện pháp audio nhẹ.

        Không đọc/chỉnh waveform và không cắt silence. Kết quả là danh sách vùng
        ảo cho FFmpeg cùng timeline sub đã remap; project gốc không bị sửa.
        """
        ordered = sorted(segments, key=lambda item: (item.start, item.end, item.line))
        if not ordered:
            return [], list(segments), []
        min_video_speed = max(
            0.80, min(0.99, float(getattr(config, "merge_video_speed_min", 0.92)))
        )
        hold_max = max(0.0, min(1.0, float(
            getattr(config, "merge_video_hold_max", 0.40)
        )))
        voice_speed_max = max(1.0, min(1.50, float(
            getattr(config, "merge_voice_speed_max", 1.20)
        )))
        max_shift = max(0.0, float(getattr(config, "merge_max_audio_shift", 0.55)))
        min_gap = max(0.0, float(getattr(config, "merge_min_gap", 0.03)))
        accept_overlap = max(0.0, float(
            getattr(config, "merge_accept_overlap", 0.08)
        ))

        intervals: list[tuple[float, float, float, float]] = []
        warnings: list[str] = []
        occupied_end = 0.0
        for index, seg in enumerate(ordered):
            wav = voice_files.get(seg.line)
            if not wav or not Path(wav).exists() or seg.duration < 0.03:
                continue
            voice_dur = self._wav_duration(wav)
            if voice_dur <= 0:
                continue
            previous_end = ordered[index - 1].end if index else 0.0
            next_start = ordered[index + 1].start if index + 1 < len(ordered) else video_dur
            after_room = max(seg.end, next_start - min_gap) - seg.start
            before_room = min(
                max_shift,
                max(0.0, seg.start - previous_end - min_gap),
            )
            capacity = max(seg.duration, after_room) + before_room + accept_overlap
            required = voice_dur / voice_speed_max
            deficit = required - capacity
            if deficit <= 0.01:
                continue

            start = max(float(seg.start), occupied_end)
            end = min(float(seg.end), video_dur)
            source_dur = end - start
            if source_dur < 0.03:
                warnings.append(
                    f"Dòng {seg.line}: voice dài nhưng vùng hình chồng dòng trước; "
                    "giữ cơ chế tăng tốc/overlap, không cắt voice."
                )
                continue
            max_slow_extra = source_dur / min_video_speed - source_dur
            slow_extra = min(deficit, max_slow_extra)
            speed = source_dur / (source_dur + slow_extra) if slow_extra > 0 else 1.0
            remaining = max(0.0, deficit - slow_extra)
            hold = min(hold_max, remaining)
            if speed >= 0.9995 and hold < 0.005:
                continue
            intervals.append((start, end, speed, hold))
            occupied_end = end
            warnings.append(
                f"Dòng {seg.line}: kéo vùng hình {speed:.2f}x"
                + (f" và giữ khung {hold:.2f}s" if hold > 0.005 else "")
                + "; giữ nguyên toàn bộ voice."
            )
            unresolved = remaining - hold
            if unresolved > accept_overlap:
                warnings.append(
                    f"Dòng {seg.line}: còn thiếu {unresolved:.2f}s sau co giãn; "
                    "sẽ tiếp tục dùng tăng tốc nhẹ và overlap/fade."
                )

        adjusted = [
            Segment(
                line=seg.line,
                start=self._map_timeline_time(seg.start, intervals),
                end=self._map_timeline_time(seg.end, intervals),
                text=seg.text,
                translation=seg.translation,
                speaker=seg.speaker,
                gender=seg.gender,
                voice=seg.voice,
            )
            for seg in segments
        ]
        return intervals, adjusted, warnings

    # ---------- Dựng audio timeline ----------

    def _build_dub_audio(self, segments: list[Segment],
                         voice_files: dict[int, str], video_dur: float,
                         out_wav: Path, ffmpeg: FFmpeg, config: Any,
                         tmp_dir: Path) -> list[str]:
        """Dựng track audio dài bằng video: im lặng + đặt voice đúng mốc SRT.

        Voice dài hơn nhẹ thì giữ nguyên và tràn sang sau. Voice overlap vừa/lớn
        được xử lý theo cụm liền kề: tận dụng khoảng trống gần đó, tăng speed nhẹ,
        phần còn dư mới overlap/mix thay vì bị cắt.
        Nếu câu sau chồng lên tail câu trước, mix thêm câu sau để cả hai cùng nghe được.
        Trả danh sách cảnh báo câu tràn.
        """
        import numpy as np  # noqa: PLC0415 - có sẵn theo torch

        accept_overlap = float(getattr(config, "merge_accept_overlap", 0.10))
        warn_overlap = float(getattr(config, "merge_warn_overlap", 0.25))
        min_gap = float(getattr(config, "merge_min_gap", 0.04))
        max_shift = float(getattr(config, "merge_max_audio_shift", 0.20))
        # Fallback 1.18 giữ đúng trần "tăng tốc NHẸ" của thiết kế resolver khi
        # thiếu config; app thật đọc merge_voice_speed_max (mặc định 1.20) từ Cài đặt.
        mild_speed_max = max(1.0, min(1.50, float(
            getattr(config, "merge_voice_speed_max", 1.18)
        )))
        ordered = sorted(
            (s for s in segments
             if voice_files.get(s.line) and Path(voice_files[s.line]).exists()),
            key=lambda s: s.start,
        )
        if not ordered:
            raise ModuleError("Không có dòng nào có voice để lồng tiếng.")

        total_len = max(1, int(round((video_dur + 0.5) * DUB_SR)))
        merged = np.zeros(total_len, dtype=np.float32)
        warnings: list[str] = []
        missing = [s.line for s in segments if s.line not in voice_files]
        if missing:
            preview = ", ".join(map(str, missing[:20]))
            warnings.append(
                f"Thiếu file voice ở {len(missing)} dòng ({preview}); các dòng này không có tiếng."
            )
        items = []

        for i, seg in enumerate(ordered):
            self.check_cancelled()
            wav = voice_files[seg.line]
            audio = self._load_wav_mono(wav)
            dur = len(audio) / DUB_SR
            items.append({
                "seg": seg,
                "wav": wav,
                "audio": audio,
                "dur": dur,
                "start": float(seg.start),
                "speed": 1.0,
            })

        # Voice NGẮN hơn slot: giữ nguyên tốc độ — phần dư là khoảng lặng tự
        # nhiên của track (đã thử giãn chậm, nghe tệ nên bỏ hẳn). Chỉ voice DÀI
        # mới được resolver xử lý: mượn khoảng trống rồi tăng tốc nhẹ.
        self._resolve_voice_overlaps(
            items, video_dur, ffmpeg, tmp_dir, warnings, accept_overlap,
            warn_overlap, min_gap, max_shift, mild_speed_max,
        )

        for item in items:
            seg = item["seg"]
            audio = item["audio"]
            start = int(round(item["start"] * DUB_SR))
            if item["speed"] > 1.01:
                warnings.append(
                    f"Dòng {seg.line}: tăng speed nhẹ {item['speed']:.2f}x "
                    "để giảm overlap."
                )
            if abs(item["start"] - seg.start) > 0.001:
                warnings.append(
                    f"Dòng {seg.line}: dịch audio {item['start'] - seg.start:+.2f}s "
                    "để giảm overlap."
                )

            audio = self._fade_edges(audio)
            merged = self._mix_audio(merged, audio, start, duck_existing=0.72)

        peak = float(np.max(np.abs(merged))) if merged.size else 0.0
        if peak > 1.0:
            # Limiter mềm cục bộ: overlap lớn không kéo nhỏ âm lượng của cả video.
            hot = np.abs(merged) > 0.98
            merged[hot] = np.tanh(merged[hot])
        pcm = (np.clip(merged, -1.0, 1.0) * 32767.0).astype("<i2")
        with wave.open(str(out_wav), "wb") as f:
            f.setnchannels(1)
            f.setsampwidth(2)
            f.setframerate(DUB_SR)
            f.writeframes(pcm.tobytes())
        return warnings

    def _resolve_voice_overlaps(self, items: list[dict], video_dur: float,
                                ffmpeg: FFmpeg, tmp_dir: Path, warnings: list[str],
                                accept_overlap: float, warn_overlap: float,
                                min_gap: float, max_shift: float,
                                mild_speed_max: float) -> None:
        """Giảm overlap theo cụm hội thoại liền kề, không coi overlap nhỏ là lỗi."""
        if len(items) < 2:
            return

        for pass_no in range(4):
            changed = False
            for i in range(len(items) - 1):
                self.check_cancelled()
                left = items[i]
                right = items[i + 1]
                overlap = (left["start"] + left["dur"]) - right["start"]
                if overlap <= accept_overlap:
                    continue

                need = overlap - accept_overlap

                # 1) Tận dụng khoảng trống trước câu đang tràn bằng cách cho nó vào sớm nhẹ.
                prev_end = (
                    items[i - 1]["start"] + items[i - 1]["dur"]
                    if i > 0 else 0.0
                )
                earliest = max(prev_end + min_gap, left["seg"].start - max_shift, 0.0)
                shift_left = min(need, max(0.0, left["start"] - earliest))
                if shift_left > 0.005:
                    left["start"] -= shift_left
                    need -= shift_left
                    changed = True

                # 2) Tận dụng khoảng trống sau câu kế bằng cách cho câu kế vào muộn nhẹ.
                next_start = items[i + 2]["start"] if i + 2 < len(items) else video_dur
                latest = min(
                    right["seg"].start + max_shift,
                    max(right["start"], next_start - right["dur"] - min_gap),
                )
                shift_right = min(need, max(0.0, latest - right["start"]))
                if shift_right > 0.005:
                    right["start"] += shift_right
                    need -= shift_right
                    changed = True

                # 3) Tăng speed nhẹ câu trước để giảm tail dài.
                overlap = (left["start"] + left["dur"]) - right["start"]
                if overlap > accept_overlap:
                    target_dur = max(0.15, right["start"] + accept_overlap - left["start"])
                    speed = min(left["dur"] / target_dur, mild_speed_max)
                    if speed > left["speed"] + 0.015 and speed > 1.02:
                        sped = tmp_dir / f"_smart_fit_{left['seg'].line}_{pass_no}.wav"
                        try:
                            ffmpeg.speed_audio(left["wav"], speed, str(sped))
                            left["audio"] = self._load_wav_mono(str(sped))
                            left["dur"] = len(left["audio"]) / DUB_SR
                            left["speed"] = speed
                            changed = True
                        except FFmpegError as exc:
                            warnings.append(
                                f"Dòng {left['seg'].line}: tăng speed tự động lỗi: {exc}"
                            )
                        finally:
                            sped.unlink(missing_ok=True)

            if not changed:
                break

        # Bảo vệ mép cuối video: đẩy câu cuối vào khoảng trống phía trước trước khi
        # để muxer -shortest cắt mất đuôi. Nếu vẫn không đủ, tăng tốc nhẹ câu cuối.
        last = items[-1]
        overflow = last["start"] + last["dur"] - video_dur
        if overflow > accept_overlap:
            prev_end = (
                items[-2]["start"] + items[-2]["dur"] + min_gap
                if len(items) > 1 else 0.0
            )
            earliest = max(prev_end, last["seg"].start - max_shift, 0.0)
            shift = min(overflow, max(0.0, last["start"] - earliest))
            if shift > 0.005:
                last["start"] -= shift
                overflow -= shift
            if overflow > accept_overlap:
                target_dur = max(0.15, video_dur - last["start"] + accept_overlap)
                speed = min(last["dur"] / target_dur, mild_speed_max)
                if speed > 1.02:
                    sped = tmp_dir / f"_smart_fit_last_{last['seg'].line}.wav"
                    try:
                        ffmpeg.speed_audio(last["wav"], speed, str(sped))
                        last["audio"] = self._load_wav_mono(str(sped))
                        last["dur"] = len(last["audio"]) / DUB_SR
                        last["speed"] = max(last["speed"], speed)
                    except FFmpegError as exc:
                        warnings.append(
                            f"Dòng {last['seg'].line}: bảo vệ đuôi voice lỗi: {exc}"
                        )
                    finally:
                        sped.unlink(missing_ok=True)

        final_overflow = items[-1]["start"] + items[-1]["dur"] - video_dur
        if final_overflow > accept_overlap:
            warnings.append(
                f"Dòng {items[-1]['seg'].line}: voice vượt cuối video "
                f"{final_overflow:.2f}s; cần rút gọn câu để tránh mất đuôi."
            )

        for i in range(len(items) - 1):
            left = items[i]
            right = items[i + 1]
            overlap = (left["start"] + left["dur"]) - right["start"]
            if overlap <= accept_overlap:
                continue
            ms = int(round(overlap * 1000))
            pair = f"dòng {left['seg'].line} -> {right['seg'].line}"
            if overlap <= warn_overlap:
                warnings.append(f"Cảnh báo overlap {pair}: {ms}ms, vẫn trong mức tạm chấp nhận.")
            else:
                warnings.append(
                    f"Lỗi overlap {pair}: {ms}ms sau auto xử lý. "
                    "Cần rút gọn/sửa timing thủ công; bước kéo video chưa bật trong merge giữ video gốc."
                )

    @staticmethod
    def _fade_edges(audio, fade_ms: float = 12.0):
        """Fade ngắn đầu/cuối voice để tránh tiếng cắt khi overlap."""
        import numpy as np  # noqa: PLC0415

        if len(audio) < 2:
            return audio
        fade_len = min(int(DUB_SR * fade_ms / 1000.0), len(audio) // 2)
        if fade_len <= 1:
            return audio
        out = audio.astype(np.float32, copy=True)
        ramp = np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
        out[:fade_len] *= ramp
        out[-fade_len:] *= ramp[::-1]
        return out

    @staticmethod
    def _mix_audio(merged, audio, start: int, duck_existing: float = 1.0):
        """Đặt voice vào timeline bằng mix, không overwrite khi tràn/overlap.

        Khi câu mới chồng lên tail cũ, cộng hai waveform để cả hai âm còn nghe được.
        Peak tổng được normalize cuối track để tránh vỡ tiếng.
        """
        import numpy as np  # noqa: PLC0415

        if start < 0:
            audio = audio[-start:]
            start = 0
        if len(audio) == 0:
            return merged

        end = start + len(audio)
        if end > len(merged):
            merged = np.pad(merged, (0, end - len(merged)))

        target = merged[start:end]
        overlap = (np.abs(target) > 1e-4) & (np.abs(audio) > 1e-4)
        if duck_existing < 0.999 and np.any(overlap):
            target[overlap] *= duck_existing
        target += audio
        merged[start:end] = target
        return merged

    @staticmethod
    def _load_wav_mono(path: str):
        """Đọc wav -> np.float32 mono ở DUB_SR bằng soundfile."""
        import numpy as np  # noqa: PLC0415

        with wave.open(str(path), "rb") as f:
            n_ch = f.getnchannels()
            rate = f.getframerate()
            width = f.getsampwidth()
            frames = f.readframes(f.getnframes())
        dtype = {1: np.int8, 2: np.int16, 4: np.int32}.get(width, np.int16)
        data = np.frombuffer(frames, dtype=dtype).astype(np.float32)
        if width == 1:      # 8-bit PCM là unsigned, giữa ở 128
            data = (data - 128.0) / 128.0
        else:
            data = data / float(1 << (8 * width - 1))
        if n_ch > 1:
            data = data.reshape(-1, n_ch).mean(axis=1)
        if rate != DUB_SR and len(data) > 1:
            # Resample tuyến tính đơn giản (voice OmniVoice vốn đã 24 kHz).
            new_n = int(round(len(data) * DUB_SR / rate))
            data = np.interp(
                np.linspace(0, len(data) - 1, new_n, dtype=np.float32),
                np.arange(len(data), dtype=np.float32), data,
            ).astype(np.float32)
        return data

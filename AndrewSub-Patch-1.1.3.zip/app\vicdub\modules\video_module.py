"""Video Module - cắt video theo dòng phụ đề và đồng bộ với voice.

Mỗi dòng -> một clip 001.mp4, 002.mp4...
Cơ chế đồng bộ khi voice DÀI hơn clip (chia đôi cho video và voice):
- Voice NGẮN hơn clip -> giữ video tốc độ gốc, phần thiếu ĐỆM KHOẢNG LẶNG.
- Voice DÀI hơn clip  -> ưu tiên KÉO VIDEO chậm lại, nhưng không dưới
  speed_min (vd 0.95 = 95%); phần còn thiếu thì TĂNG TỐC VOICE (giữ cao độ),
  tối đa speed_max. Nếu tăng hết cỡ voice vẫn dài thì đành kéo video chậm hơn
  floor và cảnh báo để rút gọn bản dịch.

Output: clip_files {line: mp4_path}, voice_files {line: wav} (đã tăng tốc nếu
cần), speed_warnings [str]
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import Segment


class VideoModule(BaseModule):
    """Cắt và retime clip theo thời lượng voice."""

    name = "Đồng bộ video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        video_path = data.get("video_path") or project.video_path
        segments: list[Segment] = data.get("segments") or project.load_segments()
        voice_files: dict[int, str] = data.get("voice_files") or {}

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video nguồn.")
        if not segments:
            raise ModuleError("Chưa có phụ đề.")
        if not voice_files:
            raise ModuleError("Chưa có voice. Chạy bước 'Sinh giọng nói' trước.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        clips_dir = Path(project.root) / "clips"
        clip_files: dict[int, str] = {}
        out_voice_files: dict[int, str] = dict(voice_files)
        warnings: list[str] = []

        total = len(segments)
        for i, seg in enumerate(segments):
            self.check_cancelled()
            voice_wav = voice_files.get(seg.line)
            if not voice_wav:
                continue

            self.report(
                int(100 * i / total),
                f"Clip {seg.line}/{total}: cắt {seg.start:.1f}s - {seg.end:.1f}s",
            )

            # Giữ âm nền gốc khi người dùng bật trộn nền (bg_volume > 0).
            keep_bg = getattr(config, "bg_volume", 0) > 0
            raw_clip = clips_dir / f"{seg.line:03d}_raw.mp4"
            final_clip = clips_dir / f"{seg.line:03d}.mp4"
            try:
                ffmpeg.cut_clip(video_path, seg.start, seg.end, str(raw_clip),
                                keep_audio=keep_bg)
                clip_dur = ffmpeg.duration(str(raw_clip))
                voice_dur = ffmpeg.duration(voice_wav)
            except FFmpegError as exc:
                raise ModuleError(f"Dòng {seg.line}: {exc}") from exc

            video_speed, voice_speed, _pad = self._plan_sync(
                clip_dur, voice_dur, config.speed_min, config.speed_max,
                seg.line, warnings,
            )

            # 1) Retime video theo video_speed.
            try:
                if abs(video_speed - 1.0) < 0.005:
                    raw_clip.replace(final_clip)  # không cần retime
                else:
                    ffmpeg.retime_clip(str(raw_clip), video_speed,
                                       str(final_clip), with_audio=keep_bg)
                    raw_clip.unlink(missing_ok=True)
            except FFmpegError as exc:
                raise ModuleError(f"Dòng {seg.line} retime lỗi: {exc}") from exc

            # 2) Tăng tốc voice nếu kế hoạch yêu cầu (voice quá dài).
            if voice_speed > 1.005:
                sped_wav = clips_dir / f"{seg.line:03d}_voice.wav"
                try:
                    ffmpeg.speed_audio(voice_wav, voice_speed, str(sped_wav))
                    out_voice_files[seg.line] = str(sped_wav)
                except FFmpegError as exc:
                    raise ModuleError(
                        f"Dòng {seg.line} tăng tốc voice lỗi: {exc}"
                    ) from exc

            clip_files[seg.line] = str(final_clip)

        if not clip_files:
            raise ModuleError("Không tạo được clip nào.")

        for warning in warnings:
            self.logger.warning(warning)
        message = f"Tạo {len(clip_files)} clip"
        if warnings:
            message += f" ({len(warnings)} cảnh báo tốc độ)"
        self.report(100, message)
        return {"clip_files": clip_files, "voice_files": out_voice_files,
                "speed_warnings": warnings}

    @staticmethod
    def _plan_sync(clip_dur: float, voice_dur: float, min_video_speed: float,
                   max_voice_speed: float, line: int,
                   warnings: list[str]) -> tuple[float, float, float]:
        """Lên kế hoạch đồng bộ một dòng.

        Returns:
            (video_speed, voice_speed, silence_pad):
            - voice ngắn hơn clip -> (1.0, 1.0, pad khoảng lặng).
            - voice dài hơn clip  -> kéo video chậm nhưng không dưới
              min_video_speed; phần còn thiếu tăng tốc voice, tối đa
              max_voice_speed. Voice vẫn quá dài -> kéo video chậm hơn floor
              và cảnh báo.
        """
        if voice_dur <= 0 or clip_dur <= 0:
            return 1.0, 1.0, 0.0
        if voice_dur <= clip_dur:
            pad = clip_dur - voice_dur
            return 1.0, 1.0, (pad if pad > 0.05 else 0.0)

        # voice dài hơn clip: ưu tiên kéo video chậm vừa đủ.
        ideal_video_speed = clip_dur / voice_dur  # < 1
        if ideal_video_speed >= min_video_speed:
            return ideal_video_speed, 1.0, 0.0

        # Kéo video xuống floor rồi tăng tốc voice cho phần còn thiếu.
        video_len = clip_dur / min_video_speed
        voice_speed = voice_dur / video_len       # > 1
        if voice_speed <= max_voice_speed:
            return min_video_speed, voice_speed, 0.0

        # Voice vẫn quá dài -> tăng voice tối đa, video đành chậm hơn floor.
        voice_speed = max_voice_speed
        video_len = voice_dur / voice_speed
        video_speed = clip_dur / video_len        # < min_video_speed
        warnings.append(
            f"Dòng {line}: voice quá dài - đã tăng tốc voice {voice_speed:.2f}x "
            f"và kéo video chậm {video_speed:.2f}x (dưới {min_video_speed:.2f}x). "
            "Cân nhắc rút gọn bản dịch dòng này."
        )
        return video_speed, voice_speed, 0.0


class CutModule(BaseModule):
    """Băm video thành clip theo khung giờ sub - chạy ngay sau Tách sub.

    Cắt TOÀN BỘ (ghi đè clip cũ vì ranh giới sub có thể đã đổi) để track
    Video trên Video Studio có sẵn clip xem demo. Bước Đồng bộ video sau
    này sẽ retime lại theo voice.
    """

    name = "Băm video"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        config = data["config"]
        video_path = data.get("video_path") or project.video_path
        segments: list[Segment] = data.get("segments") or project.load_segments()

        if not video_path or not Path(video_path).exists():
            raise ModuleError("Không tìm thấy video nguồn để băm.")
        if not segments:
            raise ModuleError("Chưa có sub để băm theo.")

        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )
        clips_dir = Path(project.root) / "clips"
        keep_bg = getattr(config, "bg_volume", 0) > 0

        clip_files: dict[int, str] = {}
        total = len(segments)
        for i, seg in enumerate(segments):
            self.check_cancelled()
            clip = clips_dir / f"{seg.line:03d}.mp4"
            self.report(
                int(100 * i / total),
                f"Băm clip {seg.line}/{total} "
                f"({seg.start:.1f}s - {seg.end:.1f}s)...",
            )
            try:
                ffmpeg.cut_clip(video_path, seg.start, seg.end, str(clip),
                                keep_audio=keep_bg)
            except FFmpegError as exc:
                raise ModuleError(f"Dòng {seg.line}: {exc}") from exc
            clip_files[seg.line] = str(clip)

        self.report(100, f"Băm xong {len(clip_files)} clip - xem ở Video Studio")
        return {"clip_files": clip_files}

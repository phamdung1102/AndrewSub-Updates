"""Tiện ích FFmpeg: probe, cắt clip, đổi tốc độ, ghép, mux phụ đề, OCR frames.

Mọi thao tác video/audio đi qua đây - module không tự gọi subprocess.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

logger = logging.getLogger(__name__)

# Ẩn cửa sổ console trên Windows khi gọi subprocess từ app GUI.
_CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


class FFmpegError(Exception):
    """Lỗi khi chạy FFmpeg/ffprobe."""


class FFmpeg:
    """Bao bọc FFmpeg với đường dẫn cấu hình được."""

    def __init__(self, ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe",
                 cancel_event: threading.Event | None = None,
                 timeout_seconds: int | float | None = None) -> None:
        self.ffmpeg = self._resolve_tool(ffmpeg_path or "ffmpeg", "ffmpeg")
        self.ffprobe = self._resolve_tool(ffprobe_path or "ffprobe", "ffprobe")
        self.cancel_event = cancel_event
        self.timeout_seconds = timeout_seconds

    @staticmethod
    def _resolve_tool(configured: str, tool_name: str) -> str:
        """Resolve ffmpeg/ffprobe from config, PATH, or bundled app folders."""
        configured = str(configured or "").strip()
        exe_name = f"{tool_name}.exe" if sys.platform == "win32" else tool_name
        if configured:
            path = Path(configured)
            if path.is_file():
                return str(path)
            if path.is_dir():
                for rel in (Path(exe_name), Path("bin") / exe_name, Path("ffmpeg") / exe_name, Path("ffmpeg") / "bin" / exe_name):
                    candidate = path / rel
                    if candidate.exists():
                        return str(candidate)
            found = shutil.which(configured)
            if found:
                return found

        roots: list[Path] = [
            Path.cwd(),
            Path(sys.executable).resolve().parent,
            Path(sys.executable).resolve().parent / "_internal",
            Path(__file__).resolve().parents[2],
            Path(__file__).resolve().parents[2] / "_internal",
        ]
        if getattr(sys, "_MEIPASS", None):
            roots.append(Path(sys._MEIPASS))  # type: ignore[attr-defined]

        rels = (
            Path("ffmpeg") / exe_name,
            Path("ffmpeg") / "bin" / exe_name,
            Path(exe_name),
        )
        seen: set[Path] = set()
        for root in roots:
            for rel in rels:
                candidate = (root / rel).resolve()
                if candidate in seen:
                    continue
                seen.add(candidate)
                if candidate.exists():
                    logger.info("Dùng %s kèm app: %s", tool_name, candidate)
                    return str(candidate)
        return configured or tool_name

    # ---------- Kiểm tra ----------

    def available(self) -> bool:
        """FFmpeg có gọi được không."""
        return shutil.which(self.ffmpeg) is not None or Path(self.ffmpeg).exists()

    def version(self) -> str:
        out = self._run([self.ffmpeg, "-version"], capture=True)
        return out.split("\n", 1)[0] if out else ""

    # ---------- Probe ----------

    def probe(self, media_path: str) -> dict:
        """Trả về thông tin media (format + streams) dạng dict."""
        out = self._run([
            self.ffprobe, "-v", "error", "-print_format", "json",
            "-show_format", "-show_streams", str(media_path),
        ], capture=True)
        try:
            return json.loads(out)
        except json.JSONDecodeError as exc:
            raise FFmpegError(f"ffprobe trả dữ liệu không hợp lệ: {exc}") from exc

    def duration(self, media_path: str) -> float:
        """Thời lượng media (giây)."""
        info = self.probe(media_path)
        try:
            return float(info["format"]["duration"])
        except (KeyError, ValueError) as exc:
            raise FFmpegError(f"Không đọc được thời lượng: {media_path}") from exc

    def video_size(self, media_path: str) -> tuple[int, int]:
        """Kích thước (rộng, cao) của luồng video đầu tiên, tính bằng pixel."""
        info = self.probe(media_path)
        for stream in info.get("streams", []):
            if stream.get("codec_type") == "video":
                try:
                    return int(stream["width"]), int(stream["height"])
                except (KeyError, ValueError):
                    continue
        raise FFmpegError(f"Không đọc được kích thước video: {media_path}")

    def video_fps(self, media_path: str) -> float:
        """FPS hiệu dụng của luồng video đầu tiên; 0 nếu container không khai báo."""
        info = self.probe(media_path)
        for stream in info.get("streams", []):
            if stream.get("codec_type") == "video":
                return self._fps(
                    stream.get("avg_frame_rate") or stream.get("r_frame_rate")
                )
        return 0.0

    def video_summary(self, media_path: str) -> str:
        """Tóm tắt chất lượng video chính: resolution, codec, fps, bitrate."""
        info = self.probe(media_path)
        video = next(
            (s for s in info.get("streams", []) if s.get("codec_type") == "video"),
            None,
        )
        if not video:
            raise FFmpegError(f"Không tìm thấy stream video: {media_path}")
        width = video.get("width", "?")
        height = video.get("height", "?")
        codec = video.get("codec_name", "?")
        pix_fmt = video.get("pix_fmt", "")
        fps = self._fps(video.get("avg_frame_rate") or video.get("r_frame_rate"))
        bit_rate = video.get("bit_rate") or info.get("format", {}).get("bit_rate")
        bitrate = self._format_bitrate(bit_rate)
        bits = [f"{width}x{height}", codec]
        if pix_fmt:
            bits.append(str(pix_fmt))
        if fps:
            bits.append(f"{fps:.2f} fps")
        if bitrate:
            bits.append(bitrate)
        return " | ".join(bits)

    @staticmethod
    def _fps(value: str | None) -> float:
        if not value or value in ("0/0", "N/A"):
            return 0.0
        if "/" in value:
            num, den = value.split("/", 1)
            try:
                den_f = float(den)
                return float(num) / den_f if den_f else 0.0
            except ValueError:
                return 0.0
        try:
            return float(value)
        except ValueError:
            return 0.0

    @staticmethod
    def _format_bitrate(value: object) -> str:
        try:
            bps = float(value)
        except (TypeError, ValueError):
            return ""
        if bps <= 0:
            return ""
        mbps = bps / 1_000_000
        return f"{mbps:.1f} Mbps" if mbps >= 1 else f"{bps / 1000:.0f} kbps"

    # ---------- Thao tác ----------

    def to_wav(self, src: str, out_wav: str, max_seconds: float | None = None) -> None:
        """Chuyển audio bất kỳ (mp3...) sang wav mono 24kHz."""
        cmd = [self.ffmpeg, "-y", "-i", str(src)]
        if max_seconds and max_seconds > 0:
            cmd += ["-t", f"{max_seconds:.3f}"]
        cmd += ["-ar", "24000", "-ac", "1", str(out_wav)]
        self._run(cmd)

    def extract_frame(self, video: str, at_second: float, out_png: str) -> None:
        """Trích 1 khung hình làm ảnh preview."""
        self._run([
            self.ffmpeg, "-y", "-ss", f"{at_second:.3f}", "-i", str(video),
            "-frames:v", "1", "-q:v", "3", str(out_png),
        ])

    def extract_frames_cropped(
        self, video: str, out_dir: str, fps: float = 3.0,
        crop: tuple[int, int, int, int] | None = None,
    ) -> None:
        """Trích hàng loạt khung hình (đã cắt vùng sub) cho OCR.

        Lấy mẫu `fps` khung/giây và, nếu có `crop`, chỉ giữ dải chứa phụ đề để
        OCR nhanh và ít nhiễu. Ảnh đánh số 000001.png, 000002.png... theo đúng
        thứ tự thời gian: khung thứ N (1-based) ứng với mốc (N-1)/fps giây.

        Args:
            crop: (w, h, x, y) tính bằng pixel; None = giữ nguyên cả khung.
        """
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        filters = [f"fps={fps:.6f}"]
        if crop is not None:
            w, h, x, y = crop
            filters.insert(0, f"crop={w}:{h}:{x}:{y}")
        self._run([
            self.ffmpeg, "-y", "-i", str(video),
            "-vf", ",".join(filters),
            # JPEG giảm mạnh dung lượng tạm khi quét phim dài; chất lượng 3 vẫn
            # giữ nét chữ đủ tốt cho dedup và nhận diện.
            "-q:v", "3", str(out / "%06d.jpg"),
        ])

    def cut_clip(self, video: str, start: float, end: float, out_path: str,
                 keep_audio: bool = False) -> None:
        """Cắt đoạn video [start, end] - re-encode để cắt chính xác theo frame.

        Args:
            keep_audio: giữ audio gốc (dùng cho preview khi chưa có voice).
        """
        cmd = [
            self.ffmpeg, "-y", "-ss", f"{start:.3f}", "-to", f"{end:.3f}",
            "-i", str(video),
        ]
        if keep_audio:
            cmd += ["-c:a", "aac", "-b:a", "192k"]
        else:
            cmd += ["-an"]  # bỏ audio gốc, voice AI sẽ thay thế
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                str(out_path)]
        self._run(cmd)

    @staticmethod
    def _atempo_chain(speed: float) -> str:
        """atempo chỉ nhận 0.5-2.0 - nối nhiều tầng khi vượt khoảng."""
        parts: list[str] = []
        remaining = speed
        while remaining < 0.5:
            parts.append("atempo=0.5")
            remaining /= 0.5
        while remaining > 2.0:
            parts.append("atempo=2.0")
            remaining /= 2.0
        parts.append(f"atempo={remaining:.6f}")
        return ",".join(parts)

    def retime_clip(self, clip: str, speed: float, out_path: str,
                    with_audio: bool = False) -> None:
        """Đổi tốc độ video. speed=0.9 nghĩa là chậm hơn 10%.

        setpts = PTS / speed (speed < 1 -> video dài ra / slow motion).
        with_audio=True thì âm nền của clip cũng co giãn theo (atempo).
        """
        if with_audio:
            chain = self._atempo_chain(speed)
            self._run([
                self.ffmpeg, "-y", "-i", str(clip),
                "-filter_complex",
                f"[0:v]setpts=PTS/{speed:.6f}[v];[0:a]{chain}[a]",
                "-map", "[v]", "-map", "[a]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                "-c:a", "aac", "-b:a", "192k",
                str(out_path),
            ])
        else:
            self._run([
                self.ffmpeg, "-y", "-i", str(clip),
                "-filter:v", f"setpts=PTS/{speed:.6f}",
                "-an",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                str(out_path),
            ])

    def speed_audio(self, in_wav: str, speed: float, out_wav: str) -> None:
        """Đổi tốc độ voice mà giữ cao độ (atempo). speed>1 = nhanh/ngắn lại."""
        self._run([
            self.ffmpeg, "-y", "-i", str(in_wav),
            "-filter:a", self._atempo_chain(speed),
            str(out_wav),
        ])

    def mux_voice(self, clip: str, voice_wav: str, out_path: str,
                  voice_volume: float = 1.0) -> None:
        """Ghép voice vào clip (bỏ audio gốc nếu có).

        Voice ngắn hơn video -> tự đệm khoảng lặng (apad) cho đủ; kết thúc
        theo video (-shortest) nên mọi clip đều có audio tròn thời lượng.
        """
        self._run([
            self.ffmpeg, "-y", "-i", str(clip), "-i", str(voice_wav),
            "-map", "0:v:0", "-map", "1:a:0",
            "-af", f"apad,volume={voice_volume:.2f}",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            str(out_path),
        ])

    def mux_voice_mix(self, clip: str, voice_wav: str, out_path: str,
                      bg_volume: float = 0.3,
                      voice_volume: float = 1.0) -> None:
        """Ghép voice TRỘN với âm nền gốc của clip.

        bg_volume/voice_volume: hệ số 0.0-2.0. Clip phải còn audio gốc
        (cắt với keep_audio=True) - không có thì FFmpeg báo lỗi, caller
        nên rơi về mux_voice.
        """
        filter_complex = (
            f"[0:a]volume={bg_volume:.2f}[bg];"
            f"[1:a]apad,volume={voice_volume:.2f}[vc];"
            "[bg][vc]amix=inputs=2:duration=first:normalize=0[a]"
        )
        self._run([
            self.ffmpeg, "-y", "-i", str(clip), "-i", str(voice_wav),
            "-filter_complex", filter_complex,
            "-map", "0:v:0", "-map", "[a]",
            "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            str(out_path),
        ])

    def retime_timeline(
        self, video: str, intervals: list[tuple[float, float, float, float]],
        out_path: str,
    ) -> None:
        """Kéo chậm cục bộ một số vùng và giữ audio nền đồng bộ.

        ``intervals`` chứa ``(start, end, speed, hold)`` theo timeline gốc.
        Vùng ngoài danh sách giữ tốc độ 1.0. ``hold`` giữ khung cuối và đệm
        audio nền bằng im lặng; voice không đi qua hàm này nên không bị cắt.
        Toàn bộ video chỉ được decode/encode một lượt, không tạo hàng nghìn clip.
        """
        info = self.probe(video)
        try:
            total = float(info.get("format", {}).get("duration") or 0.0)
        except (TypeError, ValueError):
            total = 0.0
        if total <= 0:
            raise FFmpegError(f"Không đọc được thời lượng: {video}")
        has_audio = any(
            stream.get("codec_type") == "audio"
            for stream in info.get("streams", [])
        )

        clean: list[tuple[float, float, float, float]] = []
        cursor = 0.0
        for start, end, speed, hold in sorted(intervals, key=lambda item: item[0]):
            start = max(cursor, min(total, float(start)))
            end = max(start, min(total, float(end)))
            speed = max(0.50, min(1.0, float(speed)))
            hold = max(0.0, float(hold))
            if end - start < 0.03 or (speed >= 0.9995 and hold < 0.005):
                continue
            clean.append((start, end, speed, hold))
            cursor = end
        if not clean:
            raise FFmpegError("Không có vùng video hợp lệ để co giãn.")

        pieces: list[tuple[float, float, float, float]] = []
        cursor = 0.0
        for start, end, speed, hold in clean:
            if start > cursor + 0.001:
                pieces.append((cursor, start, 1.0, 0.0))
            pieces.append((start, end, speed, hold))
            cursor = end
        if cursor < total - 0.001:
            pieces.append((cursor, total, 1.0, 0.0))

        graph_parts: list[str] = []
        video_labels: list[str] = []
        audio_labels: list[str] = []
        for index, (start, end, speed, hold) in enumerate(pieces):
            source_dur = end - start
            output_dur = source_dur / speed + hold
            video_filter = (
                f"[0:v]trim=start={start:.6f}:end={end:.6f},"
                f"setpts=(PTS-STARTPTS)/{speed:.8f}"
            )
            if hold > 0.001:
                video_filter += f",tpad=stop_mode=clone:stop_duration={hold:.6f}"
            video_filter += f"[v{index}]"
            graph_parts.append(video_filter)
            video_labels.append(f"[v{index}]")

            if has_audio:
                audio_filter = (
                    f"[0:a]atrim=start={start:.6f}:end={end:.6f},"
                    f"asetpts=PTS-STARTPTS,atempo={speed:.8f}"
                )
                if hold > 0.001:
                    audio_filter += (
                        f",apad=pad_dur={hold:.6f},"
                        f"atrim=duration={output_dur:.6f}"
                    )
                audio_filter += f"[a{index}]"
                graph_parts.append(audio_filter)
                audio_labels.append(f"[a{index}]")

        if has_audio:
            graph_parts.append(
                "".join(
                    label
                    for pair in zip(video_labels, audio_labels)
                    for label in pair
                )
                + f"concat=n={len(pieces)}:v=1:a=1[vout][aout]"
            )
            suffix = [
                "-map", "[vout]", "-map", "[aout]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                "-c:a", "aac", "-b:a", "192k", str(out_path),
            ]
        else:
            graph_parts.append(
                "".join(video_labels)
                + f"concat=n={len(pieces)}:v=1:a=0[vout]"
            )
            suffix = [
                "-map", "[vout]", "-an",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                str(out_path),
            ]
        self._run_filter_script(
            [self.ffmpeg, "-y", "-i", str(video)],
            ";".join(graph_parts),
            suffix,
        )

    def replace_audio(self, video: str, audio_wav: str, out_path: str,
                      bg_volume: float = 0.0, voice_volume: float = 1.0) -> None:
        """Phủ MỘT track audio (đã dựng theo timeline) lên video GỐC.

        Giữ nguyên hình + thời lượng video (copy stream video). bg_volume > 0
        thì trộn thêm tiếng gốc của video dưới voice; = 0 thì thay hẳn audio.
        """
        if bg_volume > 0:
            fc = (
                f"[0:a]volume={bg_volume:.2f}[bg];"
                f"[1:a]volume={voice_volume:.2f}[vc];"
                "[bg][vc]amix=inputs=2:duration=first:normalize=0[a]"
            )
            self._run([
                self.ffmpeg, "-y", "-i", str(video), "-i", str(audio_wav),
                "-filter_complex", fc, "-map", "0:v:0", "-map", "[a]",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                str(out_path),
            ])
        else:
            self._run([
                self.ffmpeg, "-y", "-i", str(video), "-i", str(audio_wav),
                "-map", "0:v:0", "-map", "1:a:0",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                str(out_path),
            ])

    def concat_audio(self, wavs: list[str], out_path: str) -> None:
        """Nối nhiều wav thành một file để nghe thử liên tục."""
        list_file = Path(out_path).with_suffix(".txt")
        list_file.write_text(
            "\n".join(f"file '{Path(w).as_posix()}'" for w in wavs),
            encoding="utf-8",
        )
        try:
            self._run([
                self.ffmpeg, "-y", "-f", "concat", "-safe", "0",
                "-i", str(list_file), "-c:a", "pcm_s16le", str(out_path),
            ])
        finally:
            list_file.unlink(missing_ok=True)

    def _concat_signature(self, media_path: str) -> tuple:
        """Signature du chat de noi nhanh bang -c copy an toan."""
        info = self.probe(media_path)
        video = next(
            (s for s in info.get("streams", []) if s.get("codec_type") == "video"),
            {},
        )
        audio = next(
            (s for s in info.get("streams", []) if s.get("codec_type") == "audio"),
            {},
        )
        return (
            video.get("codec_name", ""),
            int(video.get("width") or 0),
            int(video.get("height") or 0),
            video.get("pix_fmt", ""),
            video.get("avg_frame_rate") or video.get("r_frame_rate") or "",
            audio.get("codec_name", ""),
            audio.get("sample_rate", ""),
            audio.get("channel_layout") or str(audio.get("channels", "")),
        )

    def can_concat_copy(self, clips: list[str]) -> bool:
        """True neu cac clip du giong nhau de noi -c copy."""
        if len(clips) < 2:
            return True
        first = self._concat_signature(clips[0])
        return all(self._concat_signature(clip) == first for clip in clips[1:])

    def _concat_with_codec(self, clips: list[str], out_path: str, copy: bool) -> None:
        """Noi concat demuxer; copy=True la fast concat khong encode lai."""
        list_file = Path(out_path).with_suffix(".txt")
        list_file.write_text(
            "\n".join(f"file '{Path(c).as_posix()}'" for c in clips),
            encoding="utf-8",
        )
        try:
            if copy:
                self._run([
                    self.ffmpeg, "-y", "-f", "concat", "-safe", "0",
                    "-i", str(list_file), "-c", "copy", str(out_path),
                ])
            else:
                self._run([
                    self.ffmpeg, "-y", "-f", "concat", "-safe", "0",
                    "-i", str(list_file),
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                    "-c:a", "aac", "-b:a", "192k",
                    str(out_path),
                ])
        finally:
            list_file.unlink(missing_ok=True)

    def concat(self, clips: list[str], out_path: str) -> None:
        """Noi danh sach clip bang render lai de tuong thich cao."""
        self._concat_with_codec(clips, out_path, copy=False)

    def concat_auto(self, clips: list[str], out_path: str) -> str:
        """Tu chon -c copy neu an toan; loi thi fallback render lai."""
        if self.can_concat_copy(clips):
            try:
                self._concat_with_codec(clips, out_path, copy=True)
                return "copy"
            except FFmpegError:
                Path(out_path).unlink(missing_ok=True)
        self._concat_with_codec(clips, out_path, copy=False)
        return "encode"

    #: Vị trí chữ -> mã Alignment kiểu ASS (numpad): 2=dưới, 5=giữa, 8=trên
    #: (đều canh giữa theo chiều ngang).
    _SUB_ALIGNMENT = {"bottom": 2, "center": 5, "top": 8}

    def burn_subtitle(self, video: str, srt_path: str, out_path: str,
                      position: str = "bottom", font_size: int = 24,
                      background: bool = False,
                      blur_region: tuple[float, float, float, float] | None = None,
                      blur_intervals: list[tuple[float, float]] | None = None,
                      blur_mask_ass: str | None = None) -> None:
        """Hard subtitle: vẽ phụ đề trực tiếp lên khung hình.

        position: 'bottom' | 'center' | 'top' - vị trí dòng chữ trên khung.
        font_size: cỡ chữ (Fontsize kiểu ASS).
        background: True = nền hộp mờ sau chữ (dễ đọc trên nền sáng);
            False = chữ có viền đen, không nền.
        """
        # filter subtitles cần escape ':' và '\' trong đường dẫn Windows.
        srt_escaped = Path(srt_path).as_posix().replace(":", r"\:")
        align = self._SUB_ALIGNMENT.get(position, 2)
        parts = [f"Alignment={align}", f"Fontsize={max(8, int(font_size))}"]
        if align != 5:  # dưới/trên: đẩy chữ vào trong khung một chút.
            parts.append("MarginV=28")
        if background:
            # BorderStyle=3 = hộp nền; BackColour ASS &HAABBGGRR (AA: 00 đục,
            # FF trong). &H80000000 = đen mờ ~50%.
            parts += ["BorderStyle=3", "BackColour=&H80000000&", "Outline=0"]
        else:
            parts += ["BorderStyle=1", "Outline=2", "Shadow=1"]
        style = ",".join(parts)
        subtitle_filter = f"subtitles='{srt_escaped}'"
        if Path(srt_path).suffix.lower() != ".ass":
            subtitle_filter += f":force_style='{style}'"
        if blur_region:
            x0, y0, x1, y1 = self._normalized_region(blur_region)
            crop_w, crop_h = x1 - x0, y1 - y0
            if blur_mask_ass:
                mask_escaped = Path(blur_mask_ass).as_posix().replace(":", r"\:")
                graph = (
                    f"[0:v]split=3[base][blur_src][mask_src];"
                    f"[blur_src]gblur=sigma=18[blurred];"
                    f"[mask_src]drawbox=x=0:y=0:w=iw:h=ih:color=black:t=fill,"
                    f"subtitles='{mask_escaped}',format=gray[mask];"
                    f"[base][blurred][mask]maskedmerge[clean];"
                    f"[clean]{subtitle_filter}[v]"
                )
            else:
                enable = self._timeline_enable(blur_intervals)
                graph = (
                    f"[0:v]split=2[base][roi];"
                    f"[roi]crop=iw*{crop_w:.6f}:ih*{crop_h:.6f}:"
                    f"iw*{x0:.6f}:ih*{y0:.6f},gblur=sigma=18[blur];"
                    f"[base][blur]overlay=main_w*{x0:.6f}:main_h*{y0:.6f}{enable}[clean];"
                    f"[clean]{subtitle_filter}[v]"
                )
            self._run_filter_script([
                self.ffmpeg, "-y", "-i", str(video),
            ], graph, [
                "-map", "[v]", "-map", "0:a?",
                "-c:v", "libx264", "-preset", "medium", "-crf", "16",
                "-c:a", "copy", str(out_path),
            ])
        else:
            self._run([
                self.ffmpeg, "-y", "-i", str(video),
                "-vf", subtitle_filter,
                "-c:v", "libx264", "-preset", "medium", "-crf", "16",
                "-c:a", "copy",
                str(out_path),
            ])

    @staticmethod
    def _normalized_region(region) -> tuple[float, float, float, float]:
        x0, y0, x1, y1 = (float(value) for value in region)
        x0, x1 = sorted((max(0.0, min(1.0, x0)), max(0.0, min(1.0, x1))))
        y0, y1 = sorted((max(0.0, min(1.0, y0)), max(0.0, min(1.0, y1))))
        if x1 - x0 < 0.01 or y1 - y0 < 0.01:
            return 0.05, 0.78, 0.95, 1.0
        return x0, y0, x1, y1

    def blur_video_region(self, video: str, out_path: str,
                          region: tuple[float, float, float, float],
                          intervals: list[tuple[float, float]] | None = None,
                          blur_mask_ass: str | None = None) -> None:
        """Blur a normalized rectangle while preserving the rest of the frame."""
        x0, y0, x1, y1 = self._normalized_region(region)
        crop_w, crop_h = x1 - x0, y1 - y0
        if blur_mask_ass:
            mask_escaped = Path(blur_mask_ass).as_posix().replace(":", r"\:")
            graph = (
                f"[0:v]split=3[base][blur_src][mask_src];"
                f"[blur_src]gblur=sigma=18[blurred];"
                f"[mask_src]drawbox=x=0:y=0:w=iw:h=ih:color=black:t=fill,"
                f"subtitles='{mask_escaped}',format=gray[mask];"
                f"[base][blurred][mask]maskedmerge[v]"
            )
        else:
            enable = self._timeline_enable(intervals)
            graph = (
                f"[0:v]split=2[base][roi];"
                f"[roi]crop=iw*{crop_w:.6f}:ih*{crop_h:.6f}:"
                f"iw*{x0:.6f}:ih*{y0:.6f},gblur=sigma=18[blur];"
                f"[base][blur]overlay=main_w*{x0:.6f}:main_h*{y0:.6f}{enable}[v]"
            )
        self._run_filter_script([
            self.ffmpeg, "-y", "-i", str(video),
        ], graph, [
            "-map", "[v]", "-map", "0:a?", "-c:v", "libx264",
            "-preset", "medium", "-crf", "16", "-c:a", "copy", str(out_path),
        ])

    @staticmethod
    def _timeline_enable(intervals: list[tuple[float, float]] | None) -> str:
        """Build an overlay enable expression, merging touching subtitle spans."""
        if intervals is None:
            return ""
        clean = sorted(
            (max(0.0, float(start)), max(0.0, float(end)))
            for start, end in intervals if float(end) > float(start)
        )
        merged: list[list[float]] = []
        for start, end in clean:
            if merged and start <= merged[-1][1] + 0.04:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        if not merged:
            return ":enable='0'"
        expression = "+".join(
            f"between(t,{start:.3f},{end:.3f})" for start, end in merged
        )
        return f":enable='{expression}'"

    def _run_filter_script(self, prefix: list[str], graph: str,
                           suffix: list[str]) -> None:
        """Run a large filter graph from a file to avoid Windows command limits."""
        script_path = ""
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", suffix=".fffilter", delete=False,
            ) as handle:
                handle.write(graph)
                script_path = handle.name
            self._run(prefix + ["-filter_complex_script", script_path] + suffix)
        finally:
            if script_path:
                Path(script_path).unlink(missing_ok=True)

    def soft_subtitle(self, video: str, srt_path: str, out_path: str) -> None:
        """Soft subtitle: nhúng track phụ đề mov_text, bật/tắt được khi xem."""
        self._run([
            self.ffmpeg, "-y", "-i", str(video), "-i", str(srt_path),
            "-map", "0", "-map", "1:0",
            "-c", "copy", "-c:s", "mov_text",
            "-metadata:s:s:0", "language=vie",
            str(out_path),
        ])

    # ---------- Nội bộ ----------

    def _run(self, cmd: list[str], capture: bool = False) -> str:
        """Chạy lệnh, ném FFmpegError kèm stderr nếu thất bại."""
        logger.debug("FFmpeg: %s", " ".join(cmd))
        try:
            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                encoding="utf-8", errors="replace",
                creationflags=_CREATE_NO_WINDOW,
            )
        except FileNotFoundError as exc:
            raise FFmpegError(
                f"Không tìm thấy '{cmd[0]}'. Cài FFmpeg hoặc khai báo đường dẫn "
                "trong tab Cài đặt."
            ) from exc

        started = time.monotonic()
        stdout = ""
        stderr = ""
        while True:
            if self.cancel_event is not None and self.cancel_event.is_set():
                process.kill()
                stdout, stderr = process.communicate()
                detail = (stderr or stdout or "").strip()
                raise FFmpegError(
                    "Lệnh FFmpeg đã bị hủy theo yêu cầu."
                    + (f"\n{detail}" if detail else "")
                )
            if self.timeout_seconds and time.monotonic() - started > self.timeout_seconds:
                process.kill()
                stdout, stderr = process.communicate()
                detail = (stderr or stdout or "").strip()
                raise FFmpegError(
                    f"Lệnh FFmpeg quá timeout sau {int(self.timeout_seconds)} giây."
                    + (f"\n{detail}" if detail else "")
                )
            try:
                stdout, stderr = process.communicate(timeout=0.1)
                break
            except subprocess.TimeoutExpired:
                continue
        if process.returncode != 0:
            tail = (stderr or "").strip().split("\n")[-5:]
            raise FFmpegError("FFmpeg lỗi:\n" + "\n".join(tail))
        return stdout if capture else ""

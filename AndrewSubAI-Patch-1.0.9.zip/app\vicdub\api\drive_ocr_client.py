"""OCR phụ đề gắn cứng bằng Google Drive (OCR chính thức qua Drive API).

Cùng interface với ``GeminiWebClient.read_subtitle_montage`` nên cắm thẳng vào
``llm_ocr_video`` mà không phải sửa pipeline montage.

Cách hoạt động (tính năng CHÍNH THỨC của Drive API, hợp ToS):
  1. Upload ảnh montage lên Drive, ép ``mimeType`` = Google Docs kèm tham số
     ``ocrLanguage`` -> Drive tự OCR chữ trong ảnh khi convert.
  2. Export nội dung Doc dạng ``text/plain`` -> chuỗi chữ các panel.
  3. Xoá Doc tạm (tránh đầy Drive), rồi tách chữ theo số panel.

Xác thực: OAuth2 (credentials.json tải từ Google Cloud Console + token.json sinh
một lần qua ``authorize``). Chỉ cần scope ``drive.file`` (chỉ đụng tệp app tạo).
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
from pathlib import Path
from typing import Callable

import requests

logger = logging.getLogger(__name__)

TOKEN_URI = "https://oauth2.googleapis.com/token"
AUTH_URI = "https://accounts.google.com/o/oauth2/v2/auth"
UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files"
FILES_URL = "https://www.googleapis.com/drive/v3/files"
ABOUT_URL = "https://www.googleapis.com/drive/v3/about"
# drive.file = chỉ truy cập tệp do chính app tạo -> quyền tối thiểu, an toàn nhất.
SCOPE = "https://www.googleapis.com/auth/drive.file"
DOC_MIME = "application/vnd.google-apps.document"

# Gợi ý ngôn ngữ (tiếng Việt/tự do) -> mã Drive ocrLanguage.
# LƯU Ý: Drive dùng BCP-47 có script cho tiếng Trung ("zh-Hans"/"zh-Hant");
# mã ISO trơn "zh"/"zh-CN" bị Drive từ chối 400 Invalid Value.
# Phồn thể đặt TRƯỚC giản thể để thắng khi người dùng ghi rõ.
_LANG_MAP = {
    "phồn thể": "zh-Hant", "phon the": "zh-Hant", "phồn": "zh-Hant",
    "traditional": "zh-Hant", "zh-hant": "zh-Hant", "hant": "zh-Hant",
    "giản thể": "zh-Hans", "gian the": "zh-Hans", "simplified": "zh-Hans",
    "zh-hans": "zh-Hans", "hans": "zh-Hans",
    "trung": "zh-Hans", "hoa": "zh-Hans", "tàu": "zh-Hans", "tau": "zh-Hans",
    "chinese": "zh-Hans", "zh": "zh-Hans", "ch": "zh-Hans", "cn": "zh-Hans",
    "nhật": "ja", "nhat": "ja", "japan": "ja", "japanese": "ja", "ja": "ja",
    "hàn": "ko", "han": "ko", "korea": "ko", "korean": "ko", "ko": "ko",
    "anh": "en", "english": "en", "en": "en",
    "việt": "vi", "viet": "vi", "vietnam": "vi", "vietnamese": "vi", "vi": "vi",
    "thái": "th", "thai": "th", "th": "th",
    "nga": "ru", "russian": "ru", "ru": "ru",
}


# Chữ viết bắt buộc theo ngôn ngữ nguồn: dòng OCR không chứa ký tự thuộc
# script này = rác (mốc @@@ bị đọc nát, watermark tiếng Anh, số trần) -> loại.
# Latin (en/vi...) không lọc vì bản thân là chữ Latin.
_REQUIRED_SCRIPT = {
    "zh-Hans": r"[一-鿿㐀-䶿]",
    "zh-Hant": r"[一-鿿㐀-䶿]",
    "ja": r"[぀-ヿ一-鿿]",
    "ko": r"[가-힯ᄀ-ᇿ]",
    "th": r"[฀-๿]",
    "ru": r"[Ѐ-ӿ]",
}


def strip_noise_by_script(result: dict, ocr_lang: str) -> dict:
    """Loại dòng thiếu chữ viết của ngôn ngữ nguồn (mốc nát/watermark tiếng Anh).

    Chỉ áp dụng cho ngôn ngữ có bảng chữ riêng (Trung/Nhật/Hàn/Thái/Nga). Với
    ngôn ngữ Latin thì giữ nguyên (không phân biệt được rác kiểu này).
    """
    pattern = _REQUIRED_SCRIPT.get(ocr_lang)
    if not pattern:
        return result
    script_re = re.compile(pattern)
    # Ký hiệu rác đầu dòng (● ○ ■ « ...): mọi thứ KHÔNG phải chữ/số/chữ-viết.
    lead_re = re.compile(r"^[^0-9A-Za-z一-鿿぀-ヿ가-힯]+")
    # Token Latin/ngoặc ngắn CUỐI dòng = mốc @@@ đọc nát dính đuôi (" IN", " (8)").
    tail_re = re.compile(r"\s+[A-Za-z(\[][\w()\[\]]{0,4}\s*$")

    cleaned: dict = {}
    for pid, text in result.items():
        t = lead_re.sub("", (text or "").strip())
        t = tail_re.sub("", t).strip()
        cleaned[pid] = t if script_re.search(t) else ""
    return cleaned


def map_ocr_language(hint: str) -> str:
    """Đổi gợi ý ngôn ngữ tự do sang mã ISO Drive hiểu. Rỗng = để Drive tự đoán."""
    key = (hint or "").strip().lower()
    if not key:
        return ""
    for token, code in _LANG_MAP.items():
        if token in key:
            return code
    # Đã là mã 2 ký tự thì dùng luôn.
    return key[:2] if re.fullmatch(r"[a-z]{2}", key[:2]) else ""


def parse_drive_montage_ocr(text: str, ids: list[int]) -> dict[int, str]:
    """Tách text OCR của montage Drive (mốc ``@@@ N @@@`` chiếm trọn chiều ngang).

    Drive OCR đọc theo cột nên KHÔNG dùng được cột số kiểu Gemini. Ta chèn mốc
    full-width ``@@@ N @@@`` phía trên mỗi panel; OCR đọc xen kẽ mốc và chữ theo
    thứ tự trên xuống. Text của panel N = phần giữa mốc N và mốc kế tiếp.
    """
    result: dict[int, str] = {pid: "" for pid in ids}
    expected = list(ids)
    index_of = {pid: i for i, pid in enumerate(expected)}
    marker_re = re.compile(r"^[^@]*@+\s*([^@]*?)\s*@+\s*(.*)$")

    pos = 0                 # panel kế tiếp theo THỨ TỰ (không lùi)
    current: int | None = None
    for raw in (text or "").replace("\r", "\n").split("\n"):
        line = raw.strip()
        if not line:
            continue
        # Dòng CÓ '@' = một mốc header (chữ Trung không bao giờ chứa '@').
        # Mỗi mốc = một panel theo thứ tự; KHÔNG tin số OCR (hay đọc sai F, :, P1)
        # trừ khi số rõ ràng và khớp id còn lại thì dùng để đồng bộ lại.
        if "@" in line:
            match = marker_re.match(line)
            tail = ""
            digits = ""
            if match:
                digits = "".join(re.findall(r"\d", match.group(1)))
                tail = match.group(2).strip()
            target = pos
            if digits:
                d = int(digits)
                if d in index_of and index_of[d] >= pos:
                    target = index_of[d]      # đồng bộ tiến nếu OCR số sạch
            if target < len(expected):
                current = expected[target]
                pos = target + 1
                if tail:
                    result[current] = tail    # trường hợp mốc và chữ cùng dòng
            else:
                current = None
            continue
        # Dòng không có '@' = chữ phụ đề của panel đang mở.
        if current is not None:
            result[current] = (result[current] + " " + line).strip()

    # Dọn sạn khi OCR làm tuột hết '@' của mốc -> số trần dính vào chữ:
    #  - "1 那蒋门神" -> "那蒋门神" (bỏ số mốc rò rỉ đầu dòng)
    #  - "25" -> "" (cả dòng chỉ còn số/dấu = mốc mất '@', không phải phụ đề)
    for pid, value in result.items():
        value = re.sub(r"^\s*\d{1,4}[\s:.\-]+", "", value.strip())
        if re.fullmatch(r"[\d\s:.\-@]*", value):
            value = ""
        result[pid] = value.strip()
    return result


def drive_montage_markers_complete(text: str, ids: list[int]) -> bool:
    """Chỉ tin montage khi Drive còn đọc đủ số header phân cách panel.

    Nếu mất một header, chữ panel kế tiếp có thể bị nối vào panel trước. Không có
    cách suy ra timestamp an toàn từ chuỗi OCR đó, nên cả batch phải đi cứu hộ.
    """
    marker_lines = [
        line for line in (text or "").replace("\r", "\n").split("\n")
        if "@" in line
    ]
    return len(marker_lines) >= len(ids)


def parse_montage_ocr(text: str, ids: list[int]) -> dict[int, str]:
    """Tách text OCR cả tấm montage thành chữ theo từng panel.

    Montage vẽ số panel (1, 2, 3...) ở cột trái, chữ phụ đề ở giữa, đọc theo
    thứ tự trên xuống. Ta dò các mốc số theo ĐÚNG THỨ TỰ ``ids`` tăng dần: một
    dòng bắt đầu bằng số = id kỳ vọng kế tiếp thì mở panel mới, phần còn lại là
    chữ; các dòng sau dồn vào panel đang mở tới khi gặp id kế tiếp.

    Bền với việc OCR tách/nối dòng khác nhau, và không nhầm số nằm trong câu
    thành mốc panel (vì chỉ nhận số khớp id kế tiếp).
    """
    result: dict[int, str] = {pid: "" for pid in ids}
    expected = list(ids)
    index_of = {pid: i for i, pid in enumerate(expected)}
    pos = 0                    # chỉ nhận id ở vị trí >= pos (giữ thứ tự, không lùi)
    current: int | None = None
    for raw in (text or "").replace("\r", "\n").split("\n"):
        line = raw.strip().strip("`").strip()
        if not line:
            continue
        match = re.match(r"^[\[\(]?(\d{1,7})[\]\):.\-]*\s*(.*)$", line)
        # Mốc panel = số đầu dòng khớp một id CÒN LẠI (>= pos). Cho phép NHẢY qua
        # id mà OCR bỏ sót (id bị thiếu -> panel đó rỗng) thay vì kẹt dồn chữ.
        cand = int(match.group(1)) if match else None
        if cand is not None and cand in index_of and index_of[cand] >= pos:
            current = cand
            pos = index_of[cand] + 1
            result[current] = match.group(2).strip()
        elif current is not None:
            result[current] = (result[current] + " " + line).strip()
    return result


class DriveOcrError(RuntimeError):
    """Lỗi Drive OCR có thông điệp hợp để hiển thị lên UI."""


def classify_drive_error(error: BaseException | str) -> str:
    """Classify a Drive failure for pool failover/cooldown decisions.

    Returns one of: ``permanent_account``, ``rate_limit``, ``network``,
    ``malformed_montage`` or ``other``.
    """
    message = str(error).casefold()
    if any(token in message for token in (
        "invalid_client", "invalid_grant", "token has been expired",
        "token has been revoked", "token revoked", "unauthorized_client",
        "client secret is invalid", "insufficient permission",
    )):
        return "permanent_account"
    if any(token in message for token in (
        "429", "ratelimit", "rate limit", "quota", "userratelimitexceeded",
        "dailylimitexceeded",
    )):
        return "rate_limit"
    if any(token in message for token in (
        "nameresolutionerror", "failed to resolve", "getaddrinfo failed",
        "connectionerror", "connection aborted", "connection reset",
        "connect timeout", "read timed out", "network is unreachable",
        "temporary failure in name resolution",
    )):
        return "network"
    if "rụng mốc montage" in message or "missing montage marker" in message:
        return "malformed_montage"
    if any(token in message for token in (
        "401", "unauthorized", "403", "permission denied",
    )):
        return "permanent_account"
    return "other"


class DriveOcrClient:
    """Đọc montage phụ đề bằng Google Drive OCR. Cùng interface GeminiWebClient."""

    def __init__(
        self,
        credentials_path: str,
        token_path: str,
        folder_id: str = "",
        report: Callable[[int, str], None] | None = None,
        request_timeout: int = 120,
    ) -> None:
        self.credentials_path = str(credentials_path)
        self.token_path = str(token_path)
        self.folder_id = (folder_id or "").strip()
        self.report = report
        self.request_timeout = max(30, int(request_timeout))
        self._session = requests.Session()
        self._access_token = ""
        self._expiry = 0.0
        self._token_lock = threading.Lock()  # refresh token an toàn khi vá song song
        self._client_id, self._client_secret = self._load_client_secret()
        self._refresh_token = self._load_refresh_token()

    # ---------- Xác thực ----------

    def _load_client_secret(self) -> tuple[str, str]:
        try:
            raw = json.loads(Path(self.credentials_path).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise DriveOcrError(
                f"Không đọc được credentials.json Drive OCR: {exc}"
            ) from exc
        block = raw.get("installed") or raw.get("web") or raw
        cid = block.get("client_id", "")
        secret = block.get("client_secret", "")
        if not cid or not secret:
            raise DriveOcrError(
                "credentials.json thiếu client_id/client_secret (OAuth desktop)."
            )
        return cid, secret

    def _load_refresh_token(self) -> str:
        try:
            raw = json.loads(Path(self.token_path).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise DriveOcrError(
                "Chưa kết nối Google Drive OCR (thiếu token). Chạy setup_drive_ocr "
                f"để đăng nhập một lần. Chi tiết: {exc}"
            ) from exc
        token = raw.get("refresh_token", "")
        if not token:
            raise DriveOcrError(
                "token.json thiếu refresh_token. Đăng nhập lại với prompt=consent."
            )
        return token

    def _ensure_token(self) -> str:
        """Trả access_token còn hạn; tự refresh khi sắp hết (đệm 60s)."""
        if self._access_token and time.time() < self._expiry - 60:
            return self._access_token
        with self._token_lock:
            # Kiểm lại trong khóa: luồng khác có thể vừa refresh xong.
            if self._access_token and time.time() < self._expiry - 60:
                return self._access_token
            return self._refresh_access_token()

    def _refresh_access_token(self) -> str:
        try:
            resp = self._session.post(
                TOKEN_URI,
                data={
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "refresh_token": self._refresh_token,
                    "grant_type": "refresh_token",
                },
                timeout=self.request_timeout,
            )
        except requests.RequestException as exc:
            raise DriveOcrError(f"Không refresh được token Drive: {exc}") from exc
        if resp.status_code != 200:
            raise DriveOcrError(
                f"Refresh token Drive bị từ chối ({resp.status_code}): {resp.text[:200]}"
            )
        data = resp.json()
        self._access_token = data.get("access_token", "")
        self._expiry = time.time() + float(data.get("expires_in", 3600))
        if not self._access_token:
            raise DriveOcrError("Không nhận được access_token từ Google.")
        return self._access_token

    def _auth_header(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._ensure_token()}"}

    def account_email(self) -> str:
        """Email Google đang sở hữu token, dùng để nhận biết slot OCR bị lỗi."""
        try:
            response = self._session.get(
                ABOUT_URL,
                params={"fields": "user(emailAddress,displayName)"},
                headers=self._auth_header(),
                timeout=self.request_timeout,
            )
        except requests.RequestException as exc:
            raise DriveOcrError(f"Không đọc được email tài khoản Drive: {exc}") from exc
        if response.status_code == 401:
            self._access_token = ""
            response = self._session.get(
                ABOUT_URL,
                params={"fields": "user(emailAddress,displayName)"},
                headers=self._auth_header(),
                timeout=self.request_timeout,
            )
        if response.status_code != 200:
            raise DriveOcrError(
                f"Không đọc được email tài khoản Drive ({response.status_code}): "
                f"{response.text[:160]}"
            )
        return str((response.json().get("user") or {}).get("emailAddress", "")).strip()

    # ---------- Montage riêng cho Drive OCR ----------

    MONTAGE_WIDTH = 620
    HEADER_H = 60

    @staticmethod
    def _font(size: int):
        from PIL import ImageFont  # noqa: PLC0415
        for name in ("arialbd.ttf", "arial.ttf", "segoeui.ttf"):
            try:
                return ImageFont.truetype(f"C:/Windows/Fonts/{name}", size)
            except OSError:
                continue
        return ImageFont.load_default()

    def build_montage(self, images: list, ids: list[int]) -> bytes:
        """Dựng montage dọc, mỗi panel có DÒNG TIÊU ĐỀ full-width ``@@@ N @@@``.

        Cùng chữ ký với ``llm_ocr_subtitles.build_montage`` để pipeline gọi được;
        khác cách vẽ số (full-width header thay cột trái) cho hợp Drive OCR.
        """
        import io  # noqa: PLC0415
        from PIL import Image, ImageDraw  # noqa: PLC0415

        w = self.MONTAGE_WIDTH
        panels = []
        for img in images:
            src = img.convert("RGB") if hasattr(img, "convert") else Image.fromarray(img).convert("RGB")
            ph = max(1, int(round(src.height * w / max(1, src.width))))
            panels.append(src.resize((w, ph), Image.Resampling.LANCZOS))

        sep = 8
        total = sum(self.HEADER_H + p.height + sep for p in panels) + sep
        montage = Image.new("RGB", (w, total), (255, 255, 255))
        draw = ImageDraw.Draw(montage)
        font = self._font(38)
        y = sep
        for pid, panel in zip(ids, panels):
            draw.rectangle([0, y, w, y + self.HEADER_H], fill=(0, 0, 0))
            draw.text((14, y + 7), f"@@@ {pid:06d} @@@", fill=(255, 255, 255), font=font)
            y += self.HEADER_H
            montage.paste(panel, (0, y))
            y += panel.height + sep

        buf = io.BytesIO()
        montage.save(buf, format="PNG")
        return buf.getvalue()

    # ---------- OCR ----------

    def _upload_montage(self, montage_png: bytes, ocr_lang: str) -> str:
        """Upload ảnh + convert sang Google Docs (kích hoạt OCR). Trả docId."""
        metadata: dict = {"name": "vicdub_montage_ocr", "mimeType": DOC_MIME}
        if self.folder_id:
            metadata["parents"] = [self.folder_id]
        boundary = "vicdub_drive_ocr_boundary"
        body = (
            f"--{boundary}\r\n"
            "Content-Type: application/json; charset=UTF-8\r\n\r\n"
            + json.dumps(metadata)
            + f"\r\n--{boundary}\r\n"
            "Content-Type: image/png\r\n\r\n"
        ).encode("utf-8") + montage_png + f"\r\n--{boundary}--\r\n".encode("utf-8")

        params = {"uploadType": "multipart", "fields": "id"}
        if ocr_lang:
            params["ocrLanguage"] = ocr_lang
        headers = self._auth_header()
        headers["Content-Type"] = f"multipart/related; boundary={boundary}"

        resp = None
        for attempt in range(5):
            resp = self._session.post(
                UPLOAD_URL, params=params, data=body, headers=headers,
                timeout=self.request_timeout,
            )
            if resp.status_code == 401 and attempt == 0:
                self._access_token = ""
                headers = self._auth_header()
                headers["Content-Type"] = f"multipart/related; boundary={boundary}"
                continue
            if resp.status_code in (403, 429) or 500 <= resp.status_code < 600:
                time.sleep(min(30.0, (2 ** attempt) + (attempt * 0.25)))
                continue
            break
        assert resp is not None
        if resp.status_code not in (200, 201):
            raise DriveOcrError(
                f"Upload montage lên Drive lỗi ({resp.status_code}): {resp.text[:200]}"
            )
        doc_id = resp.json().get("id", "")
        if not doc_id:
            raise DriveOcrError("Drive không trả về id tài liệu sau khi upload.")
        return doc_id

    def _export_text(self, doc_id: str) -> str:
        resp = None
        for attempt in range(6):
            resp = self._session.get(
                f"{FILES_URL}/{doc_id}/export",
                params={"mimeType": "text/plain"},
                headers=self._auth_header(),
                timeout=self.request_timeout,
            )
            if resp.status_code == 200:
                break
            if resp.status_code in (403, 404, 429) or 500 <= resp.status_code < 600:
                time.sleep(min(20.0, 1.5 * (2 ** attempt)))
                continue
            break
        assert resp is not None
        if resp.status_code != 200:
            raise DriveOcrError(
                f"Export text từ Drive lỗi ({resp.status_code}): {resp.text[:200]}"
            )
        # Google export text/plain kèm BOM; bỏ đi cho sạch.
        return resp.content.decode("utf-8-sig", errors="replace")

    def _delete(self, doc_id: str) -> None:
        try:
            self._session.delete(
                f"{FILES_URL}/{doc_id}", headers=self._auth_header(),
                timeout=self.request_timeout,
            )
        except requests.RequestException:
            logger.warning("Không xoá được doc tạm Drive %s (bỏ qua).", doc_id)

    def read_subtitle_montage(
        self, montage_png: bytes, ids: list[int], lang_hint: str = ""
    ) -> dict[int, str]:
        """Đọc chữ từng panel trong montage bằng Drive OCR."""
        ocr_lang = map_ocr_language(lang_hint)
        if self.report:
            self.report(5, "Đang gửi dữ liệu nhận diện phụ đề...")
        doc_id = self._upload_montage(montage_png, ocr_lang)
        try:
            text = self._export_text(doc_id)
        finally:
            self._delete(doc_id)
        if not drive_montage_markers_complete(text, ids):
            logger.warning(
                "Drive OCR rụng mốc montage (%d panel); bỏ batch để cứu hộ nhỏ hơn",
                len(ids),
            )
            # This is a malformed response, not proof that every panel is empty.
            # Raise so the pool retries the batch on another account and never
            # caches a lost-marker response as a permanent no-text result.
            raise DriveOcrError(
                f"Drive OCR rụng mốc montage ({len(ids)} panel)."
            )
        parsed = parse_drive_montage_ocr(text, ids)
        # Loại rác không đúng chữ viết nguồn (mốc @@@ đọc nát -> "IN"/"(8)"/"AGRY",
        # watermark tiếng Anh...). Phụ đề thật luôn chứa chữ của ngôn ngữ nguồn.
        return strip_noise_by_script(parsed, ocr_lang)

    def read_single(self, image, lang_hint: str = "") -> str:
        """OCR MỘT ảnh crop phụ đề riêng lẻ (không montage, không mốc).

        Dùng để vá các panel montage bị bỏ sót (nhất là sub NGẮN 1-3 chữ mà OCR
        hay bỏ khi nằm trong ảnh montage lớn). Phóng to ảnh để chữ rõ hơn.
        """
        import io  # noqa: PLC0415
        from PIL import Image  # noqa: PLC0415

        src = image.convert("RGB") if hasattr(image, "convert") else Image.fromarray(image).convert("RGB")
        if src.width < 900:  # phóng to giúp OCR chữ nhỏ/ngắn
            scale = 900 / src.width
            src = src.resize((900, max(1, int(src.height * scale))), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        src.save(buf, format="PNG")

        ocr_lang = map_ocr_language(lang_hint)
        doc_id = self._upload_montage(buf.getvalue(), ocr_lang)
        try:
            text = self._export_text(doc_id)
        finally:
            self._delete(doc_id)
        # Ảnh đơn: chỉ có chữ phụ đề (+ có thể 1 dòng gạch viền). Gộp lại rồi lọc.
        lines = [
            ln.strip() for ln in text.replace("\r", "\n").split("\n")
            if ln.strip() and "___" not in ln
        ]
        return strip_noise_by_script({1: " ".join(lines)}, ocr_lang).get(1, "")

    def close(self) -> None:
        """Đóng session (để tương thích interface client OCR)."""
        try:
            self._session.close()
        except Exception:  # noqa: BLE001
            pass


# ---------- Đăng nhập một lần (OAuth loopback, không cần thư viện Google) ----------

def self_test(
    credentials_path: str,
    token_path: str,
    folder_id: str = "",
    report: Callable[[str], None] | None = None,
) -> tuple[int, int, dict[int, str]]:
    """Gửi 1 montage chữ mẫu lên Drive OCR, trả (số_đúng, tổng, kết_quả).

    Dùng cho nút "Test Drive OCR" ở nhiều nơi mà không lặp code. ``report`` nhận
    thông điệp tiến trình (chuỗi) để UI hiển thị.
    """
    from PIL import Image, ImageDraw, ImageFont  # noqa: PLC0415

    def say(msg: str) -> None:
        if report:
            report(msg)

    def font(size: int):
        for name in ("arialbd.ttf", "arial.ttf"):
            try:
                return ImageFont.truetype(f"C:/Windows/Fonts/{name}", size)
            except OSError:
                continue
        return ImageFont.load_default()

    def make(text: str):
        img = Image.new("RGB", (560, 54), (15, 15, 15))
        ImageDraw.Draw(img).text((20, 12), text, fill=(255, 255, 255), font=font(26))
        return img

    ids = [1, 2, 3]
    samples = ["HELLO WORLD", "GOOD MORNING", "DRIVE OCR OK"]
    say("chuẩn bị ảnh mẫu...")
    # Adapter: client báo (pct, msg) -> ta chỉ lấy msg cho UI.
    client = DriveOcrClient(
        credentials_path, token_path, folder_id=folder_id,
        report=lambda _pct, msg: say(msg),
    )
    try:
        montage = client.build_montage([make(s) for s in samples], ids)
        res = client.read_subtitle_montage(montage, ids, lang_hint="en")
        say("đối chiếu kết quả...")
    finally:
        client.close()
    good = sum(1 for i, s in zip(ids, samples) if res.get(i, "").strip().upper() == s)
    return good, len(ids), res


def authorize(
    credentials_path: str,
    token_path: str,
    port: int = 0,
    open_browser: bool = True,
) -> str:
    """Chạy luồng OAuth loopback một lần, lưu token.json (kèm refresh_token).

    Dùng credentials kiểu 'Desktop app' (installed) từ Google Cloud Console đã
    bật Drive API. Trả về đường dẫn token đã lưu.
    """
    import http.server
    import socketserver
    import urllib.parse
    import webbrowser

    raw = json.loads(Path(credentials_path).read_text(encoding="utf-8"))
    block = raw.get("installed") or raw.get("web") or raw
    client_id = block["client_id"]
    client_secret = block["client_secret"]

    code_holder: dict[str, str] = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            code_holder["code"] = params.get("code", [""])[0]
            code_holder["error"] = params.get("error", [""])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            msg = ("Đăng nhập Drive OCR xong. Đóng tab này và quay lại VICDub."
                   if code_holder.get("code") else "Đăng nhập thất bại.")
            self.wfile.write(f"<h3>{msg}</h3>".encode("utf-8"))

        def log_message(self, *args):  # tắt log server
            pass

    with socketserver.TCPServer(("127.0.0.1", port), Handler) as httpd:
        actual_port = httpd.server_address[1]
        redirect_uri = f"http://127.0.0.1:{actual_port}"
        auth_url = AUTH_URI + "?" + urllib.parse.urlencode({
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": SCOPE,
            "access_type": "offline",
            "prompt": "consent",
        })
        if open_browser:
            webbrowser.open(auth_url)
        else:
            print("Mở link sau để cấp quyền:\n", auth_url)
        httpd.handle_request()  # chờ đúng một redirect

    if code_holder.get("error") or not code_holder.get("code"):
        raise DriveOcrError(
            f"OAuth thất bại: {code_holder.get('error') or 'không nhận được code'}"
        )

    resp = requests.post(TOKEN_URI, data={
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code_holder["code"],
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code",
    }, timeout=120)
    if resp.status_code != 200:
        raise DriveOcrError(
            f"Đổi code lấy token lỗi ({resp.status_code}): {resp.text[:200]}"
        )
    token_data = resp.json()
    if "refresh_token" not in token_data:
        raise DriveOcrError(
            "Không nhận được refresh_token. Gỡ quyền app ở tài khoản Google rồi "
            "đăng nhập lại (cần prompt=consent + access_type=offline)."
        )
    Path(token_path).parent.mkdir(parents=True, exist_ok=True)
    Path(token_path).write_text(
        json.dumps(token_data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return str(token_path)

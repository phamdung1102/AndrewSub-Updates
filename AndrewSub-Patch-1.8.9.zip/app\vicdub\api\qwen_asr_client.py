"""Qwen3-ASR (Alibaba Model Studio) - nhận diện lời thoại thành phụ đề gốc.

Dịch vụ CLOUD nhẹ: KHÔNG cài model vào máy. Chỉ cần FFmpeg (đã có) + API key.

Cơ chế (đúng như đường STT của AIO nhưng bằng key riêng, hợp lệ):
    FFmpeg trích audio 16k mono
    -> VAD bằng ffmpeg silencedetect (bỏ khoảng lặng, không cần model)
    -> chia KHỐI dưới ngưỡng payload (auto-split cho video dài 2h)
    -> gửi base64 tới qwen3-asr-flash-filetrans (async submit/poll)
    -> POOL nhiều key + FAILOVER (key lỗi/limit -> đổi key khác)
    -> word-level timestamp, remap về TIMELINE GỐC
Trả về list[Word] (text kèm dấu câu, start/end giây) cho segmenter/app xử lý tiếp.
"""

from __future__ import annotations

import base64
import json
import re
import subprocess
import threading
import time
import wave
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Callable

import numpy as np

from vicdub.utils.segmenter import Word

SR = 16000
BASE = "https://dashscope-intl.aliyuncs.com"
SUBMIT_URL = BASE + "/api/v1/services/audio/asr/transcription"
TASK_URL = BASE + "/api/v1/tasks/{tid}"
MODEL = "qwen3-asr-flash-filetrans"

Report = Callable[[int, str], None]
Cancelled = Callable[[], bool]


class AsrError(Exception):
    """Lỗi nghiệp vụ ASR - thông điệp hiển thị được."""


@dataclass
class AsrTranscript:
    """ASR result plus hard voice/VAD spans in original video timeline."""

    words: list[Word]
    speech_spans: list[tuple[float, float]]


# ---------------------------------------------------------------- keys
def config_keys(config) -> list[str]:
    """Danh sách key ASR đã bật (giải mã DPAPI) từ pool asr_accounts."""
    fn = getattr(config, "asr_keys_list", None)
    if callable(fn):
        return fn()
    return []


def check_key(key: str, timeout: int = 20) -> tuple[bool, str]:
    """Kiểm tra 1 key sống/die. Trả (ok, thông điệp ngắn)."""
    import requests
    key = (key or "").strip()
    if not key:
        return False, "trống"
    try:
        r = requests.get(BASE + "/compatible-mode/v1/models",
                         headers={"Authorization": f"Bearer {key}"}, timeout=timeout)
        if r.status_code == 200:
            return True, "Sống"
        if r.status_code in (401, 403):
            return False, "Die (key sai/hết hạn)"
        return False, f"? (HTTP {r.status_code})"
    except Exception:  # noqa: BLE001
        return False, "Lỗi mạng"


def _read_corpus(path: str, max_chars: int = 8000) -> str:
    """Read ASR glossary/text hints; invalid or missing files are ignored."""
    p = Path(path)
    if not path or not p.is_file():
        return ""
    terms: list[str] = []
    try:
        for raw in p.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                left, right = line.split("=", 1)
                terms.extend([left.strip(), right.strip()])
            else:
                terms.append(line)
    except OSError:
        return ""
    corpus = "\n".join(dict.fromkeys(t for t in terms if t))
    return corpus[:max_chars]


class _KeyPool:
    """Round-robin + cooldown khi lỗi (failover)."""

    def __init__(self, keys: list[str]) -> None:
        self.keys = keys
        self._i = 0
        self._cooldown: dict[str, float] = {}
        self._lock = threading.Lock()

    def acquire(self) -> str:
        while True:
            with self._lock:
                now = time.time()
                for _ in range(len(self.keys)):
                    k = self.keys[self._i % len(self.keys)]
                    self._i += 1
                    if self._cooldown.get(k, 0) <= now:
                        return k
                wait = (min(self._cooldown.values()) - now) if self._cooldown else 1.0
            time.sleep(min(max(wait, 0.5), 10))

    def penalize(self, key: str, seconds: int = 30) -> None:
        with self._lock:
            self._cooldown[key] = time.time() + seconds


# ---------------------------------------------------------------- ffmpeg
def _run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )


def _extract_wav(ffmpeg: str, video: str, out_wav: str) -> None:
    r = _run([ffmpeg, "-y", "-loglevel", "error", "-i", video,
              "-vn", "-ac", "1", "-ar", str(SR), out_wav])
    if r.returncode != 0 or not Path(out_wav).is_file():
        raise AsrError(f"Không trích được âm thanh từ video:\n{r.stderr[:300]}")


def _read_wav(path: str) -> np.ndarray:
    with wave.open(path, "rb") as w:
        n = w.getnframes()
        raw = w.readframes(n)
    return np.frombuffer(raw, dtype="<i2").astype("float32") / 32768.0


def _silence_intervals(ffmpeg: str, wav: str, noise_db: int, min_sil: float) -> list[tuple[float, float]]:
    """Trả các khoảng IM LẶNG (giây) do ffmpeg silencedetect tìm."""
    r = _run([ffmpeg, "-i", wav, "-af",
              f"silencedetect=noise={noise_db}dB:d={min_sil}", "-f", "null", "-"])
    starts = [float(m) for m in re.findall(r"silence_start:\s*([0-9.]+)", r.stderr)]
    ends = [float(m) for m in re.findall(r"silence_end:\s*([0-9.]+)", r.stderr)]
    return list(zip(starts, ends))  # ends có thể ngắn hơn starts nếu im lặng tới cuối


def _speech_segments(audio: np.ndarray, silences: list[tuple[float, float]],
                     pad: float, min_speech: float) -> list[tuple[int, int]]:
    """Đảo khoảng lặng -> khoảng CÓ TIẾNG (đơn vị mẫu), có pad, bỏ đoạn quá ngắn."""
    total = len(audio) / SR
    segs, cursor = [], 0.0
    for s, e in silences:
        if s > cursor:
            segs.append((cursor, s))
        cursor = max(cursor, e)
    if cursor < total:
        segs.append((cursor, total))
    out = []
    for s, e in segs:
        s = max(0.0, s - pad)
        e = min(total, e + pad)
        if e - s >= min_speech:
            out.append((int(s * SR), int(e * SR)))
    # gộp đoạn chồng nhau sau khi pad
    merged: list[tuple[int, int]] = []
    for s, e in out:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


def _pack_chunks(audio: np.ndarray, segs: list[tuple[int, int]],
                 join_pad_s: float, max_voiced_s: float):
    """Chia segs thành khối <= max_voiced_s giây tiếng. Mỗi khối: (pcm, map)."""
    groups, cur, cur_s = [], [], 0.0
    for s, e in segs:
        seg_s = (e - s) / SR
        if cur and cur_s + seg_s > max_voiced_s:
            groups.append(cur); cur, cur_s = [], 0.0
        cur.append((s, e)); cur_s += seg_s
    if cur:
        groups.append(cur)

    join = np.zeros(int(join_pad_s * SR), dtype="float32")
    packed = []
    for g in groups:
        parts, mapping, pos = [], [], 0
        for i, (s, e) in enumerate(g):
            seg = audio[s:e]
            mapping.append({"c": pos * 1000 // SR, "o": s * 1000 // SR, "d": len(seg) * 1000 // SR})
            parts.append(seg); pos += len(seg)
            if i != len(g) - 1:
                parts.append(join); pos += len(join)
        packed.append((np.concatenate(parts) if parts else np.zeros(0, "float32"), mapping))
    return packed


def _pack_continuous_chunks(
    audio: np.ndarray, chunk_s: float = 120.0, overlap_s: float = 1.5,
) -> list[tuple[np.ndarray, list[dict], tuple[float, float]]]:
    """Chia audio LIÊN TỤC; overlap chỉ làm ngữ cảnh, không nhân đôi kết quả.

    ``keep`` là vùng timeline thuộc quyền sở hữu của chunk. Word ở phần overlap
    ngoài keep bị bỏ sau remap, nhờ vậy không cần dedup mù ở biên.
    """
    total_s = len(audio) / SR
    if total_s <= 0:
        return []
    chunk_s = max(20.0, float(chunk_s))
    overlap_s = max(0.0, min(float(overlap_s), chunk_s * 0.20))
    packed = []
    core_start = 0.0
    while core_start < total_s:
        core_end = min(total_s, core_start + chunk_s)
        audio_start = max(0.0, core_start - overlap_s)
        audio_end = min(total_s, core_end + overlap_s)
        start = int(round(audio_start * SR))
        end = int(round(audio_end * SR))
        pcm = audio[start:end]
        mapping = [{
            "c": 0,
            "o": int(round(audio_start * 1000)),
            "d": int(round((audio_end - audio_start) * 1000)),
        }]
        packed.append((pcm, mapping, (core_start, core_end)))
        core_start = core_end
    return packed


def _keep_owned_words(words: list[Word], keep: tuple[float, float], final: bool) -> list[Word]:
    """Giữ word theo midpoint trong vùng core của chunk, loại bản sao overlap."""
    start, end = keep
    result = []
    for word in words:
        midpoint = (word.start + word.end) / 2.0
        if midpoint >= start and (midpoint < end or (final and midpoint <= end + 0.001)):
            result.append(word)
    return result


def _normalize_retry_pcm(pcm: np.ndarray, max_gain_db: float = 6.0) -> np.ndarray:
    """Nâng thoại nhỏ có giới hạn đỉnh; không hard-clip gây méo như nhân gain cũ."""
    if len(pcm) == 0:
        return pcm
    rms = float(np.sqrt(np.mean(np.square(pcm, dtype="float64"))))
    peak = float(np.max(np.abs(pcm)))
    if rms <= 1e-7 or peak <= 1e-7:
        return pcm.copy()
    requested = 10 ** (max(0.0, float(max_gain_db)) / 20.0)
    target_gain = 0.075 / rms
    peak_gain = 0.96 / peak
    gain = max(1.0, min(requested, target_gain, peak_gain))
    return (pcm * gain).astype("float32", copy=False)


def _write_mp3_b64(ffmpeg: str, pcm: np.ndarray, workdir: str, idx: int, kbps: int) -> str:
    wav = str(Path(workdir) / f"c{idx}.wav")
    mp3 = str(Path(workdir) / f"c{idx}.mp3")
    i16 = np.clip(pcm * 32767.0, -32768, 32767).astype("<i2")
    with wave.open(wav, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(i16.tobytes())
    _run([ffmpeg, "-y", "-loglevel", "error", "-i", wav,
          "-ac", "1", "-ar", str(SR), "-codec:a", "libmp3lame", "-b:a", f"{kbps}k", mp3])
    data = Path(mp3).read_bytes()
    return "data:audio/mpeg;base64," + base64.b64encode(data).decode()


def _rms(audio: np.ndarray, start: int, end: int) -> float:
    segment = audio[max(0, start):min(len(audio), end)]
    if len(segment) == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(segment, dtype="float64"))))


def _peak(audio: np.ndarray, start: int, end: int) -> float:
    segment = audio[max(0, start):min(len(audio), end)]
    if len(segment) == 0:
        return 0.0
    return float(np.max(np.abs(segment)))


def _has_word(words: list[Word], start_s: float, end_s: float) -> bool:
    return any(w.start < end_s and w.end > start_s for w in words)


def _retry_candidates(
    audio: np.ndarray,
    speech_segs: list[tuple[int, int]],
    words: list[Word],
    limit_ratio: float,
    pad_s: float = 0.35,
) -> list[tuple[int, int]]:
    """Pick suspicious audio regions for a small second ASR pass.

    The retry pass must not become a full re-transcription.  Candidates are
    scored, capped by total duration, then sent with mild gain.  Main targets:
    VAD spans with no recognized words and energetic gaps between words.
    """
    if len(audio) == 0 or limit_ratio <= 0:
        return []

    total_limit = max(0.0, len(audio) / SR * min(max(limit_ratio, 0.0), 0.30))
    if total_limit <= 0:
        return []

    global_rms = _rms(audio, 0, len(audio))
    rms_floor = max(0.0025, global_rms * 0.30)
    peak_floor = max(0.012, float(np.percentile(np.abs(audio), 85)) * 0.50)
    candidates: list[tuple[float, int, int]] = []

    def add(start_s: float, end_s: float, score: float) -> None:
        start = max(0, int((start_s - pad_s) * SR))
        end = min(len(audio), int((end_s + pad_s) * SR))
        dur = (end - start) / SR
        if dur < 0.25 or dur > 8.0:
            return
        region_rms = _rms(audio, start, end)
        region_peak = _peak(audio, start, end)
        if region_rms < rms_floor and region_peak < peak_floor:
            return
        candidates.append((score + region_rms * 20.0 + region_peak * 2.0, start, end))

    sorted_words = sorted(words, key=lambda w: w.start)

    # 1) Voice/VAD spans that produced no words: highest-value retry.
    for s, e in speech_segs:
        start_s, end_s = s / SR, e / SR
        if not _has_word(sorted_words, start_s, end_s):
            add(start_s, end_s, 6.0)

    # 2) Energetic gaps between recognized words: possible quiet/fast missed cue.
    # Hạ từ 0.55 xuống 0.25s để không bỏ câu chen rất nhanh.
    for left, right in zip(sorted_words, sorted_words[1:]):
        gap_start = max(left.end, 0.0)
        gap_end = max(right.start, gap_start)
        gap = gap_end - gap_start
        if 0.25 <= gap <= 6.0:
            add(gap_start, gap_end, 3.0 if gap <= 2.5 else 2.0)

    # 3) Beginning/end tails. Không giới hạn 3 giây: chia cửa sổ dài thành
    # đoạn nhỏ để câu đầu/cuối bị bỏ vẫn có cơ hội đi pass phụ.
    def add_windows(start_s: float, end_s: float, score: float) -> None:
        cursor = start_s
        while end_s - cursor >= 0.25:
            stop = min(end_s, cursor + 6.0)
            add(cursor, stop, score)
            cursor = stop

    if sorted_words:
        if sorted_words[0].start >= 0.25:
            add_windows(0.0, sorted_words[0].start, 1.5)
        total_s = len(audio) / SR
        if total_s - sorted_words[-1].end >= 0.25:
            add_windows(sorted_words[-1].end, total_s, 1.5)

    if not candidates:
        return []

    # Merge overlaps first so nearby suspicious windows are retried once.
    candidates.sort(key=lambda item: item[1])
    merged: list[tuple[float, int, int]] = []
    for score, start, end in candidates:
        # Chỉ gộp ứng viên cùng mức tin cậy. Một cửa sổ tail rộng, điểm thấp
        # không được kéo đầu vùng VAD điểm cao về 0 rồi làm crop sai vị trí.
        if merged and start <= merged[-1][2] and abs(score - merged[-1][0]) <= 0.75:
            old_score, old_start, old_end = merged[-1]
            merged[-1] = (max(old_score, score), old_start, max(old_end, end))
        else:
            merged.append((score, start, end))

    selected: list[tuple[float, int, int]] = []
    used_s = 0.0
    for score, start, end in sorted(merged, key=lambda item: item[0], reverse=True):
        dur = (end - start) / SR
        if used_s + dur > total_limit:
            remaining = total_limit - used_s
            if remaining < 0.25:
                continue
            end = min(end, start + int(remaining * SR))
            dur = (end - start) / SR
        selected.append((score, start, end))
        used_s += dur
        if used_s >= total_limit:
            break

    return [(start, end) for _, start, end in sorted(selected, key=lambda item: item[1])]


def _merge_retry_words(base: list[Word], retry: list[Word]) -> list[Word]:
    """Merge the low-volume retry pass without deleting a different short word."""
    def norm(text: str) -> str:
        return re.sub(r"[^\w\u3400-\u9fff]+", "", text or "").casefold()

    merged = sorted(base, key=lambda w: w.start)
    for word in sorted(retry, key=lambda w: w.start):
        dur = max(0.05, word.end - word.start)
        word_mid = (word.start + word.end) / 2.0
        word_text = norm(word.text)
        duplicate = False
        for old in merged:
            old_dur = max(0.05, old.end - old.start)
            overlap = max(0.0, min(old.end, word.end) - max(old.start, word.start))
            old_mid = (old.start + old.end) / 2.0
            old_text = norm(old.text)
            same_text = bool(word_text and old_text and (
                word_text == old_text
                or SequenceMatcher(None, word_text, old_text).ratio() >= 0.92
            ))
            # Same recognition near the same time is a duplicate. Different text
            # is retained unless both timestamps are effectively identical.
            if same_text and (overlap / min(dur, old_dur) >= 0.30 or abs(old_mid - word_mid) <= 0.40):
                duplicate = True
                break
            if overlap / min(dur, old_dur) >= 0.90 and abs(old_mid - word_mid) <= 0.15:
                duplicate = True
                break
        if not duplicate:
            merged.append(word)
            merged.sort(key=lambda w: w.start)
    return merged


# ---------------------------------------------------------------- API
def _submit(key: str, audio_ref: str, lang: str, corpus: str) -> str:
    import requests
    params = {"enable_words": True}
    if lang:
        params["language_hints"] = [lang]
    if corpus:
        params["corpus"] = {"text": corpus}
    body = {"model": MODEL, "input": {"file_url": audio_ref}, "parameters": params}
    r = requests.post(SUBMIT_URL, timeout=120,
                      headers={"Authorization": f"Bearer {key}",
                               "Content-Type": "application/json",
                               "X-DashScope-Async": "enable"},
                      data=json.dumps(body))
    if r.status_code != 200:
        raise AsrError(f"submit {r.status_code}: {r.text[:200]}")
    tid = r.json().get("output", {}).get("task_id")
    if not tid:
        raise AsrError(f"thiếu task_id: {r.text[:200]}")
    return tid


def _poll(key: str, tid: str, is_cancelled: Cancelled) -> dict:
    import requests
    deadline = time.time() + 3600
    while time.time() < deadline:
        if is_cancelled():
            raise AsrError("Đã hủy.")
        r = requests.get(TASK_URL.format(tid=tid), timeout=60,
                         headers={"Authorization": f"Bearer {key}"})
        out = r.json().get("output", {})
        st = out.get("task_status")
        if st == "SUCCEEDED":
            return out
        if st in ("FAILED", "CANCELED"):
            raise AsrError(f"task {st}: {json.dumps(out, ensure_ascii=False)[:200]}")
        time.sleep(3)
    raise AsrError("Hết thời gian chờ nhận diện.")


def _transcription_urls(out: dict) -> list[str]:
    urls: list[str] = []

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                urls.append(v) if k == "transcription_url" and isinstance(v, str) else walk(v)
        elif isinstance(o, list):
            for it in o:
                walk(it)
    walk(out)
    return urls


def _remap_words(
    data: dict,
    mapping: list[dict],
    min_duration_ms: int = 40,
) -> list[Word]:
    """transcript (thời gian theo file KHỐI) -> Word timeline GỐC (giây), clamp trong đoạn."""
    starts = [m["c"] for m in mapping]
    import bisect
    words: list[Word] = []
    for tr in data.get("transcripts", []):
        for sen in tr.get("sentences", []):
            for w in sen.get("words") or []:
                tok = (w.get("text") or "").strip()
                if not tok:
                    continue
                punct = w.get("punctuation") or ""
                b_ms, e_ms = w["begin_time"], w["end_time"]
                i = max(0, bisect.bisect_right(starts, b_ms) - 1)
                m = mapping[i]
                map_start = m["o"]
                map_end = m["o"] + m["d"]
                ob = map_start + min(max(b_ms - m["c"], 0), m["d"])
                oe = map_start + min(max(e_ms - m["c"], 0), m["d"])
                # Some responses contain begin_time == end_time. Keep the word
                # inside its source mapping but never emit a zero-length word.
                wanted = max(1, int(min_duration_ms))
                if oe - ob < wanted:
                    oe = min(map_end, ob + wanted)
                    if oe - ob < wanted:
                        ob = max(map_start, oe - wanted)
                words.append(Word(text=tok + punct, start=ob / 1000.0, end=oe / 1000.0))
    words.sort(key=lambda w: w.start)
    return words


def transcribe_video_with_spans(
    video_path: str, config, report: Report, is_cancelled: Cancelled
) -> AsrTranscript:
    """Nhận diện lời thoại -> list[Word] (timeline gốc). Ném AsrError nếu lỗi."""
    keys = config_keys(config)
    if not keys:
        raise AsrError("Chưa cấu hình dịch vụ nhận diện lời thoại (API key).")
    ffmpeg = getattr(config, "ffmpeg_path", "ffmpeg") or "ffmpeg"
    lang = str(getattr(config, "asr_lang", "") or "").strip()
    gloss_path = str(getattr(config, "asr_glossary", "") or "").strip()
    corpus = _read_corpus(gloss_path)
    kbps = int(getattr(config, "asr_mp3_kbps", 32))
    max_payload = float(getattr(config, "asr_max_payload_mb", 8.0))
    noise_db = int(getattr(config, "asr_silence_db", -30))
    min_sil = float(getattr(config, "asr_min_silence", 0.5))
    chunk_seconds = float(getattr(config, "asr_chunk_seconds", 120.0))
    chunk_overlap = float(getattr(config, "asr_chunk_overlap", 1.5))
    min_word_ms = max(1, int(float(getattr(config, "asr_min_word_duration", 0.04)) * 1000))
    pool = _KeyPool(keys)

    with TemporaryDirectory(prefix="vicdub_asr_") as work:
        report(4, "Đang trích âm thanh...")
        wav = str(Path(work) / "audio.wav")
        _extract_wav(ffmpeg, video_path, wav)
        audio = _read_wav(wav)
        total_s = len(audio) / SR

        report(8, "Đang dò khoảng lời thoại...")
        silences = _silence_intervals(ffmpeg, wav, noise_db, min_sil)
        segs = _speech_segments(audio, silences, pad=0.3, min_speech=0.2)
        if not segs:
            # VAD có thể sai với thoại rất nhỏ. Không được dùng kết quả này để
            # chặn pass chính; giữ toàn bộ timeline làm vùng tham chiếu.
            segs = [(0, len(audio))]
        voiced_s = sum(e - s for s, e in segs) / SR
        max_voiced_s = max_payload * 1024 * 1024 / (kbps * 1000 / 8 * 1.34)
        # Pass chính KHÔNG xóa vùng VAD nữa. Audio liên tục giữ nguyên lời nhỏ,
        # khoảng nghỉ và ngữ cảnh; overlap chỉ cấp ngữ cảnh ở biên chunk.
        safe_chunk_s = min(max_voiced_s, max(20.0, chunk_seconds))
        chunks = _pack_continuous_chunks(audio, safe_chunk_s, chunk_overlap)
        report(
            12,
            f"{total_s/60:.0f} phút audio liên tục, {len(chunks)} khối "
            f"(VAD tham chiếu {voiced_s/60:.0f} phút)",
        )

        all_words: list[Word] = []
        n = len(chunks)
        for idx, (pcm, mapping, keep) in enumerate(chunks):
            if is_cancelled():
                raise AsrError("Đã hủy.")
            audio_ref = _write_mp3_b64(ffmpeg, pcm, work, idx, kbps)
            data = _transcribe_chunk_failover(pool, audio_ref, lang, corpus, is_cancelled)
            remapped = _remap_words(data, mapping, min_word_ms)
            all_words.extend(_keep_owned_words(remapped, keep, idx == n - 1))
            report(12 + int(83 * (idx + 1) / n), f"Nhận diện khối {idx + 1}/{n}")

        all_words.sort(key=lambda w: w.start)
        retry_enabled = bool(getattr(config, "asr_retry_enabled", True))
        retry_ratio = float(getattr(config, "asr_retry_ratio", 0.15))
        if retry_enabled and retry_ratio > 0:
            retry_segs = _retry_candidates(audio, segs, all_words, retry_ratio)
            if retry_segs:
                retry_s = sum(e - s for s, e in retry_segs) / SR
                report(96, f"ASR pass phu: {retry_s/60:.1f} phut nghi ngo")
                retry_chunks = _pack_chunks(audio, retry_segs, join_pad_s=0.3, max_voiced_s=max_voiced_s)
                retry_words: list[Word] = []
                for ridx, (pcm, mapping) in enumerate(retry_chunks):
                    if is_cancelled():
                        raise AsrError("Đã hủy.")
                    boosted = _normalize_retry_pcm(
                        pcm, float(getattr(config, "asr_retry_gain_db", 6.0))
                    )
                    audio_ref = _write_mp3_b64(ffmpeg, boosted, work, 10000 + ridx, kbps)
                    data = _transcribe_chunk_failover(pool, audio_ref, lang, corpus, is_cancelled)
                    retry_words.extend(_remap_words(data, mapping, min_word_ms))
                    report(
                        96 + int(3 * (ridx + 1) / max(1, len(retry_chunks))),
                        f"ASR pass phu {ridx + 1}/{len(retry_chunks)}",
                    )
                before = len(all_words)
                all_words = _merge_retry_words(all_words, retry_words)
                added = len(all_words) - before
                if added:
                    report(99, f"ASR pass phu them {added} word")
        # VAD không còn là biên cắt cứng. Segmenter dùng word gap/punctuation;
        # VAD chỉ phục vụ chấm vùng nghi ngờ ở pass phụ.
        return AsrTranscript(words=all_words, speech_spans=[])


def transcribe_video(video_path: str, config, report: Report, is_cancelled: Cancelled) -> list[Word]:
    """Compatibility wrapper: return words only."""
    return transcribe_video_with_spans(video_path, config, report, is_cancelled).words


def _transcribe_chunk_failover(pool: _KeyPool, audio_ref: str, lang: str, corpus: str,
                               is_cancelled: Cancelled) -> dict:
    """Trả transcript JSON (thời gian theo khối). Đổi key khi lỗi."""
    last = None
    for _ in range(max(len(pool.keys) * 2, 4)):
        if is_cancelled():
            raise AsrError("Đã hủy.")
        key = pool.acquire()
        try:
            tid = _submit(key, audio_ref, lang, corpus)
            out = _poll(key, tid, is_cancelled)
            urls = _transcription_urls(out)
            if not urls:
                raise AsrError("thiếu transcription_url")
            import requests
            return requests.get(urls[0], timeout=180).json()
        except AsrError as exc:
            if "Đã hủy" in str(exc):
                raise
            last = exc
            pool.penalize(key, 30)
    raise AsrError(f"Khối lỗi sau nhiều lần thử: {last}")

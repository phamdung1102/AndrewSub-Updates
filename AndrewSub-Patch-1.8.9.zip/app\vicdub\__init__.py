﻿"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.8.9"
APP_NAME = "AndrewSub"


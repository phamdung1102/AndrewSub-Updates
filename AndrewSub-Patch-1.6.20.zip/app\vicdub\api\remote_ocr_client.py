"""Client cho máy chủ OCR dùng chung.

Contract ``read_images`` giống VisionOcrClient để cắm thẳng vào detector hiện có.
Kết quả luôn được ráp theo candidate_id, không phụ thuộc thứ tự worker hoàn thành.
"""

from __future__ import annotations

import base64
import hashlib
import io
import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable

import requests
from PIL import Image

from vicdub.utils.secret_store import unprotect_secret


class RemoteOcrError(RuntimeError):
    pass


def default_client_id() -> str:
    return socket.gethostname().strip() or "andrewsub-client"


class RemoteOcrClient:
    def __init__(self, config):
        self.base_url = str(getattr(config, "remote_ocr_url", "") or "").strip().rstrip("/")
        self.api_key = unprotect_secret(
            str(getattr(config, "remote_ocr_api_key", "") or "")
        ).strip()
        self.client_id = str(
            getattr(config, "remote_ocr_client_id", "") or default_client_id()
        ).strip()
        self.timeout = max(15, int(getattr(config, "remote_ocr_timeout", 180) or 180))
        # Google Docs OCR behind the shared server can miss montage markers when
        # a batch contains many very short subtitle panels.  Keep the remote
        # batch smaller than the local Drive path so panel text cannot silently
        # bleed into the neighbouring subtitle.
        self.max_reliable_batch = 10
        self.batch_size = max(1, min(self.max_reliable_batch, int(getattr(config, "remote_ocr_batch", 10) or 10)))
        self.parallel = max(1, min(12, int(getattr(config, "remote_ocr_parallel", 5) or 5)))
        self._session = requests.Session()
        if not self.base_url:
            raise RemoteOcrError("Chưa nhập địa chỉ máy chủ nhận diện.")
        if not self.api_key:
            raise RemoteOcrError("Chưa nhập khóa truy cập máy chủ nhận diện.")

    @property
    def headers(self) -> dict[str, str]:
        return {"X-API-Key": self.api_key, "X-Client-ID": self.client_id}

    def close(self) -> None:
        self._session.close()

    def _json(self, response: requests.Response) -> dict:
        try:
            payload = response.json()
        except ValueError as exc:
            raise RemoteOcrError(
                f"Máy chủ trả dữ liệu không hợp lệ (HTTP {response.status_code})."
            ) from exc
        if response.status_code == 401:
            raise RemoteOcrError("Khóa truy cập máy chủ nhận diện không đúng.")
        if response.status_code == 403:
            raise RemoteOcrError("Máy này đang bị tắt hoặc không được phép dùng máy chủ nhận diện.")
        if not response.ok or not payload.get("ok", False):
            detail = payload.get("detail") or payload.get("error") or response.reason
            raise RemoteOcrError(f"Máy chủ nhận diện lỗi: {detail}")
        return payload

    def check_connection(self) -> dict:
        try:
            health = self._session.get(f"{self.base_url}/health", timeout=15)
            if not health.ok:
                raise RemoteOcrError(f"Không kết nối được máy chủ (HTTP {health.status_code}).")
            heartbeat = self._session.post(
                f"{self.base_url}/v1/heartbeat", headers=self.headers, json={}, timeout=15,
            )
        except requests.RequestException as exc:
            raise RemoteOcrError(f"Không kết nối được máy chủ nhận diện: {exc}") from exc
        payload = self._json(heartbeat)
        try:
            payload["health"] = health.json()
        except ValueError:
            payload["health"] = {}
        return payload

    @staticmethod
    def _encode(image) -> str:
        if isinstance(image, Image.Image):
            converted = image.convert("RGB")
        else:
            converted = Image.fromarray(image).convert("RGB")
        out = io.BytesIO()
        converted.save(out, format="JPEG", quality=94, optimize=True)
        return base64.b64encode(out.getvalue()).decode("ascii")

    def build_montage(self, images: list, ids: list[int]):
        """Adapter cho pipeline streaming: server nhận ảnh rời, không cần montage."""
        return list(images), list(ids)

    def read_subtitle_montage(
        self, payload, ids: list[int], lang_hint: str = ""
    ) -> dict[int, str]:
        images, stored_ids = payload
        actual_ids = list(stored_ids or ids)
        candidates = [
            {"candidate_id": str(candidate_id), "image_base64": self._encode(image)}
            for candidate_id, image in zip(actual_ids, images)
        ]
        digest = hashlib.sha256()
        digest.update(self.client_id.encode("utf-8"))
        for candidate in candidates:
            digest.update(candidate["candidate_id"].encode("ascii"))
            digest.update(candidate["image_base64"].encode("ascii"))
        body = {
            "idempotency_key": digest.hexdigest(),
            "ocr_language": (lang_hint or "zh-Hans").strip(),
            "candidates": candidates,
        }
        try:
            response = self._session.post(
                f"{self.base_url}/v1/ocr/batches",
                headers=self.headers,
                json=body,
                timeout=(12, self.timeout),
            )
        except requests.RequestException as exc:
            raise RemoteOcrError(f"Mất kết nối khi gửi ảnh nhận diện: {exc}") from exc
        results = self._json(response).get("results", [])
        parsed: dict[int, str] = {}
        for result in results:
            try:
                candidate_id = int(result.get("candidate_id", ""))
            except (TypeError, ValueError):
                continue
            parsed[candidate_id] = str(result.get("text", "") or "").strip()
        return parsed

    def read_images(
        self,
        images: list,
        lang_hint: str = "",
        report: Callable[[int, str], None] | None = None,
        is_cancelled: Callable[[], bool] | None = None,
    ) -> tuple[list[str], list[int]]:
        texts = [""] * len(images)
        if not images:
            return texts, []
        starts = list(range(0, len(images), self.batch_size))
        total_batches = len(starts)

        def send(start: int) -> list[dict]:
            indexes = list(range(start, min(start + self.batch_size, len(images))))
            candidates = [
                {"candidate_id": str(index), "image_base64": self._encode(images[index])}
                for index in indexes
            ]
            digest = hashlib.sha256()
            digest.update(self.client_id.encode("utf-8"))
            for candidate in candidates:
                digest.update(candidate["candidate_id"].encode("ascii"))
                digest.update(candidate["image_base64"].encode("ascii"))
            body = {
                "idempotency_key": digest.hexdigest(),
                "ocr_language": (lang_hint or "zh-Hans").strip(),
                "candidates": candidates,
            }
            try:
                # read_images có thể chạy nhiều worker. requests.Session không
                # cam kết thread-safe, nên đường song song dùng request độc lập.
                response = requests.post(
                    f"{self.base_url}/v1/ocr/batches",
                    headers=self.headers,
                    json=body,
                    timeout=(12, self.timeout),
                )
            except requests.RequestException as exc:
                raise RemoteOcrError(f"Mất kết nối khi gửi ảnh nhận diện: {exc}") from exc
            return list(self._json(response).get("results", []))

        done = 0
        lock = threading.Lock()
        with ThreadPoolExecutor(max_workers=min(self.parallel, total_batches)) as pool:
            futures = {
                pool.submit(send, start): start
                for start in starts
                if not (is_cancelled and is_cancelled())
            }
            for future in as_completed(futures):
                if is_cancelled and is_cancelled():
                    for pending in futures:
                        pending.cancel()
                    break
                results = future.result()
                for result in results:
                    try:
                        index = int(result.get("candidate_id", ""))
                    except (TypeError, ValueError):
                        continue
                    if 0 <= index < len(texts):
                        texts[index] = str(result.get("text", "") or "").strip()
                with lock:
                    done += 1
                    completed_images = min(done * self.batch_size, len(images))
                if report:
                    pct = 40 + int(55 * done / max(1, total_batches))
                    report(pct, f"Máy chủ đã đọc khoảng {completed_images}/{len(images)} ảnh...")
        return texts, [i for i, text in enumerate(texts) if not text.strip()]

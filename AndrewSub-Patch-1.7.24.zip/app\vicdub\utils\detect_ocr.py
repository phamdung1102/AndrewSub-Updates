"""Tách phụ đề = detector streaming (sub_detector) + Drive OCR đọc chữ.

Đường CHÍNH XÁC thay cho llm_ocr_video: state machine cho mốc khít + hết vết tách
giả (gap-tolerance), OCR ảnh đại diện nét nhất. Hậu xử lý chỉ gộp track kề nhau
khi cả chữ OCR và nét ảnh cùng xác nhận; không gộp theo số lượng mục tiêu.
"""

from __future__ import annotations

import logging
import hashlib
import json
import os
import queue
import re
import shutil
import threading
import time
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable

from concurrent.futures import ThreadPoolExecutor

from vicdub.api.vision_ocr_client import PANELS_PER_MONTAGE as VISION_PANELS
from vicdub.utils.subtitles import Segment
from vicdub.utils.sub_detector import (
    DetectedSub, _bright_stroke_mask, detect_subtitles, stream_roi_frames,
    stroke_overlap,
)

logger = logging.getLogger(__name__)

ProgressFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]


def _format_metric_seconds(seconds: float) -> str:
    try:
        value = max(0.0, float(seconds))
    except (TypeError, ValueError):
        value = 0.0
    if value >= 60:
        minutes = int(value // 60)
        remain = int(round(value - minutes * 60))
        if remain >= 60:
            minutes += 1
            remain = 0
        return f"{minutes}p{remain:02d}s"
    if value >= 10:
        return f"{value:.0f}s"
    return f"{value:.1f}s"


class _ResultCallbackError(RuntimeError):
    """Lỗi lưu kết quả phải nổi lên UI, không được hiểu nhầm là lỗi Drive OCR."""


class OcrQualityError(RuntimeError):
    """Kết quả OCR bất thường; không được fallback rồi ghi đè dữ liệu tốt."""


_MIXED_PREFIX_RE = re.compile(r"^[A-Za-z]{1,12}\s+[\u3400-\u9fff]")
_CJK_RE = re.compile(r"[\u3400-\u9fff]")
_FOREIGN_ALPHA_RE = re.compile(
    r"[A-Za-zÀ-ÖØ-öø-ÿ\u0400-\u052f]+(?:[ '\-]+[A-Za-zÀ-ÖØ-öø-ÿ\u0400-\u052f]+)*"
)


def _has_suspicious_latin_prefix(text: str) -> bool:
    """Drive montage sometimes leaks a damaged header before CJK text."""
    return bool(_MIXED_PREFIX_RE.match((text or "").strip()))


def _is_chinese_hint(lang_hint: str) -> bool:
    hint = (lang_hint or "").strip().lower()
    return any(token in hint for token in ("trung", "chinese", "zh", "中文", "汉语", "漢語"))


def _is_chinese_timeline(texts: list[str], lang_hint: str) -> bool:
    """Use the explicit source language, or infer it from a mostly-CJK result set."""
    if _is_chinese_hint(lang_hint):
        return True
    nonempty = [value for value in texts if (value or "").strip()]
    if len(nonempty) < 3:
        return False
    return sum(bool(_CJK_RE.search(value)) for value in nonempty) / len(nonempty) >= 0.60


def _strip_foreign_noise_from_chinese(text: str) -> str:
    """Remove unstable alphabetic OCR fragments from an otherwise CJK line.

    This deliberately runs only when the selected source language is Chinese.
    Digits and normal subtitle punctuation are preserved. Alphabetic-only rows
    are handled separately after one isolated rescue OCR pass.
    """
    value = " ".join((text or "").split()).strip()
    if not _CJK_RE.search(value):
        return value
    value = _FOREIGN_ALPHA_RE.sub("", value)
    # Remove isolated OCR panel markers that stick to a Chinese subtitle.  This
    # is deliberately narrow: only standalone digits separated by whitespace at
    # the very start/end are removed, so real content like "10个人" is preserved.
    value = re.sub(r"^\s*\d{1,3}\s+(?=[\u3400-\u9fff])", "", value)
    value = re.sub(r"(?<=[\u3400-\u9fff])\s+\d{1,3}\s*$", "", value)
    # Drive/Docs can read the same very short cue twice inside one crop
    # ("笑话 笑话").  Collapse only identical short CJK tokens.
    duplicate = re.fullmatch(
        r"\s*([\u3400-\u9fff]{1,3})(?:\s+\1)+\s*",
        value,
    )
    if duplicate:
        value = duplicate.group(1)
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"\s+([，。！？、；：,.!?;:])", r"\1", value)
    return value.strip(" -_|/\\,.;:，。；：")


def _can_clean_mixed_chinese_locally(text: str) -> bool:
    """Return True when a mixed row has a strong CJK core safe to keep locally.

    Drive OCR occasionally attaches short Latin/Cyrillic fragments to a valid
    Chinese subtitle. Re-uploading every such row one-by-one is both slow and
    unnecessary. Rows with at least two CJK glyphs and a CJK-majority payload
    can be cleaned deterministically; short/ambiguous rows still go through the
    OCR rescue lane so real text is not discarded on a guess.
    """
    value = " ".join((text or "").split()).strip()
    if not value or not _FOREIGN_ALPHA_RE.search(value):
        return False
    cjk_count = len(_CJK_RE.findall(value))
    if cjk_count < 2:
        return False
    foreign_count = sum(len(match.group(0).replace(" ", "")) for match in _FOREIGN_ALPHA_RE.finditer(value))
    # OCR junk can be longer than the real subtitle (for example a detached
    # 8–10 letter watermark token), so a strict 50% ratio would still resend
    # many otherwise obvious Chinese rows. The two-CJK minimum protects short
    # ambiguous lines; 35% covers the measured noisy cases without accepting
    # alphabetic-only detections.
    return cjk_count / max(1, cjk_count + foreign_count) >= 0.35


def _normal_text(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u3400-\u9fff]+", "", (text or "").lower())


def _cjk_count(text: str) -> int:
    return len(_CJK_RE.findall(text or ""))


def _is_short_cjk_dialogue(text: str) -> bool:
    """Short Chinese dialogue must keep its own timing.

    OCR dramas often have one-word replies ("那", "不", "行", "哥").  These
    cues are visually real even when they last only a few frames.  Treat them
    as merge-sensitive so post-processing does not absorb them into neighbours.
    """
    normal = _normal_text(text)
    if not normal:
        return False
    cjk = _cjk_count(normal)
    return 0 < cjk <= 4 and cjk / max(1, len(normal)) >= 0.70


def _text_similarity(first: str, second: str) -> float:
    a, b = _normal_text(first), _normal_text(second)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def _ocr_text_quality(text: str, duration: float, chinese_source: bool) -> float:
    """Cheap score used only to decide whether a second OCR pass is safer.

    Higher is better.  It favours a clean CJK core, penalises foreign/noisy
    fragments, and penalises text that is implausibly long for a very short cue.
    """
    value = (text or "").strip()
    if not value:
        return -10.0
    normal = _normal_text(value)
    cjk = _cjk_count(normal)
    foreign = len(_FOREIGN_ALPHA_RE.findall(normal))
    quality = float(cjk or len(normal) * 0.25)
    if chinese_source:
        if cjk <= 0:
            quality -= 6.0
        quality -= foreign * 2.0
        if _has_suspicious_latin_prefix(value):
            quality -= 3.0
    if duration > 0:
        cps = len(normal) / max(0.05, duration)
        cjkps = cjk / max(0.05, duration)
        if duration <= 0.35 and cjk >= 5:
            quality -= 4.0
        if cps > 28:
            quality -= 2.0
        if chinese_source and cjkps > 18:
            quality -= 2.5
    return quality


def _suspect_ocr_score(
    index: int,
    subs: list[DetectedSub],
    texts: list[str],
    chinese_source: bool,
) -> int:
    """Rank rows worth a small-batch second OCR pass.

    The first pass remains fast and batched.  This only selects rows where the
    OCR result contradicts the cue timing or carries obvious noise.
    """
    value = (texts[index] or "").strip()
    sub = subs[index]
    duration = max(0.0, float(sub.end) - float(sub.start))
    cjk = _cjk_count(value)
    normal = _normal_text(value)
    score = 0
    if not value:
        score += 4
    if duration <= 0.16:
        score += 3
    elif duration <= 0.30:
        score += 2
    elif duration <= 0.45:
        score += 1
    if value and chinese_source and cjk == 0:
        score += 3
    if _has_suspicious_latin_prefix(value):
        score += 3
    if chinese_source and _FOREIGN_ALPHA_RE.search(value or ""):
        score += 2
    if duration > 0 and value:
        cps = len(normal) / max(0.05, duration)
        cjkps = cjk / max(0.05, duration)
        if cps > 30:
            score += 2
        if cjkps > 18:
            score += 2
        if duration <= 0.35 and cjk >= 5:
            score += 3
    for neighbour in (index - 1, index + 1):
        if 0 <= neighbour < len(texts):
            other = (texts[neighbour] or "").strip()
            gap = (
                subs[index].start - subs[neighbour].end
                if neighbour < index else subs[neighbour].start - subs[index].end
            )
            if other and value and abs(gap) <= 0.20:
                if _normal_text(other) == normal:
                    score += 2
                elif len(normal) >= 3 and (
                    normal in _normal_text(other) or _normal_text(other) in normal
                ):
                    score += 1
    return score


def _prefer_second_pass_ocr(
    old_text: str,
    new_text: str,
    duration: float,
    chinese_source: bool,
) -> bool:
    new_value = (new_text or "").strip()
    if not new_value:
        return False
    old_value = (old_text or "").strip()
    if not old_value:
        return True
    old_clean = (
        _strip_foreign_noise_from_chinese(old_value)
        if chinese_source else old_value
    )
    new_clean = (
        _strip_foreign_noise_from_chinese(new_value)
        if chinese_source else new_value
    )
    old_quality = _ocr_text_quality(old_clean, duration, chinese_source)
    new_quality = _ocr_text_quality(new_clean, duration, chinese_source)
    if new_quality >= old_quality + 1.5:
        return True
    old_cjk = _cjk_count(old_clean)
    new_cjk = _cjk_count(new_clean)
    if chinese_source and new_cjk <= 0:
        return False
    if duration <= 0.35 and 0 < new_cjk <= 4 and old_cjk >= new_cjk + 3:
        return True
    if _has_suspicious_latin_prefix(old_value) and new_cjk >= max(1, old_cjk - 1):
        return True
    return False


def _choose_consensus_text(values: list[str]) -> str:
    """Choose the medoid OCR result, not the longest (which often contains junk)."""
    # Keep repetitions: three neighbouring reads A/B/B must vote for B. Removing
    # duplicates here would turn that useful majority into an arbitrary tie.
    candidates = [value.strip() for value in values if value.strip()]
    if not candidates:
        return ""
    if len(candidates) == 1:
        return candidates[0]

    def score(candidate: str) -> tuple[float, int]:
        agreement = sum(_text_similarity(candidate, other) for other in candidates)
        return agreement / len(candidates), len(_normal_text(candidate))

    return max(candidates, key=score)


def _connected_stroke_components(mask) -> list[dict]:
    """Label bright-stroke components with row runs (NumPy only).

    OpenCV is intentionally not a dependency.  Run-length union keeps this
    cheap enough for subtitle strips and also preserves the source pixels that
    belong to every component so a clean OCR image can be reconstructed.
    """
    import numpy as np  # noqa: PLC0415

    source = np.asarray(mask, dtype=bool)
    parents: list[int] = []
    records: list[tuple[int, int, int, int]] = []
    previous: list[tuple[int, int, int]] = []

    def make_set() -> int:
        parents.append(len(parents))
        return len(parents) - 1

    def find(value: int) -> int:
        while parents[value] != value:
            parents[value] = parents[parents[value]]
            value = parents[value]
        return value

    def union(first: int, second: int) -> None:
        a, b = find(first), find(second)
        if a != b:
            parents[b] = a

    for y, row in enumerate(source):
        padded = np.pad(row.astype(np.int8), (1, 1))
        changes = np.flatnonzero(np.diff(padded))
        current: list[tuple[int, int, int]] = []
        for start, stop in zip(changes[0::2], changes[1::2]):
            run_id = make_set()
            x0, x1 = int(start), int(stop - 1)
            current.append((x0, x1, run_id))
            records.append((y, x0, x1, run_id))
            for px0, px1, previous_id in previous:
                if px1 < x0 - 1:
                    continue
                if px0 > x1 + 1:
                    break
                union(run_id, previous_id)
        previous = current

    components: dict[int, dict] = {}
    for y, x0, x1, run_id in records:
        root = find(run_id)
        item = components.setdefault(root, {
            "x0": x0, "x1": x1, "y0": y, "y1": y,
            "area": 0, "runs": [],
        })
        item["x0"] = min(item["x0"], x0)
        item["x1"] = max(item["x1"], x1)
        item["y0"] = min(item["y0"], y)
        item["y1"] = max(item["y1"], y)
        item["area"] += x1 - x0 + 1
        item["runs"].append((y, x0, x1))
    return list(components.values())


def _dilate_mask(mask, radius: int):
    import numpy as np  # noqa: PLC0415

    result = np.asarray(mask, dtype=bool)
    for _ in range(max(0, int(radius))):
        padded = np.pad(result, 1)
        h, w = result.shape
        result = np.logical_or.reduce([
            padded[dy:dy + h, dx:dx + w]
            for dy in range(3) for dx in range(3)
        ])
    return result


def _dominant_subtitle_layer(image):
    """Return ``(clean_image, confidence, reason)`` for likely layered text.

    A real two-line subtitle normally has the same glyph scale on both lines.
    Text printed inside the scene is commonly smaller/off-axis and separated
    from the large screen-aligned subtitle.  We only produce a second OCR image
    when that size/spatial separation is strong; the original is never lost.
    """
    import numpy as np  # noqa: PLC0415
    from PIL import Image  # noqa: PLC0415

    rgb = image.convert("RGB")
    mask = _bright_stroke_mask(rgb)
    height, width = mask.shape
    if height < 12 or width < 40 or int(mask.sum()) < 20:
        return None, 0.0, ""

    components = _connected_stroke_components(mask)
    glyphs = []
    for item in components:
        item["width"] = item["x1"] - item["x0"] + 1
        item["height"] = item["y1"] - item["y0"] + 1
        item["cx"] = (item["x0"] + item["x1"]) / 2.0
        item["cy"] = (item["y0"] + item["y1"]) / 2.0
        if (
            item["area"] >= 3
            and 3 <= item["height"] <= height * 0.70
            and item["width"] <= width * 0.30
        ):
            glyphs.append(item)
    if len(glyphs) < 3:
        return None, 0.0, ""

    central = [
        item for item in glyphs
        if width * 0.10 <= item["cx"] <= width * 0.90
        # Long bright phone/window edges are not glyphs. They previously won
        # the height percentile and made the filter retain the wrong text row.
        and item["width"] >= 3
        and item["height"] / max(1, item["width"]) <= 3.0
        and item["width"] / max(1, item["height"]) <= 3.5
    ] or glyphs
    seed_height = float(np.percentile([item["height"] for item in central], 86))
    seeds = [item for item in central if item["height"] >= max(6.0, seed_height)]
    if len(seeds) < 2:
        return None, 0.0, ""

    # Score horizontal rows of large glyph components. A subtitle is normally
    # a centred row containing several large components; UI/background text
    # forms smaller rows and isolated phone edges form one-component clusters.
    seed_scale = float(np.median([item["height"] for item in seeds]))
    row_tolerance = max(6.0, seed_scale * 0.48)
    rows: list[list[dict]] = []
    for item in sorted(seeds, key=lambda value: value["cy"]):
        target = min(
            rows,
            key=lambda row: abs(
                item["cy"] - sum(member["cy"] for member in row) / len(row)
            ),
            default=None,
        )
        if target is not None:
            center = sum(member["cy"] for member in target) / len(target)
        if target is not None and abs(item["cy"] - center) <= row_tolerance:
            target.append(item)
        else:
            rows.append([item])

    def row_score(row: list[dict]) -> float:
        area = sum(item["area"] * item["height"] for item in row)
        center = sum(item["cx"] * item["area"] for item in row) / max(
            1, sum(item["area"] for item in row)
        )
        centrality = 1.0 - min(
            1.0, abs(center - width / 2.0) / max(1.0, width / 2.0)
        )
        return area * (0.70 + 0.30 * centrality) * min(1.8, 0.75 + len(row) * 0.18)

    anchors = max(rows, key=row_score)
    if len(anchors) < 2:
        return None, 0.0, ""
    scale = float(np.percentile([item["height"] for item in anchors], 65))
    core_anchors = [
        item for item in anchors if item["height"] >= max(5.0, scale * 0.62)
    ]
    if len(core_anchors) >= 2:
        anchors = core_anchors
        scale = float(np.percentile([item["height"] for item in anchors], 65))
    anchor_weight = sum(item["area"] for item in anchors)
    main_y = sum(item["cy"] * item["area"] for item in anchors) / max(1, anchor_weight)
    y_tolerance = max(5.0, scale * 0.68)
    selected = [
        item for item in glyphs
        if abs(item["cy"] - main_y) <= y_tolerance
        and item["height"] >= max(2.0, scale * 0.18)
    ]
    if len(selected) < 2:
        return None, 0.0, ""
    selected_ids = {id(item) for item in selected}
    secondary = [
        item for item in glyphs
        if id(item) not in selected_ids and item["area"] >= 3
    ]
    if not secondary:
        return None, 0.0, ""

    primary_area = sum(item["area"] for item in selected)
    secondary_area = sum(item["area"] for item in secondary)
    secondary_ratio = secondary_area / max(1, primary_area + secondary_area)
    secondary_scale = float(np.median([item["height"] for item in secondary]))
    size_ratio = scale / max(1.0, secondary_scale)
    main_x = sum(item["cx"] * item["area"] for item in selected) / max(1, primary_area)
    centrality = 1.0 - min(1.0, abs(main_x - width / 2.0) / max(1.0, width / 2.0))

    # Conservative trigger: small punctuation or a legitimate second line with
    # the same font must not activate the destructive branch.
    if secondary_ratio < 0.055 or size_ratio < 1.30:
        return None, 0.0, ""
    confidence = min(
        0.98,
        0.55
        + min(0.18, (size_ratio - 1.30) * 0.20)
        + min(0.18, secondary_ratio * 0.65)
        + 0.07 * centrality,
    )
    pixels = np.asarray(rgb)
    cleaned = np.zeros_like(pixels)
    # Copy a tight row rectangle rather than only the detected edge pixels.
    # Keeping complete glyph fills/outlines makes the second OCR branch much
    # more readable while still removing the surrounding UI/comment layers.
    anchor_x0 = min(item["x0"] for item in anchors)
    anchor_x1 = max(item["x1"] for item in anchors)
    x_pad = max(4, int(round(scale * 0.48)))
    x0 = max(0, anchor_x0 - x_pad)
    x1 = min(width, anchor_x1 + x_pad + 1)
    y0 = max(0, int(round(main_y - y_tolerance)))
    y1 = min(height, int(round(main_y + y_tolerance + 1)))
    cleaned[y0:y1, x0:x1] = pixels[y0:y1, x0:x1]
    reason = (
        f"phát hiện lớp chữ phụ nhỏ hơn {size_ratio:.1f}x "
        f"(tỷ lệ nét phụ {secondary_ratio:.0%})"
    )
    return Image.fromarray(cleaned, "RGB"), confidence, reason


def _best_filtered_cjk_core(original: str, filtered: str) -> tuple[str, float]:
    """Find the short CJK phrase in polluted OCR supported by filtered OCR.

    Example: filtered ``今大活动`` is imperfect, while the polluted original
    still contains the exact phrase ``今天活动价`` among UI comments. Matching
    locally recovers that phrase instead of comparing against the whole noisy
    sentence and rejecting the useful filtered branch.
    """
    target = "".join(_CJK_RE.findall(filtered or ""))
    if len(target) < 2:
        return "", 0.0
    candidates: list[tuple[float, float, str]] = []
    min_size = max(2, len(target) - 1)
    max_size = len(target) + 2
    for run in re.findall(r"[\u3400-\u9fff]+", original or ""):
        for size in range(min_size, min(len(run), max_size) + 1):
            for start in range(0, len(run) - size + 1):
                value = run[start:start + size]
                similarity = SequenceMatcher(None, target, value).ratio()
                boundary_bonus = (
                    (0.06 if value[0] == target[0] else 0.0)
                    + (0.04 if value[-1] == target[-1] else 0.0)
                    # Filtered OCR often drops one edge glyph after the tight
                    # crop; a supported one-glyph completion from the original
                    # is preferable to a visibly truncated subtitle.
                    + (0.07 if len(value) == len(target) + 1 else 0.0)
                )
                candidates.append((similarity + boundary_bonus, similarity, value))
    if not candidates:
        return "", 0.0
    best_rank = max(item[0] for item in candidates)
    # Within a close similarity band prefer the complete/longer phrase; this
    # retains sentence-final glyphs such as ``价`` rather than truncating them.
    near_best = [
        item for item in candidates if item[0] >= best_rank - 0.09
    ]
    _rank, similarity, value = max(
        near_best, key=lambda item: (len(item[2]), item[0])
    )
    best_similarity = max(item[1] for item in candidates)
    return (value, similarity) if best_similarity >= 0.58 else ("", best_similarity)


def _resolve_layered_ocr(
    original: str, filtered: str, confidence: float, reason: str,
    suspicion: float = 0.0,
) -> tuple[str, str]:
    """Choose conservatively and always flag a material disagreement."""
    first = " ".join((original or "").split()).strip()
    second = " ".join((filtered or "").split()).strip()
    if not second:
        return first, f"Nghi nhiều lớp chữ; ảnh lọc không đọc được ({reason})."
    if not first:
        return second, f"Nghi nhiều lớp chữ; chỉ ảnh lọc đọc được ({reason})."
    a, b = _normal_text(first), _normal_text(second)
    if a == b:
        return first, ""
    similarity = _text_similarity(first, second)
    local_core, core_similarity = _best_filtered_cjk_core(first, second)
    if (
        confidence >= 0.70
        and local_core
        and len(a) >= max(8, len(_normal_text(local_core)) * 1.55)
        and core_similarity >= 0.58
    ):
        return local_core, (
            f"Đã tách cụm chữ chính từ OCR gốc bằng ảnh lọc ({reason})."
        )
    clean_is_core = bool(b and b in a and len(a) >= len(b) * 1.15)
    likely_cleaner = (
        confidence >= 0.78
        and len(b) >= 1
        and len(a) >= len(b) * 1.20
        and (clean_is_core or similarity >= 0.52)
    )
    if likely_cleaner:
        return second, (
            f"Đã ưu tiên dòng chữ chính; OCR gốc và ảnh lọc khác nhau ({reason})."
        )
    filtered_cjk = "".join(_CJK_RE.findall(second))
    if (
        suspicion >= 4.0
        and confidence >= 0.72
        and 2 <= len(filtered_cjk) <= 14
        and len(a) >= len(filtered_cjk) * 1.8
    ):
        return second, (
            f"Đã bỏ OCR gốc bất thường và dùng dòng chữ đã lọc ({reason})."
        )
    return first, (
        f"Nghi nhiều lớp chữ; giữ OCR gốc vì hai kết quả chưa đủ chắc chắn ({reason})."
    )


def _layered_text_suspicion(
    text: str, duration: float, typical_cjk_length: float,
) -> float:
    """Score only obviously abnormal Chinese OCR for the expensive second pass.

    Image layout alone is not enough: a livestream/phone scene can contain UI
    text in thousands of frames while only one OCR result is actually polluted.
    The second branch therefore requires both an abnormal OCR payload and the
    visual layered-text signal.
    """
    value = " ".join((text or "").split()).strip()
    cjk_count = len(_CJK_RE.findall(value))
    if cjk_count < 8:
        return 0.0
    runs = re.findall(r"[\u3400-\u9fff]+", value)
    typical = max(1.0, float(typical_cjk_length or 0.0))
    long_limit = max(18.0, typical * 2.35)
    seconds = max(0.08, float(duration or 0.0))
    chars_per_second = cjk_count / seconds

    score = 0.0
    if cjk_count >= long_limit:
        score += 2.0 + min(3.0, cjk_count / long_limit)
    if cjk_count >= 12 and chars_per_second >= 42.0:
        score += 1.5 + min(3.0, chars_per_second / 70.0)
    if cjk_count >= 14 and len(runs) >= 3:
        score += 1.5 + min(2.0, len(runs) * 0.25)
    # Require a strong anomaly, not merely a legitimate long/two-line subtitle.
    return score if score >= 2.5 else 0.0


def _is_short_numeric_noise(text: str) -> bool:
    """OCR noise such as ``00`` from UI/frame edges in a Chinese timeline."""
    value = " ".join((text or "").split()).strip()
    if not value:
        return False
    return bool(re.fullmatch(r"[\d\s:：.,，/\\|｜¦_-]{1,4}", value))


def _cjk_chunks(text: str) -> list[str]:
    return re.findall(r"[\u3400-\u9fff]+", text or "")


def _looks_fragmented_cjk_noise(text: str, duration: float) -> bool:
    """Detect one OCR row that is actually many detached scene/UI labels.

    Real fast dialogue can be 1–4 CJK chars. The bad case is different: within
    less than ~1s, OCR returns many short chunks separated by spaces, usually
    names/labels from the frame rather than the subtitle line.
    """
    value = " ".join((text or "").split()).strip()
    chunks = _cjk_chunks(value)
    if len(chunks) < 4:
        return False
    cjk_count = sum(len(chunk) for chunk in chunks)
    if cjk_count < 10:
        return False
    if re.search(r"[。！？?!]", value):
        return False
    seconds = max(0.08, float(duration or 0.0))
    short_ratio = sum(1 for chunk in chunks if len(chunk) <= 3) / len(chunks)
    if seconds <= 1.25 and len(chunks) >= 5 and short_ratio >= 0.70:
        return True
    if seconds <= 0.85 and len(chunks) >= 4 and short_ratio >= 0.65:
        return True
    return False


def _drop_fragmented_cjk_flicker_rows(rows: list[dict]) -> tuple[list[dict], int]:
    """Drop short fragmented OCR rows when adjacent rows already contain a core.

    This fixes cases like ``记住 南哥 入场 没错 耀哥 正好 文文 蒋爷`` sitting for
    0.67s before the real next subtitle ``蒋爷 蒋爷 最新消息``. Keeping that row
    makes translation hallucinate a long announcement and breaks voice timing.
    """
    if len(rows) < 2:
        return rows, 0
    kept: list[dict] = []
    removed = 0
    for index, row in enumerate(rows):
        text = row["texts"][0] if row.get("texts") else ""
        duration = float(row["end"] - row["start"])
        if not _looks_fragmented_cjk_noise(text, duration):
            kept.append(row)
            continue
        chunks = [chunk for chunk in _cjk_chunks(text) if len(chunk) <= 4]
        previous_text = (
            rows[index - 1]["texts"][0]
            if index > 0 and rows[index - 1].get("texts") else ""
        )
        next_text = (
            rows[index + 1]["texts"][0]
            if index + 1 < len(rows) and rows[index + 1].get("texts") else ""
        )
        neighbour = previous_text + " " + next_text
        repeated_nearby = any(chunk and chunk in neighbour for chunk in chunks)
        cps = sum(len(chunk) for chunk in _cjk_chunks(text)) / max(0.08, duration)
        if repeated_nearby or cps >= 18.0:
            removed += 1
            continue
        row.setdefault("warnings", []).append(
            "Nghi OCR gộp nhiều cụm chữ rời; cần kiểm tra thủ công."
        )
        kept.append(row)
    return kept, removed


def _postprocess_ocr_segments(
    subs, texts: list[str], lang_hint: str, *, max_gap: float = 0.12,
    fuzzy_threshold: float = 0.97, min_stroke_overlap: float = 0.76,
    warnings: list[str] | None = None,
) -> tuple[list[Segment], int, int]:
    """Language cleanup plus safe 2–3-neighbour temporal consensus.

    Adjacent OCR rows are joined only when they are very likely the same
    on-screen subtitle.  Short CJK dialogue is protected: a one-word/one-glyph
    cue keeps its own start/end instead of being absorbed by a neighbour.
    """
    chinese = _is_chinese_timeline(texts, lang_hint)
    rows = []
    removed_foreign = 0
    warning_values = list(warnings or [])
    if len(warning_values) < len(texts):
        warning_values.extend([""] * (len(texts) - len(warning_values)))
    for sub, raw_text, warning in zip(subs, texts, warning_values):
        text = " ".join((raw_text or "").split()).strip()
        if not text:
            continue
        if chinese:
            cleaned = _strip_foreign_noise_from_chinese(text)
            if cleaned != text:
                removed_foreign += 1
            text = cleaned
            # After the isolated rescue pass, an alphabetic-only result in a
            # Chinese source is OCR/background noise, not a usable subtitle.
            if not _CJK_RE.search(text) and _FOREIGN_ALPHA_RE.search(text):
                removed_foreign += 1
                continue
            if not _CJK_RE.search(text) and _is_short_numeric_noise(text):
                removed_foreign += 1
                continue
        if text:
            rows.append({"start": sub.start, "end": sub.end, "texts": [text],
                         "images": [sub.image], "warnings": [warning] if warning else []})

    if chinese:
        rows, removed_fragmented = _drop_fragmented_cjk_flicker_rows(rows)
        removed_foreign += removed_fragmented
        rows, removed_compound = _drop_compound_rows_covered_by_fast_rescues(rows)
        removed_foreign += removed_compound

    groups = []
    merged_count = 0
    for row in rows:
        previous = groups[-1] if groups else None
        should_merge = False
        gap = row["start"] - previous["end"] if previous is not None else float("inf")
        if previous is not None and gap <= max(max_gap, 0.25):
            nearby_texts = previous["texts"][-3:]
            similarity = max(_text_similarity(row["texts"][0], value)
                             for value in nearby_texts)
            # Track bị băm giả nối liền nhau chỉ được gộp khi còn bằng chứng
            # hình học rất mạnh. Với phim thoại nhanh, 0.2–0.3s đã đủ cho một
            # câu một/two chữ thật; gộp theo "gần giống" ở đây sẽ làm text đúng
            # nhưng timing sai: câu sau bị kéo về câu trước hoặc bị nuốt mất.
            same_text = any(
                _normal_text(row["texts"][0]) == _normal_text(value)
                for value in nearby_texts
            )
            short_dialogue_boundary = (
                _is_short_cjk_dialogue(row["texts"][0])
                or any(_is_short_cjk_dialogue(value) for value in nearby_texts)
            )
            overlap = max(
                (stroke_overlap(image, row["images"][0])
                 for image in previous["images"][-3:]),
                default=0.0,
            )
            if short_dialogue_boundary:
                # One/two-character replies are usually real separate cues.
                # Merge only if the split is essentially a frame-boundary tear
                # of the same glyph.
                previous_duration = previous["end"] - previous["start"]
                current_duration = row["end"] - row["start"]
                exact = same_text and (
                    (gap <= 0.055 and overlap >= 0.92)
                    or (
                        gap <= 0.25
                        and overlap >= 0.985
                        and min(previous_duration, current_duration) >= 0.35
                    )
                )
            else:
                exact = same_text and (
                    (gap <= 0.045 and overlap >= 0.82)
                    or (gap <= max_gap and overlap >= max(0.84, min_stroke_overlap))
                    # Detector đôi lúc băm một hard-sub đứng yên thành hai track
                    # qua một khoảng hở ngắn. Chỉ nối qua khoảng hở dài hơn khi
                    # cả text và nét ảnh gần như trùng tuyệt đối.
                    or (gap <= 0.25 and overlap >= 0.97)
                )
            # OCR variants are less trustworthy than exact text.  Keep this
            # deliberately narrow: if the text is not the same, preserving the
            # candidate is safer than shifting the visible subtitle timing.
            fuzzy_same_track = (
                not short_dialogue_boundary
                and not same_text and similarity >= min(fuzzy_threshold, 0.85)
                and gap <= 0.045
                and overlap >= max(0.95, min_stroke_overlap)
            )
            should_merge = exact or fuzzy_same_track
        if should_merge:
            previous["end"] = max(previous["end"], row["end"])
            previous["texts"].extend(row["texts"])
            previous["images"].extend(row["images"])
            previous["warnings"].extend(row["warnings"])
            merged_count += 1
        else:
            groups.append(row)

    segments = [
        Segment(
            line=index,
            start=round(group["start"], 3),
            end=round(group["end"], 3),
            text=_choose_consensus_text(group["texts"]),
            ocr_warning="; ".join(dict.fromkeys(group["warnings"])),
        )
        for index, group in enumerate(groups, 1)
    ]
    segments = _tighten_overlapping_boundaries(segments)
    segments, flicker_removed = _drop_tiny_duplicate_flicker_segments(segments)
    merged_count += flicker_removed
    return segments, merged_count, removed_foreign


def _interval_overlap(first_start: float, first_end: float, second_start: float, second_end: float) -> float:
    return max(0.0, min(first_end, second_end) - max(first_start, second_start))


def _is_fast_rescue_row(row: dict) -> bool:
    return any("rất nhanh" in str(value) or "nhanh" in str(value) for value in row.get("warnings", []))


def _drop_compound_rows_covered_by_fast_rescues(rows: list[dict]) -> tuple[list[dict], int]:
    """Drop a compound OCR row when rescued fast rows explain it better.

    Fast dialogue often appears as one wide OCR row ("没错 所以") plus two
    near-miss rows ("没错", "所以").  Keeping all three creates duplicated text
    and wrong voice timing.  Remove only when at least two rescued rows overlap
    the compound and their text is contained in the compound, so a legitimate
    one-line subtitle is not deleted by a single ambiguous rescue.
    """
    if len(rows) < 3:
        return rows, 0
    drop: set[int] = set()
    normals = [_normal_text(row["texts"][0] if row.get("texts") else "") for row in rows]
    for index, row in enumerate(rows):
        if index in drop:
            continue
        base = normals[index]
        if len(base) < 4:
            continue
        start = float(row["start"])
        end = float(row["end"])
        duration = max(0.001, end - start)
        if duration > 1.35:
            continue
        covered: list[int] = []
        for other_index, other in enumerate(rows):
            if other_index == index or other_index in drop:
                continue
            if not _is_fast_rescue_row(other):
                continue
            child = normals[other_index]
            if not child or len(child) > 4 or child not in base:
                continue
            overlap = _interval_overlap(
                start, end, float(other["start"]), float(other["end"]),
            )
            child_duration = max(0.001, float(other["end"]) - float(other["start"]))
            if overlap >= min(child_duration * 0.35, duration * 0.35):
                covered.append(other_index)
        unique_children = []
        seen = set()
        for child_index in covered:
            value = normals[child_index]
            if value not in seen:
                unique_children.append(child_index)
                seen.add(value)
        explained_chars = sum(len(normals[item]) for item in unique_children)
        if len(unique_children) >= 2 and explained_chars >= max(3, int(len(base) * 0.60)):
            row.setdefault("warnings", []).append(
                "Đã bỏ dòng OCR gộp vì có nhiều phụ đề nhanh phủ cùng thời điểm."
            )
            drop.add(index)
    if not drop:
        return rows, 0
    kept = [row for index, row in enumerate(rows) if index not in drop]
    return kept, len(drop)


def _tighten_overlapping_boundaries(
    segments: list[Segment],
    *,
    min_duration: float = 0.08,
) -> list[Segment]:
    """Keep visual timing monotonic after rescue candidates are merged in.

    Near-miss rescue can add a very short cue inside the previous cue's tail.
    If left untouched, the previous subtitle/voice occupies the time where the
    new text is already visible.  Split only real overlaps; do not pad or move
    ordinary gaps.
    """
    if len(segments) < 2:
        return segments
    ordered = sorted(segments, key=lambda item: (item.start, item.end))
    for index in range(1, len(ordered)):
        previous = ordered[index - 1]
        current = ordered[index]
        if previous.end <= current.start:
            continue
        midpoint = round((previous.end + current.start) / 2.0, 3)
        previous_min_end = previous.start + min_duration
        current_max_start = current.end - min_duration
        boundary = min(max(midpoint, previous_min_end), current_max_start)
        if previous.start < boundary < current.end:
            previous.end = round(boundary, 3)
            current.start = round(boundary, 3)
        else:
            previous.end = min(previous.end, current.start)
    for line, segment in enumerate(ordered, 1):
        segment.line = line
    return ordered


def _drop_tiny_duplicate_flicker_segments(
    segments: list[Segment],
    *,
    tiny_duration: float = 0.25,
    nearby_gap: float = 0.12,
    touch_gap: float = 0.025,
) -> tuple[list[Segment], int]:
    """Bỏ cue rác do detector recall mạnh băm một dòng thành nhiều lát ngắn.

    Quy tắc cố ý hẹp:
    - Chỉ bỏ cue cùng text đã chuẩn hoá.
    - Cue bị bỏ phải cực ngắn (<= ~5 frame ở 24fps).
    - Cue đó phải nằm sát cue trước/sau cùng text.

    Nhờ vậy các câu lặp thật cách nhau bằng khoảng im rõ vẫn được giữ.
    """
    if len(segments) < 2:
        return segments, 0

    def norm(segment: Segment) -> str:
        text = " ".join((segment.text or "").split()).strip()
        text = text.strip("[]【】()（）「」『』<>《》")
        # Drive OCR đôi khi dính marker panel vào đầu text: "3 活该...".
        # Chỉ bỏ trong phép so trùng, không sửa text thật để tránh làm mất số
        # nội dung ở những câu hợp lệ như "10 người".
        text = re.sub(r"^\s*\d{1,3}\s+(?=[\u3400-\u9fff])", "", text)
        return _normal_text(text)

    def tiny_duplicate_of_neighbour(value: str, neighbour: Segment | None, gap: float) -> bool:
        if neighbour is None or gap > nearby_gap:
            return False
        other = norm(neighbour)
        if not value or not other:
            return False
        if value == other:
            return True
        if (
            len(value) >= 2
            and max(len(value), len(other)) >= 4
            and (value in other or other in value)
        ):
            return True
        if (
            max(len(value), len(other)) >= 4
            and len(value) <= 8
            and len(other) <= 12
            and _text_similarity(value, other) >= 0.72
        ):
            return True
        return False

    drop: set[int] = set()
    for index, segment in enumerate(segments):
        duration = max(0.0, segment.end - segment.start)
        if duration > tiny_duration:
            continue
        value = norm(segment)
        if not value:
            continue
        previous = segments[index - 1] if index > 0 else None
        following = segments[index + 1] if index + 1 < len(segments) else None
        prev_same = tiny_duplicate_of_neighbour(
            value, previous,
            segment.start - previous.end if previous is not None else float("inf"),
        )
        next_same = tiny_duplicate_of_neighbour(
            value, following,
            following.start - segment.end if following is not None else float("inf"),
        )
        if prev_same or next_same:
            drop.add(index)

    removed = len(drop)

    # Sau khi bỏ lát flicker chen giữa, nối lại các mảnh cùng text chạm nhau.
    merged: list[Segment] = []
    for index, segment in enumerate(segments):
        if index in drop:
            # Không để việc bỏ cue tạo ra một "lỗ" thời gian khiến hai mảnh
            # cùng text hai bên không nối lại được.
            previous = merged[-1] if merged else None
            if (
                previous is not None
                and norm(previous) == norm(segment)
                and norm(segment)
                and segment.start - previous.end <= nearby_gap
            ):
                previous.end = max(previous.end, segment.end)
            continue
        previous = merged[-1] if merged else None
        if (
            previous is not None
            and norm(previous) == norm(segment)
            and norm(segment)
            and segment.start - previous.end <= touch_gap
        ):
            previous.end = max(previous.end, segment.end)
            if segment.ocr_warning and segment.ocr_warning not in (previous.ocr_warning or ""):
                previous.ocr_warning = "; ".join(
                    value for value in [previous.ocr_warning, segment.ocr_warning] if value
                )
            removed += 1
            continue
        merged.append(segment)

    for line, segment in enumerate(merged, 1):
        segment.line = line
    return merged, removed


def _emit_result(callback, index: int, text: str) -> None:
    if not callback:
        return
    try:
        callback(index, text)
    except Exception as exc:  # noqa: BLE001 - bọc để pool không nuốt lỗi database
        raise _ResultCallbackError(f"Không lưu được kết quả OCR #{index + 1}: {exc}") from exc


def _ocr_each_image(clients, images, lang_hint, report, is_cancelled,
                    checkpoint_dir: str | None = None,
                    max_attempts: int = 3,
                    on_result: Callable[[int, str], None] | None = None,
                    ) -> tuple[list[str], list[int]]:
    """Pool động: một worker/tài khoản, retry chéo và checkpoint từng ảnh."""
    if not isinstance(clients, (list, tuple)):
        clients = [clients]
    clients = [client for client in clients if getattr(client, "read_single", None)]
    if not clients:
        raise RuntimeError("Không có tài khoản xử lý nào hoạt động.")

    results = [""] * len(images)
    attempts = [0] * len(images)
    tried: list[set[int]] = [set() for _ in images]
    failures: list[str] = [""] * len(images)
    work: queue.Queue[int] = queue.Queue()
    lock = threading.Lock()
    done = 0
    started = time.monotonic()
    account_done = [0] * len(clients)
    account_errors = [0] * len(clients)

    checkpoint = Path(checkpoint_dir) if checkpoint_dir else None
    def image_fingerprint(image) -> str:
        raw = image if isinstance(image, (bytes, bytearray)) else image.tobytes()
        return hashlib.sha256(raw).hexdigest()[:16]

    digest = hashlib.sha256(
        "|".join(image_fingerprint(image) for image in images).encode()
    ).hexdigest()
    state_path = checkpoint / "state.json" if checkpoint else None
    if checkpoint:
        checkpoint.mkdir(parents=True, exist_ok=True)
        old_digest = ""
        try:
            old_digest = json.loads(state_path.read_text(encoding="utf-8")).get("digest", "")
        except (OSError, ValueError, TypeError):
            pass
        if old_digest != digest:
            for path in checkpoint.glob("image_*.json"):
                path.unlink(missing_ok=True)
            state_path.write_text(json.dumps({"digest": digest, "count": len(images)}), encoding="utf-8")

    def save(index: int, status: str) -> None:
        if not checkpoint:
            return
        payload = {
            "image_id": index, "status": status, "text": results[index],
            "attempts": attempts[index], "accounts_tried": sorted(tried[index]),
            "last_error": failures[index],
        }
        path = checkpoint / f"image_{index:06d}.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, path)

    # Nạp lại ảnh đã OCR thành công; ảnh lỗi/rỗng được đưa lại hàng đợi.
    for i in range(len(images)):
        path = checkpoint / f"image_{i:06d}.json" if checkpoint else None
        if path and path.exists():
            try:
                saved = json.loads(path.read_text(encoding="utf-8"))
                if saved.get("status") == "done" and str(saved.get("text", "")).strip():
                    results[i] = str(saved["text"]).strip()
                    done += 1
                    _emit_result(on_result, i, results[i])
                    continue
            except (OSError, ValueError, TypeError):
                pass
        work.put(i)

    def progress_message() -> str:
        elapsed = max(0.001, time.monotonic() - started)
        if done < min(8, len(images)):
            stats = ", ".join(f"TK{i + 1}:{n}" for i, n in enumerate(account_done))
            return f"OCR {done}/{len(images)} câu — đang đo tốc độ ({stats})"
        newly_done = max(1, done)
        remaining = max(0, len(images) - done)
        eta_minutes = remaining * elapsed / newly_done / 60.0
        stats = ", ".join(f"TK{i + 1}:{n}" for i, n in enumerate(account_done))
        return f"OCR {done}/{len(images)} câu — còn khoảng {eta_minutes:.1f} phút ({stats})"

    def worker(account_index: int) -> None:
        nonlocal done
        client = clients[account_index]
        consecutive_account_errors = 0
        while not is_cancelled():
            try:
                index = work.get(timeout=0.2)
            except queue.Empty:
                with lock:
                    if done >= len(images):
                        return
                continue
            with lock:
                if results[index] or attempts[index] >= max_attempts:
                    continue
                attempts[index] += 1
                tried[index].add(account_index)
            try:
                text = str(client.read_single(images[index], lang_hint) or "").strip()
                if not text:
                    raise ValueError("OCR trả kết quả rỗng")
                with lock:
                    results[index] = text
                    account_done[account_index] += 1
                    done += 1
                    consecutive_account_errors = 0
                    save(index, "done")
                    _emit_result(on_result, index, text)
                    report(40 + int(58 * done / max(1, len(images))), progress_message())
            except _ResultCallbackError:
                raise
            except Exception as exc:  # noqa: BLE001
                message = str(exc)
                lower_message = message.lower()
                backoff = 0.0
                with lock:
                    failures[index] = message
                    account_errors[account_index] += 1
                    account_fault = any(token in message.lower() for token in (
                        "401", "invalid_grant", "unauthorized", "403", "permission",
                        "insufficient", "token has been expired", "revoked",
                    ))
                    consecutive_account_errors = consecutive_account_errors + 1 if account_fault else 0
                    if "429" in lower_message or "ratelimit" in lower_message:
                        backoff = min(8.0, 2.0 ** min(3, account_errors[account_index]))
                    if attempts[index] < max_attempts:
                        work.put(index)
                    else:
                        done += 1
                        save(index, "failed")
                        report(40 + int(58 * done / max(1, len(images))), progress_message())
                # Lỗi quyền/token lặp lại: loại riêng tài khoản, ảnh đã được trả hàng đợi.
                if consecutive_account_errors >= 2:
                    logger.warning("Loại tài khoản OCR %d trong tác vụ: %s", account_index + 1, message)
                    return
                if backoff:
                    report(
                        40 + int(58 * done / max(1, len(images))),
                        f"Tài khoản {account_index + 1} bị giới hạn; nghỉ {backoff:.0f}s — "
                        + progress_message(),
                    )
                    time.sleep(backoff)
                # Cho worker khác cơ hội nhận lượt retry, thay vì cùng tài khoản
                # giành lại ngay ảnh vừa thất bại.
                time.sleep(0.05)

    report(40, f"Đang đọc chữ bằng {len(clients)} tài khoản xử lý song song...")
    with ThreadPoolExecutor(max_workers=len(clients)) as executor:
        futures = [executor.submit(worker, i) for i in range(len(clients))]
        for future in futures:
            future.result()

    # Nếu worker hỏng rời hàng đợi, tài khoản khỏe đầu tiên vét nốt tuần tự.
    while not work.empty() and not is_cancelled():
        index = work.get_nowait()
        if results[index] or attempts[index] >= max_attempts:
            continue
        attempts[index] += 1
        try:
            results[index] = str(clients[0].read_single(images[index], lang_hint) or "").strip()
            if not results[index]:
                raise ValueError("OCR trả kết quả rỗng")
            save(index, "done")
            _emit_result(on_result, index, results[index])
        except _ResultCallbackError:
            raise
        except Exception as exc:  # noqa: BLE001
            failures[index] = str(exc)
            if attempts[index] < max_attempts:
                work.put(index)
            else:
                save(index, "failed")

    failed = [i for i, value in enumerate(results) if not value]
    return results, failed


def _ocr_montage_pool(clients, images, lang_hint, report,
                       batch_size: int = 8, is_cancelled=None,
                       on_result: Callable[[int, str], None] | None = None,
                       checkpoint_dir: str | None = None,
                       ) -> tuple[list[str], list[int]]:
    """OCR nhanh cho Repair Mode: montage nhỏ, một worker cho mỗi tài khoản."""
    if not isinstance(clients, (list, tuple)):
        clients = [clients]
    clients = list(clients)
    if not clients:
        raise RuntimeError("Không có tài khoản xử lý nào hoạt động.")
    # Tôn trọng giới hạn nghiêm ngặt nhất của nguồn OCR. Máy chủ dùng Google Docs
    # hiện cần một ảnh/lượt vì Docs có thể đảo chữ quanh marker montage. Giới hạn
    # này phải áp dụng cả lượt cứu ảnh rỗng/nhiễu, nếu không lượt đầu đúng nhưng
    # lượt sửa cuối lại có thể đẩy chữ sang candidate bên cạnh.
    reliable_batch = min(
        [20, *[
            int(getattr(client, "max_reliable_batch", 20) or 20)
            for client in clients
        ]]
    )
    batch_size = max(1, min(reliable_batch, int(batch_size)))
    results = [""] * len(images)
    checkpoint = Path(checkpoint_dir) if checkpoint_dir else None
    cached_empty: set[int] = set()

    def image_fingerprint(image) -> str:
        raw = image if isinstance(image, (bytes, bytearray)) else image.tobytes()
        return hashlib.sha256(raw).hexdigest()[:16]

    if checkpoint:
        checkpoint.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(
            "|".join(image_fingerprint(image) for image in images).encode()
        ).hexdigest()
        state_path = checkpoint / "state.json"
        old_digest = ""
        old_mode = ""
        old_batch_size = 0
        try:
            old_state = json.loads(state_path.read_text(encoding="utf-8"))
            old_digest = old_state.get("digest", "")
            old_mode = old_state.get("mode", "")
            old_batch_size = int(old_state.get("batch_size", 0) or 0)
        except (OSError, ValueError, TypeError):
            pass
        if (old_digest != digest or old_mode != "montage-strict-v3"
                or old_batch_size != batch_size):
            for path in checkpoint.glob("image_*.json"):
                path.unlink(missing_ok=True)
            # Ảnh kiểm tra thuộc đúng một lần quét. Không để UI mở ảnh cũ bằng
            # index của lần quét mới (đã từng có 5.666 ảnh cũ đi với 8.788 JSON).
            for name in ("candidates", "failed_images", "rejected_images", "mixed_batch"):
                shutil.rmtree(checkpoint / name, ignore_errors=True)
            for name in ("rejected.json",):
                (checkpoint / name).unlink(missing_ok=True)
            state_path.write_text(
                json.dumps({
                    "digest": digest, "count": len(images),
                    "mode": "montage-strict-v3", "batch_size": batch_size,
                }), encoding="utf-8"
            )

    def save(index: int, text_value: str, status: str = "done") -> None:
        if not checkpoint or (status != "empty" and not text_value.strip()):
            return
        path = checkpoint / f"image_{index:06d}.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps({
            "image_id": index, "status": status, "text": text_value.strip(),
            "attempts": 1, "accounts_tried": [], "last_error": "",
        }, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, path)

    # Tận dụng được cả checkpoint từng ảnh của pipeline cũ. Chỉ các panel chưa
    # có chữ mới được ghép montage và gửi lên Drive.
    for index in range(len(images)):
        path = checkpoint / f"image_{index:06d}.json" if checkpoint else None
        if not path or not path.exists():
            continue
        try:
            saved = json.loads(path.read_text(encoding="utf-8"))
            if saved.get("status") == "done" and str(saved.get("text", "")).strip():
                results[index] = str(saved["text"]).strip()
                _emit_result(on_result, index, results[index])
            elif saved.get("status") == "empty":
                cached_empty.add(index)
        except (OSError, ValueError, TypeError):
            continue

    pending = [
        index for index, value in enumerate(results)
        if not value and index not in cached_empty
    ]
    batches = [
        pending[start:start + batch_size]
        for start in range(0, len(pending), batch_size)
    ]
    if not batches:
        return results, [index for index, value in enumerate(results) if not value]
    work: queue.Queue[int] = queue.Queue()
    for batch_index in range(len(batches)):
        work.put(batch_index)
    attempts = [0] * len(batches)
    tried_accounts: list[set[int]] = [set() for _ in batches]
    lock = threading.Lock()
    done_batches = 0
    started = time.monotonic()

    def worker(account_index: int) -> None:
        nonlocal done_batches
        client = clients[account_index]
        while True:
            if is_cancelled and is_cancelled():
                return
            try:
                batch_index = work.get(timeout=0.2)
            except queue.Empty:
                with lock:
                    if done_batches >= len(batches):
                        return
                continue
            with lock:
                # Lỗi API mới chuyển batch sang tài khoản CHƯA thử. Các worker
                # vẫn đợi hàng đợi nên batch retry không rơi lại vào worker cũ.
                if (len(clients) > 1 and account_index in tried_accounts[batch_index]
                        and len(tried_accounts[batch_index]) < len(clients)):
                    work.put(batch_index)
                    retry_elsewhere = True
                else:
                    tried_accounts[batch_index].add(account_index)
                    attempts[batch_index] += 1
                    retry_elsewhere = False
            if retry_elsewhere:
                time.sleep(0.02)
                continue
            indexes = batches[batch_index]
            ids = [index + 1 for index in indexes]
            try:
                if is_cancelled and is_cancelled():
                    return
                montage = client.build_montage([images[index] for index in indexes], ids)
                parsed = client.read_subtitle_montage(montage, ids, lang_hint)
                completed: list[tuple[int, str]] = []
                with lock:
                    for index, panel_id in zip(indexes, ids):
                        results[index] = str(parsed.get(panel_id, "") or "").strip()
                        if results[index]:
                            save(index, results[index], "done")
                            completed.append((index, results[index]))
                        else:
                            # Complete montage marker + blank panel is a stable
                            # no-text result for this exact image digest. Cache it
                            # so reopening/rerunning does not spend requests again.
                            save(index, "", "empty")
                    done_batches += 1
                    elapsed = max(0.001, time.monotonic() - started)
                    remain = len(batches) - done_batches
                    eta = remain * elapsed / max(1, done_batches) / 60.0
                    report(
                        40 + int(50 * done_batches / len(batches)),
                        f"Lượt {done_batches}/{len(batches)} — còn khoảng {eta:.1f} phút",
                    )
                # Callback có thể ghi database nên chạy ngoài lock của pool.
                for index, value in completed:
                    _emit_result(on_result, index, value)
            except _ResultCallbackError:
                raise
            except Exception as exc:  # noqa: BLE001
                if (not (is_cancelled and is_cancelled())
                        and attempts[batch_index] < max(2, min(4, len(clients)))):
                    work.put(batch_index)
                else:
                    with lock:
                        done_batches += 1
                        if len(indexes) > 1 and not (is_cancelled and is_cancelled()):
                            middle = max(1, len(indexes) // 2)
                            children = (indexes[:middle], indexes[middle:])
                            for child in children:
                                if not child:
                                    continue
                                child_index = len(batches)
                                batches.append(child)
                                attempts.append(0)
                                tried_accounts.append(set())
                                work.put(child_index)
                            logger.warning(
                                "Montage OCR %d (%d panel) không an toàn; chia thành %d + %d: %s",
                                batch_index + 1, len(indexes), len(children[0]), len(children[1]), exc,
                            )
                        else:
                            logger.warning("Montage sửa OCR %d lỗi: %s", batch_index + 1, exc)

    with ThreadPoolExecutor(max_workers=len(clients)) as executor:
        futures = [executor.submit(worker, index) for index in range(len(clients))]
        for future in futures:
            future.result()
    failed = [index for index, value in enumerate(results) if not value]
    return results, failed


def _enhance_failed_image(image):
    """Phóng to/làm rõ ảnh khó trước lượt OCR cứu hộ."""
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps  # noqa: PLC0415

    source = image.convert("RGB") if hasattr(image, "convert") else image
    width, height = source.size
    enlarged = source.resize(
        (max(1, width * 2), max(1, height * 2)),
        resample=Image.Resampling.LANCZOS,
    )
    gray = ImageOps.grayscale(enlarged)
    gray = ImageOps.autocontrast(gray, cutoff=1)
    gray = ImageEnhance.Contrast(gray).enhance(1.45)
    gray = gray.filter(ImageFilter.UnsharpMask(radius=1.2, percent=170, threshold=2))
    return ImageOps.expand(gray.convert("RGB"), border=16, fill="white")


def _blank_candidate_score(sub) -> float:
    """Lọc panel rỗng đáng OCR lại, tránh gửi lại toàn bộ nhiễu nền.

    Drive montage đôi khi bỏ một subtitle rất ngắn dù marker vẫn đủ.  Một track
    đáng cứu phải có nét sáng thật và thỏa một trong hai bằng chứng:

    * tồn tại ổn định ít nhất 0,75 giây; hoặc
    * tồn tại ít nhất 0,25 giây và phần lớn nét nằm trong vùng giữa của dải sub.

    Điều kiện thứ hai giữ được thoại chớp nhanh, còn các mép áo/đèn/cảnh chuyển
    động ở hai rìa thường bị loại. Đây chỉ là bộ chọn request; OCR vẫn là nơi
    quyết định có tạo subtitle hay không.
    """
    import numpy as np  # noqa: PLC0415
    from vicdub.utils.sub_detector import _bright_stroke_mask  # noqa: PLC0415

    image = getattr(sub, "image", None)
    if image is None:
        return 0.0
    mask = np.asarray(_bright_stroke_mask(image), dtype=bool)
    if mask.ndim != 2 or mask.size == 0:
        return 0.0
    density = float(mask.mean())
    if density < 0.003 or density > 0.10:
        return 0.0
    duration = max(0.0, float(sub.end) - float(sub.start))
    if duration < 0.25:
        return 0.0
    total = int(mask.sum())
    if total <= 0:
        return 0.0
    height, width = mask.shape
    center = mask[:, int(0.20 * width):max(1, int(0.80 * width))]
    middle_rows = mask[
        int(0.15 * height):max(1, int(0.85 * height)), :
    ]
    center_ratio = float(center.sum()) / total
    middle_ratio = float(middle_rows.sum()) / total
    if duration >= 0.75:
        # Long-lived logos/UI edges used to pass purely because of duration.
        # Require a centred text-like layout even for stable candidates.
        if center_ratio < 0.62 or middle_ratio < 0.65:
            return 0.0
    elif center_ratio < 0.75 or middle_ratio < 0.75:
        return 0.0
    density_quality = 1.0 - min(1.0, abs(density - 0.022) / 0.078)
    return (
        center_ratio * 2.0
        + middle_ratio
        + min(1.5, duration) * 0.35
        + density_quality * 0.5
    )


def _blank_candidate_likely_text(sub) -> bool:
    return _blank_candidate_score(sub) > 0.0


def _rescue_blank_montage(
    clients,
    subs,
    images,
    texts: list[str],
    failed: list[int],
    lang_hint: str,
    report: ProgressFn,
    is_cancelled: CancelFn,
    checkpoint_dir: str | None,
) -> tuple[list[str], list[int], int, int]:
    """OCR lại có chọn lọc panel rỗng bằng montage nhỏ đã tăng độ rõ.

    Checkpoint riêng đảm bảo mở lại dự án không gọi mạng lần nữa. Kết quả luôn
    ghép về candidate id gốc, tuyệt đối không phụ thuộc thứ tự worker hoàn thành.
    """
    ranked = []
    for index in failed:
        if 0 <= index < len(subs):
            score = _blank_candidate_score(subs[index])
            if score:
                ranked.append((score, index))
    ranked.sort(reverse=True)
    # A two-hour UI-heavy video may contain hundreds of OCR-empty detector
    # tracks. Rescue only the strongest 1%, never more than 48 panels.
    rescue_limit = max(8, min(48, (len(subs) + 99) // 100))
    selected = [index for _score, index in ranked[:rescue_limit]]
    if not selected or is_cancelled():
        return texts, failed, 0, len(selected)
    report(
        97,
        f"Kiểm tra nhanh {len(selected)}/{len(failed)} ảnh rỗng còn dấu hiệu chữ...",
    )
    rescue_dir = (
        str(Path(checkpoint_dir) / "blank_rescue_v1")
        if checkpoint_dir else None
    )
    try:
        rescued, _still_empty = _ocr_montage_pool(
            clients,
            [_enhance_failed_image(images[index]) for index in selected],
            lang_hint,
            lambda _pct, _message: None,
            # Montage nhỏ giúp Drive chú ý subtitle một-hai chữ mà không tăng
            # thành hàng chục request OCR đơn.
            batch_size=8,
            is_cancelled=is_cancelled,
            checkpoint_dir=rescue_dir,
        )
    except Exception as exc:  # rescue failure must preserve first-pass results
        logger.warning("Bỏ qua lượt cứu panel rỗng: %s", exc)
        return texts, failed, 0, len(selected)
    recovered = 0
    for source_index, value in zip(selected, rescued):
        value = str(value or "").strip()
        if value:
            texts[source_index] = value
            recovered += 1
    remaining = [index for index in failed if not texts[index].strip()]
    return texts, remaining, recovered, len(selected)


def _uncovered_timeline_candidates(
    ffmpeg_bin: str,
    video_path: str,
    crop,
    segments: list[Segment],
    is_cancelled: CancelFn,
    *,
    sample_fps: float = 10.0,
    min_score: float = 0.007,
) -> list[DetectedSub]:
    """Tìm ảnh có chữ mạnh nằm ngoài mọi đoạn đã OCR thành công.

    Đây là lưới an toàn độc lập với state machine chính. Nó không OCR lại toàn
    video: chỉ lấy frame ngoài timeline đã có chữ, gom các frame sát nhau thành
    một track và giữ frame có mask chữ mạnh nhất. OCR phía sau loại cảnh nền.
    """
    intervals = [
        (float(segment.start) - 0.04, float(segment.end) + 0.04)
        for segment in segments
    ]

    def covered(at_second: float) -> bool:
        return any(start <= at_second <= end for start, end in intervals)

    frame_duration = 1.0 / max(1.0, float(sample_fps))
    groups: list[DetectedSub] = []
    active = None

    def close_active() -> None:
        nonlocal active
        if active is not None:
            groups.append(DetectedSub(
                start=round(active["start"], 3),
                end=round(active["last"] + frame_duration, 3),
                image=active["image"],
            ))
        active = None

    for at_second, image in stream_roi_frames(
        ffmpeg_bin, video_path, crop, sample_fps, is_cancelled,
    ):
        if is_cancelled():
            break
        mask = _bright_stroke_mask(image)
        width = mask.shape[1] if getattr(mask, "ndim", 0) == 2 else 0
        if width > 0:
            center = mask[:, int(0.15 * width):max(1, int(0.85 * width))]
            score = float(center.mean()) if center.size else 0.0
        else:
            score = 0.0
        usable = not covered(at_second) and score >= min_score
        if not usable:
            close_active()
            continue
        if active is None or at_second - active["last"] > frame_duration * 1.55:
            close_active()
            active = {
                "start": at_second, "last": at_second,
                "score": score, "image": image.copy(),
            }
        else:
            active["last"] = at_second
            if score > active["score"]:
                active["score"] = score
                active["image"] = image.copy()
    close_active()
    return groups


def _rescue_uncovered_timeline(
    ffmpeg_bin: str,
    video_path: str,
    crop,
    segments: list[Segment],
    clients,
    lang_hint: str,
    report: ProgressFn,
    is_cancelled: CancelFn,
    checkpoint_dir: str | None,
) -> tuple[list[DetectedSub], list[str], int]:
    """Quét nhẹ các khoảng trống và OCR montage để vá candidate bị bỏ lọt."""
    candidates = _uncovered_timeline_candidates(
        ffmpeg_bin, video_path, crop, segments, is_cancelled,
    )
    if not candidates or is_cancelled():
        return [], [], len(candidates)
    report(
        97,
        f"Kiểm tra {len(candidates)} vùng trống còn dấu hiệu phụ đề...",
    )
    rescue_dir = (
        str(Path(checkpoint_dir) / "timeline_gap_rescue_v1")
        if checkpoint_dir else None
    )
    try:
        values, _failed = _ocr_montage_pool(
            clients,
            [_enhance_failed_image(item.image) for item in candidates],
            lang_hint,
            lambda _pct, _message: None,
            batch_size=20,
            is_cancelled=is_cancelled,
            checkpoint_dir=rescue_dir,
        )
    except Exception as exc:
        logger.warning("Bỏ qua lượt kiểm tra khoảng trống timeline: %s", exc)
        return [], [], len(candidates)
    recovered_subs = []
    recovered_texts = []
    for candidate, value in zip(candidates, values):
        value = str(value or "").strip()
        if value:
            recovered_subs.append(candidate)
            recovered_texts.append(value)
    return recovered_subs, recovered_texts, len(candidates)


def _near_miss_score(sub) -> float:
    """Chấm track nhanh đã thấy trong lượt chính nhưng chưa đủ mở state.

    Không dùng thời lượng tối thiểu 0,25 giây như cứu OCR-rỗng: near-miss chủ
    yếu là subtitle 0,08–0,20 giây. Đổi lại, nét phải nằm rất rõ trong vùng
    giữa của dải phụ đề để loại đèn/logo/cạnh áo.
    """
    import numpy as np  # noqa: PLC0415
    from vicdub.utils.sub_detector import _bright_stroke_mask  # noqa: PLC0415

    image = getattr(sub, "image", None)
    if image is None:
        return 0.0
    mask = np.asarray(_bright_stroke_mask(image), dtype=bool)
    if mask.ndim != 2 or mask.size == 0:
        return 0.0
    density = float(mask.mean())
    if density < 0.003 or density > 0.085:
        return 0.0
    total = int(mask.sum())
    if total <= 0:
        return 0.0
    height, width = mask.shape
    center = mask[:, int(0.18 * width):max(1, int(0.82 * width))]
    middle = mask[int(0.12 * height):max(1, int(0.88 * height)), :]
    center_ratio = float(center.sum()) / total
    middle_ratio = float(middle.sum()) / total
    if center_ratio < 0.78 or middle_ratio < 0.78:
        return 0.0
    duration = max(0.0, float(sub.end) - float(sub.start))
    return center_ratio * 2.0 + middle_ratio + min(0.30, duration)


def _select_near_misses(near_misses, accepted_segments) -> list[DetectedSub]:
    """Lấy near-miss ngoài timeline đã đọc, không giới hạn số lượng tùy tiện."""
    accepted = sorted(
        (float(item.start), float(item.end))
        for item in accepted_segments
    )
    selected: list[DetectedSub] = []
    interval_index = 0
    for candidate in sorted(near_misses, key=lambda item: (item.start, item.end)):
        start, end = float(candidate.start), float(candidate.end)
        duration = max(0.001, end - start)
        score = _near_miss_score(candidate)
        while (
            interval_index < len(accepted)
            and accepted[interval_index][1] < start
        ):
            interval_index += 1
        overlaps = False
        if interval_index < len(accepted):
            accepted_start, accepted_end = accepted[interval_index]
            actual_overlap = max(
                0.0,
                min(end, accepted_end) - max(start, accepted_start),
            )
            overlap_ratio = actual_overlap / duration
            edge_distance = min(
                abs(start - accepted_start),
                abs(end - accepted_start),
                abs(start - accepted_end),
                abs(end - accepted_end),
            )
            # Không loại chỉ vì candidate chạm/sát biên một cue đã đọc. Đây là
            # vị trí thường xuất hiện câu đáp rất nhanh (1–2 chữ). Cho candidate
            # ngắn ở biên đi OCR; hậu xử lý sẽ dùng cả text + nét ảnh để gộp nếu
            # nó thực sự chỉ là bản lặp. Chỉ bỏ candidate gần như nằm trọn trong
            # cue đã có và không phải một chớp chữ ngắn ở biên.
            short_edge_candidate = duration <= 0.22 and edge_distance <= 0.08
            overlaps = overlap_ratio >= 0.85 and not short_edge_candidate
        if overlaps or score <= 0:
            continue
        previous = selected[-1] if selected else None
        if previous is not None and start - previous.end <= 0.06:
            # Cùng một chớp chữ có thể tạo hai near-miss kề nhau. Chỉ gộp khi
            # nét thực sự trùng; hai câu thoại nhanh khác nhau vẫn giữ riêng.
            if stroke_overlap(previous.image, candidate.image) >= 0.58:
                previous.end = max(previous.end, candidate.end)
                if score > _near_miss_score(previous):
                    previous.image = candidate.image
                continue
        selected.append(DetectedSub(start, end, candidate.image))
    return selected


def _rescue_near_misses(
    clients,
    near_misses,
    accepted_segments,
    lang_hint: str,
    report: ProgressFn,
    is_cancelled: CancelFn,
    checkpoint_dir: str | None,
) -> tuple[list[DetectedSub], list[str], list[str], int]:
    """OCR candidate nhanh có sẵn từ lượt quét chính; không decode video lần hai."""
    selected = _select_near_misses(near_misses, accepted_segments)
    if not selected or is_cancelled():
        return [], [], [], len(selected)
    report(
        97,
        f"Kiểm tra nhanh {len(selected)} vùng nghi thiếu đã giữ từ lượt quét chính...",
    )
    rescue_dir = (
        str(Path(checkpoint_dir) / "near_miss_rescue_v1")
        if checkpoint_dir else None
    )
    try:
        values, _failed = _ocr_montage_pool(
            clients,
            [_enhance_failed_image(item.image) for item in selected],
            lang_hint,
            lambda _pct, _message: None,
            batch_size=20,
            is_cancelled=is_cancelled,
            checkpoint_dir=rescue_dir,
        )
    except Exception as exc:
        logger.warning("Bỏ qua lượt OCR vùng nghi thiếu đã lưu: %s", exc)
        return [], [], [], len(selected)

    chinese = _is_chinese_timeline(
        [str(value or "") for value in values], lang_hint,
    )
    recovered_subs: list[DetectedSub] = []
    recovered_texts: list[str] = []
    warnings: list[str] = []
    for candidate, value in zip(selected, values):
        text = " ".join(str(value or "").split()).strip()
        if chinese:
            text = _strip_foreign_noise_from_chinese(text)
            if not _CJK_RE.search(text):
                continue
        if not text:
            continue
        recovered_subs.append(candidate)
        recovered_texts.append(text)
        warnings.append(
            "Phụ đề rất nhanh được tự động cứu từ lượt quét chính; "
            "đánh dấu để kiểm tra nếu cần."
        )
    return recovered_subs, recovered_texts, warnings, len(selected)


def _merge_exact_adjacent_segments(
    segments: list[Segment], max_gap: float = 0.35,
) -> tuple[list[Segment], int]:
    """Loại track flicker khi OCR trả text GIỐNG HỆT ở sát nhau.

    Không fuzzy/substring merge: hai câu khác dù chỉ một ký tự vẫn giữ riêng.
    """
    merged: list[Segment] = []
    removed = 0
    for segment in segments:
        previous = merged[-1] if merged else None
        gap = segment.start - previous.end if previous else float("inf")
        if (previous is not None and previous.text.strip() == segment.text.strip()
                and gap <= max_gap):
            previous.end = max(previous.end, segment.end)
            removed += 1
            continue
        merged.append(segment)
    for line, segment in enumerate(merged, 1):
        segment.line = line
    return merged, removed


def _count_text_bands(image, min_gap: int = 6) -> int:
    """Số dải chữ tách biệt theo chiều dọc trong một panel (dải cách <=min_gap
    hàng coi là một — sub 2 dòng sát nhau không bị đếm đôi)."""
    from vicdub.utils.sub_detector import _bright_stroke_mask  # noqa: PLC0415

    mask = _bright_stroke_mask(image)
    if not mask.any():
        return 0
    rows = mask.mean(axis=1)
    on = rows > max(0.01, 0.15 * float(rows.max()))
    bands = 0
    running = False
    gap = 0
    for value in on:
        if value:
            if not running:
                bands += 1
                running = True
            gap = 0
        elif running:
            gap += 1
            if gap > min_gap:
                running = False
                gap = 0
    return bands


def double_subtitle_warning(images, sample: int = 80) -> str:
    """Cảnh báo khi vùng OCR có vẻ trùm HAI BẢN phụ đề (video burn sub 2 lần).

    Đo thực tế: panel dính 2 bản (một bản bị xén/mờ) làm cả per-image OCR đọc ra
    rác ghép (vd '最新消息' -> '取新徧面 县新消自') — không heuristic hậu kỳ nào gỡ
    nổi. PHÁT HIỆN thì đáng tin (77% panel >=2 dải trên video lỗi thật, video sạch
    đa số 1 dải); tự CHỌN bản đúng thì không (đã thử 3 cách, tối đa 2/5) -> chỉ
    cảnh báo để người dùng khoanh lại vùng quanh MỘT bản sub.
    """
    picked = images[:: max(1, len(images) // sample)][:sample]
    if len(picked) < 10:
        return ""
    counts = [_count_text_bands(image) for image in picked]
    nonempty = [c for c in counts if c > 0]
    if not nonempty:
        return ""
    multi = sum(1 for c in nonempty if c >= 2)
    heavy = sum(1 for c in nonempty if c >= 3)
    if multi / len(nonempty) > 0.70 or heavy / len(nonempty) > 0.25:
        return (
            f"⚠ {multi}/{len(nonempty)} ảnh phụ đề chứa NHIỀU dải chữ — video này "
            "có thể burn phụ đề 2 lần (bản to + bản nhỏ) và vùng OCR đang trùm cả "
            "hai. OCR sẽ dễ ra chữ rác. Nên khoanh lại vùng OCR ôm sát MỘT bản "
            "phụ đề rõ nhất rồi tách lại."
        )
    return ""


def _requires_single_panel(sub) -> bool:
    """Ưu tiên OCR riêng cho cue cực nhanh hoặc có vùng nét chữ rất ngắn."""
    duration = max(0.0, float(sub.end) - float(sub.start))
    if duration <= 0.45:
        return True
    if duration > 1.20 or getattr(sub, "image", None) is None:
        return False
    try:
        mask = _bright_stroke_mask(sub.image)
        active_columns = mask.any(axis=0)
        positions = active_columns.nonzero()[0]
        if len(positions) == 0:
            return False
        width = max(1, int(mask.shape[1]))
        span_ratio = (int(positions[-1]) - int(positions[0]) + 1) / width
        coverage_ratio = float(active_columns.mean())
        # Một–hai chữ CJK thường chỉ chiếm một dải hẹp giữa ROI. Gửi riêng để
        # không phụ thuộc reading order của montage.
        return span_ratio <= 0.24 and coverage_ratio <= 0.14
    except Exception:  # noqa: BLE001 - phân loại tối ưu, lỗi thì dùng batch thường
        return False


def _ocr_lane_for_candidate(sub) -> str:
    """Default to the fast legacy OCR lane.

    Splitting short cues into separate OCR requests was accurate in narrow cases
    but too slow in real videos because it multiplied request count. Keep the
    hook for future controlled experiments, but production runs should batch all
    candidates normally unless an explicit safety mode forces single panels.
    """
    return "normal"


class _StreamingMontageOcr:
    """Disk-backed producer/consumer OCR used while video detection is running.

    Candidate order is never inferred from worker completion order.  The
    detector assigns a stable integer id, every worker writes by that id, and
    the caller rebuilds the timeline only after all in-flight batches finish.
    """

    _EOF = object()
    _STOP = object()

    def __init__(
        self,
        clients,
        lang_hint: str,
        batch_size: int,
        checkpoint_dir: str | None,
        is_cancelled: CancelFn,
        report: ProgressFn,
        account_labels: list[str] | None = None,
        flush_seconds: float = 1.0,
    ) -> None:
        if not isinstance(clients, (list, tuple)):
            clients = [clients]
        self.clients = list(clients)
        if not self.clients:
            raise RuntimeError("Không có tài khoản xử lý nào hoạt động.")
        self.lang_hint = lang_hint
        reliable_batch = min(
            [20, *[
                int(getattr(client, "max_reliable_batch", 20) or 20)
                for client in self.clients
            ]]
        )
        self.batch_size = max(1, min(reliable_batch, int(batch_size)))
        self.flush_seconds = max(0.1, float(flush_seconds))
        self.is_cancelled = is_cancelled
        self.report = report
        labels = list(account_labels or [])
        self.account_labels = [
            (
                labels[index]
                if index < len(labels) and str(labels[index]).strip()
                else f"Tài khoản {index + 1}"
            )
            for index in range(len(self.clients))
        ]
        self.account_activity = ["chờ"] * len(self.clients)
        protocols = {
            str(getattr(client, "checkpoint_protocol", "") or "").strip()
            for client in self.clients
        }
        protocols.discard("")
        self.checkpoint_protocol = (
            "|".join(sorted(protocols)) if protocols else ""
        )
        self._force_single_short_panels = (
            "remote-centered-v3" not in self.checkpoint_protocol
        )
        # Remote OCR server v3 is allowed to scale account count independently
        # from the app.  The app therefore should not wait a long fixed window
        # hoping to fill a 20-image batch: that starves the server while local
        # scan is still running.  Keep the max batch at 20 for dense dialogue,
        # but flush partial batches quickly so scan and OCR overlap in practice.
        # Short/narrow lanes only apply to old/local engines; centered-v3 can
        # keep everything in the normal stream.
        self.short_batch_size = 5
        self.single_batch_size = 1
        self.short_flush_seconds = 1.5
        if not self._force_single_short_panels:
            self.flush_seconds = min(max(self.flush_seconds, 0.8), 1.2)
        self.input_queue: queue.Queue = queue.Queue()
        self.batch_queue: queue.Queue = queue.Queue()
        self.lock = threading.RLock()
        self.results: dict[int, str] = {}
        self.failed: set[int] = set()
        self.submitted = 0
        self.completed = 0
        self.fatal_error = ""
        self.batches_sent = 0
        self.images_sent = 0
        self.ocr_seconds = 0.0
        self.client_split_retries = 0
        self.batch_sizes: list[int] = []
        self.ocr_latencies: list[float] = []
        self.queue_wait_latencies: list[float] = []
        self.emitted_batches = 0
        self.emitted_images = 0
        self.emit_small_1_5 = 0
        self.emit_mid_6_10 = 0
        self.emit_mid_11_14 = 0
        self.emit_full_15_plus = 0
        self.normal_batches = 0
        self.normal_images = 0
        self.short_batches = 0
        self.short_images = 0
        self.single_batches = 0
        self.single_images = 0
        self.checkpoint = (
            Path(checkpoint_dir) / "streaming"
            if checkpoint_dir else None
        )
        if self.checkpoint:
            self.checkpoint.mkdir(parents=True, exist_ok=True)
        self.worker_client_indexes = list(range(len(self.clients)))
        if len(self.clients) == 1:
            remote_parallel = int(getattr(self.clients[0], "parallel", 1) or 1)
            if remote_parallel > 1:
                self.worker_client_indexes = [0] * remote_parallel
        self.account_ready = [True] * len(self.worker_client_indexes)
        self.account_cooldown = [0.0] * len(self.worker_client_indexes)
        self.batcher = threading.Thread(
            target=self._batcher, name="ocr-batcher", daemon=True,
        )
        self.workers = [
            threading.Thread(
                target=self._worker,
                args=(worker_index,),
                name=f"ocr-account-{worker_index + 1}",
                daemon=True,
            )
            for worker_index in range(len(self.worker_client_indexes))
        ]
        self.batcher.start()
        for worker in self.workers:
            worker.start()

    @staticmethod
    def _fingerprint(image) -> str:
        digest = hashlib.sha256()
        digest.update(str(getattr(image, "mode", "")).encode("ascii", "ignore"))
        digest.update(str(getattr(image, "size", "")).encode("ascii", "ignore"))
        digest.update(image.tobytes())
        return digest.hexdigest()[:24]

    def _manifest_path(self, candidate_id: int) -> Path | None:
        if not self.checkpoint:
            return None
        return self.checkpoint / f"candidate_{candidate_id:07d}.json"

    def _save(
        self,
        candidate_id: int,
        sub,
        fingerprint: str,
        status: str,
        text: str = "",
        error: str = "",
    ) -> None:
        path = self._manifest_path(candidate_id)
        if path is None:
            return
        payload = {
            "candidate_id": candidate_id,
            "start": float(sub.start),
            "end": float(sub.end),
            "fingerprint": fingerprint,
            "ocr_protocol": self.checkpoint_protocol,
            "status": status,
            "text": text,
            "last_error": error,
        }
        temp = path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(payload, ensure_ascii=False), encoding="utf-8",
        )
        os.replace(temp, path)

    def submit(self, candidate_id: int, sub) -> None:
        """Persist before enqueueing so cancellation/account failure loses no id."""
        fingerprint = self._fingerprint(sub.image)
        restored = ""
        restored_empty = False
        path = self._manifest_path(candidate_id)
        if path and path.exists():
            try:
                saved = json.loads(path.read_text(encoding="utf-8"))
                same_candidate = (
                    saved.get("fingerprint") == fingerprint
                    and abs(float(saved.get("start", -1)) - float(sub.start)) < 0.002
                    and abs(float(saved.get("end", -1)) - float(sub.end)) < 0.002
                    and (
                        not self.checkpoint_protocol
                        or saved.get("ocr_protocol") == self.checkpoint_protocol
                    )
                )
                if same_candidate and saved.get("status") == "done":
                    restored = str(saved.get("text", "") or "").strip()
                elif same_candidate and saved.get("status") == "empty":
                    restored_empty = True
            except (OSError, ValueError, TypeError):
                pass
        with self.lock:
            self.submitted += 1
            if restored:
                self.results[candidate_id] = restored
                self.completed += 1
                return
            if restored_empty:
                self.failed.add(candidate_id)
                self.completed += 1
                return
        self._save(candidate_id, sub, fingerprint, "pending")
        self.input_queue.put((candidate_id, sub, fingerprint))

    def _batcher(self) -> None:
        pending = []
        short_pending = []
        single_pending = []
        eof = False

        def emit_from(buffer: list, count: int, lane: str) -> None:
            if count <= 0:
                return
            batch = {
                "items": buffer[:count],
                "attempts": 0,
                "tried": set(),
                "emitted_at": time.perf_counter(),
                "lane": lane,
            }
            del buffer[:count]
            with self.lock:
                self.emitted_batches += 1
                self.emitted_images += count
                if count <= 5:
                    self.emit_small_1_5 += 1
                elif count <= 10:
                    self.emit_mid_6_10 += 1
                elif count <= 14:
                    self.emit_mid_11_14 += 1
                else:
                    self.emit_full_15_plus += 1
                if lane == "single":
                    self.single_batches += 1
                    self.single_images += count
                elif lane == "short":
                    self.short_batches += 1
                    self.short_images += count
                else:
                    self.normal_batches += 1
                    self.normal_images += count
            self.batch_queue.put(batch)

        while not eof:
            if single_pending or short_pending:
                timeout = min(self.short_flush_seconds, self.flush_seconds)
            elif pending:
                timeout = self.flush_seconds
            else:
                timeout = 0.2
            try:
                item = self.input_queue.get(timeout=timeout)
            except queue.Empty:
                item = None
            if item is self._EOF:
                eof = True
                self.input_queue.task_done()
            elif item is not None:
                lane = _ocr_lane_for_candidate(item[1])
                if not self._force_single_short_panels:
                    lane = "normal"
                if self._force_single_short_panels and _requires_single_panel(item[1]):
                    lane = "single"
                if lane == "single":
                    # Giữ thứ tự queue dễ theo dõi log; kết quả cuối vẫn ráp ID.
                    single_pending.append(item)
                    if len(single_pending) >= self.single_batch_size:
                        emit_from(single_pending, self.single_batch_size, "single")
                elif lane == "short":
                    short_pending.append(item)
                    if len(short_pending) >= self.short_batch_size:
                        emit_from(short_pending, self.short_batch_size, "short")
                else:
                    pending.append(item)
                self.input_queue.task_done()
            fast_timeout = item is None and bool(single_pending or short_pending)
            if single_pending and (
                len(single_pending) >= self.single_batch_size or item is None or eof
            ):
                emit_from(single_pending, min(self.single_batch_size, len(single_pending)), "single")
            if short_pending and (
                len(short_pending) >= self.short_batch_size or item is None or eof
            ):
                emit_from(short_pending, min(self.short_batch_size, len(short_pending)), "short")
            if pending and (
                len(pending) >= self.batch_size
                or eof
                or (item is None and not fast_timeout)
            ):
                emit_from(pending, min(self.batch_size, len(pending)), "normal")
            # EOF may leave more than one full batch in the local buffer.
            if eof:
                while single_pending:
                    emit_from(single_pending, min(self.single_batch_size, len(single_pending)), "single")
                while short_pending:
                    emit_from(short_pending, min(self.short_batch_size, len(short_pending)), "short")
                while pending:
                    emit_from(pending, min(self.batch_size, len(pending)), "normal")

    @staticmethod
    def _error_kind(exc: Exception) -> str:
        from vicdub.api.drive_ocr_client import classify_drive_error  # noqa: PLC0415

        classified = classify_drive_error(exc)
        if classified == "permanent_account":
            return "permanent"
        if classified == "rate_limit":
            return "cooldown"
        return "retry"

    def _finish_items(self, items, parsed: dict) -> None:
        completed = []
        with self.lock:
            for candidate_id, sub, fingerprint in items:
                value = str(parsed.get(candidate_id, "") or "").strip()
                if value:
                    self.results[candidate_id] = value
                    self._save(
                        candidate_id, sub, fingerprint, "done", text=value,
                    )
                else:
                    self.failed.add(candidate_id)
                    self._save(candidate_id, sub, fingerprint, "empty")
                self.completed += 1
                completed.append(candidate_id)
            done = self.completed
            total = self.submitted
        self.report(
            0,
            f"Đang quét và nhận diện đồng thời — OCR {done}/{total} câu đã phát hiện"
            + " — đang dùng "
            + ", ".join(
                self.account_labels[index]
                for index, state in enumerate(self.account_activity)
                if state == "đang làm"
            ),
        )

    def _mark_pending_error(self, items, message: str) -> None:
        with self.lock:
            for candidate_id, sub, fingerprint in items:
                self.failed.add(candidate_id)
                self._save(
                    candidate_id, sub, fingerprint, "pending", error=message,
                )
                self.completed += 1

    def snapshot_stats(self) -> dict:
        with self.lock:
            latencies = list(self.ocr_latencies)
            sizes = list(self.batch_sizes)
            return {
                "submitted": int(self.submitted),
                "completed": int(self.completed),
                "failed": len(self.failed),
                "emitted_batches": int(self.emitted_batches),
                "emitted_images": int(self.emitted_images),
                "emit_small_1_5": int(self.emit_small_1_5),
                "emit_mid_6_10": int(self.emit_mid_6_10),
                "emit_mid_11_14": int(self.emit_mid_11_14),
                "emit_full_15_plus": int(self.emit_full_15_plus),
                "normal_batches": int(self.normal_batches),
                "normal_images": int(self.normal_images),
                "short_batches": int(self.short_batches),
                "short_images": int(self.short_images),
                "single_batches": int(self.single_batches),
                "single_images": int(self.single_images),
                "batches_sent": int(self.batches_sent),
                "images_sent": int(self.images_sent),
                "ocr_seconds": float(self.ocr_seconds),
                "avg_batch_size": sum(sizes) / len(sizes) if sizes else 0.0,
                "max_batch_size": max(sizes) if sizes else 0,
                "avg_batch_seconds": sum(latencies) / len(latencies) if latencies else 0.0,
                "max_batch_seconds": max(latencies) if latencies else 0.0,
                "avg_queue_wait_seconds": (
                    sum(self.queue_wait_latencies) / len(self.queue_wait_latencies)
                    if self.queue_wait_latencies else 0.0
                ),
                "max_queue_wait_seconds": (
                    max(self.queue_wait_latencies)
                    if self.queue_wait_latencies else 0.0
                ),
                "client_split_retries": int(self.client_split_retries),
            }

    def _worker(self, account_index: int) -> None:
        client_index = self.worker_client_indexes[account_index]
        client = self.clients[client_index]
        while True:
            item = self.batch_queue.get()
            if item is self._STOP:
                self.batch_queue.task_done()
                return
            batch = item
            items = batch["items"]
            try:
                emitted_at = float(batch.get("emitted_at") or time.perf_counter())
                with self.lock:
                    self.queue_wait_latencies.append(
                        max(0.0, time.perf_counter() - emitted_at)
                    )
                if self.is_cancelled():
                    self._mark_pending_error(items, "cancelled")
                    continue
                if not self.account_ready[account_index]:
                    if not any(self.account_ready):
                        self.fatal_error = (
                            "Tất cả tài khoản nhận diện đều mất hiệu lực; "
                            "candidate đã được giữ trong checkpoint."
                        )
                        self._mark_pending_error(items, self.fatal_error)
                    else:
                        self.batch_queue.put(batch)
                        time.sleep(0.05)
                    continue
                cooldown = self.account_cooldown[account_index] - time.monotonic()
                if cooldown > 0:
                    self.batch_queue.put(batch)
                    time.sleep(min(0.25, cooldown))
                    continue
                if (
                    account_index in batch["tried"]
                    and len(batch["tried"]) < sum(self.account_ready)
                ):
                    self.batch_queue.put(batch)
                    time.sleep(0.02)
                    continue
                batch["tried"].add(account_index)
                batch["attempts"] += 1
                self.account_activity[account_index] = "đang làm"
                self.report(
                    0,
                    f"{self.account_labels[account_index]} đang nhận diện "
                    f"{len(items)} ảnh...",
                )
                # ID nội bộ luôn 0-based. Marker montage phải bắt đầu từ 1 để
                # tương thích Drive Docs và không sinh marker 0/-1. Kết quả
                # được ánh xạ ngược bằng dict, tuyệt đối không theo thứ tự
                # worker hoàn thành.
                transport_ids = [
                    candidate_id + 1 for candidate_id, _sub, _fp in items
                ]
                transport_to_candidate = {
                    transport_id: candidate_id
                    for transport_id, (candidate_id, _sub, _fp)
                    in zip(transport_ids, items)
                }
                montage = client.build_montage(
                    [sub.image for _candidate_id, sub, _fp in items],
                    transport_ids,
                )
                ocr_started = time.perf_counter()
                parsed_transport = client.read_subtitle_montage(
                    montage, transport_ids, self.lang_hint,
                )
                ocr_elapsed = time.perf_counter() - ocr_started
                with self.lock:
                    self.batches_sent += 1
                    self.images_sent += len(items)
                    self.ocr_seconds += ocr_elapsed
                    self.batch_sizes.append(len(items))
                    self.ocr_latencies.append(ocr_elapsed)
                parsed = {
                    transport_to_candidate[transport_id]: value
                    for transport_id, value in parsed_transport.items()
                    if transport_id in transport_to_candidate
                }
                self._finish_items(items, parsed)
                self.account_activity[account_index] = "sẵn sàng"
            except Exception as exc:  # noqa: BLE001
                message = str(exc).lower()
                if len(items) > 1 and "montage_marker_invalid" in message:
                    with self.lock:
                        self.client_split_retries += 1
                    # Lỗi ánh xạ là lỗi bố cục của chính lô ảnh, đổi tài khoản
                    # không giúp. Chia đôi ngay; nếu vẫn lỗi sẽ tự về một ảnh.
                    middle = max(1, len(items) // 2)
                    for child in (items[:middle], items[middle:]):
                        self.batch_queue.put({
                            "items": child, "attempts": 0, "tried": set(),
                        })
                    self.account_activity[account_index] = "chia lô an toàn"
                    continue
                kind = self._error_kind(exc)
                if kind == "permanent":
                    self.account_ready[account_index] = False
                    self.account_activity[account_index] = "lỗi"
                    self.report(
                        0,
                        f"{self.account_labels[account_index]} mất hiệu lực; "
                        "đang chuyển lô sang tài khoản khác.",
                    )
                    self.batch_queue.put(batch)
                elif kind == "cooldown":
                    # Keep the batch pending.  A healthy account can take it;
                    # otherwise this worker resumes after its own cooldown.
                    self.account_cooldown[account_index] = (
                        time.monotonic() + min(30.0, 2.0 ** min(5, batch["attempts"]))
                    )
                    self.account_activity[account_index] = "tạm nghỉ"
                    self.report(
                        0,
                        f"{self.account_labels[account_index]} đang bị giới hạn; "
                        "tạm nghỉ và chuyển việc sang tài khoản khác.",
                    )
                    batch["tried"].discard(account_index)
                    self.batch_queue.put(batch)
                elif batch["attempts"] < max(2, len(self.clients) * 2):
                    self.account_activity[account_index] = "thử lại"
                    self.batch_queue.put(batch)
                elif len(items) > 1:
                    middle = max(1, len(items) // 2)
                    for child in (items[:middle], items[middle:]):
                        self.batch_queue.put({
                            "items": child, "attempts": 0, "tried": set(),
                        })
                else:
                    self._mark_pending_error(items, str(exc))
            finally:
                self.batch_queue.task_done()

    def finish(self) -> tuple[dict[int, str], list[int]]:
        """EOF flush, then wait for every in-flight/retried batch."""
        self.input_queue.put(self._EOF)
        self.input_queue.join()
        self.batcher.join()
        self.batch_queue.join()
        for _worker in self.workers:
            self.batch_queue.put(self._STOP)
        self.batch_queue.join()
        for worker in self.workers:
            worker.join(timeout=2.0)
        if self.fatal_error:
            raise RuntimeError(self.fatal_error)
        with self.lock:
            return dict(self.results), sorted(self.failed)


def detect_ocr_video(
    video_path: str,
    ffmpeg_bin: str,
    client,
    crop: tuple[int, int, int, int],
    scan_fps: float = 12.0,
    batch: int = 20,
    lang_hint: str = "",
    duration: float = 0.0,
    min_duration: float = 0.12,
    progress: ProgressFn | None = None,
    cancelled: CancelFn | None = None,
    checkpoint_dir: str | None = None,
    vision_client=None,
    account_labels: list[str] | None = None,
    picked_colors: list | None = None,
    color_tolerance: int = 45,
    scan_start: float = 0.0,
    scan_end: float | None = None,
    fast_postprocess: bool = False,
) -> list[Segment]:
    """Phát hiện (streaming state machine) + OCR. Trả segments timing chuẩn.

    ``vision_client`` có -> đọc chữ bằng Cloud Vision (nhanh & chính xác hơn);
    None -> giữ nguyên đường Drive OCR cũ.
    """
    report_lock = threading.Lock()
    last_report_pct = [0]
    run_started = time.perf_counter()
    scan_seconds = 0.0
    ocr_wait_seconds = 0.0
    post_seconds = 0.0
    stream_stats: dict = {}

    def report(pct: int, msg: str) -> None:
        if progress:
            # Detector and OCR workers report from different threads. Never let
            # a slower detector update move the visible progress bar backward.
            with report_lock:
                last_report_pct[0] = max(last_report_pct[0], int(pct))
                progress(last_report_pct[0], msg)

    def is_cancelled() -> bool:
        return bool(cancelled and cancelled())

    clients = list(client) if isinstance(client, (list, tuple)) else [client]
    streaming_supported = (
        vision_client is None
        and bool(clients)
        and all(
            callable(getattr(item, "build_montage", None))
            and callable(getattr(item, "read_subtitle_montage", None))
            for item in clients
        )
    )
    stream_pool = None
    if streaming_supported:
        stream_pool = _StreamingMontageOcr(
            clients, lang_hint, batch, checkpoint_dir, is_cancelled, report,
            account_labels=account_labels,
        )

    streamed_ids = 0
    near_misses: list[DetectedSub] = []

    def on_candidate(sub) -> None:
        nonlocal streamed_ids
        if stream_pool is not None:
            stream_pool.submit(streamed_ids, sub)
            streamed_ids += 1

    def on_near_miss(sub) -> None:
        near_misses.append(sub)

    scan_started = time.perf_counter()
    try:
        subs = detect_subtitles(
            ffmpeg_bin, video_path, crop, scan_fps=scan_fps,
            report=report, is_cancelled=is_cancelled, duration=duration,
            # OCR is the final judge.  Do not drop 0.05–0.10s dialogue at the
            # detector layer; short one-word replies are common in fast drama
            # dialogue and must keep their own candidate/time.
            min_duration=0.0,
            enter_frames=1,
            change_frames=1,
            # Recall-first cho hội thoại nhanh/chữ ngắn: chấp nhận cả mask thưa và
            # hẹp. OCR phía sau mới là nơi quyết định ảnh có thực sự chứa phụ đề.
            min_text_density=0.002,
            min_col_coverage=0.025,
            # Mask đã khóa vào nét sáng có viền tối. Mức 0.015 tách đổi glyph
            # tốt hơn mặc định mà không băm nền thành hàng trăm track rác.
            mask_threshold=0.015,
            # Frame-true OCR mode: do not bridge blanks.  If the hard subtitle
            # disappears for a sampled frame, close the cue there; postprocess
            # may merge only exact duplicate text caused by one-frame flicker.
            max_gap_seconds=0.0,
            on_candidate=on_candidate if stream_pool is not None else None,
            on_near_miss=on_near_miss,
            picked_colors=picked_colors,
            color_tolerance=color_tolerance,
            scan_start=scan_start,
            scan_end=scan_end,
        )
        scan_seconds = time.perf_counter() - scan_started
    except Exception:
        # Do not leak OCR worker threads when FFmpeg/detection fails halfway.
        if stream_pool is not None:
            stream_pool.finish()
        raise
    if not subs:
        if stream_pool is not None:
            stream_pool.finish()
        raise RuntimeError("Không phát hiện được câu phụ đề nào từ video.")

    # Compatibility with custom detectors/tests that return a list but do not
    # invoke the streaming callback. Production detection emits each item once.
    if stream_pool is not None and streamed_ids < len(subs):
        for candidate_id in range(streamed_ids, len(subs)):
            stream_pool.submit(candidate_id, subs[candidate_id])
        streamed_ids = len(subs)

    # Tuyệt đối không gộp theo hình/nét trước OCR. Hai câu thoại cực ngắn có thể
    # cùng độ dài và bố cục nên phép so mask/stroke dễ nuốt mất một câu thật.
    # Chấp nhận gửi dư ảnh; sau OCR chỉ gộp khi text giống HỆT và nằm sát nhau.

    images = [s.image for s in subs]
    band_warning = double_subtitle_warning(images)
    if band_warning:
        logger.warning(band_warning)
        report(39, band_warning)
    if vision_client is not None:
        # Vision: 40 câu/ảnh, 16 ảnh/request -> video 2h chỉ ~3 lần gọi mạng (Drive
        # cần ~114). Ánh xạ câu bằng toạ độ pixel nên không cần marker/lọc script.
        report(40, f"Đang đọc {len(images)} câu (chế độ nhận diện nhanh)...")
        texts, failed = vision_client.read_images(
            images, lang_hint, report=report, is_cancelled=is_cancelled,
        )
    elif stream_pool is not None:
        report(
            40,
            f"Đã quét {len(images)} ảnh; đang hoàn tất các lô nhận diện còn lại...",
        )
        ocr_wait_started = time.perf_counter()
        by_id, failed = stream_pool.finish()
        ocr_wait_seconds = time.perf_counter() - ocr_wait_started
        stream_stats = stream_pool.snapshot_stats()
        # Completion order is deliberately ignored. The detector id is the only
        # join key, so four accounts and retries cannot shift subtitles.
        texts = [str(by_id.get(index, "") or "") for index in range(len(subs))]
    else:
        # Đo thực trên Drive: nâng 4 -> 20 panel/montage cho recall Y HỆT nhưng
        # giảm ~5x số API call và ~4x thời gian (marker @@@ vẫn sống 100%). Trước
        # đây tham số `batch` bị bỏ qua (kẹt cứng 4) nên OCR chậm vô ích.
        panels = max(1, int(batch))
        report(40, f"Đang đọc {len(images)} ảnh phụ đề "
                   f"({panels} câu mỗi lượt, nhiều tài khoản song song)...")
        texts, failed = _ocr_montage_pool(
            client, images, lang_hint, report, batch_size=panels,
            is_cancelled=is_cancelled, checkpoint_dir=checkpoint_dir,
        )

    post_started = time.perf_counter()

    # If the first complete pass reads almost nothing, retries only waste several
    # minutes on the same invalid crop/account state. Abort early and preserve the
    # project; a normal subtitle strip returns text for far more than 5% of panels.
    first_pass_count = sum(bool(value.strip()) for value in texts)
    if len(images) >= 20 and first_pass_count / len(images) < 0.05:
        raise OcrQualityError(
            f"Chỉ đọc được {first_pass_count}/{len(images)} ảnh ở lượt đầu. "
            "Đã dừng sớm vì vùng phụ đề hoặc dịch vụ nhận diện đang bất thường; "
            "kết quả cũ được giữ nguyên."
        )

    blank_rescued = 0
    blank_checked = 0
    # Streaming Drive path intentionally keeps the fast first pass montage-only.
    # At EOF, retry only blank panels that still look like stable subtitle text.
    # This catches one/two-character lines without turning every bright scene
    # edge into an extra network request.
    if (
        stream_pool is not None
        and failed
        and not fast_postprocess
        and not is_cancelled()
    ):
        texts, failed, blank_rescued, blank_checked = _rescue_blank_montage(
            clients, subs, images, texts, failed, lang_hint, report,
            is_cancelled, checkpoint_dir,
        )

    # Header OCR can occasionally leak fragments such as ``E 请`` or
    # ``ANCH 明白`` into a valid CJK panel. Re-read only those suspicious panels
    # without a montage/header. This also preserves legitimate mixed text: if the
    # source really says ``AI 技术``, individual OCR returns the same wording.
    chinese_source = _is_chinese_timeline(texts, lang_hint)
    suspect_checked = 0
    suspect_changed = 0
    if (
        stream_pool is not None
        and len(images) >= 8
        and not fast_postprocess
        and not is_cancelled()
    ):
        failed_set_for_suspect = set(failed)
        ranked_suspects = [
            (_suspect_ocr_score(index, subs, texts, chinese_source), index)
            for index in range(len(texts))
        ]
        ranked_suspects = [
            item for item in ranked_suspects
            if item[0] >= 3 and item[1] not in failed_set_for_suspect
        ]
        ranked_suspects.sort(key=lambda item: (-item[0], item[1]))
        max_suspect_checks = max(5, min(80, (len(texts) + 4) // 5))
        suspect_indexes = [
            index for _score, index in ranked_suspects[:max_suspect_checks]
        ]
        suspect_indexes.sort()
        if suspect_indexes:
            suspect_checked = len(suspect_indexes)
            suspect_batch = max(8, min(20, int(batch)))
            report(
                96,
                f"Kiểm tra phụ {suspect_checked} dòng nghi gộp/nhiễu "
                f"({suspect_batch} ảnh/lượt)...",
            )
            suspect_dir = (
                str(Path(checkpoint_dir) / "suspect_batch_v1")
                if checkpoint_dir else None
            )
            try:
                suspect_texts, _ = _ocr_montage_pool(
                    clients,
                    [images[index] for index in suspect_indexes],
                    lang_hint,
                    lambda _pct, _message: None,
                    batch_size=suspect_batch,
                    is_cancelled=is_cancelled,
                    checkpoint_dir=suspect_dir,
                )
            except Exception as exc:
                logger.warning("Bỏ qua lượt kiểm tra phụ OCR: %s", exc)
                suspect_texts = [""] * len(suspect_indexes)
            for source_index, candidate_text in zip(suspect_indexes, suspect_texts):
                duration_value = max(
                    0.0, float(subs[source_index].end) - float(subs[source_index].start)
                )
                if _prefer_second_pass_ocr(
                    texts[source_index], candidate_text, duration_value, chinese_source,
                ):
                    texts[source_index] = candidate_text.strip()
                    suspect_changed += 1

    local_clean_count = 0
    if chinese_source:
        for index, value in enumerate(texts):
            if _can_clean_mixed_chinese_locally(value):
                cleaned_value = _strip_foreign_noise_from_chinese(value)
                if cleaned_value and cleaned_value != value.strip():
                    texts[index] = cleaned_value
                    local_clean_count += 1
    suspicious = [
        index for index, value in enumerate(texts)
        if _has_suspicious_latin_prefix(value)
        or (chinese_source and _FOREIGN_ALPHA_RE.search(value or ""))
    ]
    if suspicious and not fast_postprocess and not is_cancelled():
        rescue_batch = max(8, min(20, int(batch)))
        report(
            97,
            f"Đang kiểm tra nhanh {len(suspicious)} dòng nghi nhiễu "
            f"({rescue_batch} dòng/lượt)...",
        )
        mixed_dir = str(Path(checkpoint_dir) / "mixed_batch") if checkpoint_dir else None
        try:
            cleaned, _ = _ocr_montage_pool(
                clients,
                [_enhance_failed_image(images[index]) for index in suspicious],
                lang_hint,
                lambda _pct, _message: None,
                batch_size=rescue_batch,
                is_cancelled=is_cancelled,
                checkpoint_dir=mixed_dir,
            )
        except Exception as exc:  # cleanup failure must not erase successful OCR
            logger.warning("Bỏ qua lượt kiểm tra nhiễu theo lô: %s", exc)
            cleaned = [""] * len(suspicious)
        for source_index, clean_text in zip(suspicious, cleaned):
            clean_text = clean_text.strip()
            if clean_text:
                old_cjk = len(_CJK_RE.findall(texts[source_index]))
                new_cjk = len(_CJK_RE.findall(clean_text))
                # Prefer the rescue only when it recovers at least as much CJK.
                # Otherwise retain the original core for deterministic cleanup.
                if not chinese_source or new_cjk >= old_cjk:
                    texts[source_index] = clean_text
            else:
                texts[source_index] = re.sub(
                    r"^[A-Za-z]{1,12}\s+(?=[\u3400-\u9fff])", "",
                    texts[source_index].strip(), count=1,
                )

    # Some vertical dramas contain small scene/UI text behind a much larger
    # subtitle. OCR then concatenates both layers into one nonsense sentence.
    # Keep the untouched OCR as branch A and re-read a reconstructed dominant
    # subtitle layer as branch B. Only suspicious panels pay this network cost.
    ocr_warnings = [""] * len(texts)
    layered = []
    cjk_lengths = sorted(
        len(_CJK_RE.findall(value or ""))
        for value in texts if _CJK_RE.search(value or "")
    )
    typical_cjk_length = (
        float(cjk_lengths[len(cjk_lengths) // 2]) if cjk_lengths else 0.0
    )
    ranked_layer_candidates = []
    if chinese_source and not fast_postprocess:
        for index, (sub, value) in enumerate(zip(subs, texts)):
            score = _layered_text_suspicion(
                value, max(0.0, sub.end - sub.start), typical_cjk_length,
            )
            if score:
                ranked_layer_candidates.append((score, index))
    # Even a pathological UI-heavy video must never schedule thousands of
    # second-pass requests. Keep at most 1% of the timeline, capped at 32 rows.
    max_layer_checks = max(8, min(32, (len(texts) + 99) // 100))
    ranked_layer_candidates.sort(reverse=True)
    for score, index in ranked_layer_candidates[:max_layer_checks]:
        image = images[index]
        cleaned_image, confidence, reason = _dominant_subtitle_layer(image)
        if cleaned_image is not None:
            layered.append((index, cleaned_image, confidence, reason, score))
    # OCR completion and anomaly ranking order must not affect temporal logic.
    layered.sort(key=lambda item: item[0])
    layered_checked = 0
    layered_changed = 0
    if layered and not is_cancelled():
        layered_checked = len(layered)
        report(97, f"Kiểm tra {layered_checked} dòng nghi có nhiều lớp chữ...")
        filtered_images = [item[1] for item in layered]
        layered_dir = (
            str(Path(checkpoint_dir) / "layer_filter_v1")
            if checkpoint_dir else None
        )
        try:
            if vision_client is not None:
                filtered_texts, _ = vision_client.read_images(
                    filtered_images, lang_hint,
                    report=lambda _pct, _message: None,
                    is_cancelled=is_cancelled,
                )
            else:
                filtered_texts, _ = _ocr_montage_pool(
                    clients, filtered_images, lang_hint,
                    lambda _pct, _message: None,
                    batch_size=max(4, min(8, int(batch))),
                    is_cancelled=is_cancelled,
                    checkpoint_dir=layered_dir,
                )
        except Exception as exc:  # the primary OCR remains a valid fallback
            logger.warning("Bỏ qua nhánh kiểm tra nhiều lớp chữ: %s", exc)
            filtered_texts = [""] * len(layered)
        filtered_texts = list(filtered_texts or [])
        if len(filtered_texts) < len(layered):
            filtered_texts.extend([""] * (len(layered) - len(filtered_texts)))

        resolved_layered = []
        for item, filtered_text in zip(layered, filtered_texts):
            source_index, clean_image, confidence, reason, score = item
            previous_text = texts[source_index]
            resolved, warning = _resolve_layered_ocr(
                previous_text, filtered_text, confidence, reason, score,
            )
            texts[source_index] = resolved
            ocr_warnings[source_index] = warning
            resolved_layered.append(
                (source_index, clean_image, resolved, warning)
            )
            if resolved != previous_text:
                layered_changed += 1

        # A noisy UI often splits one visible subtitle into several 0.08–0.3s
        # tracks. Stabilise only adjacent warning rows whose isolated main-text
        # strokes still overlap; real fast dialogue with different glyphs stays
        # separate. The longer medoid wins ties, restoring complete phrases.
        for position in range(1, len(resolved_layered)):
            previous = resolved_layered[position - 1]
            current = resolved_layered[position]
            previous_index, previous_image, previous_value, previous_warning = previous
            current_index, current_image, current_value, current_warning = current
            gap = subs[current_index].start - subs[previous_index].end
            similarity = _text_similarity(previous_value, current_value)
            overlap = stroke_overlap(previous_image, current_image)
            if (
                previous_warning and current_warning
                and gap <= 0.12
                and similarity >= 0.55
                and overlap >= 0.48
            ):
                consensus = _choose_consensus_text([previous_value, current_value])
                texts[previous_index] = consensus
                texts[current_index] = consensus
                note = "Đã ổn định theo các khung chữ chính liền nhau."
                if note not in ocr_warnings[previous_index]:
                    ocr_warnings[previous_index] += f" {note}"
                if note not in ocr_warnings[current_index]:
                    ocr_warnings[current_index] += f" {note}"
                resolved_layered[position - 1] = (
                    previous_index, previous_image, consensus,
                    ocr_warnings[previous_index],
                )
                resolved_layered[position] = (
                    current_index, current_image, consensus,
                    ocr_warnings[current_index],
                )

    if failed:
        report(
            97,
            f"Bỏ qua {len(failed)} vùng OCR rỗng — không gửi lại; "
            "đang lưu mốc để có thể sửa thủ công.",
        )

    # OCR đã chạy thành công nhưng panel vẫn rỗng thường là detector bắt nhầm
    # vùng sáng/logo, không phải lỗi tài khoản. Không tạo dòng phụ đề rác; lưu
    # ảnh + timestamp riêng để người dùng có thể kiểm tra/khôi phục khi cần.
    if checkpoint_dir:
        rejected_dir = Path(checkpoint_dir) / "rejected_images"
        rejected_dir.mkdir(parents=True, exist_ok=True)
        failed_set = set(failed)
        for index, image in enumerate(images):
            path = rejected_dir / f"image_{index:06d}.png"
            if index in failed_set:
                image.convert("RGB").save(path)
            else:
                path.unlink(missing_ok=True)
        manifest = [
            {"image_id": index, "start": subs[index].start, "end": subs[index].end,
             "image": f"rejected_images/image_{index:06d}.png"}
            for index in failed
        ]
        (Path(checkpoint_dir) / "rejected.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # Final pass sees the complete timeline: clean foreign OCR noise for a
    # Chinese source, then compare only the 2–3 immediately adjacent tracks.
    # Fuzzy joining additionally requires matching on-screen strokes.
    segments, duplicate_count, foreign_count = _postprocess_ocr_segments(
        subs, texts, lang_hint, warnings=ocr_warnings,
    )
    gap_checked = 0
    gap_rescued = 0
    # Không giải mã/quét lại toàn bộ video ở 97%. Detector đã giữ near-miss ngay
    # trong lượt 25 fps; cuối pipeline chỉ OCR đúng các vùng đó.
    if (
        stream_pool is not None
        and near_misses
        and not fast_postprocess
        and not is_cancelled()
    ):
        gap_subs, gap_texts, gap_warnings, gap_checked = _rescue_near_misses(
            clients, near_misses, segments, lang_hint,
            report, is_cancelled, checkpoint_dir,
        )
        gap_rescued = len(gap_subs)
        if gap_subs:
            ordered = sorted(
                [
                    *zip(subs, texts, ocr_warnings),
                    *zip(gap_subs, gap_texts, gap_warnings),
                ],
                key=lambda item: (item[0].start, item[0].end),
            )
            merged_subs = [item[0] for item in ordered]
            merged_texts = [item[1] for item in ordered]
            merged_warnings = [item[2] for item in ordered]
            segments, duplicate_count, foreign_count = _postprocess_ocr_segments(
                merged_subs, merged_texts, lang_hint,
                warnings=merged_warnings,
            )
    suffix = f"; loại {len(failed)} vùng không có chữ (đã lưu ảnh kiểm tra)" if failed else ""
    if duplicate_count:
        suffix += f"; gộp {duplicate_count} track lặp/gần giống"
    if foreign_count:
        suffix += f"; làm sạch {foreign_count} dòng lẫn ký tự"
    if local_clean_count:
        suffix += f" ({local_clean_count} dòng xử lý nhanh tại máy)"
    if blank_checked:
        suffix += (
            f"; cứu {blank_rescued}/{blank_checked} ảnh rỗng còn dấu hiệu chữ"
        )
    if suspect_checked:
        suffix += (
            f"; kiểm tra phụ {suspect_checked} dòng nghi gộp/nhiễu"
            f" ({suspect_changed} dòng đã thay)"
        )
    if gap_checked:
        suffix += (
            f"; cứu {gap_rescued}/{gap_checked} phụ đề nhanh từ lượt quét chính"
        )
    if layered_checked:
        warning_count = sum(bool(segment.ocr_warning) for segment in segments)
        suffix += (
            f"; kiểm tra {layered_checked} ảnh nhiều lớp chữ"
            f" ({layered_changed} dòng đã lọc, {warning_count} dòng đánh dấu đỏ)"
        )
    post_seconds = time.perf_counter() - post_started
    total_seconds = time.perf_counter() - run_started
    batches_sent = int(stream_stats.get("batches_sent", 0) or 0)
    images_sent = int(stream_stats.get("images_sent", 0) or 0)
    avg_batch_size = float(stream_stats.get("avg_batch_size", 0.0) or 0.0)
    avg_batch_seconds = float(stream_stats.get("avg_batch_seconds", 0.0) or 0.0)
    split_retries = int(stream_stats.get("client_split_retries", 0) or 0)
    small_batches = int(stream_stats.get("emit_small_1_5", 0) or 0)
    mid_batches = int(stream_stats.get("emit_mid_6_10", 0) or 0)
    near_full_batches = int(stream_stats.get("emit_mid_11_14", 0) or 0)
    full_batches = int(stream_stats.get("emit_full_15_plus", 0) or 0)
    avg_queue_wait = float(stream_stats.get("avg_queue_wait_seconds", 0.0) or 0.0)
    normal_batches = int(stream_stats.get("normal_batches", 0) or 0)
    short_batches = int(stream_stats.get("short_batches", 0) or 0)
    single_batches = int(stream_stats.get("single_batches", 0) or 0)
    metric_parts = [
        f"tổng {_format_metric_seconds(total_seconds)}",
        f"quét {_format_metric_seconds(scan_seconds)}",
        f"chờ OCR {_format_metric_seconds(ocr_wait_seconds)}",
        f"hậu xử lý {_format_metric_seconds(post_seconds)}",
        f"{len(subs)} candidate",
    ]
    if batches_sent:
        metric_parts.append(
            f"{images_sent} ảnh/{batches_sent} batch"
            f" (TB {avg_batch_size:.1f} ảnh, {avg_batch_seconds:.1f}s/batch)"
        )
        metric_parts.append(
            f"phân bố batch 1-5:{small_batches}, 6-10:{mid_batches}, "
            f"11-14:{near_full_batches}, 15+:{full_batches}"
        )
        metric_parts.append(
            f"lane normal:{normal_batches}, short:{short_batches}, single:{single_batches}"
        )
        metric_parts.append(f"chờ queue TB {_format_metric_seconds(avg_queue_wait)}")
    if split_retries:
        metric_parts.append(f"{split_retries} lần tách batch lỗi")
    metrics_message = "Thống kê tách: " + "; ".join(metric_parts)
    if checkpoint_dir:
        stats_payload = {
            "total_seconds": total_seconds,
            "scan_seconds": scan_seconds,
            "ocr_wait_seconds": ocr_wait_seconds,
            "post_seconds": post_seconds,
            "candidates": len(subs),
            "segments": len(segments),
            "failed": len(failed),
            "duplicate_count": duplicate_count,
            "foreign_count": foreign_count,
            "blank_checked": blank_checked,
            "blank_rescued": blank_rescued,
            "suspect_checked": suspect_checked,
            "suspect_changed": suspect_changed,
            "gap_checked": gap_checked,
            "gap_rescued": gap_rescued,
            "layered_checked": layered_checked,
            "layered_changed": layered_changed,
            "stream": stream_stats,
        }
        try:
            Path(checkpoint_dir).mkdir(parents=True, exist_ok=True)
            (Path(checkpoint_dir) / "run_stats.json").write_text(
                json.dumps(stats_payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Không ghi được thống kê OCR: %s", exc)
    report(98, metrics_message)
    report(98, f"Xong: {len(segments)} dòng phụ đề{suffix}")
    if not segments:
        raise OcrQualityError("Không đọc được chữ từ ảnh phụ đề.")
    # A bad crop can make the detector follow motion/brightness while almost all
    # OCR panels contain no text. Never accept or silently fallback on that data.
    success_ratio = len(segments) / max(1, len(subs))
    if len(subs) >= 10 and (len(segments) < 3 or success_ratio < 0.20):
        raise OcrQualityError(
            f"Chỉ đọc được {len(segments)}/{len(subs)} ảnh "
            f"({success_ratio:.0%}). Vùng phụ đề có thể đang cắt mất chữ; "
            "kết quả này đã bị chặn và không được lưu."
        )
    return segments

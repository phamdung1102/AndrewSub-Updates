"""Subtitle Module - sinh phụ đề gốc.

Chọn nguồn theo cấu hình:
- Đã import file phụ đề (.srt/.ass/.vtt): dùng luôn.
- Ngược lại: OCR phụ đề gắn cứng qua Gemini Web (montage vision).

Output: segments (list[Segment]), original_srt (đường dẫn)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from vicdub.core.module_base import BaseModule, ModuleError
from vicdub.utils.ffmpeg_utils import FFmpeg, FFmpegError
from vicdub.utils.subtitles import Segment, load_subtitle_file, write_srt


class SubtitleModule(BaseModule):
    """Tách phụ đề: import file có sẵn hoặc OCR gắn cứng qua Gemini Web."""

    name = "Tách phụ đề"

    def run(self, data: dict[str, Any]) -> dict[str, Any]:
        project = data["project"]
        subtitle_path = data.get("subtitle_path", "")

        mode = "ocr"
        try:
            mode = str(project.get_meta("subtitle_extraction_mode", "ocr") or "ocr")
        except Exception:  # noqa: BLE001 - giữ tương thích project/mock cũ
            mode = "ocr"
        subtitle_source = getattr(data["config"], "subtitle_source", "drive")
        if mode == "audio":
            subtitle_source = "voice"
        elif mode == "remote_ocr":
            subtitle_source = "remote_ocr"

        if subtitle_path:
            segments = self._from_file(subtitle_path)
        elif subtitle_source == "voice":
            # Nhận diện lời thoại (Qwen3-ASR cloud) -> phụ đề gốc tiếng nguồn.
            segments = self._from_asr(data)
        elif subtitle_source == "remote_ocr":
            segments = self._from_drive_ocr(data, remote=True)
        else:
            # Nhận diện video chỉ dùng pool Google Drive OCR. Trình duyệt được
            # giữ riêng cho chức năng dịch, không còn là nguồn OCR dự phòng.
            segments = self._from_drive_ocr(data)

        if not segments:
            raise ModuleError("Không thu được dòng phụ đề nào.")

        # One broken OCR run must not destroy a good result already in project.
        # Importing a subtitle file is explicit, so it is exempt from this guard.
        previous = project.load_segments()
        if (not subtitle_path and len(previous) >= 10
                and len(segments) < max(3, int(len(previous) * 0.35))):
            raise ModuleError(
                f"Kết quả mới chỉ có {len(segments)} dòng, thấp bất thường so với "
                f"{len(previous)} dòng đang có. Đã giữ nguyên phụ đề cũ."
            )

        # Lưu original.srt vào project.
        original_srt = Path(project.root) / "subtitles" / "original.srt"
        write_srt(segments, original_srt)
        project.save_segments(segments)

        self.report(100, f"Có {len(segments)} dòng phụ đề")
        return {"segments": segments, "original_srt": str(original_srt)}

    # ---------- Import file ----------

    def _from_file(self, subtitle_path: str) -> list[Segment]:
        self.report(20, f"Đang đọc phụ đề: {Path(subtitle_path).name}")
        if not Path(subtitle_path).exists():
            raise ModuleError(f"File phụ đề không tồn tại: {subtitle_path}")
        try:
            return load_subtitle_file(subtitle_path)
        except ValueError as exc:
            raise ModuleError(str(exc)) from exc

    # ---------- Nhận diện lời thoại (Qwen3-ASR cloud) ----------

    def _from_asr(self, data: dict[str, Any]) -> list[Segment]:
        """Nhận diện lời thoại thành phụ đề gốc bằng dịch vụ Qwen3-ASR."""
        video_path = data.get("video_path", "")
        if not video_path or not Path(video_path).exists():
            raise ModuleError("Chưa có video để nhận diện lời thoại.")

        from vicdub.utils.asr_segments import (  # noqa: PLC0415
            apply_glossary, group_words_by_spans, load_glossary,
            scored_boundary_spans, validate_and_repair_segments,
        )

        config = data["config"]
        cancelled = lambda: (self._cancel_event is not None and self._cancel_event.is_set())
        try:
            provider = str(data["project"].get_meta(
                "subtitle_audio_provider", getattr(config, "asr_provider", "qwen")
            ) or "qwen").lower()
        except Exception:  # noqa: BLE001 - tương thích project/mock cũ
            provider = str(getattr(config, "asr_provider", "qwen") or "qwen").lower()
        if provider == "whisper_server":
            from vicdub.api.whisper_asr_client import (  # noqa: PLC0415
                WhisperAsrError, transcribe_video_with_spans,
            )
            try:
                transcript = transcribe_video_with_spans(
                    video_path, config, report=self.report, is_cancelled=cancelled,
                )
            except WhisperAsrError as exc:
                raise ModuleError(str(exc)) from exc
            words = transcript.words
            speech_spans = transcript.speech_spans
            segment_spans = list(getattr(transcript, "segment_spans", []) or [])
        else:
            from vicdub.api.qwen_asr_client import (  # noqa: PLC0415
                AsrError, transcribe_video_with_spans,
            )
            try:
                transcript = transcribe_video_with_spans(
                    video_path, config, report=self.report, is_cancelled=cancelled,
                )
            except AsrError as exc:
                raise ModuleError(str(exc)) from exc
            words = transcript.words
            speech_spans = transcript.speech_spans
            segment_spans = []

        if not words:
            raise ModuleError("Không nhận diện được lời thoại nào trong video.")

        group_max_chars = int(getattr(config, "asr_max_chars", 16))
        group_soft_chars = int(getattr(config, "asr_soft_chars", 2))
        group_max_duration = float(getattr(config, "asr_max_duration", 5.0))
        if provider == "whisper_server" and speech_spans:
            fused = scored_boundary_spans(words, speech_spans, segment_spans)
            expected = max(1, len(speech_spans) - 1)
            accepted = max(0, len(fused) - 1)
            if fused and accepted >= max(2, int(expected * 0.55)):
                speech_spans = fused
                self.report(
                    99,
                    f"Đã chốt {max(0, len(fused) - 1)} biên câu từ "
                    "Silero + timestamp + segment Whisper.",
                )
            else:
                # Server may return VAD on the original timeline but Whisper
                # words/segments on a packed timeline. Never let contradictory
                # clocks collapse a good subtitle result.
                speech_spans = []
                self.report(
                    99,
                    "Timestamp Silero/Whisper chưa đồng bộ; dùng bộ chia câu "
                    "tương thích để bảo toàn nội dung.",
                )
        if provider == "whisper_server" and not speech_spans:
            # Server đã trả timestamp thật từng từ/ký tự. Với thoại Trung,
            # 16 chữ vẫn gộp 2-3 câu; 6 chữ khớp gần số cue OCR độc lập mà
            # không tạo thêm mảnh một chữ.
            group_max_chars = min(group_max_chars, 6)
            group_soft_chars = min(group_soft_chars, 6)
            group_max_duration = min(group_max_duration, 3.5)

        segments = group_words_by_spans(
            words,
            speech_spans,
            max_chars=group_max_chars,
            soft_chars=group_soft_chars,
            gap_split=float(getattr(config, "asr_gap_split", 0.35)),
            max_duration=group_max_duration,
        )
        glossary_path = str(getattr(config, "asr_glossary", "") or "").strip()
        if glossary_path:
            segments = apply_glossary(segments, load_glossary(glossary_path))
        segments, repair = validate_and_repair_segments(
            segments,
            min_duration=float(getattr(config, "asr_min_cue_duration", 0.35)),
            tiny_duration=float(getattr(config, "asr_tiny_cue_duration", 0.12)),
            merge_gap=float(getattr(config, "asr_tiny_merge_gap", 0.08)),
            max_chars=group_max_chars,
        )
        changed = sum(value for key, value in repair.items() if key != "suspicious")
        self.report(
            99,
            f"Kiểm tra cuối: sửa {changed} lỗi cơ học; "
            f"còn {repair['suspicious']} dòng cần xem lại",
        )
        return segments

    # ---------- OCR gắn cứng qua Google Drive ----------

    def _from_drive_ocr(self, data: dict[str, Any], remote: bool = False) -> list[Segment]:
        """OCR phụ đề gắn cứng bằng Google Drive (OCR chính thức, hợp ToS)."""
        video_path = data.get("video_path", "")
        if not video_path:
            raise ModuleError("Chưa có video để nhận diện phụ đề.")
        if not Path(video_path).exists():
            raise ModuleError(f"Video không tồn tại: {video_path}")

        from vicdub.api.drive_ocr_client import (  # noqa: PLC0415
            DriveOcrClient, DriveOcrError, classify_drive_error,
        )
        from vicdub.utils.llm_ocr_subtitles import (  # noqa: PLC0415
            DEFAULT_REGION as LLM_REGION, llm_ocr_video,
        )

        config = data["config"]
        project = data["project"]
        accounts = [] if remote else config.enabled_drive_accounts()
        creds = config.resolve_drive_credentials()
        if not remote and not creds and not any(a.get("credentials_path") for a in accounts):
            raise ModuleError(
                "Chưa có file kết nối cho nguồn nhận diện chính. Vào tab Cài đặt "
                "và kết nối tài khoản xử lý trước."
            )
        if not remote and not accounts:
            raise ModuleError(
                "Chưa kết nối tài khoản nhận diện. Vào tab Cài đặt và đăng nhập "
                "tài khoản xử lý trước."
            )

        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or LLM_REGION
        ))
        if len(region) != 4:
            region = LLM_REGION
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )

        self.report(3, "Đang chuẩn bị dữ liệu nhận diện phụ đề...")
        clients = []
        account_labels: list[str] = []
        if remote:
            from vicdub.api.remote_ocr_client import RemoteOcrClient  # noqa: PLC0415
            # Chỉ tạo một adapter cho một máy chủ. _StreamingMontageOcr sẽ nhân
            # số worker theo ``remote_ocr_parallel`` từ adapter đó; nếu tạo nhiều
            # adapter cùng client_id thì server coi là một máy bắn dồn request và
            # trả client_rate_limited liên tục.
            remote_workers = max(
                1, int(getattr(config, "remote_ocr_parallel", 5) or 5)
            )
            clients = [RemoteOcrClient(config)]
            connection = clients[0].check_connection()
            health = connection.get("health", {})
            clients[0].apply_server_capabilities(health)
            account_labels = [f"Luong may chu {index}" for index in range(1, remote_workers + 1)]
            self.report(3, "Máy chủ sẵn sàng · nhận diện đồng thời trong lúc quét.")
        for index, account in enumerate(accounts):
            label = str(account.get("email") or account.get("name") or f"Tài khoản {index + 1}")
            try:
                client = DriveOcrClient(
                    credentials_path=account.get("credentials_path") or creds,
                    token_path=account["token_path"],
                    folder_id=account.get("folder_id", ""),
                    report=None,
                )
                try:
                    # Refresh token before spending time scanning the video. Only
                    # permanent account errors remove a slot; network errors may recover.
                    email = client.account_email()
                    if email:
                        label = email
                except Exception as exc:  # noqa: BLE001
                    if classify_drive_error(exc) == "permanent_account":
                        client.close()
                        self.report(3, f"Bỏ {label}: kết nối đã hết hiệu lực.")
                        self.logger.warning("Tài khoản OCR %s bị loại khi kiểm tra: %s", label, exc)
                        continue
                    self.logger.warning("Chưa kiểm tra được tài khoản OCR %s: %s", label, exc)
                clients.append(client)
                account_labels.append(label)
            except (DriveOcrError, OSError, KeyError) as exc:
                self.report(3, f"Bỏ {label}: thiếu hoặc sai tệp kết nối.")
                self.logger.warning("Không mở được tài khoản OCR %s: %s", label, exc)
        if not remote and not clients:
            raise ModuleError(
                "Không còn tài khoản nhận diện hoạt động. Hãy thay/kết nối tài khoản; "
                "lần chạy sau sẽ tiếp tục từ checkpoint đã lưu."
            )
        if not remote:
            self.report(
                3,
                f"Có {len(clients)}/{len(accounts)} tài khoản sẵn sàng: "
                + ", ".join(account_labels),
            )

        vsf_exe = config.resolve_vsf_exe()
        try:
            if vsf_exe and not remote:
                # Đường CHÍNH XÁC (giống AIO): VideoSubFinder phát hiện + timing,
                # Drive OCR đọc chữ. Không dedup/gộp -> hết sót/lặp/lệch.
                from vicdub.utils.vsf_ocr import vsf_ocr_video  # noqa: PLC0415
                self.report(3, "Đang phân tích phụ đề trong video...")
                segments = vsf_ocr_video(
                    video_path, vsf_exe, clients[0], region=region,
                    output_dir=str(Path(project.root) / ".vsf"),
                    batch=int(getattr(config, "llm_ocr_batch", 20)),
                    lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                    num_threads=int(getattr(config, "vsf_num_threads", 4)),
                    use_cuda=bool(getattr(config, "vsf_use_cuda", False)),
                    progress=self.report,
                    cancelled=lambda: (self._cancel_event is not None
                                       and self._cancel_event.is_set()),
                )
            else:
                # Đường CHÍNH (mới): detector streaming + state machine (bám nét chữ
                # trắng, gap-tolerance) -> câu sạch, timing khít; OCR từng ảnh riêng
                # (không montage -> không dính chữ). Hết sót/lặp/lệch hơn hẳn cách cũ.
                from vicdub.utils.detect_ocr import (  # noqa: PLC0415
                    OcrQualityError, detect_ocr_video,
                )
                from vicdub.utils.sub_detector import effective_detector_fps  # noqa: PLC0415
                from vicdub.utils.video_frames import region_to_crop  # noqa: PLC0415
                self.report(3, "Đang phân tích phụ đề trong video...")
                width, height = ffmpeg.video_size(video_path)
                duration = ffmpeg.duration(video_path)
                source_fps = ffmpeg.video_fps(video_path)
                scan_mode = str(
                    project.get_meta(
                        "ocr_scan_mode",
                        "fast",
                    ) or "fast"
                ).strip().lower()
                if scan_mode not in {"fast", "stable", "standard"}:
                    scan_mode = "fast"
                if scan_mode == "standard":
                    requested_fps = 25.0
                    mode_label = "Chuẩn"
                elif scan_mode == "stable":
                    requested_fps = 20.0
                    mode_label = "Ổn định"
                else:
                    requested_fps = 18.0
                    mode_label = "Nhanh"
                scan_fps = effective_detector_fps(source_fps, requested_fps)
                self.report(
                    4,
                    f"Quét {scan_fps:g} fps ({mode_label})"
                    + (" (đủ frame gốc)" if source_fps > 0 and scan_fps >= source_fps else ""),
                )
                # Expand the selected strip vertically. A box drawn tightly on one
                # frame can clip a different font/line in subsequent frames.
                # Tôn trọng đúng vùng người dùng khoanh. Nới ngầm thêm 10% từng
                # kéo nhiều nền động vào mask, làm loãng thay đổi glyph và nuốt
                # các câu thoại liên tiếp có cùng vị trí.
                crop = region_to_crop(region, width, height)
                # Có Vision API key -> đọc chữ bằng Cloud Vision (nhanh hơn nhiều và
                # ánh xạ câu bằng toạ độ pixel). Không có key -> Drive OCR như cũ.
                vision_client = None
                vision_key = str(getattr(config, "vision_api_key", "") or "").strip()
                if vision_key and not remote:
                    from vicdub.api.vision_ocr_client import (  # noqa: PLC0415
                        VisionOcrClient, VisionOcrError,
                    )
                    try:
                        vision_client = VisionOcrClient(vision_key)
                        self.report(4, "Đang dùng chế độ nhận diện nhanh.")
                    except VisionOcrError as exc:
                        self.logger.warning("Chế độ nhận diện nhanh không dùng được (%s); chuyển chế độ ổn định.", exc)
                try:
                    picked_colors = None
                    if project.get_meta("ocr_color_filter_enabled", "0") == "1":
                        try:
                            loaded_colors = json.loads(
                                project.get_meta("ocr_picked_colors", "[]")
                            )
                            if isinstance(loaded_colors, list):
                                picked_colors = loaded_colors
                        except (TypeError, ValueError, json.JSONDecodeError):
                            self.logger.warning("Bỏ cấu hình màu OCR hỏng của dự án.")
                    base_checkpoint = Path(project.root) / ".drive_ocr_checkpoint"
                    ocr_batch = int(getattr(
                        config,
                        "remote_ocr_batch" if remote else "llm_ocr_batch",
                        20,
                    ))
                    ocr_lang_hint = getattr(config, "llm_ocr_lang_hint", "")
                    color_tolerance = int(project.get_meta(
                        "ocr_color_tolerance",
                        str(getattr(config, "ocr_color_tolerance", 45)),
                    ))
                    cancel_cb = lambda: (self._cancel_event is not None
                                         and self._cancel_event.is_set())

                    segments = detect_ocr_video(
                        video_path, config.ffmpeg_path, clients, crop,
                        vision_client=vision_client,
                        scan_fps=scan_fps,
                        batch=ocr_batch,
                        lang_hint=ocr_lang_hint,
                        duration=duration,
                        # Recall-first: m?t frame h?p l? v?n l? ?ng vi?n. Ch? OCR
                        # m?i c? quy?n k?t lu?n v?ng ?? kh?ng ch?a ph? ??.
                        min_duration=0.0,
                        progress=self.report,
                        cancelled=cancel_cb,
                        checkpoint_dir=str(base_checkpoint),
                        account_labels=account_labels,
                        picked_colors=picked_colors,
                        color_tolerance=color_tolerance,
                        stable_only=(scan_mode == "stable"),
                        fast_postprocess=(scan_mode in {"fast", "stable"}),
                    )
                except OcrQualityError as exc:
                    # This is invalid OCR input, not a detector crash. The legacy
                    # path would reuse the same bad region and risk bad overwrite.
                    raise ModuleError(str(exc)) from exc
                except Exception as exc:  # noqa: BLE001 - detector lỗi -> về cách cũ
                    if remote:
                        raise ModuleError(str(exc)) from exc
                    self.logger.warning("Bộ phân tích mới lỗi (%s); chuyển phương án dự phòng.", exc)
                    self.report(3, "Đang chuyển sang phương án nhận diện dự phòng...")
                    segments = llm_ocr_video(
                        video_path, ffmpeg,
                        clients[0] if len(clients) == 1 else clients,
                        region=region,
                        fps=float(getattr(config, "llm_ocr_fps", 8.0)),
                        batch=int(getattr(config, "llm_ocr_batch", 18)),
                        sim_threshold=max(0.95, float(getattr(config, "ocr_sim_threshold", 0.7))),
                        min_duration=float(getattr(config, "ocr_min_duration", 0.12)),
                        max_merge_gap=0.08,
                        lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                        progress=self.report,
                        cancelled=lambda: (self._cancel_event is not None
                                           and self._cancel_event.is_set()),
                        checkpoint_dir=str(Path(project.root) / ".ocr_checkpoint"),
                        engine_label="Nhận diện phụ đề",
                    )
        except RuntimeError as exc:
            raise ModuleError(str(exc)) from exc
        except FFmpegError as exc:
            raise ModuleError(f"Lỗi khi trích khung hình phụ đề:\n{exc}") from exc
        finally:
            for client in clients:
                client.close()
            if 'vision_client' in locals() and vision_client is not None:
                close = getattr(vision_client, "close", None)
                if callable(close):
                    close()

        if not segments:
            raise ModuleError(
                "Không đọc được dòng phụ đề nào. Kiểm tra lại vùng sub, "
                "hoặc import file phụ đề có sẵn."
            )
        return segments

    # ---------- OCR gắn cứng qua Gemini Web ----------

    def _from_gemini_web(self, data: dict[str, Any]) -> list[Segment]:
        """OCR phụ đề gắn cứng qua Gemini Web, dùng profile Chrome lâu dài."""
        video_path = data.get("video_path", "")
        if not video_path:
            raise ModuleError("Chưa có video để nhận diện phụ đề.")
        if not Path(video_path).exists():
            raise ModuleError(f"Video không tồn tại: {video_path}")

        from vicdub.api.gemini_web_client import GeminiWebClient  # noqa: PLC0415
        from vicdub.utils.llm_ocr_subtitles import (  # noqa: PLC0415
            DEFAULT_REGION as LLM_REGION, llm_ocr_video,
        )

        config = data["config"]
        project = data["project"]
        region = tuple(project.get_ocr_region(
            getattr(config, "ocr_region", None) or LLM_REGION
        ))
        if len(region) != 4:
            region = LLM_REGION
        ffmpeg = FFmpeg(
            config.ffmpeg_path, config.ffprobe_path,
            cancel_event=self._cancel_event,
            timeout_seconds=getattr(config, "ffmpeg_timeout_seconds", 21600),
        )

        self.report(3, "Đang chuẩn bị dữ liệu nhận diện phụ đề...")
        profile_count = max(1, int(getattr(config, "gemini_web_profiles", 1)))
        profile_count = min(profile_count, 2)
        mode_note = "ổn định" if profile_count == 1 else "song song"
        self.report(4, f"Nhận diện bằng {profile_count} phiên ({mode_note}).")
        web_clients = [
            GeminiWebClient(
                config.data_dir,
                # llm_ocr_video owns the 0-100 pipeline progress. GeminiWebClient
                # logs its browser state separately so it does not reset UI progress
                # back to 4-5% while OCR is already in the Gemini batch phase.
                report=None,
                login_timeout=getattr(config, "gemini_web_login_timeout", 300),
                # Phản hồi bình thường mất 10-25 giây. Không để một request web
                # im lặng giữ cả phim ở 50% suốt 4 phút trước khi retry.
                response_timeout=min(
                    90, int(getattr(config, "gemini_web_response_timeout", 180))
                ),
                profile_name=str(idx + 1),
            )
            for idx in range(profile_count)
        ]
        gemini_arg = web_clients[0] if len(web_clients) == 1 else web_clients
        try:
            segments = llm_ocr_video(
                video_path,
                ffmpeg,
                gemini_arg,
                region=region,
                fps=float(getattr(config, "llm_ocr_fps", 2.0)),
                batch=int(getattr(config, "llm_ocr_batch", 18)),
                dedup_threshold=float(getattr(config, "ocr_dedup_threshold", 0.006)),
                # Fast-dialogue hard-sub should prefer duplicate candidates over
                # missing subtitles. Keep Web OCR merging conservative.
                sim_threshold=max(0.95, float(getattr(config, "ocr_sim_threshold", 0.7))),
                min_duration=float(getattr(config, "ocr_min_duration", 0.12)),
                max_merge_gap=0.08,
                lang_hint=getattr(config, "llm_ocr_lang_hint", ""),
                progress=self.report,
                cancelled=lambda: (self._cancel_event is not None
                                   and self._cancel_event.is_set()),
                checkpoint_dir=str(Path(project.root) / ".ocr_checkpoint"),
                engine_label="Nhận diện phụ đề",
            )
        except RuntimeError as exc:
            raise ModuleError(str(exc)) from exc
        except FFmpegError as exc:
            raise ModuleError(f"Lỗi khi trích khung hình phụ đề:\n{exc}") from exc
        finally:
            for client in web_clients:
                client.close()

        if not segments:
            raise ModuleError(
                "Không đọc được dòng phụ đề nào. Kiểm tra lại vùng "
                "sub, hoặc import file phụ đề có sẵn."
            )
        return segments

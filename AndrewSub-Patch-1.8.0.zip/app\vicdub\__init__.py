﻿"""AndrewSub - Phần mềm xử lý phụ đề và lồng tiếng."""

__version__ = "1.8.0"
APP_NAME = "AndrewSub"

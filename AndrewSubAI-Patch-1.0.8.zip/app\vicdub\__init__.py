"""VICDub AI - Phần mềm lồng tiếng video bằng AI."""

__version__ = "1.0.8"
APP_NAME = "VICDub AI"

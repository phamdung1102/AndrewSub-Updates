"""Tách phụ đề = detector streaming (sub_detector) + Drive OCR đọc chữ.

Đường CHÍNH XÁC thay cho llm_ocr_video: state machine cho mốc khít + hết vết tách
giả (gap-tolerance), OCR ảnh đại diện nét nhất. KHÔNG dedup/gộp sau vì detector đã
cho câu sạch.
"""

from __future__ import annotations

import logging
import hashlib
import json
import os
import queue
import re
import threading
import time
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable

from concurrent.futures import ThreadPoolExecutor

from vicdub.api.vision_ocr_client import PANELS_PER_MONTAGE as VISION_PANELS
from vicdub.utils.subtitles import Segment
from vicdub.utils.sub_detector import detect_subtitles, stroke_overlap

logger = logging.getLogger(__name__)

ProgressFn = Callable[[int, str], None]
CancelFn = Callable[[], bool]


class _ResultCallbackError(RuntimeError):
    """Lỗi lưu kết quả phải nổi lên UI, không được hiểu nhầm là lỗi Drive OCR."""


class OcrQualityError(RuntimeError):
    """Kết quả OCR bất thường; không được fallback rồi ghi đè dữ liệu tốt."""


_MIXED_PREFIX_RE = re.compile(r"^[A-Za-z]{1,12}\s+[\u3400-\u9fff]")
_CJK_RE = re.compile(r"[\u3400-\u9fff]")
_FOREIGN_ALPHA_RE = re.compile(
    r"[A-Za-zÀ-ÖØ-öø-ÿ\u0400-\u052f]+(?:[ '\-]+[A-Za-zÀ-ÖØ-öø-ÿ\u0400-\u052f]+)*"
)


def _has_suspicious_latin_prefix(text: str) -> bool:
    """Drive montage sometimes leaks a damaged header before CJK text."""
    return bool(_MIXED_PREFIX_RE.match((text or "").strip()))


def _is_chinese_hint(lang_hint: str) -> bool:
    hint = (lang_hint or "").strip().lower()
    return any(token in hint for token in ("trung", "chinese", "zh", "中文", "汉语", "漢語"))


def _is_chinese_timeline(texts: list[str], lang_hint: str) -> bool:
    """Use the explicit source language, or infer it from a mostly-CJK result set."""
    if _is_chinese_hint(lang_hint):
        return True
    nonempty = [value for value in texts if (value or "").strip()]
    if len(nonempty) < 3:
        return False
    return sum(bool(_CJK_RE.search(value)) for value in nonempty) / len(nonempty) >= 0.60


def _strip_foreign_noise_from_chinese(text: str) -> str:
    """Remove unstable alphabetic OCR fragments from an otherwise CJK line.

    This deliberately runs only when the selected source language is Chinese.
    Digits and normal subtitle punctuation are preserved. Alphabetic-only rows
    are handled separately after one isolated rescue OCR pass.
    """
    value = " ".join((text or "").split()).strip()
    if not _CJK_RE.search(value):
        return value
    value = _FOREIGN_ALPHA_RE.sub("", value)
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"\s+([，。！？、；：,.!?;:])", r"\1", value)
    return value.strip(" -_|/\\,.;:，。；：")


def _normal_text(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u3400-\u9fff]+", "", (text or "").lower())


def _text_similarity(first: str, second: str) -> float:
    a, b = _normal_text(first), _normal_text(second)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def _choose_consensus_text(values: list[str]) -> str:
    """Choose the medoid OCR result, not the longest (which often contains junk)."""
    # Keep repetitions: three neighbouring reads A/B/B must vote for B. Removing
    # duplicates here would turn that useful majority into an arbitrary tie.
    candidates = [value.strip() for value in values if value.strip()]
    if not candidates:
        return ""
    if len(candidates) == 1:
        return candidates[0]

    def score(candidate: str) -> tuple[float, int]:
        agreement = sum(_text_similarity(candidate, other) for other in candidates)
        return agreement / len(candidates), len(_normal_text(candidate))

    return max(candidates, key=score)


def _postprocess_ocr_segments(
    subs, texts: list[str], lang_hint: str, *, max_gap: float = 0.40,
    fuzzy_threshold: float = 0.82, min_stroke_overlap: float = 0.45,
) -> tuple[list[Segment], int, int]:
    """Language cleanup plus safe 2–3-neighbour temporal consensus.

    Exact adjacent duplicates are always joined. Fuzzy variants are joined only
    when their timings are continuous *and* the subtitle strokes overlap, so a
    real repeated line that disappeared and came back remains separate.
    """
    chinese = _is_chinese_timeline(texts, lang_hint)
    rows = []
    removed_foreign = 0
    for sub, raw_text in zip(subs, texts):
        text = " ".join((raw_text or "").split()).strip()
        if not text:
            continue
        if chinese:
            cleaned = _strip_foreign_noise_from_chinese(text)
            if cleaned != text:
                removed_foreign += 1
            text = cleaned
            # After the isolated rescue pass, an alphabetic-only result in a
            # Chinese source is OCR/background noise, not a usable subtitle.
            if not _CJK_RE.search(text) and _FOREIGN_ALPHA_RE.search(text):
                removed_foreign += 1
                continue
        if text:
            rows.append({"start": sub.start, "end": sub.end, "texts": [text],
                         "images": [sub.image]})

    groups = []
    merged_count = 0
    for row in rows:
        previous = groups[-1] if groups else None
        should_merge = False
        if previous is not None and row["start"] - previous["end"] <= max_gap:
            nearby_texts = previous["texts"][-3:]
            similarity = max(_text_similarity(row["texts"][0], value)
                             for value in nearby_texts)
            exact = any(_normal_text(row["texts"][0]) == _normal_text(value)
                        for value in nearby_texts)
            overlap = max(
                (stroke_overlap(image, row["images"][0])
                 for image in previous["images"][-3:]),
                default=0.0,
            )
            should_merge = exact or (
                similarity >= fuzzy_threshold and overlap >= min_stroke_overlap
            )
        if should_merge:
            previous["end"] = max(previous["end"], row["end"])
            previous["texts"].extend(row["texts"])
            previous["images"].extend(row["images"])
            merged_count += 1
        else:
            groups.append(row)

    segments = [
        Segment(
            line=index,
            start=round(group["start"], 3),
            end=round(group["end"], 3),
            text=_choose_consensus_text(group["texts"]),
        )
        for index, group in enumerate(groups, 1)
    ]
    return segments, merged_count, removed_foreign


def _emit_result(callback, index: int, text: str) -> None:
    if not callback:
        return
    try:
        callback(index, text)
    except Exception as exc:  # noqa: BLE001 - bọc để pool không nuốt lỗi database
        raise _ResultCallbackError(f"Không lưu được kết quả OCR #{index + 1}: {exc}") from exc


def _ocr_each_image(clients, images, lang_hint, report, is_cancelled,
                    checkpoint_dir: str | None = None,
                    max_attempts: int = 3,
                    on_result: Callable[[int, str], None] | None = None,
                    ) -> tuple[list[str], list[int]]:
    """Pool động: một worker/tài khoản, retry chéo và checkpoint từng ảnh."""
    if not isinstance(clients, (list, tuple)):
        clients = [clients]
    clients = [client for client in clients if getattr(client, "read_single", None)]
    if not clients:
        raise RuntimeError("Không có tài khoản xử lý nào hoạt động.")

    results = [""] * len(images)
    attempts = [0] * len(images)
    tried: list[set[int]] = [set() for _ in images]
    failures: list[str] = [""] * len(images)
    work: queue.Queue[int] = queue.Queue()
    lock = threading.Lock()
    done = 0
    started = time.monotonic()
    account_done = [0] * len(clients)
    account_errors = [0] * len(clients)

    checkpoint = Path(checkpoint_dir) if checkpoint_dir else None
    def image_fingerprint(image) -> str:
        raw = image if isinstance(image, (bytes, bytearray)) else image.tobytes()
        return hashlib.sha256(raw).hexdigest()[:16]

    digest = hashlib.sha256(
        "|".join(image_fingerprint(image) for image in images).encode()
    ).hexdigest()
    state_path = checkpoint / "state.json" if checkpoint else None
    if checkpoint:
        checkpoint.mkdir(parents=True, exist_ok=True)
        old_digest = ""
        try:
            old_digest = json.loads(state_path.read_text(encoding="utf-8")).get("digest", "")
        except (OSError, ValueError, TypeError):
            pass
        if old_digest != digest:
            for path in checkpoint.glob("image_*.json"):
                path.unlink(missing_ok=True)
            state_path.write_text(json.dumps({"digest": digest, "count": len(images)}), encoding="utf-8")

    def save(index: int, status: str) -> None:
        if not checkpoint:
            return
        payload = {
            "image_id": index, "status": status, "text": results[index],
            "attempts": attempts[index], "accounts_tried": sorted(tried[index]),
            "last_error": failures[index],
        }
        path = checkpoint / f"image_{index:06d}.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, path)

    # Nạp lại ảnh đã OCR thành công; ảnh lỗi/rỗng được đưa lại hàng đợi.
    for i in range(len(images)):
        path = checkpoint / f"image_{i:06d}.json" if checkpoint else None
        if path and path.exists():
            try:
                saved = json.loads(path.read_text(encoding="utf-8"))
                if saved.get("status") == "done" and str(saved.get("text", "")).strip():
                    results[i] = str(saved["text"]).strip()
                    done += 1
                    _emit_result(on_result, i, results[i])
                    continue
            except (OSError, ValueError, TypeError):
                pass
        work.put(i)

    def progress_message() -> str:
        elapsed = max(0.001, time.monotonic() - started)
        if done < min(8, len(images)):
            stats = ", ".join(f"TK{i + 1}:{n}" for i, n in enumerate(account_done))
            return f"OCR {done}/{len(images)} câu — đang đo tốc độ ({stats})"
        newly_done = max(1, done)
        remaining = max(0, len(images) - done)
        eta_minutes = remaining * elapsed / newly_done / 60.0
        stats = ", ".join(f"TK{i + 1}:{n}" for i, n in enumerate(account_done))
        return f"OCR {done}/{len(images)} câu — còn khoảng {eta_minutes:.1f} phút ({stats})"

    def worker(account_index: int) -> None:
        nonlocal done
        client = clients[account_index]
        consecutive_account_errors = 0
        while not is_cancelled():
            try:
                index = work.get(timeout=0.2)
            except queue.Empty:
                with lock:
                    if done >= len(images):
                        return
                continue
            with lock:
                if results[index] or attempts[index] >= max_attempts:
                    continue
                attempts[index] += 1
                tried[index].add(account_index)
            try:
                text = str(client.read_single(images[index], lang_hint) or "").strip()
                if not text:
                    raise ValueError("OCR trả kết quả rỗng")
                with lock:
                    results[index] = text
                    account_done[account_index] += 1
                    done += 1
                    consecutive_account_errors = 0
                    save(index, "done")
                    _emit_result(on_result, index, text)
                    report(40 + int(58 * done / max(1, len(images))), progress_message())
            except _ResultCallbackError:
                raise
            except Exception as exc:  # noqa: BLE001
                message = str(exc)
                lower_message = message.lower()
                backoff = 0.0
                with lock:
                    failures[index] = message
                    account_errors[account_index] += 1
                    account_fault = any(token in message.lower() for token in (
                        "401", "invalid_grant", "unauthorized", "403", "permission",
                        "insufficient", "token has been expired", "revoked",
                    ))
                    consecutive_account_errors = consecutive_account_errors + 1 if account_fault else 0
                    if "429" in lower_message or "ratelimit" in lower_message:
                        backoff = min(8.0, 2.0 ** min(3, account_errors[account_index]))
                    if attempts[index] < max_attempts:
                        work.put(index)
                    else:
                        done += 1
                        save(index, "failed")
                        report(40 + int(58 * done / max(1, len(images))), progress_message())
                # Lỗi quyền/token lặp lại: loại riêng tài khoản, ảnh đã được trả hàng đợi.
                if consecutive_account_errors >= 2:
                    logger.warning("Loại tài khoản OCR %d trong tác vụ: %s", account_index + 1, message)
                    return
                if backoff:
                    report(
                        40 + int(58 * done / max(1, len(images))),
                        f"Tài khoản {account_index + 1} bị giới hạn; nghỉ {backoff:.0f}s — "
                        + progress_message(),
                    )
                    time.sleep(backoff)
                # Cho worker khác cơ hội nhận lượt retry, thay vì cùng tài khoản
                # giành lại ngay ảnh vừa thất bại.
                time.sleep(0.05)

    report(40, f"Đang đọc chữ bằng {len(clients)} tài khoản xử lý song song...")
    with ThreadPoolExecutor(max_workers=len(clients)) as executor:
        futures = [executor.submit(worker, i) for i in range(len(clients))]
        for future in futures:
            future.result()

    # Nếu worker hỏng rời hàng đợi, tài khoản khỏe đầu tiên vét nốt tuần tự.
    while not work.empty() and not is_cancelled():
        index = work.get_nowait()
        if results[index] or attempts[index] >= max_attempts:
            continue
        attempts[index] += 1
        try:
            results[index] = str(clients[0].read_single(images[index], lang_hint) or "").strip()
            if not results[index]:
                raise ValueError("OCR trả kết quả rỗng")
            save(index, "done")
            _emit_result(on_result, index, results[index])
        except _ResultCallbackError:
            raise
        except Exception as exc:  # noqa: BLE001
            failures[index] = str(exc)
            if attempts[index] < max_attempts:
                work.put(index)
            else:
                save(index, "failed")

    failed = [i for i, value in enumerate(results) if not value]
    return results, failed


def _ocr_montage_pool(clients, images, lang_hint, report,
                       batch_size: int = 8, is_cancelled=None,
                       on_result: Callable[[int, str], None] | None = None,
                       checkpoint_dir: str | None = None,
                       ) -> tuple[list[str], list[int]]:
    """OCR nhanh cho Repair Mode: montage nhỏ, một worker cho mỗi tài khoản."""
    if not isinstance(clients, (list, tuple)):
        clients = [clients]
    clients = list(clients)
    if not clients:
        raise RuntimeError("Không có tài khoản xử lý nào hoạt động.")
    results = [""] * len(images)
    checkpoint = Path(checkpoint_dir) if checkpoint_dir else None
    cached_empty: set[int] = set()

    def image_fingerprint(image) -> str:
        raw = image if isinstance(image, (bytes, bytearray)) else image.tobytes()
        return hashlib.sha256(raw).hexdigest()[:16]

    if checkpoint:
        checkpoint.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(
            "|".join(image_fingerprint(image) for image in images).encode()
        ).hexdigest()
        state_path = checkpoint / "state.json"
        old_digest = ""
        old_mode = ""
        try:
            old_state = json.loads(state_path.read_text(encoding="utf-8"))
            old_digest = old_state.get("digest", "")
            old_mode = old_state.get("mode", "")
        except (OSError, ValueError, TypeError):
            pass
        if old_digest != digest or old_mode != "montage-v2":
            for path in checkpoint.glob("image_*.json"):
                path.unlink(missing_ok=True)
            state_path.write_text(
                json.dumps({
                    "digest": digest, "count": len(images), "mode": "montage-v2",
                }), encoding="utf-8"
            )

    def save(index: int, text_value: str, status: str = "done") -> None:
        if not checkpoint or (status != "empty" and not text_value.strip()):
            return
        path = checkpoint / f"image_{index:06d}.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps({
            "image_id": index, "status": status, "text": text_value.strip(),
            "attempts": 1, "accounts_tried": [], "last_error": "",
        }, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, path)

    # Tận dụng được cả checkpoint từng ảnh của pipeline cũ. Chỉ các panel chưa
    # có chữ mới được ghép montage và gửi lên Drive.
    for index in range(len(images)):
        path = checkpoint / f"image_{index:06d}.json" if checkpoint else None
        if not path or not path.exists():
            continue
        try:
            saved = json.loads(path.read_text(encoding="utf-8"))
            if saved.get("status") == "done" and str(saved.get("text", "")).strip():
                results[index] = str(saved["text"]).strip()
                _emit_result(on_result, index, results[index])
            elif saved.get("status") == "empty":
                cached_empty.add(index)
        except (OSError, ValueError, TypeError):
            continue

    pending = [
        index for index, value in enumerate(results)
        if not value and index not in cached_empty
    ]
    batches = [
        pending[start:start + max(1, batch_size)]
        for start in range(0, len(pending), max(1, batch_size))
    ]
    if not batches:
        return results, [index for index, value in enumerate(results) if not value]
    work: queue.Queue[int] = queue.Queue()
    for batch_index in range(len(batches)):
        work.put(batch_index)
    attempts = [0] * len(batches)
    tried_accounts: list[set[int]] = [set() for _ in batches]
    lock = threading.Lock()
    done_batches = 0
    started = time.monotonic()

    def worker(account_index: int) -> None:
        nonlocal done_batches
        client = clients[account_index]
        while True:
            if is_cancelled and is_cancelled():
                return
            try:
                batch_index = work.get(timeout=0.2)
            except queue.Empty:
                with lock:
                    if done_batches >= len(batches):
                        return
                continue
            with lock:
                # Lỗi API mới chuyển batch sang tài khoản CHƯA thử. Các worker
                # vẫn đợi hàng đợi nên batch retry không rơi lại vào worker cũ.
                if (len(clients) > 1 and account_index in tried_accounts[batch_index]
                        and len(tried_accounts[batch_index]) < len(clients)):
                    work.put(batch_index)
                    retry_elsewhere = True
                else:
                    tried_accounts[batch_index].add(account_index)
                    attempts[batch_index] += 1
                    retry_elsewhere = False
            if retry_elsewhere:
                time.sleep(0.02)
                continue
            indexes = batches[batch_index]
            ids = [index + 1 for index in indexes]
            try:
                if is_cancelled and is_cancelled():
                    return
                montage = client.build_montage([images[index] for index in indexes], ids)
                parsed = client.read_subtitle_montage(montage, ids, lang_hint)
                completed: list[tuple[int, str]] = []
                with lock:
                    for index, panel_id in zip(indexes, ids):
                        results[index] = str(parsed.get(panel_id, "") or "").strip()
                        if results[index]:
                            save(index, results[index], "done")
                            completed.append((index, results[index]))
                        else:
                            # Complete montage marker + blank panel is a stable
                            # no-text result for this exact image digest. Cache it
                            # so reopening/rerunning does not spend requests again.
                            save(index, "", "empty")
                    done_batches += 1
                    elapsed = max(0.001, time.monotonic() - started)
                    remain = len(batches) - done_batches
                    eta = remain * elapsed / max(1, done_batches) / 60.0
                    report(
                        40 + int(50 * done_batches / len(batches)),
                        f"Lượt {done_batches}/{len(batches)} — còn khoảng {eta:.1f} phút",
                    )
                # Callback có thể ghi database nên chạy ngoài lock của pool.
                for index, value in completed:
                    _emit_result(on_result, index, value)
            except _ResultCallbackError:
                raise
            except Exception as exc:  # noqa: BLE001
                if (not (is_cancelled and is_cancelled())
                        and attempts[batch_index] < min(3, max(2, len(clients)))):
                    work.put(batch_index)
                else:
                    with lock:
                        done_batches += 1
                        logger.warning("Montage sửa OCR %d lỗi: %s", batch_index + 1, exc)

    with ThreadPoolExecutor(max_workers=len(clients)) as executor:
        futures = [executor.submit(worker, index) for index in range(len(clients))]
        for future in futures:
            future.result()
    failed = [index for index, value in enumerate(results) if not value]
    return results, failed


def _enhance_failed_image(image):
    """Phóng to/làm rõ ảnh khó trước lượt OCR cứu hộ."""
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps  # noqa: PLC0415

    source = image.convert("RGB") if hasattr(image, "convert") else image
    width, height = source.size
    enlarged = source.resize(
        (max(1, width * 2), max(1, height * 2)),
        resample=Image.Resampling.LANCZOS,
    )
    gray = ImageOps.grayscale(enlarged)
    gray = ImageOps.autocontrast(gray, cutoff=1)
    gray = ImageEnhance.Contrast(gray).enhance(1.45)
    gray = gray.filter(ImageFilter.UnsharpMask(radius=1.2, percent=170, threshold=2))
    return ImageOps.expand(gray.convert("RGB"), border=16, fill="white")


def _merge_exact_adjacent_segments(
    segments: list[Segment], max_gap: float = 0.35,
) -> tuple[list[Segment], int]:
    """Loại track flicker khi OCR trả text GIỐNG HỆT ở sát nhau.

    Không fuzzy/substring merge: hai câu khác dù chỉ một ký tự vẫn giữ riêng.
    """
    merged: list[Segment] = []
    removed = 0
    for segment in segments:
        previous = merged[-1] if merged else None
        gap = segment.start - previous.end if previous else float("inf")
        if (previous is not None and previous.text.strip() == segment.text.strip()
                and gap <= max_gap):
            previous.end = max(previous.end, segment.end)
            removed += 1
            continue
        merged.append(segment)
    for line, segment in enumerate(merged, 1):
        segment.line = line
    return merged, removed


def _count_text_bands(image, min_gap: int = 6) -> int:
    """Số dải chữ tách biệt theo chiều dọc trong một panel (dải cách <=min_gap
    hàng coi là một — sub 2 dòng sát nhau không bị đếm đôi)."""
    from vicdub.utils.sub_detector import _bright_stroke_mask  # noqa: PLC0415

    mask = _bright_stroke_mask(image)
    if not mask.any():
        return 0
    rows = mask.mean(axis=1)
    on = rows > max(0.01, 0.15 * float(rows.max()))
    bands = 0
    running = False
    gap = 0
    for value in on:
        if value:
            if not running:
                bands += 1
                running = True
            gap = 0
        elif running:
            gap += 1
            if gap > min_gap:
                running = False
                gap = 0
    return bands


def double_subtitle_warning(images, sample: int = 80) -> str:
    """Cảnh báo khi vùng OCR có vẻ trùm HAI BẢN phụ đề (video burn sub 2 lần).

    Đo thực tế: panel dính 2 bản (một bản bị xén/mờ) làm cả per-image OCR đọc ra
    rác ghép (vd '最新消息' -> '取新徧面 县新消自') — không heuristic hậu kỳ nào gỡ
    nổi. PHÁT HIỆN thì đáng tin (77% panel >=2 dải trên video lỗi thật, video sạch
    đa số 1 dải); tự CHỌN bản đúng thì không (đã thử 3 cách, tối đa 2/5) -> chỉ
    cảnh báo để người dùng khoanh lại vùng quanh MỘT bản sub.
    """
    picked = images[:: max(1, len(images) // sample)][:sample]
    if len(picked) < 10:
        return ""
    counts = [_count_text_bands(image) for image in picked]
    nonempty = [c for c in counts if c > 0]
    if not nonempty:
        return ""
    multi = sum(1 for c in nonempty if c >= 2)
    heavy = sum(1 for c in nonempty if c >= 3)
    if multi / len(nonempty) > 0.70 or heavy / len(nonempty) > 0.25:
        return (
            f"⚠ {multi}/{len(nonempty)} ảnh phụ đề chứa NHIỀU dải chữ — video này "
            "có thể burn phụ đề 2 lần (bản to + bản nhỏ) và vùng OCR đang trùm cả "
            "hai. OCR sẽ dễ ra chữ rác. Nên khoanh lại vùng OCR ôm sát MỘT bản "
            "phụ đề rõ nhất rồi tách lại."
        )
    return ""


def detect_ocr_video(
    video_path: str,
    ffmpeg_bin: str,
    client,
    crop: tuple[int, int, int, int],
    scan_fps: float = 12.0,
    batch: int = 20,
    lang_hint: str = "",
    duration: float = 0.0,
    min_duration: float = 0.12,
    progress: ProgressFn | None = None,
    cancelled: CancelFn | None = None,
    checkpoint_dir: str | None = None,
    vision_client=None,
) -> list[Segment]:
    """Phát hiện (streaming state machine) + OCR. Trả segments timing chuẩn.

    ``vision_client`` có -> đọc chữ bằng Cloud Vision (nhanh & chính xác hơn);
    None -> giữ nguyên đường Drive OCR cũ.
    """
    def report(pct: int, msg: str) -> None:
        if progress:
            progress(pct, msg)

    def is_cancelled() -> bool:
        return bool(cancelled and cancelled())

    subs = detect_subtitles(
        ffmpeg_bin, video_path, crop, scan_fps=scan_fps,
        report=report, is_cancelled=is_cancelled, duration=duration,
        min_duration=min_duration,
        # Recall-first cho hội thoại nhanh/chữ ngắn: chấp nhận cả mask thưa và
        # hẹp. OCR phía sau mới là nơi quyết định ảnh có thực sự chứa phụ đề.
        min_text_density=0.003,
        min_col_coverage=0.04,
    )
    if not subs:
        raise RuntimeError("Không phát hiện được câu phụ đề nào từ video.")

    # Tuyệt đối không gộp theo hình/nét trước OCR. Hai câu thoại cực ngắn có thể
    # cùng độ dài và bố cục nên phép so mask/stroke dễ nuốt mất một câu thật.
    # Chấp nhận gửi dư ảnh; sau OCR chỉ gộp khi text giống HỆT và nằm sát nhau.

    images = [s.image for s in subs]
    band_warning = double_subtitle_warning(images)
    if band_warning:
        logger.warning(band_warning)
        report(39, band_warning)
    if vision_client is not None:
        # Vision: 40 câu/ảnh, 16 ảnh/request -> video 2h chỉ ~3 lần gọi mạng (Drive
        # cần ~114). Ánh xạ câu bằng toạ độ pixel nên không cần marker/lọc script.
        report(40, f"Đang đọc {len(images)} câu (chế độ nhận diện nhanh)...")
        texts, failed = vision_client.read_images(
            images, lang_hint, report=report, is_cancelled=is_cancelled,
        )
    else:
        # Đo thực trên Drive: nâng 4 -> 20 panel/montage cho recall Y HỆT nhưng
        # giảm ~5x số API call và ~4x thời gian (marker @@@ vẫn sống 100%). Trước
        # đây tham số `batch` bị bỏ qua (kẹt cứng 4) nên OCR chậm vô ích.
        panels = max(1, int(batch))
        report(40, f"Đang đọc {len(images)} ảnh phụ đề "
                   f"({panels} câu mỗi lượt, nhiều tài khoản song song)...")
        texts, failed = _ocr_montage_pool(
            client, images, lang_hint, report, batch_size=panels,
            is_cancelled=is_cancelled, checkpoint_dir=checkpoint_dir,
        )

    # If the first complete pass reads almost nothing, retries only waste several
    # minutes on the same invalid crop/account state. Abort early and preserve the
    # project; a normal subtitle strip returns text for far more than 5% of panels.
    first_pass_count = sum(bool(value.strip()) for value in texts)
    if len(images) >= 20 and first_pass_count / len(images) < 0.05:
        raise OcrQualityError(
            f"Chỉ đọc được {first_pass_count}/{len(images)} ảnh ở lượt đầu. "
            "Đã dừng sớm vì vùng phụ đề hoặc dịch vụ nhận diện đang bất thường; "
            "kết quả cũ được giữ nguyên."
        )

    # Header OCR can occasionally leak fragments such as ``E 请`` or
    # ``ANCH 明白`` into a valid CJK panel. Re-read only those suspicious panels
    # without a montage/header. This also preserves legitimate mixed text: if the
    # source really says ``AI 技术``, individual OCR returns the same wording.
    chinese_source = _is_chinese_timeline(texts, lang_hint)
    suspicious = [
        index for index, value in enumerate(texts)
        if _has_suspicious_latin_prefix(value)
        or (chinese_source and _FOREIGN_ALPHA_RE.search(value or ""))
    ]
    if suspicious and not is_cancelled():
        report(97, f"Đang làm sạch {len(suspicious)} dòng nghi lẫn nhiễu...")
        mixed_dir = str(Path(checkpoint_dir) / "mixed") if checkpoint_dir else None
        cleaned, _ = _ocr_each_image(
            client, [_enhance_failed_image(images[index]) for index in suspicious], lang_hint,
            lambda _pct, _message: None, is_cancelled,
            checkpoint_dir=mixed_dir, max_attempts=1,
        )
        for source_index, clean_text in zip(suspicious, cleaned):
            clean_text = clean_text.strip()
            if clean_text:
                old_cjk = len(_CJK_RE.findall(texts[source_index]))
                new_cjk = len(_CJK_RE.findall(clean_text))
                # Prefer the isolated/enhanced retry when it recovers at least as
                # much CJK. Otherwise retain the original core for final cleanup.
                if not chinese_source or new_cjk >= old_cjk:
                    texts[source_index] = clean_text
            else:
                # The panel already contains valid CJK; if the isolated retry is
                # empty, remove only the detached Latin prefix instead of losing it.
                texts[source_index] = re.sub(
                    r"^[A-Za-z]{1,12}\s+(?=[\u3400-\u9fff])", "",
                    texts[source_index].strip(), count=1,
                )

    if failed:
        report(
            97,
            f"Giữ {len(failed)} ảnh chưa đọc được cho chế độ sửa; không tự gửi "
            "lại để tránh tốn lượt.",
        )

    # OCR đã chạy thành công nhưng panel vẫn rỗng thường là detector bắt nhầm
    # vùng sáng/logo, không phải lỗi tài khoản. Không tạo dòng phụ đề rác; lưu
    # ảnh + timestamp riêng để người dùng có thể kiểm tra/khôi phục khi cần.
    if checkpoint_dir:
        rejected_dir = Path(checkpoint_dir) / "rejected_images"
        rejected_dir.mkdir(parents=True, exist_ok=True)
        failed_set = set(failed)
        for index, image in enumerate(images):
            path = rejected_dir / f"image_{index:06d}.png"
            if index in failed_set:
                image.convert("RGB").save(path)
            else:
                path.unlink(missing_ok=True)
        manifest = [
            {"image_id": index, "start": subs[index].start, "end": subs[index].end,
             "image": f"rejected_images/image_{index:06d}.png"}
            for index in failed
        ]
        (Path(checkpoint_dir) / "rejected.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # Final pass sees the complete timeline: clean foreign OCR noise for a
    # Chinese source, then compare only the 2–3 immediately adjacent tracks.
    # Fuzzy joining additionally requires matching on-screen strokes.
    segments, duplicate_count, foreign_count = _postprocess_ocr_segments(
        subs, texts, lang_hint,
    )
    suffix = f"; loại {len(failed)} vùng không có chữ (đã lưu ảnh kiểm tra)" if failed else ""
    if duplicate_count:
        suffix += f"; gộp {duplicate_count} track lặp/gần giống"
    if foreign_count:
        suffix += f"; làm sạch {foreign_count} dòng lẫn ký tự"
    report(98, f"Xong: {len(segments)} dòng phụ đề{suffix}")
    if not segments:
        raise OcrQualityError("Không đọc được chữ từ ảnh phụ đề.")
    # A bad crop can make the detector follow motion/brightness while almost all
    # OCR panels contain no text. Never accept or silently fallback on that data.
    success_ratio = len(segments) / max(1, len(subs))
    if len(subs) >= 10 and (len(segments) < 3 or success_ratio < 0.20):
        raise OcrQualityError(
            f"Chỉ đọc được {len(segments)}/{len(subs)} ảnh "
            f"({success_ratio:.0%}). Vùng phụ đề có thể đang cắt mất chữ; "
            "kết quả này đã bị chặn và không được lưu."
        )
    return segments

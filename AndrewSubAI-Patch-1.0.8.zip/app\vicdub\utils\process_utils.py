"""Options that keep console subprocesses hidden behind the GUI on Windows."""

from __future__ import annotations

import os
import subprocess


CREATE_NO_WINDOW = (
    getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    if os.name == "nt"
    else 0
)


def hidden_process_kwargs() -> dict[str, int]:
    """Keyword arguments safe to expand into subprocess.run/Popen."""
    return {"creationflags": CREATE_NO_WINDOW} if CREATE_NO_WINDOW else {}
